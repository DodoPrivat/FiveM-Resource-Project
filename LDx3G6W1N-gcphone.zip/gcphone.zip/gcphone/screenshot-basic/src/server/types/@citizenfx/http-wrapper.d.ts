export function setHttpCallback(requestHandler: any): void;
