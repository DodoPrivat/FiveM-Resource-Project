INSERT INTO `jobs` (`id`, `name`, `label`, `whitelisted`) VALUES (42, 'zlom', 'Scrap-Man', 0);

INSERT INTO `job_grades` (`id`, `job_name`, `grade`, `name`, `label`, `salary`, `skin_male`, `skin_female`) VALUES (1001, 'zlom', 0, 'employee', 'Pracownik', 10, '', '');

INSERT INTO `items` (`id`, `name`, `label`, `limit`, `rare`, `can_remove`) VALUES (80, 'zlom', 'Scrap', -1, 0, 1, NULL, NULL, NULL);
