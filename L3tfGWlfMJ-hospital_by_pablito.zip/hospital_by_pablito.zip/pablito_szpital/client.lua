Citizen.CreateThread(function()
		
-- Pillbox hospital: 307.1680, -590.807, 43.280
    --RequestIpl("rc12b_default")
    RequestIpl("rc12b_hospitalinterior")
    RequestIpl("rc12b_hospitalinterior_lod")
		
end)