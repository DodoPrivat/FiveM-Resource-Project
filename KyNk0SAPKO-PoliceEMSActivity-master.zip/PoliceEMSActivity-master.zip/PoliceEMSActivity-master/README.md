# PoliceEMSActivity
A simple EMS Activity Blip Fivem script that has some other features too
