commands = {}
commandSuggestions = {}

function starts_with(str, start)
    return str:sub(1, #start) == start
end