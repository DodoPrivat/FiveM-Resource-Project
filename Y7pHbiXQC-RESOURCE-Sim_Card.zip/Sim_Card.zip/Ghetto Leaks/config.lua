-- BU SCRİPTİN OPTİMİZASYON VE DÜZENLEMELERİ Kenzh1N Tarafından yapılmıştır. --
-- Ulaşmak için : ^Kenzh1N#0805 --

Config                        = {}
Config.DrawDistance           = 15
Config.MarkerSize             = {x = 1.5, y = 1.5, z = 1.0}
Config.MarkerColor            = {r = 255, g = 0, b = 0}
Config.RoomMenuMarkerColor    = {r = 255, g = 0, b = 0}
Config.MarkerType             = 25
Config.Zones                  = {x = -230.46, y = -957.23, z = 31.22}
Config.Locale                 = 'fr'
