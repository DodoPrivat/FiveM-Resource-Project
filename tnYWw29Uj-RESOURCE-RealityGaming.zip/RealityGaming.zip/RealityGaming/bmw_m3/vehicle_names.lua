Citizen.CreateThread(function()
	AddTextEntry('m3gtr', 'BMW M3')
end)