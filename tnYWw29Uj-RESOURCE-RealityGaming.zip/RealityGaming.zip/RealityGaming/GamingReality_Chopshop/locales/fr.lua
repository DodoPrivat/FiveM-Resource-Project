Locales['fr'] = {
  ['press_to_chop'] = "Appuyez sur ~INPUT_CONTEXT~ pour démonter le vehicle.",
  ['map_blip'] = "Chop Shop",
  ['map_blip_shop'] = "Stanley's Car Parts",
  ['no_vehicle'] = "Vous devez être dans un vehicle.",
  ['open_shop'] = "Appuyez sur  ~INPUT_CONTEXT~ pour accéder au ~y~magasin~s~.",
  ['sold'] = "Tu as vendu ~b~%sx~s~ ~y~%s~s~ pour ~g~$%s~s~",
  ['not_enough'] = 'Vous n\'avez pas assez de cet article!',
  ['shop_prompt'] = 'Appuyez sur ~INPUT_CONTEXT~ pour parler avec ~r~Stanley~s~.',
  ['item'] = '$%s',
  ['shop_title'] = 'Stanley\'s Car Parts',
  ['cooldown'] = '~s~Vous devez ~g~attendre ~r~%s secondes ~s~avant que vous pouvez ~g~demonter ~s~un autre véhicule.',
  ['call'] = 'Quelqu\'un est en train de demonter un vehicule.',
  ['911'] = '911 Call',
  ['chop'] = 'Car Chopping',
  ['not_enough_cops'] = 'Pas assez de flics en service',
}
