Locales['en'] = {
  -- regulars
  	['press_e'] = 'Press ~INPUT_CONTEXT~ to check what the person ~r~died~s~ of',
	['hardmeele'] = 'Probaly hit by something hard in the head',
	['bullet'] = 'Probaly shot by an bullet, bulletholes in body',
	['knifes'] = 'Probaly knifed by something sharp',
	['bitten'] = 'Probaly bitten by an animal',
	['brokenlegs'] = 'Probaly fell, broke both legs',
	['explosive'] = 'Probaly died by something that explodes',
	['gas'] = 'Probaly died by gas damages in lungs',
	['fireextinguisher'] = 'Probaly died by the gas in an fireextinguisher',
	['fire'] = 'Probaly died by fire',
	['caraccident'] = 'Probaly died in a car accident',
	['drown'] = 'Probaly drowned',
	['unknown'] = 'Deathcause unknown',
}
