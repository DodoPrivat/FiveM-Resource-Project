Config                            = {}
--language currently available EN and SV
Config.Locale                     = 'en'
