Locales['pl'] = {
    ['no_hands_up']         = 'cel nie ma podniesionych rąk!',
    ['cash']                = 'gotówka',
    ['black_money']         = 'brudna kasa',
    ['inventory']           = 'ekwipunek',
    ['target_inventory']    = 'ekwipunek celu',
    ['steal']               = 'rabuj',
    ['return']              = 'cofnij',
    ['action_choice']       = 'wybór akcji',
    ['amount']              = 'ilość',
    ['too_far']             = 'jesteś za daleko!',
    ['no_players_nearby']   = 'brak gracza w pobliżu',
    ['ex_inv_lim_source']   = 'brak miejsca w ekwipunku',
    ['ex_inv_lim_target']   = 'brak miejsca w ekwipunku',
    ['you_stole']           = 'zrabowałeś',
    ['from_your_target']    = 'od celu',
    ['someone_stole']       = 'ktoś zrabował',
    ['invalid_quantity']    = 'zła ilość',
	['cuff']				= 'skuj',
	['uncuff']				= 'rozkuj',
	['search']				= 'przeszukaj',
	['drag']				= 'ciągnij',
    ['handcuffs']			= 'kajdanki',
    ['not_cuffed']          = 'gracz nie jest zakuty',
    ['cuffed']              = 'zostałeś zakuty',
    ['uncuffed']            = 'zostałeś rozkuty',
    ['no_handcuffs']        = 'nie masz kajdanek',
    ['no_rope']             = 'nie masz liny',
    ['gun_label']           = 'brone',
    ['not_armed']           = 'nie masz broni',
}
    