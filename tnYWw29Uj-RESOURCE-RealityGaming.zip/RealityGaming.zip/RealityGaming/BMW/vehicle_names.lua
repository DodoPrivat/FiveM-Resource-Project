Citizen.CreateThread(function()
	AddTextEntry('m3e36', 'BMW M3E36')
end)