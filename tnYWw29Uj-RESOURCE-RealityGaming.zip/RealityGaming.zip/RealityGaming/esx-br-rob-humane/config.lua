Config = {}
Config.Locale = 'en'
Config.NumberOfCopsRequired = 8
Config.NumberOfEMSRequired = 2
Banks = {
	["humane_labs"] = {
		position = { ['x'] = 3536.17, ['y'] = 3660.11, ['z'] = 28.12 },
		reward = math.random(7000000,11000000), --10M
		nameofbank = "Humane Labs",
		lastrobbed = 0
	},
}
