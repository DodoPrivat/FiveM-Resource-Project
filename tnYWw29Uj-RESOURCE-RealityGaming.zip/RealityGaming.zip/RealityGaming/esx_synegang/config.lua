Config                            = {}

Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 0.5 }
Config.MarkerColor                = { r = 178, g = 34, b = 34 }

Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- enable if you're using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableLicenses             = true -- enable if you're using esx_license

Config.EnableHandcuffTimer        = false -- enable handcuff timer? will unrestrain player after the time ends
Config.HandcuffTimer              = 10 * 60000 -- 10 mins

Config.EnableJobBlip              = true -- enable blips for colleagues, requires esx_society

Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.MafiaStations = {

	Mafia = {

		Cloakrooms = {
			vector3(-1153.95, -1710.74, 4.3),
			--vector3(-1391.45, 656.09, 197.1)
		},

		Armories = {
			vector3(-1172.86, -1707.46, 4.37)
		},

		Vehicles = {
			{
				Spawner = vector3(-1119.21, -1720.48, 4.59),
				InsideShop = vector3(-1841.08, 2982.74, 32.81),
				SpawnPoints = {
					{ coords = vector3(-1113.95, -1712.79, 3.7), heading = 122.0, radius = 6.0 },
					{ coords = vector3(-1140.74, -1732.92, 4.2), heading = 36.5, radius = 6.0 }
					--{ coords = vector3(-1421.9, 662.71, 185.72), heading = 323.94, radius = 6.0 }
				}
			},

			{
				Spawner = vector3(-1, -1, -1),
				InsideShop = vector3(-2136.86, 3255.89, 32.81),
				SpawnPoints = {
					{ coords = vector3(-2147.53, 3240.45, 32.81), heading = 276.1, radius = 6.0 },
					{ coords = vector3(-2152.14, 3232.2, 32.81), heading = 302.5, radius = 6.0 }
				}
			}
		},

		Helicopters = {
			{
				Spawner = vector3(-1421.46, 672.89, 202.15 ),
				InsideShop = vector3(-1859.67, 2795.52, 32.81),
				SpawnPoints = {
					{ coords = vector3(-1434.2, 668.41, 202.84), heading = 260.99, radius = 10.0 }
				}
			}
		},

		BossActions = {
			vector3(-1176.95, -1706.73, 4.38)
		}

	}

}

Config.AuthorizedWeapons = {

	sergeant = {
		--{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 100000 },
		--{ weapon = 'WEAPON_CARBINERIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 500000 }
	},
}

Config.AuthorizedVehicles = {
	Shared = {
		{ model = 'REGALIA', label = 'REGALIA', price = 500000 }		
	},
	soldato = {
		{ model = 'REGALIA', label = 'REGALIA', price = 500000 }
	},
	capo = {
		{ model = 'REGALIA', label = 'REGALIA', price = 500000 }
	},
	consigliere = {
		{ model = 'REGALIA', label = 'REGALIA', price = 500000 }
	},
	boss = {
	}
}

Config.AuthorizedHelicopters = {
	recruit = {},

	officer = {},

	sergeant = {},

	intendent = {},

	lieutenant = {
		{ model = 'cargobob', label = 'CargoBob', livery = 0, price = 100000 }
	},

	chef = {
		{ model = 'cargobob', label = 'CargoBob', livery = 0, price = 100000 }
	},

	boss = {
		{ model = 'buzzard2', label = 'Militar Buzzard', livery = 0, price = 150000 }
	}
}

-- CHECK SKINCHANGER CLIENT MAIN.LUA for matching elements

Config.Uniforms = {
	formal_wear = {
		male = {
			['tshirt_1'] = 15,  ['tshirt_2'] = 0,
			['torso_1'] = 107,   ['torso_2'] = 1,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 24,
			['pants_1'] = 24,   ['pants_2'] = 0,
			['shoes_1'] = 36,   ['shoes_2'] = 3,
			['chain_1'] = 121,    ['chain_2'] = 0,
			['glasses_1'] = 7,     ['glasses_2'] = 0
		},
		female = {
			['tshirt_1'] = 0,  ['tshirt_2'] = 6,
			['torso_1'] = 10,   ['torso_2'] = 2,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 39,
			['pants_1'] = 10,   ['pants_2'] = 6,
			['shoes_1'] = 38,   ['shoes_2'] = 0,
			['chain_1'] = 24,    ['chain_2'] = 10,
			['glasses_1'] = 5,     ['glasses_2'] = 0
		}
	},
	rob_wear = {
		male = {
			['tshirt_1'] = 15,  ['tshirt_2'] = 0,
			['torso_1'] = 128,   ['torso_2'] = 8,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 11,
			['pants_1'] = 42,   ['pants_2'] = 2,
			['shoes_1'] = 6,   ['shoes_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['helmet_1'] = -1,     ['helmet_2'] = 0,
			['glasses_1'] = 0,     ['glasses_2'] = 0
		},
		female = {
			['torso_1'] = 11,   ['torso_2'] = 2,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 37,
			['pants_1'] = 10,   ['pants_2'] = 0,
			['shoes_1'] = 38,   ['shoes_2'] = 0,
			['chain_1'] = 121,    ['chain_2'] = 0,
			['helmet_1'] = 7,     ['helmet_2'] = 5,
			['glasses_1'] = 5,     ['glasses_2'] = 0
		}
	},
	humane_wear = {
		male = {
			['tshirt_1'] = 16,  ['tshirt_2'] = 0,
			['torso_1'] = 12,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 12,
			['pants_1'] = 26,   ['pants_2'] = 10,
			['shoes_1'] = 42,   ['shoes_2'] = 2,
			['chain_1'] = 49,    ['chain_2'] = 0,
			['helmet_1'] = 7,     ['helmet_2'] = 5,
			['glasses_1'] = 0,     ['glasses_2'] = 0
		},
		female = {
			['tshirt_1'] = 16,  ['tshirt_2'] = 0,
			['torso_1'] = 208,   ['torso_2'] = 9,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 19,
			['pants_1'] = 87,   ['pants_2'] = 9,
			['shoes_1'] = 70,   ['shoes_2'] = 7,
			['chain_1'] = 78,    ['chain_2'] = 0,
			['helmet_1'] = 7,     ['helmet_2'] = 5,
			['glasses_1'] = 5,     ['glasses_2'] = 0
		}
	},
	
	yacht_wear = {
		male = {
			['tshirt_1'] = 15,  ['tshirt_2'] = 0,
			['torso_1'] = 84,   ['torso_2'] = 2,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 11,
			['pants_1'] = 64,   ['pants_2'] = 10,
			['shoes_1'] = 7,   ['shoes_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['helmet_1'] = -1,     ['helmet_2'] = 0,
			['glasses_1'] = 0,     ['glasses_2'] = 0
		},
		female = {
			['tshirt_1'] = 18,  ['tshirt_2'] = 1,
			['torso_1'] = 243,   ['torso_2'] = 3,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 39,
			['pants_1'] = 94,   ['pants_2'] = 3,
			['shoes_1'] = 67,   ['shoes_2'] = 3,
			['chain_1'] = 40,    ['chain_2'] = 0,
			['helmet_1'] = 7,     ['helmet_2'] = 0,
			['glasses_1'] = 0,     ['glasses_2'] = 0
		}
	},
	boss_wear = {
		male = {
			['tshirt_1'] = 15,  ['tshirt_2'] = 0,
			['torso_1'] = 240,   ['torso_2'] = 2,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 15,
			['pants_1'] = 24,   ['pants_2'] = 5,
			['shoes_1'] = 40,   ['shoes_2'] = 4,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 49,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	
	bullet_wear = {
		male = {
			['bproof_1'] = 15,  ['bproof_2'] = 1
		},
		female = {
			['bproof_1'] = 13,  ['bproof_2'] = 1
		}
	},

}

Config.DisableBlip = false -- Set to true to disable blips. False to enable them.
Config.Map = {
  			{name="SyneGang",    color=39, scale=0.8, id=84, x=-1145.18, y=-1705.08, z=13.62}
}