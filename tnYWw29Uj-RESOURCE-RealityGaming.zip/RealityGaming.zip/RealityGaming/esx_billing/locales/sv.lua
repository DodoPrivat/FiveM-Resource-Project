Locales['sv'] = {
  ['invoices'] = 'räkningar',
  ['invoices_item'] = '%s SEK',
  ['received_invoice'] = 'du har ~y~mottagit~s~ en räkning',
  ['paid_invoice'] = 'du ~y~betalade~s~ precis en räkning på ~g~%s SEK~s~',
  ['received_payment'] = 'du har ~y~mottagit~s~ en räkning på ~g~%s SEK~s~',
  ['player_not_online'] = 'personen är inte online',
  ['no_money'] = 'du har ~r~inte råd~s~ för att kunna betala räkningen',
  ['target_no_money'] = 'personen har ~r~inte råd~s~ för att betala räkningen',
}
