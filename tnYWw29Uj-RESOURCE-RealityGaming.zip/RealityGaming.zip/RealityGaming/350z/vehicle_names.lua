Citizen.CreateThread(function()
	AddTextEntry('dk350z', 'DK 350z')
end)