Config                            = {}
Config.DrawDistance               = 100.0
--language currently available EN and SV
Config.Locale                     = 'en'

Config.Zones = {

  PoliceDuty = {
    Pos   = { x = 440.45, y = -977.53, z = 29.7 },
    Size  = { x = 1.5, y = 1.5, z = 1.5 },
    Color = { r = 0, g = 255, b = 0 },  
    Type  = 27,
  },

  AmbulanceDuty = {
    Pos = { x = 306.13, y = -597.76, z = 42.31 },
    Size = { x = 1.5, y = 1.5, z = 1.5 },
    Color = { r = 0, g = 255, b = 0 },
    Type = 27,
  },
}
