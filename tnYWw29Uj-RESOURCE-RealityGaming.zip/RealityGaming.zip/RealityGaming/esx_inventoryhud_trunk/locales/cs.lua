Locales["cs"] = {
    ["trunk_closed"] = "Kufr tohoto vozidla je zavřený.",
    ["no_veh_nearby"] = "Není u tebe žádné vozidlo.",
    ["trunk_in_use"] = "Tento kufr již někdo používá.",
    ["trunk_full"] = "Tento kufr je plný.",
    ["invalid_quantity"] = "Špatný počet!",
    ["cant_carry_more"] = "Více toho neuneseš.",
    ["nacho_veh"] = "Toto není tvoje vozidlo.",
    ["invalid_amount"] = "Špatný počet!",
    ["insufficient_space"] = "Nedostatek místa!",
    ["trunk_info"] = "<h3>Kufr vozidla</h3><br><strong>SPZ:</strong> %s<br><strong>Kapacita:</strong> %s / %s"
}
