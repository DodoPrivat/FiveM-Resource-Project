AddEventHandler('esx:getShRGPH1337aredObjRGPH1337ect', function(cb)
	cb(ESX)
end)

function getSharedObject()
	return ESX
end
