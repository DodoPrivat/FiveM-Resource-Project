Citizen.CreateThread(function()
	AddTextEntry('zn20', '2019 Zenvo TSR-S')
	AddTextEntry('63lb', 'Mercedes-Benz C63 Black Series LibertyWalk 2014')
	AddTextEntry('19gt500', '2020 Ford Mustang Shelby GT500')
	AddTextEntry('supraa90', '2020 Toyota Supra GR A90')
	AddTextEntry('z4bmw', 'BMW Z4')
	AddTextEntry('370z', 'Nissan 370z')
	AddTextEntry('teslax', 'Tesla model X')
	AddTextEntry('mv720', 'Mclaren 720')
	AddTextEntry('brzbn', 'Subaru 2')
	AddTextEntry('16challenger'), 'Dodge Challenger 2016')
end)