Locales['es'] = {
  ['male'] = 'hombre',
  ['female'] = 'mujer',
  ['carjack'] = '~o~Robo de vehículo~s~: un(a) ~r~%s~s~ ha robado un ~o~%s~s~ en ~y~%s~s~',
  ['combat'] = '~o~Pelea callejera~s~: un(a) ~r~%s~s~ peleándose en ~y~%s~s~',
  ['gunshot'] = '~o~Tiroteo~s~: un(a) ~r~%s~s~ ha disparado un arma en ~y~%s~s~',
}
