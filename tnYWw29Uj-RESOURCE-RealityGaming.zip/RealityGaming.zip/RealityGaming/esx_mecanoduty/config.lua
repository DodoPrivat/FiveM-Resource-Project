Config                            = {}
Config.DrawDistance               = 100.0
--language currently available EN and SV
Config.Locale                     = 'en'

Config.Zones = {

  MechanicDuty = {
    Pos   = { x = -203.83, y = -1330.57, z = 33.99 },
    Size  = { x = 1.5, y = 1.5, z = 1.5 },
    Color = { r = 204, g = 102, b = 0 },  
    Type  = 27,
  },

  BennysDuty = {
    Pos = { x = 2114.81, y = 3347.14, z = 49.59 },
    Size = { x = 2.5, y = 2.5, z = 1.5 },
    Color = { r = 204, g = 0, b = 0 },
    Type = 27,
  },
}
