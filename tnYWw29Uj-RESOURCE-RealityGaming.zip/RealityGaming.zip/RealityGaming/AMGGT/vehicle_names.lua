Citizen.CreateThread(function()
	AddTextEntry('amggtr', 'AMG GT')
end)