Config              = {}

Config.DrawDistance = 100.0
Config.ZoneSize     = {x = 1.0, y = 1.0, z = 0.5}
Config.MarkerColor  = {r = 0, g = 80, b = 100}
Config.MarkerType   = 2

Config.Locale = 'en'

Config.Zones = {
	vector3(-139.26, -631.54, 168.82)
}
