Citizen.CreateThread(function()
	AddTextEntry('20denalihdg', 'GMC')
end)