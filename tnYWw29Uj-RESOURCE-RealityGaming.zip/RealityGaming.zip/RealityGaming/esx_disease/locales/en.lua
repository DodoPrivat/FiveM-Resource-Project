Locales ['en'] = {
  ['have_cought'] = 'You have a bad ~r~cough.~w~ You need to take the syrup',
  ['stomach_disease'] = 'You have~r~ a sick stomach.~w~ You need to take the antibiotic.',
  ['skin_disease'] = 'You have ~r~bad red spots on your skin.~w~ You need to take the antibiotic.',
  ['no_disease'] = '~g~You are no longer sick!',
}