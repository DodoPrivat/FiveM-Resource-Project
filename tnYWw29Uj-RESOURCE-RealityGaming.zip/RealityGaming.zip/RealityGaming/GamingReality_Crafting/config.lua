Config = {}

-- Ammo given by default to crafted weapons
Config.WeaponAmmo = 500

Config.Recipes = {
	-- Can be a normal ESX item
	['lockpick'] = {
    { item = "iron", quantity = 10, remove = true },
    { item = "rope", quantity = 1 },
},
['blowtorch'] = {
    { item = "gold", quantity = 4, remove = true },
    { item = "highradio", quantity = 2 },
},
['c4_bank'] = {
    { item = "iron", quantity = 3, remove = true },
    { item = "highradio", quantity = 2 },
},
['raspberry'] = {
    { item = "iron", quantity = 5, remove = true },
    { item = "highradio", quantity = 2 },
},
	
	-- Can be a weapon, must follow this format
	['weapon_musket'] = {
    { item = "gold", quantity = 10, remove = true },
    { item = "wood", quantity = 20 },
}
}

-- Enable a shop to access the crafting menu
Config.Shop = {
	useShop = true,
	shopCoordinates = { x=978.75, y=-91.83, z=70.57 },
	shopName = "Crafting Area",
	shopBlipID = 402,
	zoneSize = { x = 0.5, y = 0.5, z = 0.5 },
	zoneColor = { r = 255, g = 0, b = 0, a = 100 }
}

-- Enable crafting menu through a keyboard shortcut
Config.Keyboard = {
	useKeyboard = false,
	keyCode = 303
}
