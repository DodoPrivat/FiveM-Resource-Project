config={} 
config.time = 7 -- 5 is 5 min you can put what you want ex 3 would be 3 min this would be how long it would send each message
config.name = '^8^*RGPH' -- change this to your server name 
config.enabled = true 
config.messages = {
    ' Have a suggestion for the server? Feel free to post on ^2Discord.',      
    --' Think you have what it takes to be apart of our ^2Staff Team^0? Apply at ^2https://discord.gg/gvfmRpc',
    ' Looking to join a department? apply on our website at ^2https://discord.gg/ZFHxD26^0.',
    --'Roleplaying as a ^2civilian^0? You must Read the Rules at ^2https://discord.gg/ZFHxD26^0. Failure to do so may result in a warning, kick, or ban.',
    ' Make sure to read our rules at ^2Discord^0. Failure to follow the rules may result in a warning, kick, or ban.',
    ' Want to talk to other civilians? Join our Discord at https://discord.gg/ZFHxD26^',
    ' Want to stay up to date? Join our ^4Discord^0 server (^2https://discord.gg/ZFHxD26^0). Our ^4Discord^0 is used for text communication only!',
}
config.tfmsg = {
[true] = 'Activated',
[false] = 'Deactivated' 

}