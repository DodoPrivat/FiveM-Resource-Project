DiscordWebhookSystemInfos = 'https://discordapp.com/api/webhooks/643708372117356545/WQ0_9NM-zaZwa-TbPNKQ00zCYo8bsvli88ISbFjlLvRErI41AAZ0stHEqStDBf65xeFe'
DiscordWebhookKillinglogs = 'https://discordapp.com/api/webhooks/643708179955449857/Q-ojwy79dC9CY6lwqINyptkVgrfJOXqr0HrFFVxKV6MuHuabmUuteuwOWCBMqF6f48dA'
DiscordWebhookChat = 'https://discordapp.com/api/webhooks/643707991438131210/a-g6sOU88HZTZPnMgR660EVptGkne01f0AnkUQoCecDOjrS3cqBcYpYwb9vX_sdWdBqg'

SystemAvatar = 'https://wiki.fivem.net/w/images/d/db/FiveM-Wiki.png'

UserAvatar = 'https://i.imgur.com/KIcqSYs.png'

SystemName = 'SYSTEM'


--[[ Special Commands formatting
		 *YOUR_TEXT*			--> Make Text Italics in Discord
		**YOUR_TEXT**			--> Make Text Bold in Discord
	   ***YOUR_TEXT***			--> Make Text Italics & Bold in Discord
		__YOUR_TEXT__			--> Underline Text in Discord
	   __*YOUR_TEXT*__			--> Underline Text and make it Italics in Discord
	  __**YOUR_TEXT**__			--> Underline Text and make it Bold in Discord
	 __***YOUR_TEXT***__		--> Underline Text and make it Italics & Bold in Discord
		~~YOUR_TEXT~~			--> Strikethrough Text in Discord
]]
-- Use 'USERNAME_NEEDED_HERE' without the quotes if you need a Users Name in a special command
-- Use 'USERID_NEEDED_HERE' without the quotes if you need a Users ID in a special command


-- These special commands will be printed differently in discord, depending on what you set it to
SpecialCommands = {
				   {'/ooc', '**[OOC]:**'},
				   {'/911', '**[ USERNAME_NEEDED_HERE | USERID_NEEDED_HERE ])**'},
				   {'/hos', '**[ USERNAME_NEEDED_HERE | USERID_NEEDED_HERE ])**'},
				   {'/yaj', '**[ USERNAME_NEEDED_HERE | USERID_NEEDED_HERE ])**'},
				   {'/flitz', '**[ USERNAME_NEEDED_HERE | USERID_NEEDED_HERE ])**'},
				   {'/3097', '**[ USERNAME_NEEDED_HERE | USERID_NEEDED_HERE ])**'},
				  }

						
-- These blacklisted commands will not be printed in discord
BlacklistedCommands = {
					   '/AnyCommand',
					   '/AnyCommand2',
					  }

-- These Commands will use their own webhook
OwnWebhookCommands = {
					  {'/AnotherCommand', 'WEBHOOK_LINK_HERE'},
					  {'/AnotherCommand2', 'WEBHOOK_LINK_HERE'},
					 }

-- These Commands will be sent as TTS messages
TTSCommands = {
			   '/Whatever',
			   '/Whatever2',
			  }

