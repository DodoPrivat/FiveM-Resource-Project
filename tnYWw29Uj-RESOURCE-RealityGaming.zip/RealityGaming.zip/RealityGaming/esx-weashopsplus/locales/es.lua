Locales ['es'] = {

  ['buy'] = 'Has comprado ~b~1 ',
  ['not_enough_black'] = 'Usted no tiene ~r~suficiente~s~ dinero negro',
  ['not_enough'] = 'Usted no tiene ~r~suficiente~s~ dinero',
  ['shop'] = 'Tienda',
  ['shop_menu'] = 'Presione ~INPUT_CONTEXT~ para acceder a la tienda.',
  ['map_blip'] = 'Arsenal',

}
