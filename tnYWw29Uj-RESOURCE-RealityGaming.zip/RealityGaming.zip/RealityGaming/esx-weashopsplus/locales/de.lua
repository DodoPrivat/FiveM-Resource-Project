Locales ['de'] = {

  ['buy'] = 'du kaufst',
  ['not_enough_black'] = 'du hast nicht genug Schwarzgeld',
  ['not_enough'] = 'du hast nicht genug Geld',
  ['shop'] = 'Geschäft',
  ['shop_menu'] = 'Drücke ~INPUT_CONTEXT~ um auf das Geschäft zuzugreifen.',
  ['map_blip'] = 'Waffenladen',

}
