Locales ['en'] = {

  ['buy_license'] = 'buy a license?',
  ['yes'] = 'yes',
  ['no'] = 'no',
  ['buy'] = 'you bought',
  ['not_enough_black'] = 'you do not have enough dirty money',
  ['not_enough'] = 'you do not have enough money',
  ['shop'] = 'shop',
  ['shop_menu'] = 'Press ~INPUT_CONTEXT~ to access the shop.',
  ['map_blip'] = 'AmmuNation',

}
