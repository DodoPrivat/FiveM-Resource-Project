Locales ['br'] = {

  ['buy'] = 'Você comprou',
  ['not_enough_black'] = 'Você não tem dinheiro sujo suficiente',
  ['not_enough'] = 'você não tem dinheiro suficiente',
  ['shop'] = 'Comprar',
  ['shop_menu'] = 'Pressione ~INPUT_CONTEXT~ para comprar armas.',
  ['map_blip'] = 'Loja de Armas',

}
