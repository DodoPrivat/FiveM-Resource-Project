Config                = {}
Config.DrawDistance   = 100
Config.Size           = { x = 1.5, y = 1.5, z = 1.0 }
Config.Color          = { r = 100, g = 20, b = 0 }
Config.Type           = 0
Config.Locale         = 'en'
Config.EnableLicense  = true
Config.LicensePrice   = 30000

Config.Zones = {

    GunShop = {
        legal = 0,
        Items = {
            {name  = "weapon_bottle", price = 2500, label = "Bottle"},			--Add a comma and duplicate the line to repeat the process. If finished, Do not add a comma at the end.
            {name  = "weapon_bat", price = 4500, label = "Baseball Bat"},
            {name  = "weapon_battleaxe", price = 5000, label = "Battle Axe"},
            {name  = "weapon_dagger", price = 6000, label = "Dagger"}
			--{name  = "clip", price = 15000, label = "Ammo"}			
   	    },
        Items1 = {
            {name  = "WEAPON_combatpistol", price = 24150, label = "Combat Pistol"},
            {name  = "WEAPON_pistol", price = 20180, label = "Pistol"},
            {name  = "WEAPON_microsmg", price = 66280, label = "Micro Smg"}
			--{name  = "clip", price = 15000, label = "Ammo"}	
        },
        Items2 = {
            {name  = "WEAPON_pumpshotgun", price = 118320, label = "Pump Shutgun"}
			--{name  = "clip", price = 15000, label = "Ammo"}	
		},
        Pos   = {
            { x = -662.180,   y = -934.961,   z = 21.829 },
            { x = 810.25,     y = -2157.60,   z = 29.62 },
            { x = 1693.44,    y = 3760.16,    z = 34.71 },
            { x = -330.24,    y = 6083.88,    z = 31.45 },
            { x = 252.63,     y = -50.00,     z = 69.94 },
            { x = 22.09,      y = -1107.28,   z = 29.8 },
            { x = 2567.69,    y = 294.38,     z = 108.73 },
            { x = -1117.58,   y = 2698.61,    z = 18.55 },
            { x = 842.44,     y = -1033.42,   z = 28.19 },

        }
    },

    BlackWeashop = {
        legal = 1,
        Items = {
		    {name  = "gadget_parachute", price = 500, label = "Parachute"},
			{name  = "weapon_hatchet", price = 5000, label = "Hatchet"},
            {name  = "weapon_knuckle", price = 5000, label = "Knuckle"},
            {name  = "weapon_golfclub", price = 5000, label = "Golf Club"},
            {name  = "weapon_hammer", price = 5000, label = "Hammer"},
            {name  = "weapon_hatchet", price = 5000, label = "Panakol"},
            {name  = "weapon_snspistol", price = 23000, label = "SNS Pistol"},
			--{name  = "clip", price = 15000, label = "Ammo"}	
		},
		Items1 = {
			{name  = "weapon_minismg", price = 34000, label = "Mini Smg"},
            {name  = "weapon_assaultsmg", price = 54000, label = "Assault SMG"},
            {name  = "weapon_gusenberg", price = 94000, label = "Gusenberg Sweeper"},
            {name  = "weapon_smg", price = 20000, label = "SMG"},
            {name  = "WEAPON_combatpdw", price = 80000, label = "Combat Pdw"}
			--{name  = "clip", price = 15000, label = "Ammo"}	
		},
		Items2 = {
            {name  = "weapon_assaultrifle", price = 140000, label = "Assault Rifle"},
            {name  = "weapon_bullpuprifle", price = 220000, label = "Bullpup Rifle"},
            {name  = "weapon_compactrifle", price = 100000, label = "Compact Rifle"}
			--{name  = "clip", price = 15000, label = "Ammo"}	
		},
        Pos   = {
            { x = -1562.08,   y = 5391.13,  z = 4.1 },
        }
    },

}
