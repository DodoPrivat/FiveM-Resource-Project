Citizen.CreateThread(function()
	RequestIpl("hei_dlc_vw_roofdoors_locked")
	RequestIpl("hei_dlc_windows_casino")
	RequestIpl("hei_dlc_casino_door")
	RequestIpl("vw_casino_main")
	RequestIpl("vw_dlc_casino_carpark")
	RemoveIpl("apa_distlodlights_large000")
	RemoveIpl("apa_distlodlights_medium000")
	RemoveIpl("apa_distlodlights_medium001")
	RemoveIpl("apa_distlodlights_medium002")
	RemoveIpl("apa_distlodlights_medium003")
	RemoveIpl("apa_distlodlights_medium004")
	RemoveIpl("apa_distlodlights_medium005")
	RemoveIpl("apa_distlodlights_medium006")
	RemoveIpl("apa_distlodlights_medium007")
	RemoveIpl("apa_distlodlights_medium008")
	RemoveIpl("apa_distlodlights_medium009")
	RemoveIpl("apa_distlodlights_medium010")
	RemoveIpl("apa_distlodlights_medium011")
	RemoveIpl("apa_distlodlights_medium012")
	RemoveIpl("apa_distlodlights_medium013")
	RemoveIpl("apa_distlodlights_medium014")
	RemoveIpl("apa_distlodlights_medium015")
	RemoveIpl("apa_distlodlights_medium016")
	RemoveIpl("apa_distlodlights_medium017")
	RemoveIpl("apa_distlodlights_medium018")
	RemoveIpl("apa_distlodlights_medium019")
	RemoveIpl("apa_distlodlights_medium020")
	RemoveIpl("apa_distlodlights_medium021")
	RemoveIpl("apa_distlodlights_medium022")
	RemoveIpl("apa_distlodlights_medium023")
	RemoveIpl("apa_distlodlights_medium024")
	RemoveIpl("apa_distlodlights_medium025")
	RemoveIpl("apa_distlodlights_medium026")
	RemoveIpl("apa_distlodlights_medium027")
	RemoveIpl("apa_distlodlights_medium028")
	RemoveIpl("apa_distlodlights_medium029")
	RemoveIpl("apa_distlodlights_medium030")
	RemoveIpl("apa_distlodlights_medium031")
	RemoveIpl("apa_distlodlights_medium032")
	RemoveIpl("apa_distlodlights_medium033")
	RemoveIpl("apa_distlodlights_medium034")
	RemoveIpl("apa_distlodlights_medium035")
	RemoveIpl("apa_distlodlights_small000")
	RemoveIpl("apa_distlodlights_small001")
	RemoveIpl("apa_distlodlights_small002")
	RemoveIpl("apa_distlodlights_small003")
	RemoveIpl("apa_distlodlights_small004")
	RemoveIpl("apa_distlodlights_small005")
	RemoveIpl("apa_distlodlights_small006")
	RemoveIpl("apa_distlodlights_small007")
	RemoveIpl("apa_distlodlights_small008")
	RemoveIpl("apa_distlodlights_small009")
	RemoveIpl("apa_distlodlights_small010")
	RemoveIpl("apa_distlodlights_small011")
	RemoveIpl("apa_distlodlights_small012")
	RemoveIpl("apa_distlodlights_small013")
	RemoveIpl("apa_distlodlights_small014")
	RemoveIpl("apa_distlodlights_small015")
	RemoveIpl("apa_distlodlights_small016")
	RemoveIpl("apa_distlodlights_small017")
	RemoveIpl("apa_distlodlights_small018")
	RemoveIpl("apa_distlodlights_small019")
	RemoveIpl("apa_distlodlights_small020")
	RemoveIpl("apa_distlodlights_small021")
	RemoveIpl("apa_distlodlights_small022")
	RemoveIpl("apa_distlodlights_small023")
	RemoveIpl("apa_distlodlights_small024")
	RemoveIpl("apa_distlodlights_small025")
	RemoveIpl("apa_distlodlights_small026")
	RemoveIpl("apa_distlodlights_small027")
	RemoveIpl("apa_distlodlights_small028")
	RemoveIpl("apa_distlodlights_small029")
	RemoveIpl("apa_distlodlights_small030")
	RemoveIpl("apa_distlodlights_small031")
	RemoveIpl("apa_distlodlights_small032")
	RemoveIpl("apa_distlodlights_small033")
	RemoveIpl("apa_distlodlights_small034")
	RemoveIpl("apa_distlodlights_small035")
	RemoveIpl("apa_distlodlights_small036")
	RemoveIpl("apa_distlodlights_small037")
	RemoveIpl("apa_distlodlights_small038")
	RemoveIpl("apa_distlodlights_small039")
	RemoveIpl("apa_distlodlights_small040")
	RemoveIpl("apa_distlodlights_small041")
	RemoveIpl("apa_distlodlights_small042")
	RemoveIpl("apa_distlodlights_small043")
	RemoveIpl("apa_distlodlights_small044")
	RemoveIpl("apa_distlodlights_small045")
	RemoveIpl("apa_distlodlights_small046")
	RemoveIpl("apa_distlodlights_small047")
	RemoveIpl("apa_distlodlights_small048")
	RemoveIpl("apa_distlodlights_small049")
	RemoveIpl("apa_distlodlights_small050")
	RemoveIpl("apa_distlodlights_small051")
	RemoveIpl("apa_distlodlights_small052")
	RemoveIpl("apa_distlodlights_small053")
	RemoveIpl("apa_distlodlights_small054")
	RemoveIpl("apa_distlodlights_small055")
	RemoveIpl("apa_distlodlights_small056")
	RemoveIpl("apa_distlodlights_small057")
	RemoveIpl("apa_distlodlights_small058")
	RemoveIpl("apa_distlodlights_small059")
	RemoveIpl("apa_distlodlights_small060")
	RemoveIpl("apa_distlodlights_small061")
	RemoveIpl("apa_distlodlights_small062")
	RemoveIpl("apa_lodlights_large000")
	RemoveIpl("apa_lodlights_medium000")
	RemoveIpl("apa_lodlights_medium001")
	RemoveIpl("apa_lodlights_medium002")
	RemoveIpl("apa_lodlights_medium003")
	RemoveIpl("apa_lodlights_medium004")
	RemoveIpl("apa_lodlights_medium005")
	RemoveIpl("apa_lodlights_medium006")
	RemoveIpl("apa_lodlights_medium007")
	RemoveIpl("apa_lodlights_medium008")
	RemoveIpl("apa_lodlights_medium009")
	RemoveIpl("apa_lodlights_medium010")
	RemoveIpl("apa_lodlights_medium011")
	RemoveIpl("apa_lodlights_medium012")
	RemoveIpl("apa_lodlights_medium013")
	RemoveIpl("apa_lodlights_medium014")
	RemoveIpl("apa_lodlights_medium015")
	RemoveIpl("apa_lodlights_medium016")
	RemoveIpl("apa_lodlights_medium017")
	RemoveIpl("apa_lodlights_medium018")
	RemoveIpl("apa_lodlights_medium019")
	RemoveIpl("apa_lodlights_medium020")
	RemoveIpl("apa_lodlights_medium021")
	RemoveIpl("apa_lodlights_medium022")
	RemoveIpl("apa_lodlights_medium023")
	RemoveIpl("apa_lodlights_medium024")
	RemoveIpl("apa_lodlights_medium025")
	RemoveIpl("apa_lodlights_medium026")
	RemoveIpl("apa_lodlights_medium027")
	RemoveIpl("apa_lodlights_medium028")
	RemoveIpl("apa_lodlights_medium029")
	RemoveIpl("apa_lodlights_medium030")
	RemoveIpl("apa_lodlights_medium031")
	RemoveIpl("apa_lodlights_medium032")
	RemoveIpl("apa_lodlights_medium033")
	RemoveIpl("apa_lodlights_medium034")
	RemoveIpl("apa_lodlights_medium035")
	RemoveIpl("apa_lodlights_small000")
	RemoveIpl("apa_lodlights_small001")
	RemoveIpl("apa_lodlights_small002")
	RemoveIpl("apa_lodlights_small003")
	RemoveIpl("apa_lodlights_small004")
	RemoveIpl("apa_lodlights_small005")
	RemoveIpl("apa_lodlights_small006")
	RemoveIpl("apa_lodlights_small007")
	RemoveIpl("apa_lodlights_small008")
	RemoveIpl("apa_lodlights_small009")
	RemoveIpl("apa_lodlights_small010")
	RemoveIpl("apa_lodlights_small011")
	RemoveIpl("apa_lodlights_small012")
	RemoveIpl("apa_lodlights_small013")
	RemoveIpl("apa_lodlights_small014")
	RemoveIpl("apa_lodlights_small015")
	RemoveIpl("apa_lodlights_small016")
	RemoveIpl("apa_lodlights_small017")
	RemoveIpl("apa_lodlights_small018")
	RemoveIpl("apa_lodlights_small019")
	RemoveIpl("apa_lodlights_small020")
	RemoveIpl("apa_lodlights_small021")
	RemoveIpl("apa_lodlights_small022")
	RemoveIpl("apa_lodlights_small023")
	RemoveIpl("apa_lodlights_small024")
	RemoveIpl("apa_lodlights_small025")
	RemoveIpl("apa_lodlights_small026")
	RemoveIpl("apa_lodlights_small027")
	RemoveIpl("apa_lodlights_small028")
	RemoveIpl("apa_lodlights_small029")
	RemoveIpl("apa_lodlights_small030")
	RemoveIpl("apa_lodlights_small031")
	RemoveIpl("apa_lodlights_small032")
	RemoveIpl("apa_lodlights_small033")
	RemoveIpl("apa_lodlights_small034")
	RemoveIpl("apa_lodlights_small035")
	RemoveIpl("apa_lodlights_small036")
	RemoveIpl("apa_lodlights_small037")
	RemoveIpl("apa_lodlights_small038")
	RemoveIpl("apa_lodlights_small039")
	RemoveIpl("apa_lodlights_small040")
	RemoveIpl("apa_lodlights_small041")
	RemoveIpl("apa_lodlights_small042")
	RemoveIpl("apa_lodlights_small043")
	RemoveIpl("apa_lodlights_small044")
	RemoveIpl("apa_lodlights_small045")
	RemoveIpl("apa_lodlights_small046")
	RemoveIpl("apa_lodlights_small047")
	RemoveIpl("apa_lodlights_small048")
	RemoveIpl("apa_lodlights_small049")
	RemoveIpl("apa_lodlights_small050")
	RemoveIpl("apa_lodlights_small051")
	RemoveIpl("apa_lodlights_small052")
	RemoveIpl("apa_lodlights_small053")
	RemoveIpl("apa_lodlights_small054")
	RemoveIpl("apa_lodlights_small055")
	RemoveIpl("apa_lodlights_small056")
	RemoveIpl("apa_lodlights_small057")
	RemoveIpl("apa_lodlights_small058")
	RemoveIpl("apa_lodlights_small059")
	RemoveIpl("apa_lodlights_small060")
	RemoveIpl("apa_lodlights_small061")
	RemoveIpl("apa_lodlights_small062")
end)