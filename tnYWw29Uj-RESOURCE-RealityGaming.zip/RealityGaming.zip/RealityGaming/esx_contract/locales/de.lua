Locales ['de'] = {
  ['writingcontract'] = 'Vertrag für folgendes Kennzeichen: %s',
  ['soldvehicle'] = 'Du hast das Fahrzeug mit dem Kennzeichen ~r~%s~s~ verkauft',
  ['boughtvehicle'] = 'Du hast das Fahrzeug mit dem Kennzeichen ~g~%s~s~ gekauft',
  ['notyourcar'] = 'Das ist nicht dein Fahrzeug',
  ['nonearby'] = 'Kein Fahrzeug in der Nähe',
  ['nonearbybuyer'] = 'Kein Käufer in der Nähe',
}
