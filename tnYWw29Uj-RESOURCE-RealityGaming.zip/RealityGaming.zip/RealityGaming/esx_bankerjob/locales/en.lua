Locales['en'] = {
  ['actions']                           = 'actions',
  ['amount']                            = 'amount',
  ['balance']                           = 'balance',
  ['bank']                              = 'bank',
  ['bill_amount']                       = 'bill amount',
  ['billing']                           = 'billing',
  ['customer']                          = 'customer',
  ['customers']                         = 'clients',
  ['deposit']                           = 'deposit',
  ['invalid_amount']                    = 'invalid amount',
  ['no_player_nearby']                  = 'no player nearby',
  ['press_input_context_to_open_menu']  = 'press ~INPUT_CONTEXT~ to open the ~g~Bank Menu~s~.',
  ['withdraw']                          = 'withdraw',
  ['boss_actions']                      = 'boss Actions',
  ['phone_receive']                     = 'bank Customer',
  ['phone_label']                       = 'bank',
}
