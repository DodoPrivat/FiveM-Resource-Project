Locales['fi'] = {
  ['actions']                           = 'toiminnot',
  ['amount']                            = 'määrä',
  ['balance']                           = 'balanssi',
  ['bank']                              = 'Pankki',
  ['bill_amount']                       = 'laskun määrä',
  ['billing']                           = 'laskutus',
  ['customer']                          = 'asiakas',
  ['customers']                         = 'asiakkaat',
  ['deposit']                           = 'talletus',
  ['invalid_amount']                    = 'virheellinen määrä',
  ['no_player_nearby']                  = 'ei pelaajia lähettyvillä',
  ['press_input_context_to_open_menu']  = 'Paina ~INPUT_CONTEXT~ avataksesi valikon',
  ['withdraw']                          = 'nosta',
  ['boss_actions']                      = 'pomo valinnat',
  ['phone_receive']                     = 'pankin asiakas',
  ['phone_label']                       = 'bank',
}
