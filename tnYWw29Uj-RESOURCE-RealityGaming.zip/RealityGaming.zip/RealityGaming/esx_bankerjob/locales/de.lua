Locales['de'] = {
  ['actions']                           = 'Aktionen',
  ['amount']                            = 'Betrag',
  ['balance']                           = 'Kontostand',
  ['bank']                              = 'Bank',
  ['bill_amount']                       = 'Rechnungsbetrag',
  ['billing']                           = 'Rechnung',
  ['customer']                          = 'Kunde',
  ['customers']                         = 'Client',
  ['deposit']                           = 'einzahlen',
  ['invalid_amount']                    = 'ungültiger Betrag',
  ['no_player_nearby']                  = 'kein Spieler in der Nähe',
  ['press_input_context_to_open_menu']  = 'Drücke ~INPUT_CONTEXT~ um das Menü zu öffnen',
  ['withdraw']                          = 'Abheben',
  ['boss_actions']                      = 'boss Actions',
  ['phone_receive']                     = 'Bankkunde',
  ['phone_label']                       = 'bank',
}
