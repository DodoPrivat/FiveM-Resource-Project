Locales['fr'] = {
  ['actions']                           = 'actions',
  ['amount']                            = 'montant',
  ['balance']                           = 'solde',
  ['bank']                              = 'banque',
  ['bill_amount']                       = 'montant de la facture',
  ['billing']                           = 'facturation',
  ['customer']                          = 'client',
  ['customers']                         = 'clients',
  ['deposit']                           = 'virement',
  ['invalid_amount']                    = 'montant invalide',
  ['no_player_nearby']                  = 'aucun joueur à proximité',
  ['press_input_context_to_open_menu']  = 'appuyez sur ~INPUT_CONTEXT~ pour ouvrir le menu',
  ['withdraw']                          = 'retrait',
  ['boss_actions']                      = 'action Patron',
  ['phone_receive']                     = 'client Banque',
  ['phone_label']                       = 'banque',
}
