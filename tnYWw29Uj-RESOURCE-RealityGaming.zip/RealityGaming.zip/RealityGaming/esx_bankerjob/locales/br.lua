Locales['br'] = {
  ['actions']                           = 'ações',
  ['amount']                            = 'quantidade',
  ['balance']                           = 'saldo',
  ['bank']                              = 'banco',
  ['bill_amount']                       = 'montante de dinheiro',
  ['billing']                           = 'faturamento',
  ['customer']                          = 'cliente',
  ['customers']                         = 'clientes',
  ['deposit']                           = 'depositar',
  ['invalid_amount']                    = 'quantidade inválida',
  ['no_player_nearby']                  = 'nenhum jogador nas proximidades',
  ['press_input_context_to_open_menu']  = 'pressione ~INPUT_CONTEXT~ para abrir o menu',
  ['withdraw']                          = 'sacar',
  ['boss_actions']                      = 'boss Actions',
  ['phone_receive']                     = 'bank Customer',
  ['phone_label']                       = 'bank',
}
