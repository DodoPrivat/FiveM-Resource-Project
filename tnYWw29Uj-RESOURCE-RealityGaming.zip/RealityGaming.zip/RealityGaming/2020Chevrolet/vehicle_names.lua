Citizen.CreateThread(function()
	AddTextEntry('c8', 'Chevrolet C8')
end)