Locales['en'] = {
  ['tattoo_shop_prompt'] = 'press ~INPUT_PICKUP~ to access the ~y~tattoo shop~s~.',
  ['money_amount']       = '<span style="color:green;">PHP%s</span>',
  ['part']               = 'part %s',
  ['go_back_to_menu']    = '< Go back',
  ['tattoo_item']        = 'tattoo %s - %s',
  ['tattoos']            = 'tattoos',
  ['tattoo_shop']        = 'tattoo shop',
  ['bought_tattoo']      = 'you bought an ~y~tattoo~s~ for ~r~PHP%s~s~',
  ['not_enough_money']   = 'you don\'t have ~r~enough money~s~ for that tattoo! You are missing ~r~PHP%s~s~'
}