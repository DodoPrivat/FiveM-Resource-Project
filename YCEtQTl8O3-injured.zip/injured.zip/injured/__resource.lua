Description "Enhanced injured script for rp servers."

client_scripts {
    "injured.lua",
}