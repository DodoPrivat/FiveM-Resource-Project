# FiveM Radial Menu

FiveM resource for a simnple radial menu to execute commands.

## Installation

1. Add the radialmenu folder to your FiveM resources directory
2. Edit your server.cfg and add "start radialmenu"
