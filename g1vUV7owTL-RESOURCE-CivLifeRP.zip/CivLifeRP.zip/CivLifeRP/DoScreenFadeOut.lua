--- Fades the screen out.
-- duration: The time the fade should take, in milliseconds.
function Global.DoScreenFadeOut(duration)
	return _in(0x891B5B39AC6302AF, duration)
end
