function Global.ClearPedTasksImmediately(ped)
	return _in(0xAAA34F8A7CB32098, ped)
end
