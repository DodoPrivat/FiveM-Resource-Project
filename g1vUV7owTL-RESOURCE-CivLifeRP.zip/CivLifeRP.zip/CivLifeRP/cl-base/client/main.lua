local PlayerData              = {}
ESX                           = nil

--[[ 
	Get Objects for ESX
]]
Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	PlayerData = ESX.GetPlayerData()
end)
--[[
	Display Hud Command (Will be for displaying hud)
 ]]

RegisterNetEvent( 'nlbase:displayhud' )
AddEventHandler( 'nlbase:displayhud', function() 
	local displaytime = 8000---- Period of time it will wait before removing the UI

	ESX.UI.HUD.SetDisplay(1.0) -- Set Hud to display
	TriggerEvent('es:setMoneyDisplay', 1.0) -- Set Cash to display
	-- TriggerEvent('esx_status:setDisplay', 0.0) --- Set Display off
	Citizen.Wait(displaytime) ---- Period of time it will wait before removing the UI
	ESX.UI.HUD.SetDisplay(0.0) -- Set Hud to not display
	TriggerEvent('es:setMoneyDisplay', 0.0) -- Set Cash to not display
end )

RegisterNetEvent( 'nlbase:displayhudoff' )
AddEventHandler( 'nlbase:displayhudoff', function() 
	ESX.UI.HUD.SetDisplay(0.0) -- Set Hud to display
	TriggerEvent('es:setMoneyDisplay', 0.0) -- Set Cash to display
end )


RegisterNetEvent( 'nlbase:displayhudon' )
AddEventHandler( 'nlbase:displayhudon', function() 
	ESX.UI.HUD.SetDisplay(1.0) -- Set Hud to display
	TriggerEvent('es:setMoneyDisplay', 1.0) -- Set Cash to display
end )

--[[
	Display Cash on Person
  ]]
  RegisterNetEvent('nlbase:displaycash' )
  AddEventHandler('nlbase:displaycash', function()
  	local displaytime = 7500 ---- Period of time it will wait before removing the UI
  	
  	TriggerEvent('es:setMoneyDisplay', 1.0) -- Set Cash to display
  	Citizen.Wait(displaytime) 
  	TriggerEvent('es:setMoneyDisplay', 0.0) -- Set Cash to not display
  	end)
