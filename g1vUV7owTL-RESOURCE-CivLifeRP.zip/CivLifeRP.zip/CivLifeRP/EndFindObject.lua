function Global.EndFindObject(findHandle)
	return _in(0xdeda4e50, findHandle)
end
