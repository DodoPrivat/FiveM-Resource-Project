function Global.DisableAllControlActions(inputGroup)
	return _in(0x5F4B6931816E599B, inputGroup)
end
