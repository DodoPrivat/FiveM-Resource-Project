function Global.ClearAreaOfCops(x, y, z, radius, flags)
	return _in(0x04F8FC8FCF58F88D, x, y, z, radius, flags)
end
