Config                            = {}

Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 95, g = 49, b = 15 }

Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- enable if you're using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false -- enable if you're using esx_license

Config.EnableHandcuffTimer        = true -- enable handcuff timer? will unrestrain player after the time ends
Config.HandcuffTimer              = 10 * 60000 -- 10 mins

Config.EnableJobBlip              = false -- enable blips for colleagues, requires esx_society

Config.MaxInService               = -1
Config.Locale = 'en'

Config.BikerStations = {

	Biker = {

		Blip = {
			Pos     = { x = 959.8, y = -139.96, z = 74.49 },
			Sprite  = 303,
			Display = 4,
			Scale   = 0.8,
			Colour  = 21,
		},

		-- https://wiki.rage.mp/index.php?title=Weapons
		AuthorizedWeapons = {
			{ name = 'WEAPON_APPISTOL',     price = 17000 },
			--{ name = 'WEAPON_STUNGUN',     price = 1000 },
			--{ name = 'WEAPON_MICROSMG',     price = 25000 },
			--{ name = 'WEAPON_PUMPSHOTGUN',     price = 35000 },
			--{ name = 'WEAPON_REVOLVER_MK2',     price = 80000 },
			--{ name = 'WEAPON_SAWNOFFSHOTGUN',     price = 40000 },
			--{ name = 'WEAPON_PISTOL50',     price = 35000 },
			--{ name = 'WEAPON_MACHETE',     price = 750 },
            --{ name = 'WEAPON_HATCHET',     price = 800 },
            --{ name = 'WEAPON_KNUCKLE',     price = 2500 },
            --{ name = 'WEAPON_MOLOTOV',     price = 7000 },
            --{ name = 'WEAPON_PISTOL_MK2',     price = 40000 },
            --{ name = 'WEAPON_VINTAGEPISTOL',     price = 25000 },
            --{ name = 'WEAPON_GUSENBERG',     price = 180000 },
            --{ name = 'WEAPON_COMBATPDW',     price = 250000 },
            --{ name = 'WEAPON_ASSAULTRIFLE',     price = 120000 },
            --{ name = 'WEAPON_COMPACTRIFLE',     price = 160000 },
            --{ name = 'WEAPON_DOUBLEACTION',     price = 350000 },
            --{ name = 'WEAPON_BULLPUPRIFLE_MK2',     price = 600000 },
		},

		Cloakrooms = {
			{ x = 986.87, y = -92.77, z = 73.85 },
		},

		Armories = {
			{ x = 971.66, y = -98.94, z = 73.85 },
		},

		Vehicles = {
			{
				Spawner    = { x = 988.35, y = -139.09, z = 72.09 },
				SpawnPoints = {
					{ x = 973.98, y = -131.23, z = 74.15, heading = 53.32, radius = 6.0 }
				}
			}
		},

		VehicleDeleters = {
			{ x = 982.13, y = -129.46, z = 72.49 }
		},

		BossActions = {
			{ x = 977.19, y = -104.18, z = 73.85 }
		},

	},

}

-- https://wiki.rage.mp/index.php?title=Vehicles
Config.AuthorizedVehicles = {
	Shared = {
		{
			model = 'zombiea',
			label = 'Zombie Bobber'
		},
		{
			model = 'gburrito',
			label = 'Gang Van'
		}
	},

	prospect = {

	},

	clubmember = {

	},

	treasurer = {

	},

	enforcer = {

	},

	sgtatarms = {

	},

	vicepresident = {

	},

	boss = {

	}
}


-- CHECK SKINCHANGER CLIENT MAIN.LUA for matching elements

Config.Uniforms = {
	prospect_wear = {
		male = {

		},
		female = {

		}
	},
	clubmember_wear = {
		male = {

		},
		female = {

		}
	},
	treasurer_wear = {
		male = {

		},
		female = {

		}
	},
	enforcer_wear = {
		male = {

		},
		female = {

		}
	},
	sgtatarms_wear = { -- currently the same as intendent_wear
		male = {

		},
		female = {

		}
	},
	vicepresident_wear = { -- currently the same as intendent_wear
		male = {

		},
		female = {

		}
	},
	boss_wear = { -- currently the same as chef_wear
		male = {

		},
		female = {

		}
	},
	bullet_wear = {
		male = {

		},
		female = {

		}
	},
	gilet_wear = {
		male = {

		},
		female = {

		}
	}

}