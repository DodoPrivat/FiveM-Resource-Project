Config					= {}
Config.Locale = 'en'
Config.Slice			= 1000
Config.Percentage		= 88
Config.MarkerSize   	= {x = 3.0, y = 3.0, z = 3.0}
Config.Blip 			= false
Config.Menu				= true
Config.Bonus			= {min = 0, max = 0}

Config.Zones = {
	{x = 1122.21, y = -3195.08, z = -41.40},
}