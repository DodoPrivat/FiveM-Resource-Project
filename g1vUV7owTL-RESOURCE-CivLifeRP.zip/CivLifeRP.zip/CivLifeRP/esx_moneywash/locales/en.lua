Locales['en'] = {
	['moneywash'] 			= 'Launderer',
	['press_menu'] 			= 'Press on ~INPUT_CONTEXT~ to wash your ~r~Dirty Money',
	['Nothere'] 			= 'Come back later ...',
	['Whitening'] 			= 'Whitening in progress ...',
	['Nocash'] 				= 'You do not have enough money to launder, minimum : $',
	['cash'] 				= 'Thanks for washing your money!   You received: ~g~$',
	['cash1'] 				= ' Clean Money',
	['Notification'] 		= 'Launderer',
	['wash'] 				= 'Wash your Dirty Money',
	['wash_money_amount']   = 'Amount to be washed',
	['invalid_amount']      = 'Invalid amount',
}

