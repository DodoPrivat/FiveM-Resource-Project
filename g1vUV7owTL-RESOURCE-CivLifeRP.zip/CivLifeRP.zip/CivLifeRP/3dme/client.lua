local color = {r = 255, g = 255, b = 255, alpha = 255} -- Color of the text 
local font = 0 -- Font of the text
local time = 7000 -- Duration of the display of the text : 1000ms = 1sec
local nbrDisplaying = 1

RegisterCommand('me', function(source, args)
    local text = '' -- edit here if you want to change the language : EN: the person / FR: la personne
    for i = 1,#args do
        text = text .. ' ' .. args[i]
    end
    text = text .. ''
    TriggerServerEvent('3dme:shareDisplay', text)
end)

RegisterCommand('dice3', function(source, args)
dice1 = math.random(1,6)
dice2 = math.random(1,6)
dice3 = math.random(1,6)
local ped = GetPlayerPed(-1)
local player = PlayerPedId()
RequestAnimSet( "move_ped_crouched" )
SetPedMovementClipset( ped, "move_ped_crouched", 0.25 )
Citizen.Wait(1000)

  local ad = "amb@code_human_in_car_mp_actions@wank@std@rds@base";

    RequestAnimDict(ad);
    while not HasAnimDictLoaded(ad) do
        Citizen.Wait(0)
    end

    TaskPlayAnim(player, ad, "idle_a", 8.0, 1.0, -1, 49, 0, 0, 0, 0 )
     Wait (600)
       TriggerServerEvent('3dme:shareDisplay', "Dice Rolled ~g~" .. dice1 .. "/6 ~w~|~g~ " .. dice2 .. "/6~w~ | ~g~" .. dice3 .. "/6")
    TaskPlayAnim(player, ad, "exit", 8.0, 1.0, -1, 49, 0, 0, 0, 0 )
        Wait (500)
     ClearPedSecondaryTask(PlayerPedId())
     Citizen.Wait(1000)
     ResetPedMovementClipset( ped, 0 )
end)

RegisterCommand('dice2', function(source, args)
dice1 = math.random(1,6)
dice2 = math.random(1,6)
local ped = GetPlayerPed(-1)
local player = PlayerPedId()
RequestAnimSet( "move_ped_crouched" )
SetPedMovementClipset( ped, "move_ped_crouched", 0.25 )
Citizen.Wait(1000)

  local ad = "amb@code_human_in_car_mp_actions@wank@std@rds@base";

    RequestAnimDict(ad);
    while not HasAnimDictLoaded(ad) do
        Citizen.Wait(0)
    end

    TaskPlayAnim(player, ad, "idle_a", 8.0, 1.0, -1, 49, 0, 0, 0, 0 )
     Wait (600)
    TriggerServerEvent('3dme:shareDisplay', "Dice Rolled ~g~" .. dice1 .. "/6 ~w~|~g~ " .. dice2 .. "/6")
    TaskPlayAnim(player, ad, "exit", 8.0, 1.0, -1, 49, 0, 0, 0, 0 )
        Wait (500)
     ClearPedSecondaryTask(PlayerPedId())
     Citizen.Wait(1000)
     ResetPedMovementClipset( ped, 0 )
end)

RegisterCommand('dice1', function(source, args)
dice1 = math.random(1,6)
local ped = GetPlayerPed(-1)
local player = PlayerPedId()
RequestAnimSet( "move_ped_crouched" )
SetPedMovementClipset( ped, "move_ped_crouched", 0.25 )
Citizen.Wait(1000)

  local ad = "amb@code_human_in_car_mp_actions@wank@std@rds@base";

    RequestAnimDict(ad);
    while not HasAnimDictLoaded(ad) do
        Citizen.Wait(0)
    end

    TaskPlayAnim(player, ad, "idle_a", 8.0, 1.0, -1, 49, 0, 0, 0, 0 )
     Wait (600)
    TriggerServerEvent('3dme:shareDisplay', "Dice Rolled ~g~" .. dice1 .. "/6" )
    TaskPlayAnim(player, ad, "exit", 8.0, 1.0, -1, 49, 0, 0, 0, 0 )
        Wait (500)
     ClearPedSecondaryTask(PlayerPedId())
     Citizen.Wait(1000)
     ResetPedMovementClipset( ped, 0 )
end)

RegisterNetEvent('3dme:triggerDisplay')
AddEventHandler('3dme:triggerDisplay', function(text, source)
    local offset = 0 + (nbrDisplaying*0.14)
    Display(GetPlayerFromServerId(source), text, offset)
end)

function Display(mePlayer, text, offset)
    local displaying = true
    Citizen.CreateThread(function()
        Wait(time)
        displaying = false
    end)
    Citizen.CreateThread(function()
        nbrDisplaying = nbrDisplaying + 1
        --print(nbrDisplaying)
        while displaying do
            Wait(0)
            local coordsMe = GetEntityCoords(GetPlayerPed(mePlayer), false)
            local coords = GetEntityCoords(PlayerPedId(), false)
            local dist = GetDistanceBetweenCoords(coordsMe['x'], coordsMe['y'], coordsMe['z'], coords['x'], coords['y'], coords['z'], true)
            if dist < 6 then
                Draw3DText2(coordsMe['x'], coordsMe['y'], coordsMe['z']+offset, text)
            end
        end
        nbrDisplaying = nbrDisplaying - 1
    end)
end

--[[function Draw3DText2(x, y, z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)
 
    local scale = (1/dist)*1
    local fov = (1/GetGameplayCamFov())*100
    local scale = 0.9
   
    if onScreen then
        SetTextScale(0.0*scale, 0.25*scale)
        SetTextFont(0)
        SetTextProportional(1)
        -- SetTextScale(0.0, 0.55)
        SetTextColour(255, 255, 255, 215)
        --SetTextDropshadow(0, 0, 0, 0, 255)
        --SetTextEdge(2, 0, 0, 0, 150)
        SetTextDropShadow()
        SetTextOutline()
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x, _y + 0.0100, 0.030 + factor, 0.025, 41, 11, 41, 100)
    --DrawRect(_x,_y+0.0100, 0.030+ factor, 0.03, 41, 11, 41, 68)
    end
end--]]

function Draw3DText2(x,y,z,text,size)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    SetTextScale(0.35,0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    --DrawRect(_x,_y+0.0125, 0.030+ factor, 0.03, 41, 11, 41, 100)
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
end
--[[ESX.Game.Utils.DrawText3D = function(coords, text, size)
  local onScreen, _x, _y = World3dToScreen2d(coords.x, coords.y, coords.z)
  local pX, pY, pZ = table.unpack(GetGameplayCamCoords())
  SetTextScale(size, size)
  SetTextFont(4)
  SetTextProportional(1)
  SetTextEntry("STRING")
  SetTextCentre(1)
  SetTextColour(255, 255, 255, 215)
  AddTextComponentString(text)
  DrawText(_x, _y)
  local factor = (string.len(text)) / 370
  DrawRect(_x, _y + 0.0150, 0.030 + factor, 0.025, 41, 11, 41, 100)

end--]]