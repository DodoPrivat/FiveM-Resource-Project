Config                            = {}

Config.DrawDistance               = 100.0
Config.MarkerType                 = 27
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 0.5 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }

Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = false
Config.EnableESXIdentity          = true -- enable if you're using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableLicenses             = true -- enable if you're using esx_license

Config.EnableHandcuffTimer        = true -- enable handcuff timer? will unrestrain player after the time ends
Config.HandcuffTimer              = 10 * 60000 -- 10 mins

Config.EnableJobBlip              = true -- enable blips for colleagues, requires esx_society

Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.PoliceStations = {

	LSPD = {

		Blip = {
			Coords  = vector3(425.1, -979.5, 30.7),
			Sprite  = 60,
			Display = 4,
			Scale   = 0.8,
			Colour  = 29
		},

		Cloakrooms = {
			vector3(452.600, -993.306, 29.750), -- Mission Row
			vector3(1839.53, 3706.12, 0.11) -- Sandy Shores
		},

		Armories = {
			vector3(460.92, -981.18, 29.69), -- Mission Row
			vector3(1842.64, 3700.67, 0.11) -- Sandy Shores
		},

		Vehicles = {
			{
				Spawner = vector3(454.6, -1017.4, 27.45), -- Mission Row
				InsideShop = vector3(228.5, -993.5, -99.5), -- Sandy Shores
				SpawnPoints = {
					{ coords = vector3(438.4, -1018.3, 27.7), heading = 90.0, radius = 6.0 }, -- Mission Row
					{ coords = vector3(441.0, -1024.2, 28.3), heading = 90.0, radius = 6.0 }, -- Mission Row
					{ coords = vector3(453.5, -1022.2, 28.0), heading = 90.0, radius = 6.0 }, -- Mission Row
					{ coords = vector3(450.9, -1016.5, 28.1), heading = 90.0, radius = 6.0 } -- Mission Row
				}
			},

			{
				Spawner = vector3(1871.41, 3689.69, 32.67), -- Sandy Shores
				InsideShop = vector3(228.5, -993.5, -99.5), -- Sandy Shores
				SpawnPoints = {
					{ coords = vector3(1864.56, 3701.2, 32.53), heading = 29.44, radius = 6.0 }, -- Sandy Shores
					{ coords = vector3(1865.43, 3680.9, 32.64), heading = 211.79, radius = 6.0 } -- Sandy Shores
				}
			}
		},

		Helicopters = {
			{
				Spawner = vector3(461.1, -981.5, 43.6),
				InsideShop = vector3(477.0, -1106.4, 43.0),
				SpawnPoints = {
					{ coords = vector3(449.5, -981.2, 43.6), heading = 92.6, radius = 10.0 }
				}
			}
		},

		BossActions = {
			vector3(448.417, -973.208, 29.689), -- Mission Row
			vector3(1856.33, 3705.52, 0.05) -- Sandy Shores
		}

	}

}

Config.AuthorizedWeapons = {
	recruit = {
	    { weapon = 'WEAPON_NIGHTSTICK', price = 0 },
	    { weapon = 'WEAPON_FLASHLIGHT', price = 0 },
	    { weapon = 'WEAPON_FIREEXTINGUISHER', price = 0 },
	    { weapon = 'WEAPON_FLARE', price = 0 },
	    { weapon = 'WEAPON_PETROLCAN', price = 0 },
	    { weapon = 'GADGET_PARACHUTE', price = 0 },
	    { weapon = 'WEAPON_STUNGUN', price = 0 },
	    { weapon = 'WEAPON_FLAREGUN', price = 0 },
	    { weapon = 'WEAPON_COMBATPISTOL', price = 0 }
	},

	trooperi = {
	    { weapon = 'WEAPON_NIGHTSTICK', price = 0 },
	    { weapon = 'WEAPON_FLASHLIGHT', price = 0 },
	    { weapon = 'WEAPON_FIREEXTINGUISHER', price = 0 },
	    { weapon = 'WEAPON_FLARE', price = 0 },
	    { weapon = 'WEAPON_PETROLCAN', price = 0 },
	    { weapon = 'GADGET_PARACHUTE', price = 0 },
	    { weapon = 'WEAPON_STUNGUN', price = 0 },
	    { weapon = 'WEAPON_FLAREGUN', price = 0 },
	    { weapon = 'WEAPON_COMBATPISTOL', price = 0 },
	    --{ weapon = 'WEAPON_CARBINERIFLE', price = 2000 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', components = { 2000, 6000, nil }, price = 0 }
	},

	trooperii = {
	    { weapon = 'WEAPON_NIGHTSTICK', price = 0 },
	    { weapon = 'WEAPON_FLASHLIGHT', price = 0 },
	    { weapon = 'WEAPON_FIREEXTINGUISHER', price = 0 },
	    { weapon = 'WEAPON_FLARE', price = 0 },
	    { weapon = 'WEAPON_PETROLCAN', price = 0 },
	    { weapon = 'GADGET_PARACHUTE', price = 0 },
	    { weapon = 'WEAPON_STUNGUN', price = 0 },
	    { weapon = 'WEAPON_FLAREGUN', price = 0 },
	    { weapon = 'WEAPON_COMBATPISTOL', price = 0 },
	    { weapon = 'WEAPON_CARBINERIFLE', price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', components = { 2000, 6000, nil }, price = 0 }
	},

	sergeant = {
	    { weapon = 'WEAPON_NIGHTSTICK', price = 0 },
	    { weapon = 'WEAPON_FLASHLIGHT', price = 0 },
	    { weapon = 'WEAPON_FIREEXTINGUISHER', price = 0 },
	    { weapon = 'WEAPON_FLARE', price = 0 },
	    { weapon = 'WEAPON_PETROLCAN', price = 0 },
	    { weapon = 'GADGET_PARACHUTE', price = 0 },
	    { weapon = 'WEAPON_STUNGUN', price = 0 },
	    { weapon = 'WEAPON_FLAREGUN', price = 0 },
	    { weapon = 'WEAPON_COMBATPISTOL', price = 0 },
	    { weapon = 'WEAPON_CARBINERIFLE', price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', components = { 2000, 6000, nil }, price = 0 }
	},

	lieutenant = {
	    { weapon = 'WEAPON_NIGHTSTICK', price = 0 },
	    { weapon = 'WEAPON_FLASHLIGHT', price = 0 },
	    { weapon = 'WEAPON_FIREEXTINGUISHER', price = 0 },
	    { weapon = 'WEAPON_FLARE', price = 0 },
	    { weapon = 'WEAPON_PETROLCAN', price = 0 },
	    { weapon = 'GADGET_PARACHUTE', price = 0 },
	    { weapon = 'WEAPON_STUNGUN', price = 0 },
	    { weapon = 'WEAPON_FLAREGUN', price = 0 },
	    { weapon = 'WEAPON_COMBATPISTOL', price = 0 },
	    { weapon = 'WEAPON_CARBINERIFLE', price = 0 },
	    --{ weapon = 'WEAPON_SMG', price = 2000 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', components = { 2000, 6000, nil }, price = 0 }
	},

	captain = {
	    { weapon = 'WEAPON_NIGHTSTICK', price = 0 },
	    { weapon = 'WEAPON_FLASHLIGHT', price = 0 },
	    { weapon = 'WEAPON_FIREEXTINGUISHER', price = 0 },
	    { weapon = 'WEAPON_FLARE', price = 0 },
	    { weapon = 'WEAPON_PETROLCAN', price = 0 },
	    { weapon = 'GADGET_PARACHUTE', price = 0 },
	    { weapon = 'WEAPON_STUNGUN', price = 0 },
	    { weapon = 'WEAPON_FLAREGUN', price = 0 },
	    { weapon = 'WEAPON_COMBATPISTOL', price = 0 },
	    { weapon = 'WEAPON_CARBINERIFLE', price = 0 },
	   -- { weapon = 'WEAPON_SMG', price = 2000 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', components = { 2000, 6000, nil }, price = 0 },
		--{ weapon = 'WEAPON_SNIPERRIFLE', price = 5000 }
	},
	
	major = {
	    { weapon = 'WEAPON_NIGHTSTICK', price = 0 },
	    { weapon = 'WEAPON_FLASHLIGHT', price = 0 },
	    { weapon = 'WEAPON_FIREEXTINGUISHER', price = 0 },
	    { weapon = 'WEAPON_FLARE', price = 0 },
	    { weapon = 'WEAPON_PETROLCAN', price = 0 },
	    { weapon = 'GADGET_PARACHUTE', price = 0 },
	    { weapon = 'WEAPON_STUNGUN', price = 0 },
	    { weapon = 'WEAPON_FLAREGUN', price = 0 },
	    { weapon = 'WEAPON_COMBATPISTOL', price = 0 },
	    { weapon = 'WEAPON_CARBINERIFLE', price = 0 },
	   -- { weapon = 'WEAPON_SMG', price = 2000 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', components = { 2000, 6000, nil }, price = 0 },
		--{ weapon = 'WEAPON_SNIPERRIFLE', price = 5000 }
	},
	
	lieutenantcolonel = {
	    { weapon = 'WEAPON_NIGHTSTICK', price = 0 },
	    { weapon = 'WEAPON_FLASHLIGHT', price = 0 },
	    { weapon = 'WEAPON_FIREEXTINGUISHER', price = 0 },
	    { weapon = 'WEAPON_FLARE', price = 0 },
	    { weapon = 'WEAPON_PETROLCAN', price = 0 },
	    { weapon = 'GADGET_PARACHUTE', price = 0 },
	    { weapon = 'WEAPON_STUNGUN', price = 0 },
	    { weapon = 'WEAPON_FLAREGUN', price = 0 },
	    { weapon = 'WEAPON_COMBATPISTOL', price = 0 },
	    { weapon = 'WEAPON_CARBINERIFLE', price = 0 },
	   -- { weapon = 'WEAPON_SMG', price = 2000 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', components = { 2000, 6000, nil }, price = 0 },
		--{ weapon = 'WEAPON_SNIPERRIFLE', price = 5000 }
	},

	boss = {
	    { weapon = 'WEAPON_NIGHTSTICK', price = 0 },
	    { weapon = 'WEAPON_FLASHLIGHT', price = 0 },
	    { weapon = 'WEAPON_FIREEXTINGUISHER', price = 0 },
	    { weapon = 'WEAPON_FLARE', price = 0 },
	    { weapon = 'WEAPON_PETROLCAN', price = 0 },
	    { weapon = 'GADGET_PARACHUTE', price = 0 },
	    { weapon = 'WEAPON_SMOKEGRENADE', price = 0 },
	    { weapon = 'WEAPON_STUNGUN', price = 0 },
	    { weapon = 'WEAPON_FLAREGUN', price = 0 },
	    { weapon = 'WEAPON_BZGAS', price = 0 },
	    { weapon = 'WEAPON_COMBATPISTOL', price = 0 },
	    { weapon = 'WEAPON_CARBINERIFLE', price = 0 },
		--{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 10000 },
		--{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 50000 },
		--{ weapon = 'WEAPON_SMG', price = 2000 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', components = { 2000, 6000, nil }, price = 0 },
		--{ weapon = 'WEAPON_SNIPERRIFLE', price = 5000 }
	}
}

Config.AuthorizedVehicles = {
	Shared = {

	},

	recruit = { -- SASP
		{
			model = 'stvic',
			label = 'SASP Crownvick (Marked)',
			price = 1
		}
	},

	trooperi = { -- SASP
		{
			model = 'stvic',
			label = 'SASP Crownvick (Marked)',
			price = 1
		},
		{
			model = 'stcharger12',
			label = 'SASP Dodge Charger 2012 (Marked)',
			price = 1
		},
		{
			model = 'sttahoe',
			label = 'SASP Chevrolet Tahoe (Marked)',
			price = 1
		},
		{
			model = 'stexplorer',
			label = 'SASP Ford Explorer (Marked)',
			price = 1
		},
		{
			model = 'stcharger18',
			label = 'SASP Dodge Charger 2018 (Marked)',
			price = 1
		}
	},

	trooperii = { -- SASP
		{
			model = 'stvic',
			label = 'SASP Crownvick (Marked)',
			price = 1
		},
		{
			model = 'stcharger12',
			label = 'SASP Dodge Charger 2012 (Marked)',
			price = 1
		},
		{
			model = 'sttahoe',
			label = 'SASP Chevrolet Tahoe (Marked)',
			price = 1
		},
		{
			model = 'stexplorer',
			label = 'SASP Ford Explorer (Marked)',
			price = 1
		},
		{
			model = 'stcharger18',
			label = 'SASP Dodge Charger 2018 (Marked)',
			price = 1
		}
	},

	sergeant = { -- SASP
		{
			model = 'stvic',
			label = 'SASP Crownvick (Marked)',
			price = 1
		},
		{
			model = 'stcharger12',
			label = 'SASP Dodge Charger 2012 (Marked)',
			price = 1
		},
		{
			model = 'sttahoe',
			label = 'SASP Chevrolet Tahoe (Marked)',
			price = 1
		},
		{
			model = 'stexplorer',
			label = 'SASP Ford Explorer (Marked)',
			price = 1
		},
		{
			model = 'stcharger18',
			label = 'SASP Dodge Charger 2018 (Marked)',
			price = 1
		}
	},

	lieutenant = { -- SASP
		{
			model = 'stvic',
			label = 'SASP Crownvick (Marked)',
			price = 1
		},
		{
			model = 'stcharger12',
			label = 'SASP Dodge Charger 2012 (Marked)',
			price = 1
		},
		{
			model = 'sttahoe',
			label = 'SASP Chevrolet Tahoe (Marked)',
			price = 1
		},
		{
			model = 'stexplorer',
			label = 'SASP Ford Explorer (Marked)',
			price = 1
		},
		{
			model = 'stcharger18',
			label = 'SASP Dodge Charger 2018 (Marked)',
			price = 1
		},
		{
			model = 'policeb',
			label = 'Police Bike (Marked)',
			price = 1
		},
		{
			model = 'um1',
			label = 'LSPD Chevy Tahoe (Unmarked)',
			price = 1
		},
		{
			model = 'um2',
			label = 'LSPD Crownvick (Unmarked)',
			price = 1
		},
		{
			model = 'um3',
			label = 'LSPD Charger White (Unmarked)',
			price = 1
		},
		{
			model = 'um5',
			label = 'LSPD Ford Explorer (Unmarked)',
			price = 1
		}
	},

	captain = { -- SASP
		{
			model = 'stvic',
			label = 'SASP Crownvick (Marked)',
			price = 1
		},
		{
			model = 'stcharger12',
			label = 'SASP Dodge Charger 2012 (Marked)',
			price = 1
		},
		{
			model = 'sttahoe',
			label = 'SASP Chevrolet Tahoe (Marked)',
			price = 1
		},
		{
			model = 'stexplorer',
			label = 'SASP Ford Explorer (Marked)',
			price = 1
		},
		{
			model = 'stcharger18',
			label = 'SASP Dodge Charger 2018 (Marked)',
			price = 1
		},
		{
			model = 'policeb',
			label = 'Police Bike (Marked)',
			price = 1
		},
		{
			model = 'um1',
			label = 'LSPD Chevy Tahoe (Unmarked)',
			price = 1
		},
		{
			model = 'um2',
			label = 'LSPD Crownvick (Unmarked)',
			price = 1
		},
		{
			model = 'um3',
			label = 'LSPD Charger White (Unmarked)',
			price = 1
		},
		{
			model = 'um5',
			label = 'LSPD Ford Explorer (Unmarked)',
			price = 1
		}
	},
	
	major = { -- SASP
		{
			model = 'stvic',
			label = 'SASP Crownvick (Marked)',
			price = 1
		},
		{
			model = 'stcharger12',
			label = 'SASP Dodge Charger 2012 (Marked)',
			price = 1
		},
		{
			model = 'sttahoe',
			label = 'SASP Chevrolet Tahoe (Marked)',
			price = 1
		},
		{
			model = 'stexplorer',
			label = 'SASP Ford Explorer (Marked)',
			price = 1
		},
		{
			model = 'stcharger18',
			label = 'SASP Dodge Charger 2018 (Marked)',
			price = 1
		},
		{
			model = 'policeb',
			label = 'Police Bike (Marked)',
			price = 1
		},
		{
			model = 'um1',
			label = 'LSPD Chevy Tahoe (Unmarked)',
			price = 1
		},
		{
			model = 'um2',
			label = 'LSPD Crownvick (Unmarked)',
			price = 1
		},
		{
			model = 'um3',
			label = 'LSPD Charger White (Unmarked)',
			price = 1
		},
		{
			model = 'um5',
			label = 'LSPD Ford Explorer (Unmarked)',
			price = 1
		}
	},

	lieutenantcolonel = { -- SASP
		{
			model = 'stvic',
			label = 'SASP Crownvick (Marked)',
			price = 1
		},
		{
			model = 'stcharger12',
			label = 'SASP Dodge Charger 2012 (Marked)',
			price = 1
		},
		{
			model = 'sttahoe',
			label = 'SASP Chevrolet Tahoe (Marked)',
			price = 1
		},
		{
			model = 'stexplorer',
			label = 'SASP Ford Explorer (Marked)',
			price = 1
		},
		{
			model = 'stcharger18',
			label = 'SASP Dodge Charger 2018 (Marked)',
			price = 1
		},
		{
			model = 'policeb',
			label = 'Police Bike (Marked)',
			price = 1
		},
		{
			model = 'um1',
			label = 'LSPD Chevy Tahoe (Unmarked)',
			price = 1
		},
		{
			model = 'um2',
			label = 'LSPD Crownvick (Unmarked)',
			price = 1
		},
		{
			model = 'um3',
			label = 'LSPD Charger White (Unmarked)',
			price = 1
		},
		{
			model = 'um5',
			label = 'LSPD Ford Explorer (Unmarked)',
			price = 1
		}
	},

	boss = {
		{
			model = 'stvic',
			label = 'SASP Crownvick (Marked)',
			price = 1
		},
		{
			model = 'stcharger12',
			label = 'SASP Dodge Charger 2012 (Marked)',
			price = 1
		},
		{
			model = 'sttahoe',
			label = 'SASP Chevrolet Tahoe (Marked)',
			price = 1
		},
		{
			model = 'stexplorer',
			label = 'SASP Ford Explorer (Marked)',
			price = 1
		},
		{
			model = 'stcharger18',
			label = 'SASP Dodge Charger 2018 (Marked)',
			price = 1
		},
		{
			model = 'policeb',
			label = 'Police Bike (Marked)',
			price = 1
		},
		{
			model = 'um1',
			label = 'LSPD Chevy Tahoe (Unmarked)',
			price = 1
		},
		{
			model = 'um2',
			label = 'LSPD Crownvick (Unmarked)',
			price = 1
		},
		{
			model = 'um3',
			label = 'LSPD Charger White (Unmarked)',
			price = 1
		},
		{
			model = 'um5',
			label = 'LSPD Ford Explorer (Unmarked)',
			price = 1
		}
	}
}

Config.AuthorizedHelicopters = {
	recruit = {},

	trooperi = {},

	trooperii = {},

	sergeant = {
		{
			model = 'polmav',
			label = 'Police Maverick',
			livery = 0,
			price = 200000
		}
	},

	lieutenant = {
		{
			model = 'polmav',
			label = 'Police Maverick',
			livery = 0,
			price = 200000
		}
	},

	captain = {
		{
			model = 'polmav',
			label = 'Police Maverick',
			livery = 0,
			price = 200000
		}
	},

	major = {
		{
			model = 'polmav',
			label = 'Police Maverick',
			livery = 0,
			price = 150000
		}
	},
	
	lieutenantcolonel = {
		{
			model = 'polmav',
			label = 'Police Maverick',
			livery = 0,
			price = 150000
		}
	},

	boss = { --LSPD/SAHP
		{
			model = 'polmav',
			label = 'Police Maverick',
			livery = 0,
			price = 100000
		}
	}
}

-- CHECK SKINCHANGER CLIENT MAIN.LUA for matching elements

Config.Uniforms = {
	recruit_wear = { -- SASP
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 118,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,       ['arms_2'] = 0,
			['pants_1'] = 10,    ['pants_2'] = 0,
			['shoes_1'] = 2,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = -1,    ['ears_2'] = 0,
			['bproof_1'] = 12,  ['bproof_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 25,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 14,       ['arms_2'] = 0,
			['pants_1'] = 41,   ['pants_2'] = 2,
			['shoes_1'] = 52,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 8,    ['chain_2'] = 0,
			['ears_1'] = -1,     ['ears_2'] = 0,
			['bproof_1'] = 14,  ['bproof_2'] = 0
		}
	},
	trooperi_wear = { -- SASP
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 118,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,       ['arms_2'] = 0,
			['pants_1'] = 10,    ['pants_2'] = 0,
			['shoes_1'] = 2,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = -1,    ['ears_2'] = 0,
			['bproof_1'] = 12,  ['bproof_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 25,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 14,       ['arms_2'] = 0,
			['pants_1'] = 41,   ['pants_2'] = 2,
			['shoes_1'] = 52,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 8,    ['chain_2'] = 0,
			['ears_1'] = -1,     ['ears_2'] = 0,
			['bproof_1'] = 14,  ['bproof_2'] = 0
		}
	},
	trooperii_wear = { -- SASP
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 118,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,       ['arms_2'] = 0,
			['pants_1'] = 10,    ['pants_2'] = 0,
			['shoes_1'] = 2,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = -1,    ['ears_2'] = 0,
			['bproof_1'] = 12,  ['bproof_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 25,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 14,       ['arms_2'] = 0,
			['pants_1'] = 41,   ['pants_2'] = 2,
			['shoes_1'] = 52,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 8,    ['chain_2'] = 0,
			['ears_1'] = -1,     ['ears_2'] = 0,
			['bproof_1'] = 14,  ['bproof_2'] = 0
		}
	},
	sergeant_wear = { -- SASP
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 118,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,       ['arms_2'] = 0,
			['pants_1'] = 10,    ['pants_2'] = 0,
			['shoes_1'] = 2,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = -1,    ['ears_2'] = 0,
			['bproof_1'] = 12,  ['bproof_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 25,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 14,       ['arms_2'] = 0,
			['pants_1'] = 41,   ['pants_2'] = 2,
			['shoes_1'] = 52,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 8,    ['chain_2'] = 0,
			['ears_1'] = -1,     ['ears_2'] = 0,
			['bproof_1'] = 14,  ['bproof_2'] = 0
		}
	},
	lieutenant_wear = { -- SASP
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 118,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,       ['arms_2'] = 0,
			['pants_1'] = 10,    ['pants_2'] = 0,
			['shoes_1'] = 2,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = -1,    ['ears_2'] = 0,
			['bproof_1'] = 12,  ['bproof_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 25,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 14,       ['arms_2'] = 0,
			['pants_1'] = 41,   ['pants_2'] = 2,
			['shoes_1'] = 52,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 8,    ['chain_2'] = 0,
			['ears_1'] = -1,     ['ears_2'] = 0,
			['bproof_1'] = 14,  ['bproof_2'] = 0
		}
	},
	captain_wear = { -- SASP
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 118,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,       ['arms_2'] = 0,
			['pants_1'] = 10,    ['pants_2'] = 0,
			['shoes_1'] = 2,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = -1,    ['ears_2'] = 0,
			['bproof_1'] = 12,  ['bproof_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 25,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 14,       ['arms_2'] = 0,
			['pants_1'] = 41,   ['pants_2'] = 2,
			['shoes_1'] = 52,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 8,    ['chain_2'] = 0,
			['ears_1'] = -1,     ['ears_2'] = 0,
			['bproof_1'] = 14,  ['bproof_2'] = 0
		}
	},
	major_wear = { -- SASP
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 118,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,       ['arms_2'] = 0,
			['pants_1'] = 10,    ['pants_2'] = 0,
			['shoes_1'] = 2,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = -1,    ['ears_2'] = 0,
			['bproof_1'] = 12,  ['bproof_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 25,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 14,       ['arms_2'] = 0,
			['pants_1'] = 41,   ['pants_2'] = 2,
			['shoes_1'] = 52,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 8,    ['chain_2'] = 0,
			['ears_1'] = -1,     ['ears_2'] = 0,
			['bproof_1'] = 14,  ['bproof_2'] = 0
		}
	},
	sahpmajor_wear = { -- SASP
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 118,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,       ['arms_2'] = 0,
			['pants_1'] = 10,    ['pants_2'] = 0,
			['shoes_1'] = 2,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = -1,    ['ears_2'] = 0,
			['bproof_1'] = 12,  ['bproof_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 25,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 14,       ['arms_2'] = 0,
			['pants_1'] = 41,   ['pants_2'] = 2,
			['shoes_1'] = 52,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 8,    ['chain_2'] = 0,
			['ears_1'] = -1,     ['ears_2'] = 0,
			['bproof_1'] = 14,  ['bproof_2'] = 0
		}
	},
	lieutenantcolonel_wear = { -- SASP
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 118,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,       ['arms_2'] = 0,
			['pants_1'] = 10,    ['pants_2'] = 0,
			['shoes_1'] = 2,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = -1,    ['ears_2'] = 0,
			['bproof_1'] = 12,  ['bproof_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 25,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 14,       ['arms_2'] = 0,
			['pants_1'] = 41,   ['pants_2'] = 2,
			['shoes_1'] = 52,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 8,    ['chain_2'] = 0,
			['ears_1'] = -1,     ['ears_2'] = 0,
			['bproof_1'] = 14,  ['bproof_2'] = 0
		}
	},
	boss_wear = { -- SASP
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 118,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,       ['arms_2'] = 0,
			['pants_1'] = 10,    ['pants_2'] = 0,
			['shoes_1'] = 2,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = -1,    ['ears_2'] = 0,
			['bproof_1'] = 12,  ['bproof_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 25,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 14,       ['arms_2'] = 0,
			['pants_1'] = 41,   ['pants_2'] = 2,
			['shoes_1'] = 52,   ['shoes_2'] = 0,
			['helmet_1'] = 13,  ['helmet_2'] = 2,
			['chain_1'] = 8,    ['chain_2'] = 0,
			['ears_1'] = -1,     ['ears_2'] = 0,
			['bproof_1'] = 14,  ['bproof_2'] = 0
		}
	},
	bullet_wear = {
		male = {
			['bproof_1'] = 7,  ['bproof_2'] = 0
		},
		female = {
			['bproof_1'] = 8,  ['bproof_2'] = 1
		}
	},
	gilet_wear = {
		male = {

		},
		female = {

		}
	}

}