JAM.RaceMod = {}
local JRM = JAM.RaceMod
JRM.ESX = JAM.ESX

JRM.FlagMarkerOffsetZ 	=   10.0
JRM.GroundMarkerOffsetZ = -  1.0
JRM.WaitForPlayersTimer =   10
JRM.JoinTimeout			=	 9
JRM.JoinDistLimit 		=   50.0
JRM.StartTimer			=   10
JRM.CountdownTimer      =    5
JRM.DrawMarkerDist		=  80000.0
JRM.LeaveDist 			=	10.0
JRM.LeaveWarnDist		=    5.0
JRM.TimeoutTimer		=   30.0
JRM.FinishRaceDist		=   20.0

--[[JAM.RaceMod = {}
local JRM = JAM.RaceMod
JRM.ESX = JAM.ESX

JRM.FlagMarkerOffsetZ = 5.0
JRM.GroundMarkerOffsetZ = -1.0

JRM.DistToMarker = 5.0
JRM.MaxMoveDist = 10.0
JRM.MoveWarnDist = 5.0

JRM.RaceTimeout = 30
JRM.NotificationLength = 10
JRM.CountdownTimer = 5
JRM.JoiningTimer = 10 ]]