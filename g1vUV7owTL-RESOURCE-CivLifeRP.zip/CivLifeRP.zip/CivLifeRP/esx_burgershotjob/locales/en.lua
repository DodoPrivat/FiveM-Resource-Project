Locales['en'] = {
    -- Cloakroom
    ['cloakroom']                = 'Clothing',
    ['citizen_wear']             = 'Regular clothes',
    ['barman_outfit']            = 'Barmens clothes',
    ['dancer_outfit_1']          = 'Dancewear 1',
    ['dancer_outfit_2']          = 'Dancewear 2',
    ['dancer_outfit_3']          = 'Dancewear 3',
    ['dancer_outfit_4']          = 'Dancewear 4',
    ['dancer_outfit_5']          = 'Dancewear 5',
    ['dancer_outfit_6']          = 'Dancewear 6',
    ['dancer_outfit_7']          = 'Dancewear 7',
    ['no_outfit']                = 'There is no uniform for you ...',
    ['open_cloackroom']          = 'Press ~INPUT_CONTEXT~ to change',
  
    -- Vault  
    ['get_weapon']               = 'Handle Weapon',
    ['put_weapon']               = 'Weapon',
    ['get_weapon_menu']          = 'Safe - Pick up weapon',
    ['put_weapon_menu']          = 'Safe - Putting a weapon',
    ['get_object']               = 'Pick up item',
    ['put_object']               = 'Put in item',
    ['vault']                    = 'Vault',
    ['open_vault']               = 'Press~INPUT_CONTEXT~ to open vault',
  
    -- Fridge  
    ['get_object']               = 'Pick Item',
    ['put_object']               = 'Place Item',
    ['fridge']                   = 'Refrigerator',
    ['open_fridge']              = 'Press ~INPUT_CONTEXT~ to open refrigerator',
    ['unicorn_fridge_stock']     = 'Refrigerator stock',
    ['fridge_inventory']         = 'Content of the refrigerator',
  
    -- Shops  
    ['shop']                     = 'Shop BurgerShot',
    ['shop_menu']                = 'Press ~INPUT_CONTEXT~ to access the store.',
    ['bought']                   = 'You Bought~b~ 1x',
    ['not_enough_money']         = 'You do not have enough money.',
    ['max_item']                 = 'You already have too many items.',
  
    -- Vehicles  
    ['vehicle_menu']             = 'Vehicles',
    ['vehicle_out']              = 'You already have a vehicle out.',
    ['vehicle_spawner']          = 'Press ~INPUT_CONTEXT~ to remove a vehicle',
    ['store_vehicle']            = 'Press ~INPUT_CONTEXT~ to store a vehicle',
    ['service_max']              = 'You already have too many employees with vehicles: ',
    ['spawn_point_busy']         = 'A vehicle is near the garage.',
  
    -- Boss Menu  
    ['take_company_money']       = 'Withdraw money from the company',
    ['deposit_money']            = 'Deposit money in the company',
    ['amount_of_withdrawal']     = 'Withdrawal amount',
    ['invalid_amount']           = 'Invalid amount',
    ['amount_of_deposit']        = 'Quantity deposited',
    ['open_bossmenu']            = 'Press ~INPUT_CONTEXT~ to open the menu',
    ['invalid_quantity']         = 'Invalid amount',
    ['you_removed']              = 'You removed x',
    ['you_added']                = 'You added x',
    ['quantity']                 = 'Amount',
    ['inventory']                = 'Inventory',
    ['unicorn_stock']            = 'Burgershot Stock',
  
    -- Billing Menu  
    ['billing']                  = 'Invoice',
    ['no_players_nearby']        = 'No players nearby',
    ['billing_amount']           = 'Invoice amount',
    ['amount_invalid']           = 'Invalid Amount',
  
    -- Crafting Menu  
    ['crafting']                 = 'Beverage Mix',
    ['martini']                  = 'Martini',
    ['icetea']                   = 'Ice Tea',
    ['drpepper']                 = 'Dr. Pepper',
    ['saucisson']                = 'Sausage',
    ['grapperaisin']             = 'grapes',
    ['energy']                   = 'Energy drink',
    ['jager']                    = 'Jägermeister',
    ['limonade']                 = 'Lemonade',
    ['vodka']                    = 'Vodka',
    ['ice']                      = 'Ice',
    ['soda']                     = 'Soda',
    ['whisky']                   = 'Whisky',
    ['rhum']                     = 'Rhum',
    ['tequila']                  = 'Tequila',
    ['menthe']                   = 'Mint',
    ['jusfruit']                 = 'Fruit Soda',
    ['jagerbomb']                = 'Jägerbomb',
    ['bolcacahuetes']            = 'Peanut',
    ['bolnoixcajou']             = 'Salted peanuts',
    ['bolpistache']              = 'Pistachios',
    ['bolchips']                 = 'French fries',
    ['jagerbomb']                = 'Jägerbomb',
    ['golem']                    = 'Golem',
    ['whiskycoca']               = 'Whisky-coke',
    ['vodkaenergy']              = 'Vodka-Engery drink',
    ['vodkafruit']               = 'Vodka Fruit Soda',
    ['rhumfruit']                = 'Rum Fruit Soda',
    ['teqpaf']                   = 'Teq\'paf',
    ['rhumcoca']                 = 'Rhum-coke',
    ['mojito']                   = 'Mojito',
    ['mixapero']                 = 'Several appetizers',
    ['metreshooter']             = 'Shots',
    ['jagercerbere']             = 'Jäger Cerberus',
    ['assembling_cocktail']      = 'Mixing of various ingredients in processing!',
    ['craft_miss']               = 'The mix failed ...',
    ['not_enough']               = 'Insufficient ~r~ ',
    ['craft']                    = 'Complete blend of ~g~',
  
    -- Misc  
    ['map_blip']                 = 'Burgershot',
    ['unicorn']                  = 'Burgershot',
  
    -- Phone  
    ['unicorn_phone']            = 'burgershot',
    ['unicorn_customer']         = 'Civil',
  
    -- Teleporters
    ['e_to_enter_1']             = 'Press ~INPUT_PICKUP~ to go behind the bar',
    ['e_to_exit_1']              = 'Press ~INPUT_PICKUP~ to go in front off the bar',
    ['e_to_enter_2']             = 'Press ~INPUT_PICKUP~ to go up to the roof.',
    ['e_to_exit_2']              = 'Press ~INPUT_PICKUP~ to go down to the offices.',
    
  }
  