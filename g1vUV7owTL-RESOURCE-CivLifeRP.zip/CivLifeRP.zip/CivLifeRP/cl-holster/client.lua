local holstered = true
local switching = false
local weapons = {
	"WEAPON_PISTOL",
	"WEAPON_COMBATPISTOL",
	"WEAPON_APPISTOL",
	"WEAPON_PISTOL50",
	"WEAPON_PUMPSHOTGUN",
	"WEAPON_SAWNOFFSHOTGUN",
	"WEAPON_ASSAULTRIFLE",
	"WEAPON_SPECIALCARBINE",
	"WEAPON_CARBINERIFLE",
	"WEAPON_SMOKEGRENADE",
	"WEAPON_MICROSMG",
	"WEAPON_KNIFE",
	"WEAPON_COMBATMG",
	"WEAPON_REVOLVER",
	"WEAPON_HEAVYPISTOL",
	"WEAPON_MINISMG",
	"WEAPON_MACHINEPISTOL",
	"WEAPON_MARKSMANPISTOL",
	"WEAPON_MICROSMG",
	"WEAPON_HEAVYSNIPER",
}

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		local ped = PlayerPedId()
		if DoesEntityExist( ped ) and not IsEntityDead( ped ) and not IsPedInAnyVehicle(PlayerPedId(), true) then
			loadAnimDict( "reaction@intimidation@1h" )
			if CheckWeapon(ped) then
				if holstered then
					switching = true
					TaskPlayAnim(ped, "reaction@intimidation@1h", "Intro", 8.0, 2.0, -1, 55, 10, 0, 0, 0 )		
					Citizen.Wait(2000)
					ClearPedTasks(ped)
					holstered = false
					switching = false
				end
			elseif not CheckWeapon(ped) then
				if not holstered then
					TaskPlayAnim(ped, "reaction@intimidation@1h", "outro", 8.0, 2.0, -1, 48, 10, 0, 0, 0 )
					Citizen.Wait(2000)
					ClearPedTasks(ped)
					holstered = true
				end
			end
		end
	end
end)


Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)

		if switching then
			DisablePlayerFiring(playerPed, true)
		else
			Citizen.Wait(0)
		end
	end
end)

function CheckWeapon(ped)
	for i = 1, #weapons do
		if GetHashKey(weapons[i]) == GetSelectedPedWeapon(ped) then
			return true
		end
	end
	return false
end

function loadAnimDict( dict )
	while ( not HasAnimDictLoaded( dict ) ) do
		RequestAnimDict( dict )
		Citizen.Wait( 0 )
	end
end
