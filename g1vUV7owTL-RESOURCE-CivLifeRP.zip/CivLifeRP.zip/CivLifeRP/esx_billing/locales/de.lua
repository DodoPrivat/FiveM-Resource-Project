Locales['de'] = {
  ['invoices'] = 'rechnungen',
  ['invoices_item'] = '$%s',
  ['received_invoice'] = 'you hast eine Rechnung ~r~erhlaten~s~',
  ['paid_invoice'] = 'du ~g~bezahlst~s~ eine Rechnung von ~r~$%s~s~',
  ['received_payment'] = 'du ~g~erhältst~s~ eine Zahlung von ~r~$%s~s~',
  ['player_not_online'] = 'der Spieler ist nicht online',
  ['no_money'] = 'you do not have enough money to pay this bill',
  ['target_no_money'] = 'the player ~r~does not~s~ have enough money to pay the bill!',
}
