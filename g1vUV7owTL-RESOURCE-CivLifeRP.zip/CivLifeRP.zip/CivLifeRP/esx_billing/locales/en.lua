Locales['en'] = {
  ['invoices'] = 'invoices',
  ['invoices_item'] = '$%s',
  ['received_invoice'] = 'you have just received an invoice',
  ['paid_invoice'] = 'you paid an invoice of $%s',
  ['received_payment'] = 'you received a payment of $%s',
  ['player_not_online'] = 'the player is not logged in',
  ['no_money'] = 'you do not have enough money to pay this bill',
  ['target_no_money'] = 'the player does not have enough money to pay the bill!',
}
