Config = {}
Config.Locale = 'en'
Config.NumberOfCopsRequired = 4
Config.Cooldown = 3600
Config.DiscordURL = 'https://ptb.discordapp.com/api/webhooks/584766367274631169/LnB1sOfd8z5Mg41il4C4zJfxKvf4SCFuz_Ifrh96gnxf-0q3479HxShRjrKBxAqLj5KM'


Banks = {
	["fleeca"] = {
		position = { ['x'] = 147.04908752441, ['y'] = -1044.9448242188, ['z'] = 29.36802482605 },
		reward = math.random(20000,32000),
		nameofbank = "Nordea",
		lastrobbed = 0
	},
	["fleeca2"] = {
		position = { ['x'] = -2957.6674804688, ['y'] = 481.45776367188, ['z'] = 15.697026252747 },
		reward = math.random(20000,32000),
		nameofbank = "Fleeca Bank (Highway)",
		lastrobbed = 0
	},
	["blainecounty"] = {
		position = { ['x'] = -107.06505584717, ['y'] = 6474.8012695313, ['z'] = 31.62670135498 },
		reward = math.random(20000,32000),
		nameofbank = "Blaine County Savings",
		lastrobbed = 0
	},
	["PrincipalBank"] = {
		position = { ['x'] = 255.001098632813, ['y'] = 225.855895996094, ['z'] = 101.005694274902 },
		reward = math.random(45000,60000),
		nameofbank = "Swedbank",
		lastrobbed = 0
	}
}
