Config                            = {}

Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }

Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- enable if you're using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false -- enable if you're using esx_license

Config.EnableHandcuffTimer        = true -- enable handcuff timer? will unrestrain player after the time ends
Config.HandcuffTimer              = 10 * 60000 -- 10 mins

Config.EnableJobBlip              = false -- enable blips for colleagues, requires esx_society

Config.MaxInService               = -1
Config.Locale = 'en'

Config.CartelStations = {

	Cartel = {
	

		-- https://wiki.rage.mp/index.php?title=Weapons
		AuthorizedWeapons = {
			{ name = 'WEAPON_ASSAULTRIFLE',     price = 30000 },
			--{ name = 'WEAPON_STUNGUN',     price = 1000 },
			--{ name = 'WEAPON_MICROSMG',     price = 25000 },
			--{ name = 'WEAPON_PUMPSHOTGUN',     price = 35000 },
			--{ name = 'WEAPON_REVOLVER_MK2',     price = 80000 },
			--{ name = 'WEAPON_SAWNOFFSHOTGUN',     price = 40000 },
			--{ name = 'WEAPON_PISTOL50',     price = 35000 },
			--{ name = 'WEAPON_MACHETE',     price = 750 },
            --{ name = 'WEAPON_HATCHET',     price = 800 },
            --{ name = 'WEAPON_KNUCKLE',     price = 2500 },
            --{ name = 'WEAPON_MOLOTOV',     price = 7000 },
            --{ name = 'WEAPON_PISTOL_MK2',     price = 40000 },
            --{ name = 'WEAPON_VINTAGEPISTOL',     price = 25000 },
            --{ name = 'WEAPON_GUSENBERG',     price = 180000 },
            --{ name = 'WEAPON_COMBATPDW',     price = 250000 },
            --{ name = 'WEAPON_ASSAULTRIFLE',     price = 120000 },
            --{ name = 'WEAPON_COMPACTRIFLE',     price = 160000 },
            --{ name = 'WEAPON_DOUBLEACTION',     price = 350000 },
            --{ name = 'WEAPON_BULLPUPRIFLE_MK2',     price = 600000 },
		},

		Cloakrooms = {
			{ x = 9.283, y = 528.914, z = 169.635 },
		},

		Armories = {
			{ x = 1.550, y = 527.397, z = 169.617 },
		},

		Vehicles = {
			{
				Spawner    = { x = 13.40, y = 549.1, z = 175.187 },
				SpawnPoints = {
					{ x = 8.237, y = 556.963, z = 175.266, heading = 90.0, radius = 6.0 }
				}
			},

			{
				Spawner    = { x = 5.29, y = 544.61, z = 174.18 },
				SpawnPoints = {
					{ x = 0.76, y = 552.42, z = 175.96, heading = 115.77, radius = 6.0 }
				}
			}
		},

		VehicleDeleters = {
			{ x = 22.74, y = 545.9, z = 175.027 },
			{ x = 21.35, y = 543.3, z = 175.027 }
		},

		BossActions = {
			{ x = 4.113, y = 526.897, z = 173.628 }
		},

	},

}

-- https://wiki.rage.mp/index.php?title=Vehicles
Config.AuthorizedVehicles = {
	Shared = {
		{
			model = 'cog55',
			label = 'Cognoscenti 55'
		},
		{
			model = 'burrito3',
			label = 'Van'
		}
	},

	asociar = {

	},

	sicario = {

	},

	teniente = {

	},

	capos = {

	},

	consejo = {

	},

	chef = {

	},

	boss = {

	}
}


-- CHECK SKINCHANGER CLIENT MAIN.LUA for matching elements

Config.Uniforms = {
	asociar_wear = {
		male = {

		},
		female = {

		}
	},
	sicario_wear = {
		male = {

		},
		female = {

		}
	},
	teniente_wear = {
		male = {

		},
		female = {

		}
	},
	capos_wear = {
		male = {

		},
		female = {

		}
	},
	consejo_wear = { -- currently the same as intendent_wear
		male = {

		},
		female = {

		}
	},
	boss_wear = { -- currently the same as chef_wear
		male = {

		},
		female = {

		}
	},
	bullet_wear = {
		male = {
			['bproof_1'] = 11,  ['bproof_2'] = 1
		},
		female = {
			['bproof_1'] = 13,  ['bproof_2'] = 1
		}
	},
	gilet_wear = {
		male = {
			['tshirt_1'] = 59,  ['tshirt_2'] = 1
		},
		female = {
			['tshirt_1'] = 36,  ['tshirt_2'] = 1
		}
	}

}