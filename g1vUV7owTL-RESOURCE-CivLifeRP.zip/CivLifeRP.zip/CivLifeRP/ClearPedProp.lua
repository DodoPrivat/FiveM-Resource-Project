--- List of component/props ID
-- gtaxscripting.blogspot.com/2016/04/gta-v-peds-component-and-props.html
function Global.ClearPedProp(ped, propId)
	return _in(0x0943E5B8E078E76E, ped, propId)
end
