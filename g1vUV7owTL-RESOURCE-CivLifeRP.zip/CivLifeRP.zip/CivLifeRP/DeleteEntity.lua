--- Deletes the specified entity, then sets the handle pointed to by the pointer to NULL.
function Global.DeleteEntity(entity)
	return _in(0xAE3CBE5BF394C9C9, _ii(entity) --[[ may be optional ]])
end
