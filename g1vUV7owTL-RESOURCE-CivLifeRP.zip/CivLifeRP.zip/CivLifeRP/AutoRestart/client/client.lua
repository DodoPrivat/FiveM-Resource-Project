ESX = nil

local restartCountdown = false
local restart30 = false
local countdown = 60

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj)ESX = obj end)
        Citizen.Wait(0)
    end
end)

RegisterNetEvent('AutoRestart:Notification')
AddEventHandler('AutoRestart:Notification', function(msg, btmMsg, cd)
    if cd then
        restartCountdown = true
        RestartCountdown()
        TriggerServerEvent("InteractSound_SV:PlayOnAll", "sirenAlarm", 0.1)
        Citizen.Wait(19000)
        TriggerServerEvent("InteractSound_SV:PlayOnAll", "sirenAlarm", 0.1)
        Citizen.Wait(19000)
        TriggerServerEvent("InteractSound_SV:PlayOnAll", "sirenAlarm", 0.1)
    else
        RestartWarning(msg, btmMsg)
    end
end)

RegisterNetEvent('AutoRestart:ping')
AddEventHandler('AutoRestart:ping', function()
  TriggerServerEvent('AutoRestart:kick')
end)

function RestartWarning(message, bottomMsg)
    local timer = 15
    local scaleform = RequestScaleformMovie("MP_BIG_MESSAGE_FREEMODE")
    
    while not HasScaleformMovieLoaded(scaleform) do
        Citizen.Wait(0)
    end
    
    PushScaleformMovieFunction(scaleform, 'SHOW_SHARD_WASTED_MP_MESSAGE')
    PushScaleformMovieFunctionParameterString(message)
    PushScaleformMovieFunctionParameterString(bottomMsg)
    PopScaleformMovieFunctionVoid()
    
    while timer > 0 do
        Citizen.Wait(1)
        timer = timer - 0.01
        
        DrawScaleformMovieFullscreen(scaleform, 255, 255, 255, 255)
    end
    
    SetScaleformMovieAsNoLongerNeeded(scaleform)
end

function RestartCountdown()
    Citizen.CreateThread(function()
        TriggerServerEvent('vSync:blizzardWeather')
        CountdownTimer()
        while true do
            Citizen.Wait(0)
            
            if restartCountdown then
                local scaleform = RequestScaleformMovie("MP_BIG_MESSAGE_FREEMODE")
                
                while not HasScaleformMovieLoaded(scaleform) do
                    Citizen.Wait(0)
                end
                
                PushScaleformMovieFunction(scaleform, 'SHOW_SHARD_WASTED_MP_MESSAGE')
                PushScaleformMovieFunctionParameterString("~r~Tsunami incoming~s~")
                PushScaleformMovieFunctionParameterString("~y~Automatic server restart in " .. countdown .. " seconds.~s~")
                PopScaleformMovieFunctionVoid()
                
                DrawScaleformMovieFullscreen(scaleform, 255, 255, 255, 255)
            end
            
            SetScaleformMovieAsNoLongerNeeded(scaleform)
        end
    end)
end

function CountdownTimer()
    Citizen.CreateThread(function()
        while restartCountdown do
            Citizen.Wait(1000)
            
            if countdown > 0 then
                countdown = countdown - 1
            else
                restartCountdown = false
                countdown = 60
            end
        end
    end)
end
