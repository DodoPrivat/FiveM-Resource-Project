function Global.DisableVehicleImpactExplosionActivation(vehicle, toggle)
	return _in(0xD8050E0EB60CF274, vehicle, toggle)
end
