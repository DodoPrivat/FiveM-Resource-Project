Locales['pl'] = {
	['shop'] = 'sklep',
	['shops'] = 'sklepy',
	['press_menu'] = 'naciśnij ~INPUT_CONTEXT~ żeby wejść do ~y~sklepu~s~.',
	['bought'] = 'właśnie zakupiłeś ~y~%s~s~ x ~b~%s~s~ za ~g~%s $~s~',
	['not_enough'] = 'nie masz ~r~wystarczjąco~s~ pięniędzy, ~y~Brakuje Ci~s~ ~r~$%s~s~!',
	['player_cannot_hold'] = '~r~Nie~s~ masz wystarczająco ~y~wolnego miejsca~s~ w swoim ekwipunku!',
	['shop_confirm'] = 'chcesz kupić %sx %s za $%s?',
	['no'] = 'nie',
	['yes'] = 'tak',
}