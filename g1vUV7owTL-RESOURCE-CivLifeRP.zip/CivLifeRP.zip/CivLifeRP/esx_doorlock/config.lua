Config = {}
Config.Locale = 'en'

Config.DoorList = {

	--
	-- Mission Row First Floor
	--

	-- To locker room & roof
	{
		objName = 'v_ilev_ph_gendoor004',
		objCoords  = {x = 449.698, y = -986.469, z = 30.689},
		textCoords = {x = 450.14, y = -986.79, z = 30.7},
		authorizedJobs = { 'police','offpolice' },
		locked = true
	},

	-- Rooftop
	{
		objName = 'v_ilev_gtdoor02',
		objCoords  = {x = 464.361, y = -984.678, z = 43.834},
		textCoords = {x = 464.42, y = -983.63, z = 43.75},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Hallway to roof
	{
		objName = 'v_ilev_arm_secdoor',
		objCoords  = {x = 461.286, y = -985.320, z = 30.839},
		textCoords = {x = 461.32, y = -986.29, z = 30.69},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Armory
	{
		objName = 'v_ilev_arm_secdoor',
		objCoords  = {x = 452.618, y = -982.702, z = 30.689},
		textCoords = {x = 453.13, y = -982.21, z = 30.99},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Captain Office
	{
		objName = 'v_ilev_ph_gendoor002',
		objCoords  = {x = 447.238, y = -980.630, z = 30.689},
		textCoords = {x = 447.63, y = -980.01, z = 30.69},
		authorizedJobs = { 'police','offpolice' },
		locked = true,
	},

	-- To downstairs (double doors)
	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 443.97, y = -989.033, z = 30.6896},
		textCoords = {x = 444.020, y = -989.445, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 3
	},

	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 445.37, y = -988.705, z = 30.6896},
		textCoords = {x = 445.350, y = -989.445, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 3
	},

	-- 
	-- Mission Row Cells
	--

	-- Main Cells
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 463.815, y = -992.686, z = 24.9149},
		textCoords = {x = 463.30, y = -992.686, z = 25.10},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 1
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 462.381, y = -993.651, z = 24.914},
		textCoords = {x = 461.806, y = -993.308, z = 25.064},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 2
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 462.331, y = -998.152, z = 24.914},
		textCoords = {x = 461.806, y = -998.800, z = 25.064},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 3
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 462.704, y = -1001.92, z = 24.9149},
		textCoords = {x = 461.806, y = -1002.450, z = 25.064},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- To Back
	{
		objName = 'v_ilev_gtdoor',
		objCoords  = {x = 463.478, y = -1003.538, z = 25.005},
		textCoords = {x = 464.54, y = -1003.49, z = 25.00},
		authorizedJobs = { 'police' },
		locked = true
	},

	--
	-- Mission Row Back
	--

	-- Back (double doors)
	{
		objName = 'v_ilev_rc_door2',
		objCoords  = {x = 467.371, y = -1014.452, z = 26.536},
		textCoords = {x = 468.09, y = -1014.452, z = 27.1362},
		authorizedJobs = {  },
		locked = true,
		
	},

	{
		objName = 'v_ilev_rc_door2',
		objCoords  = {x = 469.967, y = -1014.452, z = 26.536},
		textCoords = {x = 469.35, y = -1014.452, z = 27.136},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},

	-- Back Gate
	{
		objName = 'hei_prop_station_gate',
		objCoords  = {x = 488.894, y = -1017.210, z = 27.146},
		textCoords = {x = 488.894, y = -1020.210, z = 30.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 14,
		size = 2
	},

	-- Entrance Gate (Mission Row mod) https://www.gta5-mods.com/maps/mission-row-pd-ymap-fivem-v1
	{
		objName = 'Prop_Gate_airport_01',
		objCoords  = {x = 411.94, y = -1025.39, z = 29.33},
		textCoords = {x = 412.64, y = -1021.49, z = 32.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 14,
		size = 2
	},

	-- Side Door (Mission Row mod) https://www.gta5-mods.com/maps/mission-row-pd-ymap-fivem-v1
	{
		objName = 'Prop_BS_Map_Door_01',
		objCoords  = {x = 423.85, y = -998.05, z = 30.77},
		textCoords = {x = 424.08, y = -998.05, z = 30.89},
		authorizedJobs = { 'police' },
		locked = true
	},

	--
	-- Sandy Shores
	--

	-- Entrance
	{
		objName = 'v_ilev_shrfdoor',
		objCoords  = {x = 1855.105, y = 3683.516, z = 34.266},
		textCoords = {x = 1854.74, y = 3683.46, z = 34.27},
		authorizedJobs = { 'police','offpolice' },
		locked = true
	},

	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = 1849.01, y = 3707.77, z = 1.06},
		textCoords = {x = 1848.67, y = 3707.55, z = 1.06},
		authorizedJobs = { 'police' },
		locked = true
	},


	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = 1847.11, y = 3710.4, z = 1.06},
		textCoords = {x = 1846.75, y = 3710.09, z = 1.06},
		authorizedJobs = { 'police' },
		locked = true
	},


	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = 1843.03, y = 3707.21, z = 1.06},
		textCoords = {x = 1842.86, y = 3706.95, z = 1.06},
		authorizedJobs = { 'police' },
		locked = true
	},

	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = 1845.18, y = 3704.85, z = 1.06},
		textCoords = {x = 1844.84, y = 3704.49, z = 1.06},
		authorizedJobs = { 'police' },
		locked = true
	},


	--
	-- Paleto Bay
	--

	-- Entrance (double doors)
	{
		objName = 'v_ilev_shrf2door',
		objCoords  = {x = -443.14, y = 6015.685, z = 31.716},
		textCoords = {x = -443.14, y = 6015.685, z = 32.00},
		authorizedJobs = { 'police','offpolice' },
		locked = true,
		distance = 2.5
	},

	{
		objName = 'v_ilev_shrf2door',
		objCoords  = {x = -443.951, y = 6016.622, z = 31.716},
		textCoords = {x = -443.951, y = 6016.622, z = 32.00},
		authorizedJobs = { 'police','offpolice' },
		locked = true,
		distance = 2.5
	},

	--
	-- Bolingbroke Penitentiary
	--

	-- Entrance (Two big gates)
	{
		objName = 'prop_gate_prison_01',
		objCoords  = {x = 1844.998, y = 2604.810, z = 44.638},
		textCoords = {x = 1844.998, y = 2608.50, z = 48.00},
		authorizedJobs = { 'police','ambulance' },
		locked = true,
		distance = 12,
		size = 2
	},

	{
		objName = 'prop_gate_prison_01',
		objCoords  = {x = 1818.542, y = 2604.812, z = 44.611},
		textCoords = {x = 1818.542, y = 2608.40, z = 48.00},
		authorizedJobs = { 'police','ambulance' },
		locked = true,
		distance = 12,
		size = 2
	},

	{
		objName = 'v_ilev_cd_entrydoor', -- Visitation Side
		objCoords  = {x = 1693.36, y = 2582.42, z = -69.4},
		textCoords = {x = 1693.36, y = 2582.42, z = -69.4},
		authorizedJobs = { 'police' },
		locked = true,
	},
	
	{
		objName = 'prop_ld_jail_door', -- Jail Door Between
		objCoords  = {x = 1692.29, y = 2579.72, z = -69.38},
		textCoords = {x = 1691.29, y = 2579.72, z = -69.38},
		authorizedJobs = { 'police' },
		locked = true,
	},
		{
		objName = 'v_ilev_cd_entrydoor', -- Prisoner Side
		objCoords  = {x = 1693.16, y = 2578.38, z = -69.4},
		textCoords = {x = 1693.16, y = 2578.38, z = -69.4},
		authorizedJobs = { 'police' },
		locked = true,
	},
		{
		objName = 'v_ilev_cd_entrydoor', -- Room Next To Vistation
		objCoords  = {x = 1703.57, y = 2576.98, z = -69.4},
		textCoords = {x = 1703.57, y = 2576.98, z = -69.4},
		authorizedJobs = { 'police' },
		locked = true,
	},
	--
	-- Addons
	--

	--[[
	-- Entrance Gate (Mission Row mod) https://www.gta5-mods.com/maps/mission-row-pd-ymap-fivem-v1
	{
		objName = 'prop_gate_airport_01',
		objCoords  = {x = 420.133, y = -1017.301, z = 28.086},
		textCoords = {x = 420.133, y = -1021.00, z = 32.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 14,
		size = 2
	}
	--]]


	--
	-- Vespucci PD
	--

	--[[{
		objName = 'xm_prop_iaa_base_door_01',
		objCoords  = {x = 2055.08, y = 2969.86, z = -67.3}, 
		textCoords = {x = 2055.31, y = 2970.20, z = -67.2},
		authorizedJobs = { 'police' },
		locked = false,
	},
	{
		objName = 'xm_prop_iaa_base_door_01',
		objCoords  = {x = 2051.08, y = 2964.16, z = -67.3},
		textCoords = {x = 2051.31, y = 2964.46, z = -67.2},
		authorizedJobs = { 'police' },
		locked = false,
	},
	{
		objName = 'xm_prop_iaa_base_door_01',
		objCoords  = {x = 2051.03, y = 2975.38, z = -67.3},
		textCoords = {x = 2051.29, y = 2975.65, z = -67.2},
		authorizedJobs = { 'police' },
		locked = false,
	},
	{
		objName = 'xm_prop_iaa_base_door_01',
		objCoords  = {x = 2055.11, y = 2981.03, z = -67.3},
		textCoords = {x = 2055.28, y = 2981.40, z = -67.2},
		authorizedJobs = { 'police' },
		locked = false,
	},


	--
	-- Ammunation 
	--

	--{
		objName = 'v_ilev_gc_door04',
		objCoords  = {x = 812.39, y = -2148.18, z = 29.62},
		textCoords = {x = 812.39, y = -2148.18, z = 29.62},
		authorizedJobs = { 'ammunation' , 'police' },
		locked = true,
		distance = 3,
	},
	{
		objName = 'v_ilev_gc_door03',
		objCoords  = {x = 811.28, y = -2148.15, z = 29.62},
		textCoords = {x = 811.28, y = -2148.15, z = 29.62},
		authorizedJobs = { 'ammunation' , 'police' },
		locked = true,
		distance = 3,
	},

	{
		objName = 'v_ilev_gc_door01',
		objCoords  = {x = 826.78, y = -2160.48, z = 29.62},
		textCoords = {x = 826.46, y = -2160.55, z = 29.62},
		authorizedJobs = { 'ammunation' , 'police' },
		locked = true,
		distance = 3,
	},


	--
	-- AutoExotic
	--
	{
		--'objName = 'v_ilev_roc_door3',
		objCoords  = {x = 967.07, y = -3007.44, z = -39.64},
		textCoords = {x = 966.99, y = -3007.77, z = -39.64},
		authorizedJobs = { 'AE' },
		locked = true,
		distance = 3,
	},
	{
		objName = 'v_ilev_roc_door2',
		objCoords  = {x = 961.44, y = -2999.27, z = -39.64},
		textCoords = {x = 961.73, y = -2999.26, z = -39.64},
		authorizedJobs = { 'AE' },
		locked = true,
		distance = 3,
	},]]

	--
	-- Crusade Hospital
	--

	{--Locker Room 1
		objName = 'v_ilev_cor_firedoorwide',
		objCoords  = {x = 271.749, y = -1360.463, z = 24.5919},
		textCoords = {x = 271.749, y = -1360.463, z = 24.5919},
		authorizedJobs = { 'ambulance', 'offambulance' , 'police' , 'offpolice' },
		locked = true,
		distance = 2,
	},
	{--Locker Room 2 
		objName = 'v_ilev_cor_firedoorwide',
		objCoords  = {x = 265.92, y = -1362.97, z = 24.54},
		textCoords = {x = 265.92, y = -1362.97, z = 24.54},
		authorizedJobs = { 'ambulance', 'offambulance' , 'police' , 'offpolice' },
		locked = true,
		distance = 2,
	},
	{--Middle Glass Left 
		objName = 'v_ilev_cor_doorglassb',
		objCoords  = {x = 255.73, y = -1348.02, z = 24.54},
		textCoords = {x = 255.73, y = -1348.02, z = 24.54},
		authorizedJobs = { 'ambulance', 'offambulance' , 'police' , 'offpolice' },
		locked = true,
		distance = 1,
	},
	{--Middle Glass Door Right
		objName = 'v_ilev_cor_doorglassa',
		objCoords  = {x = 256.12, y = -1348.36, z = 24.54},
		textCoords = {x = 256.50, y = -1348.36, z = 24.54},
		authorizedJobs = { 'ambulance', 'offambulance' , 'police' , 'offpolice' },
		locked = true,
		distance = 1,
	},	
	{--Double Doors before elevator left
		objName = 'v_ilev_cor_firedoor',
		objCoords  = {x = 251.77, y = -1365.70, z = 24.54},
		textCoords = {x = 252.33, y = -1365.70, z = 24.54},
		authorizedJobs = { 'ambulance', 'offambulance' , 'police' , 'offpolice' },
		locked = true,
		distance = 2,
	},	
	{--Double Doors before elevator Right
		objName = 'v_ilev_cor_firedoor',
		objCoords  = {x = 252.26, y = -1366.04, z = 24.54},
		textCoords = {x = 252.07, y = -1365.36, z = 24.54},
		authorizedJobs = { 'ambulance', 'offambulance' , 'police' , 'offpolice' },
		locked = true,
		distance = 2,
	},
		{--Double Doors Upstairs Left
		objName = 'v_ilev_cor_firedoor',
		objCoords  = {x = 252.6249, y = -1366.38463, z = 39.85919},
		textCoords = {x = 252.6249, y = -1366.38463, z = 39.85919},
		authorizedJobs = { 'ambulance', 'offambulance' , 'police' , 'offpolice' },
		locked = true,
		distance = 2,
	},
		{--Double Doors Upstairs Right
		objName = 'v_ilev_cor_firedoor',
		objCoords  = {x = 251.749, y = -1365.38463, z = 39.835919},
		textCoords = {x = 251.749, y = -1365.38463, z = 39.835919},
		authorizedJobs = { 'ambulance', 'offambulance' , 'police' , 'offpolice' },
		locked = true,
		distance = 2,
	},
--------- UNICORN
		{
		objName = 'prop_strip_door_01',
		objCoords  = {x = 127.95520, y = -1298.5000, z = 29.41962},
		textCoords = {x = 128.60734558105, y = -1298.5103759766, z = 29.23274230957},
		authorizedJobs = { 'unicorn', 'police' },
		locked = false,
		distance = 2.5
	},

	{
		objName = 'v_ilev_door_orangesolid',
		objCoords  = {x = 113.98220, y = -1297.43000, z = 29.41868},
		textCoords = {x = 114.14762878418, y = -1296.5776367188, z = 29.268840789795},
		authorizedJobs = { 'unicorn', 'police'},
		locked = true,
		distance = 2.5
	},

		{
		objName = 'v_ilev_door_orange',
		objCoords  = {x = 132.23450, y = -1288.30300, z = 29.41947},
		textCoords = {x =132.81440734863, y = -1287.8161621094, z = 29.269550323486},
		authorizedJobs = { 'unicorn', 'police'},
		locked = true,
		distance = 2.5
	},

	{
		objName = 'v_ilev_door_orange',
		objCoords  = {x = 126.90440, y = -1279.91900, z = 29.41947},
		textCoords = {x =127.64332580566, y = -1279.7635498047,z = 29.270198822021},
		authorizedJobs = { 'unicorn', 'police'},
		locked = true,
		distance = 2.5
	},

	{
		objName = 'prop_magenta_door',
		objCoords  = {x = 96.09197, y = -1284.85400, z = 29.43878},
		textCoords = {x = 95.734817504883, y = -1285.4613037109, z = 29.268756866455},
		authorizedJobs = { 'unicorn', 'police'},
		locked = true,
		distance = 2.5
	},

		{
		objName = 'v_ilev_roc_door2',
		objCoords  = {x = 99.08321, y = -1293.70100, z = 29.41868},
		textCoords = {x = 99.801696777344, y = -1293.6994628906, z = 29.268037796021},
		authorizedJobs = { 'unicorn', 'police'},
		locked = true,
		distance = 2.5
	},

	------------------------------------------------------- Grove Street ---------------------------
	{
		objName = 'v_ilev_fa_frontdoor',
		objCoords  = {x = -14.86892, y = -1441.18200, z = 31.19323},
		textCoords = {x = -14.212866783142, y = -1440.9089355469, z = 31.101547241211},
		authorizedJobs = { 'grove', 'police'},
		locked = true,
		distance = 2.5
	},

	{
		objName = 'v_ilev_fa_roomdoor',
		objCoords  = {x = -15.98929, y = -1436.202800, z = 31.19914},
		textCoords = {x = -16.310834884644,y = -1436.7270507813, z = 31.101551055908},
		authorizedJobs = { 'grove', 'police'},
		locked = true,
		distance = 0.9
	},
----------------- LOST MC Location
	{
		objName = 'v_ilev_lostdoor',
		objCoords  = {x = 981.15050, y = -103.225520, z = 74.99358},
		textCoords = {x = 981.73107910156, y = -102.7907409668, z= 74.848808288574},
		authorizedJobs = { 'biker', 'police'},
		locked = true,
		distance = 2.5
	},

		{
		objName = 'v_ilev_losttoiletdoor',
		objCoords  = {x = 985.61040, y = -95.16254, z = 74.99793},
		textCoords = {x = 985.29541015625, y = -94.589424133301, z = 74.848289489746},
		authorizedJobs = { 'biker', 'police'},
		locked = true,
		distance = 0.9
	},

	{
		objName = 'v_ilev_losttoiletdoor',
		objCoords  = {x = 981.72660, y = -95.82788, z = 74.99499},
		textCoords = {x = 981.30627441406, y = -96.480247497559, z = 74.845054626465},
		authorizedJobs = { 'biker', 'police'},
		locked = true,
		distance = 1
	},

	{
		objName = 'prop_damdoor_01',
		objCoords  = {x = 983.86680, y = -142.64140, z = 74.2308},
		textCoords = {x = 983.57287597656, y = -143.18214416504, z = 74.271423339844},
		authorizedJobs = { 'biker', 'police'},
		locked = true,
		distance = 1
	},

	{
		objName = 'prop_com_gar_door_01',
		objCoords  = {x = 982.38460, y = -135.63680, z = 74.08931},
		textCoords = {x = 982.21746826172, y = -135.28010559082, z = 73.097702026367},
		authorizedJobs = { 'biker', 'police'},
		locked = true,
		distance = 7.5
	},

	------------- D&J Mechanic Doors --------------------------
	{
		objName = 'prop_ss1_mpint_garage_cl',
		objCoords  = {x = -222.262830, y = -1159.04200, z = 25.95924},
		textCoords = {x = -222.21, y = -1158.5, z = 23.99},
		authorizedJobs = { 'mechanic', 'police' },
		locked = false,
		distance = 16
	},


------------ BURGER SHOT -----------------------------------
	{
		objName = 'cj_bs_door_l',
		objCoords  = {x = -1196.53900, y = -883.48520, z = 14.25259},
		textCoords = {x = -1197.17, y = -884.06, z = 14.0},
		authorizedJobs = { 'burgershot', 'police', 'ambulance' },
		locked = true,
		distance = 2
	},
		{
		objName = 'cj_bs_door_r',
		objCoords  = {x = -1199.03300, y = -885.16990, z = 14.25259},
		textCoords = {x = -1198.16, y = -884.9, z = 14.0},
		authorizedJobs = { 'burgershot', 'police', 'ambulance' },
		locked = true,
		distance = 2
	},
	{
		objName = 'cj_bs_door_r',
		objCoords  = {x = -1184.89200, y = -883.33770, z = 14.25113},
		textCoords = {x = -1184.49, y = -884.08, z = 14.0},
		authorizedJobs = { 'burgershot', 'police', 'ambulance' },
		locked = true,
		distance = 2
	},
	{
		objName = 'cj_bs_door_l',
		objCoords  = {x = -1183.20700, y = -885.83120, z = 14.25113},
		textCoords = {x = -1183.74, y = -885.25, z = 14.0},
		authorizedJobs = { 'burgershot', 'police', 'ambulance' },
		locked = true,
		distance = 2
	},
		{
		objName = -1628879836,
		objCoords  = {x = -1199.72800, y = -892.04080, z = 14.24617},
		textCoords = {x = -1200.59, y = -892.6, z = 14.0},
		authorizedJobs = { 'burgershot', 'police', 'ambulance' },
		locked = false,
		distance = 2
	},
	{
		objName = 'cj_int_door_24',
		objCoords  = {x = -1195.28200, y = -897.92710, z = 14.24617},
		textCoords = {x = -1195.64, y = -897.31, z = 14.0},
		authorizedJobs = { 'burgershot', 'police', 'ambulance' },
		locked = false,
		distance = 2
	},



	--[ NIGHT CLUB ]
	{
		objName = -1119680854,
		objCoords  = {x = -1613.95600, y = -3008.94800, z = -75.03989},
		textCoords = {x = -1614.61, y = -3008.43, z = -75.21},
		authorizedJobs = { 'galaxy', 'police', 'ambulance' },
		locked = true,
		distance = 2.3
	},

		{
		objName = -1555108147,
		objCoords  = {x = -1607.53600, y = -3005.43100, z = -75.05607},
		textCoords = {x = -1607.47, y = -3006.18, z = -75.21},
		authorizedJobs = { 'galaxy', 'police', 'ambulance' },
		locked = true,
		distance = 2.3
	},
		{
		objName = -1695461688, 
		objCoords  = {x = -1621.21000, y = -3019.87300, z = -75.03989},
		textCoords = {x = -1621.96, y = -3015.9, z = -75.21},
		authorizedJobs = { 'burgershot', 'police', 'ambulance' },
		locked = false,
		distance = 2.3
	},
	{
		objName = -1119680854, 
		objCoords  = {x = -1621.28300, y = -3016.38300, z = -75.04390},
		textCoords = {x = -1621.96, y = -3015.9, z = -75.21},
		authorizedJobs = { 'galaxy', 'police', 'ambulance' },
		locked = true,
		distance = 2.3
	},
		{
		objName = 1695461688, 
		objCoords  = {x = -1621.21000, y = -3019.87300, z = -75.03989},
		textCoords = {x = -1621.24, y = -3019.25, z = -75.21},
		authorizedJobs = { 'galaxy', 'police', 'ambulance' },
		locked = true,
		distance = 2.3
	},
			{
		objName = 390840000, 
		objCoords  = {x = -1583.46500, y = -3004.96000, z = -75.83991},
		textCoords = {x = -1583.59, y = -3005.59, z = -76.0},
		authorizedJobs = { 'galaxy', 'police', 'ambulance' },
		locked = true,
		distance = 2.3
	},

				{
		objName = 390840000, 
		objCoords  = {x = -1581.91200, y = -3010.06200, z = -75.83991},
		textCoords = {x = -1582.59, y = -3010.06, z = -76.0},
		authorizedJobs = { 'galaxy', 'police', 'ambulance' },
		locked = true,
		distance = 2.3
	},
					{
		objName = -1989765534, 
		objCoords  = {x = -1607.48700, y = -3005.43100, z = -78.84087},
		textCoords = {x = -1607.56, y = -3006.07, z = -79.01},
		authorizedJobs = { 'galaxy', 'police', 'ambulance' },
		locked = true,
		distance = 2.3
	},
						{
		objName = 390840000, 
		objCoords  = {x = -1610.12500, y = -3004.97000, z = -78.84087},
		textCoords = {x = -1611.02, y = -3005.07, z = -79.01},
		authorizedJobs = { 'galaxy', 'police', 'ambulance' },
		locked = true,
		distance = 2.3
	},


	-------- Prison Doors
	{
		objName = -1033001619, 
		objCoords  = {x = 1821.17000, y = 2476.26500, z = 45.68915},
		textCoords = {x = 1821.56, y = 2477.28, z = 45.68},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.3
	},
		{
		objName = -1033001619, 
		objCoords  = {x = 1759.62000, y = 2412.83700, z = 45.71166},
		textCoords = {x = 1760.62, y = 2413.39, z = 45.63},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.3
	},
			{
		objName = -1033001619, 
		objCoords  = {x = 1658.58400, y = 2397.72200, z = 45.71526},
		textCoords = {x = 1659.7, y = 2397.73, z = 45.65},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.3
	},
	{
		objName = -1033001619, 
		objCoords  = {x = 1543.24100, y = 2471.29400, z = 45.71201},
		textCoords = {x = 1543.72, y = 2470.32, z = 45.62},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.3
	},

	{
		objName = -1033001619, 
		objCoords  = {x = 1537.811000, y = 2585.99500, z = 45.68915},
		textCoords = {x = 1537.91, y = 2584.85, z = 45.6},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.3
	},

	{
		objName = -1033001619, 
		objCoords  = {x = 1572.66200, y = 2679.19100, z = 45.72976},
		textCoords = {x = 1572.15, y = 2678.26, z = 45.64},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.3
	},

	{
		objName = -1033001619, 
		objCoords  = {x = 1651.16100, y = 2755.43600, z = 45.87868},
		textCoords = {x = 1650.14, y = 2755.0, z = 45.5},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.3
	},

	{
		objName = -1033001619, 
		objCoords  = {x = 1773.10800, y = 2759.70000, z = 45.88673},
		textCoords = {x = 1772.02, y = 2759.86, z = 45.81},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.3
	},

		{
		objName = -1033001619, 
		objCoords  = {x = 1845.7900, y = 2698.62100, z = 45.95531},
		textCoords = {x = 1845.63, y = 2699.7, z = 45.83},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.3
	},

		{
		objName = -1033001619, 
		objCoords  = {x = 1820.77000, y = 2620.77000, z = 45.95126},
		textCoords = {x = 1820.79, y = 2621.86, z = 45.86},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.3
	},
	--
	-- Addons
	--

	--[[
	-- Entrance Gate (Mission Row mod) https://www.gta5-mods.com/maps/mission-row-pd-ymap-fivem-v1
	{
		objName = 'prop_gate_airport_01',
		objCoords  = {x = 420.133, y = -1017.301, z = 28.086},
		textCoords = {x = 420.133, y = -1021.00, z = 32.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 14,
		size = 2
	}
	--]]
}

