--- Returns whether or not the passed camera handle exists.
function Global.DoesCamExist(cam)
	return _in(0xA7A932170592B50E, cam, _r)
end
