Config                        = {}
Config.DrawDistance           = 100
Config.MarkerSize             = {x = 0.5, y = 0.5, z = 0.3}
Config.MarkerColor            = {r = 102, g = 102, b = 204}
Config.RoomMenuMarkerColor    = {r = 102, g = 204, b = 102}
Config.MarkerType             = 2
Config.Zones                  = {}
Config.Properties             = {}
Config.EnablePlayerManagement = false -- If set to true you need esx_realestateagentjob
Config.Locale                 = 'en'

Config.Properties             = {}
