function Global.ClearOverrideWeather()
	return _in(0x338D2E3477711050)
end
