function Global.DrawNotification(blink, p1)
	return _in(0x2ED7843F8F801023, blink, p1, _r, _ri)
end
