Locales['en'] = {
  ['bmshop'] = 'black market shop',
  ['shops'] = 'shops',
  ['press_menu'] = 'press ~INPUT_CONTEXT~ to open the ~r~shop~s~.',
  ['bmshop_item'] = '$%s',
  ['bought'] = 'you just bought %sx %s for $%s',
  ['not_enough'] = 'you do not have enough money',
  ['missing_amount'] = 'you\'re missing $%s!',
  ['player_cannot_hold'] = 'you do not have enough free space in your inventory!',
  ['bmshop_confirm'] = 'buy %sx %s for $%s?',
  ['no'] = 'no',
  ['yes'] = 'yes',
}
