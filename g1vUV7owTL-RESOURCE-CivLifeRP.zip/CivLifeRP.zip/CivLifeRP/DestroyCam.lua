--- BOOL param indicates whether the cam should be destroyed if it belongs to the calling script.
function Global.DestroyCam(cam, thisScriptCheck)
	return _in(0x865908C81A2C22E9, cam, thisScriptCheck)
end
