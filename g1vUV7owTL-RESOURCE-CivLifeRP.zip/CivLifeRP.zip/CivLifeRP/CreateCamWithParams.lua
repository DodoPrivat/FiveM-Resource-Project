--- camName is always set to "DEFAULT_SCRIPTED_CAMERA" in Rockstar's scripts.
-- ------------
-- Camera names found in the b617d scripts:
-- "DEFAULT_ANIMATED_CAMERA"
-- "DEFAULT_SCRIPTED_CAMERA"
-- "DEFAULT_SCRIPTED_FLY_CAMERA"
-- "DEFAULT_SPLINE_CAMERA"
-- ------------
-- Side Note: It seems p8 is basically to represent what would be the bool p1 within CREATE_CAM native. As well as the p9 since it's always 2 in scripts seems to represent what would be the last param within SET_CAM_ROT native which normally would be 2.
function Global.CreateCamWithParams(camName, posX, posY, posZ, rotX, rotY, rotZ, fov, p8, p9)
	return _in(0xB51194800B257161, _ts(camName), posX, posY, posZ, rotX, rotY, rotZ, fov, p8, p9, _r, _ri)
end
