Config              = {}
Config.DrawDistance = 100.0
Config.MaxDelivery	= 10
Config.TruckPrice	= 200
Config.MarkerType                 = 27
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.Locale       = 'en'

Config.Trucks = {
	"buffalo",
	--"packer"	
}

Config.Cloakroom = {
	CloakRoom = {
			Pos   = {x = -1000.4098510742, y = -477.16662597656, z = 50.027565002441},
			Size  = {x = 2.0, y = 2.0, z = 1.0},
			Color = {r = 204, g = 204, b = 0},
			Type  = 1
		},
}

Config.Zones = {
	VehicleSpawner = {
			Pos   = {x = 214.35403442383, y = -1380.8120117188, z = 30.575706481934},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Color = {r = 204, g = 204, b = 0},
			Type  = 1
		},

	VehicleSpawnPoint = {
			Pos   = {x = 218.12886047363, y = -1381.9877929688, z = 30.558242797852},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Type  = -1
		},
}
