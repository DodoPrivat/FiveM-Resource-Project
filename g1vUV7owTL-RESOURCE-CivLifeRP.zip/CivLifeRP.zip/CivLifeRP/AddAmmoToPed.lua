function Global.AddAmmoToPed(ped, weaponHash, ammo)
	return _in(0x78F0424C34306220, ped, _ch(weaponHash), ammo)
end
