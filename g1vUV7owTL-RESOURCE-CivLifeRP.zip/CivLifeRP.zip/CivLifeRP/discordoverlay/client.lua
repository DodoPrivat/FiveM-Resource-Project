Citizen.CreateThread(function()
	while true do
        --This is the Application ID (Replace this with you own)
		SetDiscordAppId(497234299788197898)

        --Here you will have to put the image name.
		SetDiscordRichPresenceAsset('logo_name')
		SetDiscordRichPresenceAssetText('discord.gg/HNcGftj')

        --It updates every one minute just in case.
		Citizen.Wait(60000)
	end
end)