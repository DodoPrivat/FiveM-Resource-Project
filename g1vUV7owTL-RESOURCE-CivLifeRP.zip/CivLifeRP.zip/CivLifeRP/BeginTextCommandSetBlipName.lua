--- Starts a text command to change the name of a blip displayed in the pause menu.
-- This should be paired with [`END_TEXT_COMMAND_SET_BLIP_NAME`](#_0xBC38B49BCB83BC9B), once adding all required text components.
-- @param textLabel The text label to set.
function Global.BeginTextCommandSetBlipName(textLabel)
	return _in(0xF9113A30DE5C6670, _ts(textLabel))
end
