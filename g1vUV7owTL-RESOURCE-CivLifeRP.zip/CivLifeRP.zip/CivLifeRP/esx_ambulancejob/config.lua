Config                            = {}
Config.DrawDistance               = 100.0
Config.Marker                     = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false }
Config.ReviveReward               = 65  -- revive reward, set to 0 if you don't want it enabled
Config.AntiCombatLog              = true -- enable anti-combat logging?
Config.LoadIpl                    = true -- disable if you're using fivem-ipl or other IPL loaders
Config.Locale                     = 'en'

local second = 1000
local minute = 60 * second

Config.EarlyRespawnTimer          = 5 * minute  -- Time til respawn is available
Config.EnablePlayerManagement     = true
Config.RemoveWeaponsAfterRPDeath  = true
Config.RemoveCashAfterRPDeath     = true
Config.RemoveItemsAfterRPDeath    = true
-- Let the player pay for respawning early, only if he can afford it.
Config.EarlyRespawnFine           = true
Config.EarlyRespawnFineAmount     = 350
Config.RespawnPoint = { coords = vector3(341.0, -1397.3, 32.5), heading = 48.5 }
Config.Hospitals = {

	CentralLosSantos = {

		Blip = {
			coords = vector3(307.7, -1433.4, 28.9),
			sprite = 61,
			scale  = 0.8, -- old 1.2
			color  = 2
		},

		AmbulanceActions = { vector3(319.39, -581.03, 42.33)
		},

		Pharmacies = { vector3(311.14, -599.52, 42.3)
		},

		Vehicles = {
			{
				Spawner = vector3(299.54, -603.61, 43.05),
				InsideShop = vector3(446.7, -1355.6, 43.5),
				Marker = { type = 36, x = 1.0, y = 1.0, z = 1.0, r = 100, g = 50, b = 200, a = 100, rotate = true },
				SpawnPoints = {
					{ coords = vector3(288.93, -588.49, 42.36), heading = 340.66, radius = 4.0 },
					{ coords = vector3(285.57, -596.84, 42.45), heading = 340.66, radius = 4.0 }
				}
			}
		},

		Helicopters = {
			{
				Spawner = vector3(343.4, -591.49, 74.03),
				InsideShop = vector3(305.6, -1419.7, 41.5),
				Marker = { type = 34, x = 1.5, y = 1.5, z = 1.5, r = 100, g = 150, b = 150, a = 100, rotate = true },
				SpawnPoints = {
					{ coords = vector3(351.81, -587.63, 73.78), heading = 142.7, radius = 10.0 }
				}
			}
		},

		FastTravels = {

		}

	}
}

Config.AuthorizedVehicles = {

	ambulance = {
		{ model = 'ambulance', label = 'Ambulance Van', price = 1}
	},

	doctor = {
		{ model = 'ambulance', label = 'Ambulance Van', price = 1},
		{ model = 'qrv', label = 'EMS Ford Explorer 2016', price = 1}
	},

	chief_doctor = {
		{ model = 'ambulance', label = 'Ambulance Van', price = 1},
		{ model = 'qrv', label = 'EMS Ford Explorer 2016', price = 1},
		{ model = 'emscharger', label = 'EMS Charger', price = 1}
	},

	boss = {
		{ model = 'ambulance', label = 'Ambulance Van', price = 1},
		{ model = 'qrv', label = 'EMS Ford Explorer 2016', price = 1},
		{ model = 'emscharger', label = 'EMS Charger', price = 1}
	}

}

Config.AuthorizedHelicopters = {

	ambulance = {},

	doctor = {
		{ model = 'polmav', label = 'EMS Mavrick', price = 1 }
	},

	chief_doctor = {
		{ model = 'polmav', label = 'EMS Mavrick', price = 1 },
		{ model = 'seasparrow', label = 'Sea Sparrow', price = 1 }
	},

	boss = {
		{ model = 'polmav', label = 'EMS Mavrick', price = 1 },
		{ model = 'seasparrow', label = 'Sea Sparrow', price = 1 }
	}

}
