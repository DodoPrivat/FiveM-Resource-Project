Config = {}

Config.Locale = 'en'

Config.EnablePrice = true
Config.Price = 20