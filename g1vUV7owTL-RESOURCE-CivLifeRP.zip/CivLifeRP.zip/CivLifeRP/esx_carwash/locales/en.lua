Locales['en'] = {
	['press_wash'] = 'press ~b~ENTER~s~ to wash this vehicle',
	['press_wash_paid'] = 'press ~b~ENTER~s~ to wash this vehicle for ~g~$%s~s~',
	['wash_failed'] = 'you cannot afford an carwash',
	['wash_successful'] = 'your vehicle has been washed',
	['wash_successful_paid'] = 'your vehicle has been washed for ~g~$%s~s~',
}
