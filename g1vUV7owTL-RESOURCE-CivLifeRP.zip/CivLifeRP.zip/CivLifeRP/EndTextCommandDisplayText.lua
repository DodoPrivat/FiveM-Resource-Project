--- After applying the properties to the text (See UI::SET_TEXT_), this will draw the text in the applied position. Also 0.0f < x, y < 1.0f, percentage of the axis.
-- Used to be known as _DRAW_TEXT
function Global.EndTextCommandDisplayText(x, y)
	return _in(0xCD015E5BB0D96A57, x, y)
end
