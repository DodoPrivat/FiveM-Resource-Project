--- Deletes the specified object, then sets the handle pointed to by the pointer to NULL.
-- meme.
function Global.DeleteObject(object)
	return _in(0x539E0AE3E6634B9F, _ii(object) --[[ may be optional ]])
end
