Config = {}
Config.ProgressTypes = {
	Weed = {
		[1] = 'plant',
		[2] = 'water',
		[3] = 'harvest'
	},
	Cocaine = {
		[1] = 'ingredients',
		[2] = 'sample',
		[3] = 'package'
	},
	Meth = {
		[1] = 'ingredients',
		[2] = 'cook',
		[3] = 'package'
	},
	grapes = {
		[1] = 'ingredients',
		[2] = 'cook',
		[3] = 'package'
	}
}

Config.WeedFarms2 = {
	{x = 1058.08, y = -3195.81, z = -40.07},
	--{x = 1926.8653564453, y = 4823.6372070313, z = 44.628428649902} Old location
}

Config.CocaineFarms2 = {	
	{x = 1095.2404785156, y= -3196.767578125, z= -39.993461608887}
}

Config.MethFarms2 = {
	{x = 1005.76, y = -3200.31, z = -39.52}
}