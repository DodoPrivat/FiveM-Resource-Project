local Keys = {
	["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57,
	["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177,
	["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
	["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
	["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
	["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70,
	["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
	["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
	["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118
}

local RequiredPolice = 0
local DelayBetween = 10

ESX = nil
PlayerData = {}

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj)
			ESX = obj

			if ESX.IsPlayerLoaded() == true then
				PlayerData = ESX.GetPlayerData()
			end
		end)

		for i=1, #Config.WeedFarms2, 1 do
			local farm = Config.WeedFarms2[i]

			Marker.AddMarker('weed_farm_' .. i, farm, 'Press ~INPUT_CONTEXT~ to manage the weed plant.', nil, 0, function()
				OpenWeedPlantMenu2('weed_' .. i)
			end, 
			function()
				ESX.UI.Menu.CloseAll()
			end)
		end

		for i=1, #Config.CocaineFarms2, 1 do 
			local farm = Config.CocaineFarms2[i]

			Marker.AddMarker('cocaine_farm_' .. i, farm, 'Press ~INPUT_CONTEXT~ to manage the cocaine.', nil, 0, function()
				OpenCocaineFarmMenu2('cocaine_' .. i)
			end, 
			function()
				ESX.UI.Menu.CloseAll()
			end)
		end

		for i=1, #Config.MethFarms2, 1 do 
			local farm = Config.MethFarms2[i]

			Marker.AddMarker('meth_farm_' .. i, farm, 'Press ~INPUT_CONTEXT~ to manage the meth.', nil, 0, function()
				OpenMethFarmMenu2('meth_' .. i)
			end, 
			function()
				ESX.UI.Menu.CloseAll()
			end)
		end

		Citizen.Wait(0)
	end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	PlayerData.job = job
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        if IsProcess then
            DisableControlAction(0, Keys['E'], true) -- W
			DisableControlAction(0, Keys['H'], true) -- A
			DisableControlAction(0, Keys['X'], true) -- A
        else
            Citizen.Wait(500)
        end
    end
end)

function OpenWeedPlantMenu2(plantId)
	ESX.UI.Menu.CloseAll()
	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'weed_plant', 
		{
			title = 'Weed Plant',
			align = 'bottom-right',
			elements = {
				{
					label = 'Plant Seed',
					value = 'plant_seed'
				},
				{
					label = 'Manage Plant',
					value = 'water_plant'
				},
				{	
					label = 'Harvest Plant',
					value = 'harvest_plant'
				}
			}
		},
		function(data, menu)
            ESX.UI.Menu.CloseAll()
			ESX.TriggerServerCallback('revenge-drugs2:getPolice', function(count)
				if count >= RequiredPolice then
					ESX.TriggerServerCallback('revenge-drugs2:getProgress', function(progress, time)
						if data.current.value == 'plant_seed' then
							if progress.task == 'plant' then
								Citizen.CreateThread(function()
									ESX.TriggerServerCallback('revenge-drugs2:useIngredients', function(state)
										if state == true then
											playAnimation(nil, 'world_human_gardener_plant')
											--FreezeEntityPosition(GetPlayerPed(-1), true)
											TriggerEvent('esx:showNotification', 'You are planting your ~g~weed ~s~Seed')
											progress.task = 'water'
											progress.tasksLeft = 3
											IsProcess = true

											TriggerServerEvent('revenge-drugs2:setProgress', progress)

											Citizen.Wait(80000)
											ClearPedTasks(GetPlayerPed(-1))
											IsProcess = false
											--FreezeEntityPosition(GetPlayerPed(-1), false)
										else
											TriggerEvent('esx:showNotification', 'You need to gather some weed seeds!')
										end
									end, progress)
								end)
							else
								TriggerEvent('esx:showNotification', 'There is already a plant here.')
							end
						elseif data.current.value == 'water_plant' then
							if progress.task == 'water' then
								Citizen.CreateThread(function()
									if progress.delay + DelayBetween < time then
										playAnimation('amb@world_human_bum_wash@male@high@idle_a', 'idle_a')
										TriggerEvent('esx:showNotification', 'You are picking nugs off the ~g~Weed ~s~plant')

										if progress.tasksLeft > 1 then
											progress.tasksLeft = progress.tasksLeft - 1
											progress.delay = time
											--IsProcess = true
										else
											progress.task = 'harvest'
											progress.tasksLeft = 1
											progress.delay = time
											--IsProcess = true
										end

										TriggerServerEvent('revenge-drugs2:setProgress', progress)

										Citizen.Wait(80000)
										ClearPedTasks(GetPlayerPed(-1))
										--IsProcess = false

										ESX.UI.Menu.CloseAll()
									else
										TriggerEvent('esx:showNotification', 'You have already managed the plant.')
									end
								end)
							else
								if progress.task == 'plant' then
									TriggerEvent('esx:showNotification', 'There is no plant here.')
								else
									TriggerEvent('esx:showNotification', 'You have already managed the plant enough.')
									TriggerEvent('esx:showNotification', 'There is no more nugs left on this ~g~weed ~s~plant.')
								end
							end
						elseif data.current.value == 'harvest_plant' then
							if progress.task == 'harvest' then
								Citizen.CreateThread(function()
									if progress.delay + DelayBetween < time then
										progress.task = 'plant'
										progress.tasksLeft = 1
										IsProcess = true
										progress.delay = 0

										TriggerServerEvent('revenge-drugs2:setProgress', progress)

										playAnimation('amb@prop_human_movie_studio_light@base', 'base')
										TriggerEvent('esx:showNotification', 'You are currently bagging the ~g~marijuana.')
										Citizen.Wait(40000)
										ClearPedTasks(GetPlayerPed(-1))
										IsProcess = false

										ESX.TriggerServerCallback('revenge-drugs2:giveRewards', function()
											TriggerEvent('esx:showNotification', 'Harvested the ~g~weed plant.')
											TriggerEvent('esx:showNotification', 'You ~r~Paid ~g~$6250 ~s~to use the facilities.')
											ESX.UI.Menu.CloseAll()
										end, 'weed_pooch', 6)

										ESX.UI.Menu.CloseAll()
									else
										TriggerEvent('esx:showNotification', 'You need to wait for the plant to finish.')		
									end
								end)
							else
								if progress.task == 'plant' then
									TriggerEvent('esx:showNotification', 'There is no plant here.')
								else
									TriggerEvent('esx:showNotification', 'You need to manage the plant first.')
								end
							end
						end
					end, plantId)
				else
					TriggerEvent('esx:showNotification', 'There must be atleast ~b~' .. RequiredPolice .. ' ~w~police in duty to farm drugs.')
				end
			end)
		end,
		function(data, menu)
			menu.close()
		end
	)
end

function OpenCocaineFarmMenu2(plantId)
	ESX.UI.Menu.CloseAll()
	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'cocaine_farm', 
		{
			title = 'Cocaine Farm',
			align = 'bottom-right',
			elements = {
				{
					label = 'Use Ingredients',
					value = 'ingredients'
				},
				{
					label = 'Sample Coke',
					value = 'sample'
				},
				{	
					label = 'Package Coke',
					value = 'package'
				}
			}
		},
		function(data, menu)
                        ESX.UI.Menu.CloseAll()
			ESX.TriggerServerCallback('revenge-drugs2:getPolice', function(count)
				if count >= RequiredPolice then
					ESX.TriggerServerCallback('revenge-drugs2:getProgress', function(progress, time)
						if data.current.value == 'ingredients' then
							if progress.task == 'ingredients' then
								Citizen.CreateThread(function()
									ESX.TriggerServerCallback('revenge-drugs2:useIngredients', function(state)
										if state == true then
											progress.task = 'sample'
											progress.tasksLeft = 3

											TriggerServerEvent('revenge-drugs2:setProgress', progress)
											TriggerEvent('esx:showNotification', 'You are mixing the ~g~ingredients~s~ onto table!')
											playAnimation('mini@repair', 'fixing_a_ped')

											Citizen.Wait(80000)
											ClearPedTasks(GetPlayerPed(-1))

											ESX.UI.Menu.CloseAll()
										else
											TriggerEvent('esx:showNotification', 'You need to gather the coke ingredients first!')
										end
									end, progress)
								end)
							else
								TriggerEvent('esx:showNotification', 'You have already mixed the ingredients.')
							end
						elseif data.current.value == 'sample' then
							if progress.task == 'sample' then
								Citizen.CreateThread(function()
									if progress.delay + DelayBetween < time then
										if progress.tasksLeft > 1 then
											progress.tasksLeft = progress.tasksLeft - 1
											progress.delay = time

										else
											progress.task = 'package'
											progress.tasksLeft = 1
											progress.delay = time
										end

										TriggerServerEvent('revenge-drugs2:setProgress', progress)
										testtext = true
										playAnimation('mini@repair', 'fixing_a_ped')
										TriggerEvent('esx:showNotification', '~o~Tasting the ~s~cocaine~o~....')
										Citizen.Wait(80000)
										ClearPedTasks(GetPlayerPed(-1))

										ESX.UI.Menu.CloseAll()
									else
										TriggerEvent('esx:showNotification', 'You have already sampled the cocaine recently.')
										TriggerEvent('esx:showNotification', '~o~Please wait ~r~70 ~w~seconds ~o~before sampling anymore for your own health')
									end
								end)
							else
								if progress.task == 'ingredients' then
									TriggerEvent('esx:showNotification', 'You need to mix the ingredients first.\n~o~Please wait a few seconds before sampling again!')
								else
									TriggerEvent('esx:showNotification', 'The cocaine is ready for packaging.')
								end
							end
						elseif data.current.value == 'package' then
							if progress.task == 'package' then
								Citizen.CreateThread(function()
									if progress.delay + DelayBetween < time then
										progress.task = 'ingredients'
										progress.tasksLeft = 1
										progress.delay = 0

										TriggerServerEvent('revenge-drugs2:setProgress', progress)

										playAnimation('amb@prop_human_movie_studio_light@base', 'base')
										TriggerEvent('esx:showNotification', '~b~You are packaging the ~s~Cocaine~b~ Into baggies')
										Citizen.Wait(80000)
										ClearPedTasks(GetPlayerPed(-1))
										
										ESX.TriggerServerCallback('revenge-drugs2:giveRewards', function()
											local _source = source
											local xPlayer = ESX.GetPlayerFromId(_source)
											TriggerEvent('esx:showNotification', 'Packaged the cocaine.')
											TriggerEvent('esx:showNotification', '~b~You have ~g~successfuly ~b~packaged the ~s~cocaine~b~!')
											TriggerEvent('esx:showNotification', 'You ~r~Paid ~g~$3750 ~s~to use the facilities.')
											ESX.UI.Menu.CloseAll()
										end, 'coke_pooch', 4)

										ESX.UI.Menu.CloseAll()
									else
										TriggerEvent('esx:showNotification', 'You need to wait for the coke to finish.')		
									end
								end)
							else
								if progress.task == 'ingredients' then
									TriggerEvent('esx:showNotification', 'You need to mix the ingredients first.')
								else
									TriggerEvent('esx:showNotification', 'You need to sample the cocaine first.')
								end
							end
						end
					end, plantId)
				else
					TriggerEvent('esx:showNotification', 'There must be atleast ~b~' .. RequiredPolice .. ' ~w~police in duty to farm drugs.')
				end
			end)
		end,
		function(data, menu)
			menu.close()
		end
	)
end

function OpenMethFarmMenu2(plantId)
	ESX.UI.Menu.CloseAll()
	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'meth_farm', 
		{
			title = 'Meth Farm',
			align = 'bottom-right',
			elements = {
				{
					label = 'Use Ingredients',
					value = 'ingredients'
				},
				{
					label = 'Cook Meth',
					value = 'cook'
				},
				{	
					label = 'Package Meth',
					value = 'package'
				}
			}
		},
		function(data, menu)
            ESX.UI.Menu.CloseAll()
			ESX.TriggerServerCallback('revenge-drugs2:getPolice', function(count)
				if count >= RequiredPolice then
					ESX.TriggerServerCallback('revenge-drugs2:getProgress', function(progress, time)
						if data.current.value == 'ingredients' then
							if progress.task == 'ingredients' then
								Citizen.CreateThread(function()
									ESX.TriggerServerCallback('revenge-drugs2:useIngredients', function(state)
										if state == true then
											playAnimation('mini@repair', 'fixing_a_ped')
											TriggerEvent('esx:showNotification', 'You are mixing the ~b~meth~s~ ingredients!')
											progress.task = 'cook'
											progress.tasksLeft = 3

											TriggerServerEvent('revenge-drugs2:setProgress', progress)

											Citizen.Wait(80000)
											ClearPedTasks(GetPlayerPed(-1))

											ESX.UI.Menu.CloseAll()
										else
											TriggerEvent('esx:showNotification', 'You need to gather the meth ingredients first!')
										end
									end, progress)
								end)
							else
								TriggerEvent('esx:showNotification', 'You have already mixed the ingredients.')
							end
						elseif data.current.value == 'cook' then
							if progress.task == 'cook' then
								Citizen.CreateThread(function()
									if progress.delay + DelayBetween < time then
										playAnimation('mini@repair', 'fixing_a_ped')
										TriggerEvent('esx:showNotification', 'You cooking the ~b~meth~s~!')
										if progress.tasksLeft > 1 then
											progress.tasksLeft = progress.tasksLeft - 1
											progress.delay = time
										else
											progress.task = 'package'
											progress.tasksLeft = 1
											progress.delay = time
										end

										TriggerServerEvent('revenge-drugs2:setProgress', progress)

										Citizen.Wait(80000)
										ClearPedTasks(GetPlayerPed(-1))

										ESX.UI.Menu.CloseAll()
									else
										TriggerEvent('esx:showNotification', 'You are currently cooking the meth.')
										TriggerEvent('esx:showNotification', 'You have to wait ~r~70 seconds ~s~each time you cook till you can cook again.')
									end
								end)
							else
								if progress.task == 'ingredients' then
									TriggerEvent('esx:showNotification', 'You need to mix the ingredients first.')
								else
									TriggerEvent('esx:showNotification', 'The meth is ready for packaging.')
								end
							end
						elseif data.current.value == 'package' then
							if progress.task == 'package' then
								Citizen.CreateThread(function()
									if progress.delay + DelayBetween < time then
										progress.task = 'ingredients'
										progress.tasksLeft = 1
										progress.delay = 0

										TriggerServerEvent('revenge-drugs2:setProgress', progress)

										playAnimation('amb@prop_human_movie_studio_light@base', 'base')
										TriggerEvent('esx:showNotification', 'You are packaging the ~b~meth~s~!')
										Citizen.Wait(80000)
										ClearPedTasks(GetPlayerPed(-1))
										
										ESX.TriggerServerCallback('revenge-drugs2:giveRewards', function()
											TriggerEvent('esx:showNotification', 'Packaged the meth.')

											ESX.UI.Menu.CloseAll()
										end, 'meth_pooch', 20)

										ESX.UI.Menu.CloseAll()
									else
										TriggerEvent('esx:showNotification', 'You need to wait for the meth to finish cooking.')		
									end
								end)
							else
								if progress.task == 'ingredients' then
									TriggerEvent('esx:showNotification', 'You need to mix the ingredients first.')
								else
									TriggerEvent('esx:showNotification', 'You need to cook the meth first.')
								end
							end
						end
					end, plantId)
				else
					TriggerEvent('esx:showNotification', 'There must be atleast ~b~' .. RequiredPolice .. ' ~w~police in duty to farm drugs.')
				end
			end)
		end,
		function(data, menu)
			menu.close()
		end
	)
end

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(2000)

		ESX.TriggerServerCallback('revenge-drugs2:hasDrugs', function(state)
        	hasDrugs = state
        end)
	end
end)

---Citizen.CreateThread(function()
---	while true do
--		Citizen.Wait(0)
---		if testtext == true then
---			Draw3DText(1090.4879150391, -3195.8579101563, -38.993473052979, tostring("~r~Tasting the cocaine"))
---        end)

function drawTxt(x, y, width, height, scale, text, r, g, b, a, outline)
    SetTextFont(0)
    SetTextProportional(0)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextDropShadow(0, 0, 0, 0,255)
    SetTextEdge(1, 0, 0, 0, 255)
    SetTextDropShadow()
    
    if outline == true then
      SetTextOutline()
    end

    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x - width / 2, y - height / 2 + 0.005)
end




function playAnimation(group, animation)
	if group ~= nil then
		Citizen.CreateThread(function()
			RequestAnimDict(group)

			while not HasAnimDictLoaded(group) do
	        	Citizen.Wait(100)
	      	end

	      	TaskPlayAnim(GetPlayerPed(-1), group, animation, 8.0, -8, -1, 49, 0, 0, 0, 0)
		end)
	else
		TaskStartScenarioInPlace(GetPlayerPed(-1), animation, 0, true)
	end
end

function playPedAnimation(ped, group, animation)
	if group ~= nil then
		Citizen.CreateThread(function()
			RequestAnimDict(group)

			while not HasAnimDictLoaded(group) do
	        	Citizen.Wait(100)
	      	end

	      	TaskPlayAnim(ped, group, animation, 8.0, -8, -1, 49, 0, 0, 0, 0)
		end)
	else
		TaskStartScenarioInPlace(ped, animation, 0, true)
	end
end

function Draw3DText(x, y, z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)
 
    local scale = (1/dist)*2
    local fov = (1/GetGameplayCamFov())*100
    local scale = scale*fov
   
    if onScreen then
        SetTextScale(0.0*scale, 0.25*scale)
        SetTextFont(0)
        SetTextProportional(1)
        -- SetTextScale(0.0, 0.55)
        SetTextColour(0, 0, 0, 255)
        SetTextDropshadow(0, 0, 0, 0, 255)
        SetTextEdge(2, 0, 0, 0, 150)
        SetTextDropShadow()
        SetTextOutline()
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
    end
end