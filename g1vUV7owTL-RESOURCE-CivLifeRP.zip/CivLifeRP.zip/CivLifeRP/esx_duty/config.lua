Config                            = {}
Config.DrawDistance               = 100.0
--language currently available EN and SV
Config.Locale = 'en'

Config.Zones = {

  PoliceDuty = {
    Pos   = { x = 444.64, y = -975.29, z = 29.69 },
    --Pos   = { x = 1795.6, y = 2485.2, z = -122.7 },
    Size  = { x = 2.5, y = 2.5, z = 1.5 },
    Color = { r = 0, g = 255, b = 0 },  
    Type  = 27,
  },

  Police2Duty = {
    Pos   = { x = 1856.95, y = 3689.71, z = 33.27 },
    Size  = { x = 2.5, y = 2.5, z = 1.5 },
    Color = { r = 255, g = 127, b = 80 },  
    Type  = 27,
  },

  AmbulanceDuty = {
    Pos = { x = 264.45, y = -1356.84, z = 23.56 },
    Size = { x = 2.5, y = 2.5, z = 1.5 },
    Color = { r = 0, g = 255, b = 0 },
    Type = 27,
  },

  MechanicDuty = {
    Pos = { x = -343.33, y = -124.78, z = 38.01 },
    Size = { x = 2.5, y = 2.5, z = 1.5 },
    Color = { r = 255, g = 255, b = 0 },
    Type = 27,
  },
}