Locales['pl'] = {
  	['duty'] = 'Wciśnij ~INPUT_CONTEXT~ żeby ~g~rozpocząć~s~/~r~zakończyć~s~ służbę',
	['onduty'] = 'Rozpoczynasz służbę.',
	['offduty'] = 'Kończysz służbę.',
	['notpol'] = 'Nie jesteś policjantem.',
	['notamb'] = 'Nie jesteś lekarzem.',
}
