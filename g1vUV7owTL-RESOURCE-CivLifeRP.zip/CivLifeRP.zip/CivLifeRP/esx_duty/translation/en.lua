Locales['en'] = {
  -- regulars
  	['duty'] = 'Press ~INPUT_CONTEXT~ to go ~g~On-duty~s~/~r~Off-duty~s~',
	['onduty'] = 'You went onduty.',
	['offduty'] = 'You went offduty.',
	['notpol'] = 'You are not a policemen.',
	['notamb'] = 'You are not a doctor.',
        ['notmec'] = 'You are not a mechanic.',
}
