Config = {}
Config.ProgressTypes = {
	Weed = {
		[1] = 'plant',
		[2] = 'water',
		[3] = 'harvest'
	},
	Cocaine = {
		[1] = 'ingredients',
		[2] = 'sample',
		[3] = 'package'
	},
	Meth = {
		[1] = 'ingredients',
		[2] = 'cook',
		[3] = 'package'
	},
	grapes = {
		[1] = 'ingredients',
		[2] = 'cook',
		[3] = 'package'
	}
}

Config.WeedFarms = {
	{x = 1058.34, y = -3191.52, z = -40.15},
	--{x = 1922.06, y = 4828.07, z = 44.86} Old location
}

Config.CocaineFarms = {	
	{x = 1099.6306152344, y = -3194.2138671875, z = -39.993476867676}
}

Config.MethFarms = {
	{x = 1005.76, y = -3200.31, z = -39.52}
}