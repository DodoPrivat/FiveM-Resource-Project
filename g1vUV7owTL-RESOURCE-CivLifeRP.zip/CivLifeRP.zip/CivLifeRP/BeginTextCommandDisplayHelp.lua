--- Used to be known as _SET_TEXT_COMPONENT_FORMAT
function Global.BeginTextCommandDisplayHelp(inputType)
	return _in(0x8509B634FBE7DA11, _ts(inputType))
end
