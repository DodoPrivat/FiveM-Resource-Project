--[   Custom NightLife Properties     ]
--[           By KrizFrost            ]
local ESX = nil
local PlayerData                = {}
insidemarkercheck = false -- Defualt insidemarker check (DO NOT CHANGE THIS ONE IS VERY IMPORTANT)
EnterKey = 74
RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  PlayerData = xPlayer
end)
RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
  PlayerData.job = job
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)
privateoffice_Enter = {
	{-1898.46,-572.21,11.84}
}
privateoffice_Exit = {
	{-1901.99,-572.45,19.1}
}




--[[ Markers  ]]


--[[ Private Office Enter]]
Citizen.CreateThread(function ()
	while true do
		local ped = GetPlayerPed(-1)
		Citizen.Wait(0)
			for i = 1, #privateoffice_Enter do
				markerCoords1 = privateoffice_Enter[i]
				DrawMarker(-27, markerCoords1[1], markerCoords1[2], markerCoords1[3], 0, 0, 0, 0, 0, 0, 5.0, 5.0, 2.0, 0, 157, 0, 155, 0, 0, 2, 0, 0, 0, 0)
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), markerCoords1[1], markerCoords1[2], markerCoords1[3], true ) < 1 then  --and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
				 Draw3DText(markerCoords1[1], markerCoords1[2], markerCoords1[3] + 0.2, tostring('~g~[H]~w~ Enter Private Office'))
					if(IsControlJustPressed(1, EnterKey)) then
						DoScreenFadeOut(2700)
						Citizen.Wait(3000)
						 while not HasCollisionLoadedAroundEntity(ped) do
   						 	DoScreenFadeOut(500)
   						 end
						SetEntityCoordsNoOffset(ped, -1902.13, -572.34, 19.1, false, false, false, true)
						SetEntityHeading(ped, 111.31)
						TriggerEvent('InteractSound_CL:PlayOnOne', 'door', 0.8)
						Citizen.Wait(1200)
						DoScreenFadeIn(1200)

						print('entered')
						insidemarkercheck = true
					end
				end
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), markerCoords1[1], markerCoords1[2], markerCoords1[3], true ) > 1 then -- and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
				
				end
			end
	end
end)
--[[ Private Office Exit ]]

Citizen.CreateThread(function ()
	while true do
		local ped = GetPlayerPed(-1)
		Citizen.Wait(0)
			for i = 1, #privateoffice_Exit do
				markerCoords2 = privateoffice_Exit[i]
				DrawMarker(-27, markerCoords2[1], markerCoords2[2], markerCoords2[3], 0, 0, 0, 0, 0, 0, 5.0, 5.0, 2.0, 0, 157, 0, 155, 0, 0, 2, 0, 0, 0, 0)
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), markerCoords2[1], markerCoords2[2], markerCoords2[3], true ) < 1 then  --and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
				 Draw3DText(markerCoords2[1], markerCoords2[2], markerCoords2[3] + 0.2, tostring('~g~[H]~w~ Exit Private Office'))
					if(IsControlJustPressed(1, EnterKey)) then
						DoScreenFadeOut(2700)
						Citizen.Wait(3000)
						SetEntityCoordsNoOffset(ped, -1898.46,-572.21,11.84, false, false, false, true)
						SetEntityHeading(ped, 228)
						TriggerEvent('InteractSound_CL:PlayOnOne', 'door', 0.8)
						Citizen.Wait(1200)
						DoScreenFadeIn(1200)

						print('entered')
						insidemarkercheck = true
					end
				end
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), markerCoords2[1], markerCoords2[2], markerCoords2[3], true ) > 1 then -- and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
				
				end
			end
	end
end)





--[ Functions ]

function Draw3DText(x, y, z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)
 
    local scale = (1/dist)*1
    local fov = (1/GetGameplayCamFov())*100
    local scale = 0.9
   
    if onScreen then
        SetTextScale(0.0*scale, 0.25*scale)
        SetTextFont(0)
        SetTextProportional(1)
        -- SetTextScale(0.0, 0.55)
        SetTextColour(255, 255, 255, 255)
        SetTextDropshadow(0, 0, 0, 0, 255)
        SetTextEdge(2, 0, 0, 0, 150)
        SetTextDropShadow()
        SetTextOutline()
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x,_y)
    local factor = (string.len(text)) / 370
     DrawRect(_x,_y+0.0125, 0.030+ factor, 0.03, 41, 11, 41, 100)
    end
end