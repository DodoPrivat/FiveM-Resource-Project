local blips = {
    -- Example {title="", colour=, id=, x=, y=, z=},

     --{title="Coke Field", colour=40, id=501, x = -2287.48,   y = 2526.39,  z = 2.67},
     --{title="Meth Field", colour=26, id=499, x = 1525.29,   y = 1710.02,  z = 109.00},
     --{title="Weed Field", colour=52, id=496, x = 2224.1,   y = 5576.94,  z = 52.8},
     --{title="Opium Field", colour=60, id=51, x = -1094.09,   y = 4947.28,  z = 217.39},
     {title="Bahama Mamas", colour=48, id=93, x = -1388.89,   y = -585.82,  z = 30.22},
     {title="Hospital", colour=23, id=61, x = 361.89,   y = -598.73,  z = 28.66},
     {title="Money Wash", colour=6, id=500, x = -643.2, y = -1227.48, z = 11.55},
     {title="Plastic Surgery", colour=35, id=480, x = -450.37, y = -340.08, z = 34.5},
     {title="SASP Office", colour=64, id=60, x = 1855.65, y = 3682.64, z = 34.27},
     {title="Garage A", colour=3, id=357, x = 55.59, y = -878.72, z = 29.37}, -- Central Legion Garage
     {title="Garage B", colour=3, id=357, x = -330.22, y = -780.12, z = 37.78}, -- Underground Parking Garage
     {title="Garage C", colour=3, id=357, x = -2032.05, y = -467.13, z = 10.38}, -- Beach Garage
     {title="Garage D", colour=3, id=357, x = 215.800, y = -810.057, z = 29.727}, -- Legion Garage
     {title="Garage E", colour=3, id=357, x = 105.359, y = 6613.586, z = 31.3973}, -- Paleto Bay Garage
     {title="Garage F", colour=3, id=357, x = 1212.32, y = 339.94, z = 80.99}, -- Racetrack Garage
     {title="Garage G", colour=3, id=357, x = 1737.59, y = 3710.2, z = 33.14}, -- Sandy Shores Garage
     {title="Garage H", colour=3, id=357, x = 273.63, y = -344.17, z = 43.92}, -- Courthouse Garage
     {title="Garage I", colour=3, id=357, x = -342.42, y = 265.82, z = 85.5}, -- Tq Garage
     {title="Garage J", colour=3, id=357, x = 344.55, y = -1688.06, z = 31.53}, -- Rancho Garage
     {title="Los Santos Courthouse", colour=5, id=58, x = 235.75, y = -411.18, z = 48.11},
     {title="Casino", colour=5, id=108, x = 927.29, y = 45.09, z = 80.9},
     {title="Burger Shot", colour=1, id=103, x = -1193.29, y = -892.33, z = 14.0},
     {title="Mechanic Repair Shop", colour=18, id=446, x = -222.08, y = -1155.283, z = 23.03},
     {title="Motel", colour=9, id=350, x = 316.03, y = -234.94, z = 53.97},
     --{title="Bank", colour=2, id=108, x = 150.266, y = -1040.203, z = 29.374},
     --{title="Bank", colour=2, id=108, x = -1212.980, y = -330.841, z = 37.787},
     --{title="Bank", colour=2, id=108, x = -2962.582, y = 482.627, z = 15.703},
     --{title="Bank", colour=2, id=108, x = -112.202, y = 6469.295, z = 31.626},
     --{title="Bank", colour=2, id=108, x = 314.187, y = -278.621, z = 54.170},
     --{title="Bank", colour=2, id=108, x = -351.534, y = -49.529, z = 49.042},
     --{title="Bank", colour=2, id=108, x = 241.727, y = 220.706, z = 106.286},
     --{title="Bank", colour=2, id=108, x = 1175.0643310547, y = 2706.6435546875, z = 38.094036102295},

  }
      
Citizen.CreateThread(function()

    for _, info in pairs(blips) do
      info.blip = AddBlipForCoord(info.x, info.y, info.z)
      SetBlipSprite(info.blip, info.id)
      SetBlipDisplay(info.blip, 4)
      SetBlipScale(info.blip, 0.8)
      SetBlipColour(info.blip, info.colour)
      SetBlipAsShortRange(info.blip, true)
      BeginTextCommandSetBlipName("STRING")
      AddTextComponentString(info.title)
      EndTextCommandSetBlipName(info.blip)
    end
end)