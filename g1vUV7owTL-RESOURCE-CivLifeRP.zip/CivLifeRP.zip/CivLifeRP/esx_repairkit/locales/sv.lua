Locales ['sv'] = {
	['used_kit']					= 'du använde ~y~x1 ~b~Reparationskit',
	['must_be_outside']				= 'du måste vara utanför fordonet!',
	['no_vehicle_nearby']			= 'det finns inget ~r~fordon ~w~i närheten',
	['finished_repair']				= '~g~du reparerade fordonet!',
	['abort_hint']					= 'tryck ~INPUT_VEH_DUCK~ för att avbryta',
	['aborted_repair']				= 'du ~r~avbröt ~w~reparationen',
}