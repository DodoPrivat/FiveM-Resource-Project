local Keys = {
	["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57,
	["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177,
	["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
	["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
	["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
	["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70,
	["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
	["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
	["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118
  }
  
  ESX               = nil
  
  Citizen.CreateThread(function()
	  while ESX == nil do
		  TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		  Citizen.Wait(1)
	  end
		PlayerData = ESX.GetPlayerData()
  end)
  
  RegisterNetEvent('esx:playerLoaded')
  AddEventHandler('esx:playerLoaded', function(xPlayer)
	PlayerData = xPlayer
  end)
  
  RegisterNetEvent('esx:setJob')
  AddEventHandler('esx:setJob', function(job)
	PlayerData.job = job
  end)
  
  local Melee = { -1569615261, 1737195953, 1317494643, -1786099057, 1141786504, -2067956739, -868994466 }
  local Knife = { -1716189206, 1223143800, -1955384325, -1833087301, 910830060, }
  local Bullet = { 453432689, 1593441988, 584646201, -1716589765, 324215364, 736523883, -270015777, -1074790547, -2084633992, -1357824103, -1660422300, 2144741730, 487013001, 2017895192, -494615257, -1654528753, 100416529, 205991906, 1119849093 }
  local Animal = { -100946242, 148160082 }
  local FallDamage = { -842959696 }
  local Explosion = { -1568386805, 1305664598, -1312131151, 375527679, 324506233, 1752584910, -1813897027, 741814745, -37975472, 539292904, 341774354, -1090665087 }
  local Gas = { -1600701090 }
  local Burn = { 615608432, 883325847, -544306709 }
  local Drown = { -10959621, 1936677264 }
  local Car = { 133987706, -1553120962 }
  
  parts = {
    ['Right foot'] = 52301,
    ['Left foot'] = 14201,
    ['Right hand'] = 57005,
    ['Left hand'] = 18905,
    ['Right knee'] = 36864,
    ['Left knee'] = 63931,
    ['Head'] = 31086,
    ['neck'] = 39317,
    ['right arm'] = 28252,
    ['left arm'] = 61163,
    ['breast'] = 24818,
    ['pelvis'] = 11816,
    ['right shoulder'] = 40269,
    ['left shoulder'] = 45509,
    ['right wrist'] = 28422,
    ['left wrist'] = 60309,
    ['tongue'] = 47495,
    ['upperlip'] = 20178,
    ['lower lip'] = 17188,
    ['right thigh'] = 51826,
    ['left thigh'] = 58217,
    ['elbow'] = 2992,
    ['right foot'] = 2108,
    ['clavicle'] = 10706,
    ['left eye'] = 45750,
    ['right eye'] = 27474,
    ['spine'] = 57597,
    ['unknown area'] = 0,
}




  function checkArray (array, val)
	  for name, value in ipairs(array) do
		  if value == val then
			  return true
		  end
	  end
  
	  return false
  end
  
  Citizen.CreateThread(function()
	  Citizen.Wait(1000)
		while true do
		  local sleep = 3000
  
		  if not IsPedInAnyVehicle(GetPlayerPed(-1)) then
  
			  local player, distance = ESX.Game.GetClosestPlayer()
  
			  if distance ~= -1 and distance < 10.0 then
  
				  if distance ~= -1 and distance <= 2.0 then	
					  if IsPedDeadOrDying(GetPlayerPed(player)) then
						  Start(GetPlayerPed(player))
					  end
				  end
  
			  else
				  sleep = sleep / 100 * distance 
			  end
  
		  end
  
		  Citizen.Wait(sleep)
  
	  end
  end)
  
  function Start(ped)
	  checking = true
  
	  while checking do
		  Citizen.Wait(5)
  
		  local distance = GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), GetEntityCoords(ped))
  
		  local x,y,z = table.unpack(GetEntityCoords(ped))
  
		  if distance < 2.0 then
		  	if PlayerData.job.name == 'ambulance' or PlayerData.job.name == 'police' then
			  DrawText3D(x,y,z, 'Press [~g~E~s~] to check the person', 0.4)
			  
			  if IsControlPressed(0,  Keys['E']) then
				  OpenDeathMenu(ped)
			  end
		  end
  
		  if distance > 7.5 or not IsPedDeadOrDying(ped) then
			  checking = false
			end
		  end
  
	end
  
end
  
  function OpenDeathMenu(player)
  
	  loadAnimDict('amb@medic@standing@kneel@base')
	  loadAnimDict('anim@gangops@facility@servers@bodysearch@')
  
	  local elements   = {}
  
	  table.insert(elements, {label = 'Identify the cause of death', value = 'deathcause'})
		table.insert(elements, {label = 'Identify the location of the injury', value = 'damage'})
  
  
	  ESX.UI.Menu.Open(
		  'default', GetCurrentResourceName(), 'dead_citizen',
		  {
			  title    = 'EMS menu',
			  align    = 'top-right',
			  elements = elements,
		  },
	  function(data, menu)
		  local ac = data.current.value
  
		  if ac == 'damage' then
  			

			  local bone
			  local success = GetPedLastDamageBone(player,bone)
  
			  local success,bone = GetPedLastDamageBone(player)
			  if success then
				  local x,y,z = table.unpack(GetPedBoneCoords(player, bone))
				local DamagedBone = GetKeyOfValue(parts, bone)
				local timestamp = GetGameTimer()
				while (timestamp + 4500) > GetGameTimer() do

				local DamagedBone = GetKeyOfValue(parts, bone)

				if DamagedBone == nil then
				Citizen.Wait(0)	
				DrawText3D(x, y, z, 'Where the damage occured could not get identified!', 0.4)
				checking = false
				else	

				Citizen.Wait(0)	
				DrawText3D(x, y, z, 'The damage seems to occure here' .. ' '.. DamagedBone, 0.4)
				  checking = false
			  end
			end

				--[[TriggerEvent("pNotify:SendNotification",{
				text = "Personen er skadet her" .. ' ' .. DamagedBone,
				type = "success",
				timeout = (3000),
				layout = "bottomCenter",
				queue = "global",
				animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},
				killer = true,
				})
				
			  else
				TriggerEvent("pNotify:SendNotification",{
				text = "Der kunne ikke findes hvor på kroppen personen er blevet skadet!",
				type = "success",
				timeout = (3000),
				layout = "bottomCenter",
				queue = "global",
				animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},
				killer = true,
				})]]
			  end
		  end
  
		  if ac == 'deathcause' then
			  --gets deathcause
			  local d = GetPedCauseOfDeath(player)		
			  local playerPed = GetPlayerPed(-1)
  
			  --starts animation
  
			  TaskPlayAnim(GetPlayerPed(-1), "amb@medic@standing@kneel@base" ,"base" ,8.0, -8.0, -1, 1, 0, false, false, false )
			  TaskPlayAnim(GetPlayerPed(-1), "anim@gangops@facility@servers@bodysearch@" ,"player_search" ,8.0, -8.0, -1, 48, 0, false, false, false )
  
			  Citizen.Wait(5000)
  
			  --exits animation			
  
			  ClearPedTasksImmediately(playerPed)
  
			  if checkArray(Melee, d) then
				TriggerEvent("pNotify:SendNotification",{
				text = "Probaly hit by something hard in the head",
				type = "success",
				timeout = (3000),
				layout = "bottomCenter",
				queue = "global",
				animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},
				killer = true,
				})
			  elseif checkArray(Bullet, d) then
				TriggerEvent("pNotify:SendNotification",{
				text = "Probaly shot by an bullet, bulletholes in body",
				type = "success",
				timeout = (3000),
				layout = "bottomCenter",
				queue = "global",
				animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},
				killer = true,
				})
			  elseif checkArray(Knife, d) then
				TriggerEvent("pNotify:SendNotification",{
				text = "Probaly knifed by something sharp",
				type = "success",
				timeout = (3000),
				layout = "bottomCenter",
				queue = "global",
				animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},
				killer = true,
				})
			  elseif checkArray(Animal, d) then
				TriggerEvent("pNotify:SendNotification",{
				text = "Probaly bitten by an animal",
				type = "success",
				timeout = (3000),
				layout = "bottomCenter",
				queue = "global",
				animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},
				killer = true,
				})
			  elseif checkArray(FallDamage, d) then
				TriggerEvent("pNotify:SendNotification",{
				text = "Probaly fell, broke both legs",
				type = "success",
				timeout = (3000),
				layout = "bottomCenter",
				queue = "global",
				animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},
				killer = true,
				})
			  elseif checkArray(Explosion, d) then
				TriggerEvent("pNotify:SendNotification",{
				text = "Probaly died by something that explodes",
				type = "success",
				timeout = (3000),
				layout = "bottomCenter",
				queue = "global",
				animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},
				killer = true,
				})
			  elseif checkArray(Gas, d) then
				TriggerEvent("pNotify:SendNotification",{
				text = "Probaly died by gas damages in lungs",
				type = "success",
				timeout = (3000),
				layout = "bottomCenter",
				queue = "global",
				animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},
				killer = true,
				})
			  elseif checkArray(Burn, d) then
				TriggerEvent("pNotify:SendNotification",{
				text = "Probaly died by fire",
				type = "success",
				timeout = (3000),
				layout = "bottomCenter",
				queue = "global",
				animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},
				killer = true,
				})
			  elseif checkArray(Drown, d) then
				TriggerEvent("pNotify:SendNotification",{
				text = "Probaly drowned",
				type = "success",
				timeout = (3000),
				layout = "bottomCenter",
				queue = "global",
				animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},
				killer = true,
				})
			  elseif checkArray(Car, d) then
				TriggerEvent("pNotify:SendNotification",{
				text = "Probaly died in a car accident",
				type = "success",
				timeout = (3000),
				layout = "bottomCenter",
				queue = "global",
				animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},
				killer = true,
				})
			  else
				TriggerEvent("pNotify:SendNotification",{
				text = "Deathcause unknown, he may be damaged by alot of things!",
				type = "success",
				timeout = (3000),
				layout = "bottomCenter",
				queue = "global",
				animation = {open = "gta_effects_fade_in", close = "gta_effects_fade_out"},
				killer = true,
				})
				end
			end
  
	  end,
	  function(data, menu)
		menu.close()
	  end
	)
  end
  
  function loadAnimDict(dict)
	  while (not HasAnimDictLoaded(dict)) do
		  RequestAnimDict(dict)
		  
		  Citizen.Wait(1)
	  end
  end
  
  function DrawText3D(x, y, z, text, scale)
	  local onScreen, _x, _y = World3dToScreen2d(x, y, z)
	  local pX, pY, pZ = table.unpack(GetGameplayCamCoords())
   
	  SetTextScale(scale, scale)
	  SetTextFont(4)
	  SetTextProportional(1)
	  SetTextEntry("STRING")
	  SetTextCentre(1)
	  SetTextColour(255, 255, 255, 215)
   
	  AddTextComponentString(text)
	  DrawText(_x, _y)
   
  end

  function GetKeyOfValue(Table, SearchedFor)
    for Key, Value in pairs(Table) do
        if SearchedFor == Value then
            return Key
        end
    end
    return nil
end
