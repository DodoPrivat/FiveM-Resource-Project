function Global.CreateVehicle(modelHash, x, y, z, heading, networkHandle, vehiclehandle)
	return _in(0xAF35D0D2583051B0, _ch(modelHash), x, y, z, heading, networkHandle, vehiclehandle, _r, _ri)
end
