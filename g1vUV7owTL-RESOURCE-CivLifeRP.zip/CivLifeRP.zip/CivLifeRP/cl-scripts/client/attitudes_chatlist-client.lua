local emotes = {}
emotes['bis'] = {name = 'bis'}
emotes['normal'] = {name = 'normal'}
emotes['female'] = {name = 'female'}
emotes['hobo'] = {name = 'hobo'}
emotes['hurry'] = {name = 'hurry'}
emotes['arrogant'] = {name = 'arrogant'}
emotes['sassy'] = {name = 'sassy'}
emotes['sexy'] = {name = 'sexy'}
emotes['money'] = {name = 'money'}
emotes['shady'] = {name = 'shady'}
emotes['dep'] = {name = 'dep'}
emotes['conf'] = {name = 'conf'}
emotes['muscle'] = {name = 'muscle'}
emotes['injured'] = {name = 'injured'}


RegisterCommand("walks", function(source, args, rawCommand)
    TriggerEvent("chatMessage", "Attitudes", {204, 51, 255}, "(Example: /a dep)")
    local emoteslist = ""
	for k in pairs(emotes) do
		emoteslist = k .. " ".. emoteslist
	end
	TriggerEvent('chatMessage', "", {255, 0, 0}, emoteslist)
end)