local emotes = {}
emotes['salute'] = {name = 'salute'}
emotes['finger-2'] = {name = 'finger-2'}
emotes['surrender-2'] = {name = 'surrender-2'}
emotes['palm'] = {name = 'palm'}
emotes['notes'] = {name = 'notes'}
emotes['call'] = {name = 'call'}
emotes['foldarms-2'] = {name = 'foldarms-2'}
emotes['umbrella'] = {name = 'umbrella'}
emotes['brief-2'] = {name = 'brief-2'}
emotes['damn'] = {name = 'damn'}
emotes['fail'] = {name = 'fail'}
emotes['gang1'] = {name = 'gang1'}
emotes['gang2'] = {name = 'gang2'}
emotes['no'] = {name = 'no'}
emotes['pickbutt'] = {name = 'pickbutt'}
emotes['grabcrotch'] = {name = 'grabcrotch'}
emotes['picknose'] = {name = 'picknose'}
emotes['peace'] = {name = 'peace'}
emotes['cigar-2'] = {name = 'cigar2'}
emotes['joint'] = {name = 'joint'}
emotes['cig'] = {name = 'cig'}
emotes['holdcigar'] = {name = 'holdcigar'}
emotes['holdcig'] = {name = 'holdcig'}
emotes['holdjoint'] = {name = 'holdjoint'}
emotes['dead'] = {name = 'dead'}
emotes['holster'] = {name = 'holster'}
emotes['aim-2'] = {name = 'aim-2'}
emotes['box'] = {name = 'box'}
emotes['slowclap'] = {name = 'slowclap'}
emotes['cheer'] = {name = 'cheer'}
emotes['bum'] = {name = 'bum'}
emotes['lean-3'] = {name = 'lean-3'}
emotes['chair'] = {name = 'chair'}
emotes['sex-2'] = {name = 'sex-2'}
emotes['piss-2'] = {name = 'piss-2'}
emotes['shit'] = {name = 'shit'}
emotes['hug'] = {name = 'hug'}
emotes['jerk'] = {name = 'jerk'}
emotes['hump'] = {name = 'hump'}
emotes['dance1-14'] = {name = 'dance1-14'}
emotes['jazz'] = {name = 'jazz'}
emotes['freakout'] = {name = 'freakout'}
emotes['gym1-2'] = {name = 'gym1-2'}
emotes['yoga'] = {name = 'yoga'}
emotes['dab'] = {name = 'dab'}
emotes['bouncer'] = {name = 'bouncer'}
emotes['nervous'] = {name = 'nervous'}
emotes['stressed'] = {name = 'stressed'}
emotes['flex'] = {name = 'flex'}
emotes['flagdown'] = {name = 'flagdown'}
emotes['smile'] = {name = 'smile'}
emotes['stoned'] = {name = 'stoned'}
emotes['crowdfinger'] = {name = 'crowdfinger'}
emotes['vomit-2'] = {name = 'vomit-2'}
emotes['wave1-4'] = {name = 'wave1-4'}
emotes['airg'] = {name = 'airg'}
emotes['type'] = {name = 'type'}
emotes['striptease1-5'] = {name = 'striptease1-5'}
emotes['sit'] = {name = 'sit'}
emotes['copcrowd'] = {name = 'copcrowd'}
emotes['cop-2'] = {name = 'cop-2'}
emotes['sunbathe-2'] = {name = 'sunbathe-2'}
emotes['smoke'] = {name = 'smoke'}
emotes['weed'] = {name = 'weed'}
emotes['beer-2'] = {name = 'beer-2'}
emotes['sitchair'] = {name = 'sitchair'}
emotes['camera'] = {name = 'camera'}


RegisterCommand("emotes", function(source, args, rawCommand)
    TriggerEvent("chatMessage", "Emotes", {204, 51, 255}, "(Example: /e sit)")
    local emoteslist = ""
	for k in pairs(emotes) do
		emoteslist = k .. " ".. emoteslist
	end
	TriggerEvent('chatMessage', "", {255, 0, 0}, emoteslist)
end)