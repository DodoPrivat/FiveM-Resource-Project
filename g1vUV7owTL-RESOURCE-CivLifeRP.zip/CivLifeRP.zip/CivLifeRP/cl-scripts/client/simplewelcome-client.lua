AddEventHandler("playerSpawned", function(spawn)
	if firstspawn == true then else
	
		--TriggerEvent("chatMessage", "", { 255, 255, 255 }, "^1[Server Message] ^5Remember to join the Discord Server.")
         
             TriggerEvent('chat:addMessage', {
        template = '<div style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(211, 181, 146, 0.68); border-radius: 3px;"><i class="fas fa-cog"></i> Server Message:<br> Remember to join the Discord Server</div>',
    })
		
		firstspawn = true
		
	end
end)

