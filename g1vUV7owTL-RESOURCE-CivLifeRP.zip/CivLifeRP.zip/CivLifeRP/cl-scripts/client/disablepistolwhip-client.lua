Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if IsPedArmed(GetPlayerPed(-1), 6) then
            DisableControlAction(1, 140, true)
        end
    end
end)