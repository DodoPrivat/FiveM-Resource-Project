function Global.DrawRect(posX, posY, width, height, R, G, B, A)
	return _in(0x3A618A217E5154F0, posX, posY, width, height, R, G, B, A)
end
