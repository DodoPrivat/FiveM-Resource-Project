Locales['fr'] = {
	['ooc_help'] = 'ecrit un message hors du personnage',
	['ooc_prefix'] = 'hrp | %s',
	['twt_help'] = 'envoie un tweet',
	['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
	['me_help'] = 'action personnelle',
	['me_prefix'] = 'me | %s',
	['do_help'] = 'rP information', --TODO: check translation
	['do_prefix'] = 'faire | %s',
	['news_help'] = 'annonce une information (ne pas en abuser)',
	['news_prefix'] = 'info | %s',
	['ooc_argument_name'] = 'message',
	['ooc_argument_help'] = 'le message',
	['ooc_unknown_command'] = '^3%s^0 n\'est pas une commande valide!',
}
