Locales['fi'] = {
	['ooc_help'] = 'kirjota hahmon ulkopuolelle liittyvä viesti',
	['ooc_prefix'] = '[OOC] ^0%s',
	['twt_help'] = 'lähetä twiitti',
	['twt_prefix'] = '^4Twitter ^0| ^6@%s',
	['me_help'] = 'Teet jotain',
	['do_help'] = 'roolipeliä tiedot', --TODO: check translation
	['do_prefix'] = 'do | %s',
	['news_help'] = 'ilmoita uutinen (älä abuse)',
	['news_prefix'] = 'news | %s',
	['ooc_argument_name'] = 'viesti',
	['ooc_argument_help'] = 'viestin sisältö',
	['ooc_unknown_command'] = '^3%s^0 ei ole validi komento!',
}
