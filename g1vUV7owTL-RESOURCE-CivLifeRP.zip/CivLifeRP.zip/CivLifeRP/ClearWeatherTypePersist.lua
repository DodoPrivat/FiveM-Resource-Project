function Global.ClearWeatherTypePersist()
	return _in(0xCCC39339BEF76CF5)
end
