-------------- DO NOT TRADE/SELL THIS SCRIPT IT IS 100% FREE ON FIVEM FORUMS ------------------------
--[[
	The Drug Dealer Script
]]
--[[
	Tips:
	• KrizFrost - Base Code
	• qalle - Assisting with the menu [v1.5]

]]


InteractKey = 38 --- E
fuel = 0
finishedfuel = 100


local ESX = nil
local PlayerData                = {}
--[[
	Stages Default = false DO NOT CHANGE THESE!!
]]
repairing = false -- Default repairing status
paynotification = false -- Default Pay Notification Status
insidemarkercheck = false -- Defualt insidemarker check (DO NOT CHANGE THIS ONE IS VERY IMPORTANT)
--[[
	Loading ESX Data
]]

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
  PlayerData.job = job
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)
--[[
	Location of WeedStation If you change this you need to change the 3DText Locations as well 
]]
WeedStation = {
	--{-212.28,-1617.97,34.87} -313.52, y = -1630.87, z = 30.95
	{-313.52,-1630.87,30.95}
}

CokeStation = {
	--{-2044.33,-355.13,22.5}
	{1653.36, 4741.54, 41.03}
}


function DrawSpecialText(m_text, showtime)
	SetTextEntry_2("STRING")
	AddTextComponentString(m_text)
	DrawSubtitleTimed(showtime, 1)
end

Citizen.CreateThread(function ()
	while true do
		Citizen.Wait(0)
			for i = 1, #WeedStation do
				drugCoords2 = WeedStation[i]
				DrawMarker(-27, drugCoords2[1], drugCoords2[2], drugCoords2[3], 0, 0, 0, 0, 0, 0, 5.0, 5.0, 2.0, 0, 157, 0, 155, 0, 0, 2, 0, 0, 0, 0)
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), drugCoords2[1], drugCoords2[2], drugCoords2[3], true ) < 2 then  --and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
				 --Draw3DText2(-212.28,-1617.97,34.87, tostring("~w~Press ~g~[E]~w~ To Interact")) -- Messy but will work
				 Draw3DText2(-313.52,-1630.87,30.95 + 1, tostring("~w~Press ~g~[E]~w~ To Interact")) -- Messy but will work
					if(IsControlJustPressed(1, InteractKey)) then
						DrugWeedMenu()
						insidemarkercheck = true
					end
				end
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), drugCoords2[1], drugCoords2[2], drugCoords2[3], true ) > 2 then -- and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
					    if ESX.UI.Menu.IsOpen('default', GetCurrentResourceName(), 'weed_menu') then
       						ESX.UI.Menu.CloseAll()
   					end
				end
			end
	end
end)


WeedStationDoor = {
	--{-2044.33,-355.13,22.5}
	{465.06, -1512.73, 34.54}
}
Citizen.CreateThread(function ()
	while true do
		Citizen.Wait(0)
			for i = 1, #WeedStationDoor do
				drugdoorCoords2 = WeedStationDoor[i]
				DrawMarker(-27, drugdoorCoords2[1], drugdoorCoords2[2], drugdoorCoords2[3], 0, 0, 0, 0, 0, 0, 5.0, 5.0, 2.0, 0, 157, 0, 155, 0, 0, 2, 0, 0, 0, 0)
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), drugdoorCoords2[1], drugdoorCoords2[2], drugdoorCoords2[3], true ) < 1 then  --and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
				 --Draw3DText2(-212.28,-1617.97,34.87, tostring("~w~Press ~g~[E]~w~ To Interact")) -- Messy but will work
				 Draw3DText2(465.52, -1512.6, 34.4 + 0.3, tostring("~w~~g~[E]~w~ Enter")) -- Messy but will work
					if(IsControlJustPressed(1, InteractKey)) then
						local ped = GetPlayerPed(-1)
				while not HasCollisionLoadedAroundEntity(GetPlayerPed(-1)) do
   				FreezeEntityPosition(ped, true)
   				end
	  					SetEntityCoordsNoOffset(ped, 1066.37, -3183.45, -39.17, false, false, false, true)
	  					SetEntityHeading(ped, 89.32)
	  					FreezeEntityPosition(ped, true)
	  					Citizen.Wait(200)
	  					FreezeEntityPosition(ped, false)
	 					DoScreenFadeIn(500)
						insidemarkercheck = true
					end
				end
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), drugdoorCoords2[1], drugdoorCoords2[2], drugdoorCoords2[3], true ) > 1 then -- and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
				end
			end
	end
end)


WeedStationDoor2 = {
	--{-2044.33,-355.13,22.5}
	{1066.37, -3183.45, -39.17}
}
Citizen.CreateThread(function ()
	while true do
		Citizen.Wait(0)
			for i = 1, #WeedStationDoor2 do
				drugdoorCoords1 = WeedStationDoor2[i]
				DrawMarker(-27, drugdoorCoords1[1], drugdoorCoords1[2], drugdoorCoords1[3], 0, 0, 0, 0, 0, 0, 5.0, 5.0, 2.0, 0, 157, 0, 155, 0, 0, 2, 0, 0, 0, 0)
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), drugdoorCoords1[1], drugdoorCoords1[2], drugdoorCoords1[3], true ) < 1 then  --and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
				 --Draw3DText2(-212.28,-1617.97,34.87, tostring("~w~Press ~g~[E]~w~ To Interact")) -- Messy but will work
				 Draw3DText2(1066.37, -3183.45, -39.17 + 0.3, tostring("~w~~g~[E]~w~ Exit")) -- Messy but will work
					if(IsControlJustPressed(1, InteractKey)) then
						local ped = GetPlayerPed(-1)
	  					SetEntityCoordsNoOffset(ped, 464.18, -1511.72, 34.53, false, false, false, true)
	  					SetEntityHeading(ped, 3.33)
	  					FreezeEntityPosition(ped, true)
	  					Citizen.Wait(200)
	  					FreezeEntityPosition(ped, false)
	 					DoScreenFadeIn(500)
						insidemarkercheck = true
					end
				end
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), drugdoorCoords1[1], drugdoorCoords1[2], drugdoorCoords1[3], true ) > 1 then -- and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
				end
			end
	end
end)

CokeStationDoor = {
	--{-2044.33,-355.13,22.5}
	{-496.51, 79.42, 55.85}
}
Citizen.CreateThread(function ()
	while true do
		Citizen.Wait(0)
			for i = 1, #CokeStationDoor do
				drugdoorCoords3 = CokeStationDoor[i]
				DrawMarker(-27, drugdoorCoords3[1], drugdoorCoords3[2], drugdoorCoords3[3], 0, 0, 0, 0, 0, 0, 5.0, 5.0, 2.0, 0, 157, 0, 155, 0, 0, 2, 0, 0, 0, 0)
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), drugdoorCoords3[1], drugdoorCoords3[2], drugdoorCoords3[3], true ) < 1 then  --and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
				 --Draw3DText2(-212.28,-1617.97,34.87, tostring("~w~Press ~g~[E]~w~ To Interact")) -- Messy but will work
				 Draw3DText2(-496.51, 79.42, 55.85 + 0.3, tostring("~w~~g~[E]~w~ Enter")) -- Messy but will work
					if(IsControlJustPressed(1, InteractKey)) then
						local ped = GetPlayerPed(-1)
	  					SetEntityCoordsNoOffset(ped, 1088.76, -3188.07, -39.0, false, false, false, true)
	  					SetEntityHeading(ped, 181.0)
	  					FreezeEntityPosition(ped, true)
	  					Citizen.Wait(200)
	  					FreezeEntityPosition(ped, false)
	 					DoScreenFadeIn(500)
						insidemarkercheck = true
					end
				end
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), drugdoorCoords3[1], drugdoorCoords3[2], drugdoorCoords3[3], true ) > 1 then -- and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
				end
			end
	end
end)

CokeStationDoor2 = {
	--{-2044.33,-355.13,22.5}
	{1088.68, -3187.57, -39.0}
}
Citizen.CreateThread(function ()
	while true do
		Citizen.Wait(0)
			for i = 1, #CokeStationDoor2 do
				drugdoorCoords4 = CokeStationDoor2[i]
				DrawMarker(-27, drugdoorCoords4[1], drugdoorCoords4[2], drugdoorCoords4[3], 0, 0, 0, 0, 0, 0, 5.0, 5.0, 2.0, 0, 157, 0, 155, 0, 0, 2, 0, 0, 0, 0)
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), drugdoorCoords4[1], drugdoorCoords4[2], drugdoorCoords4[3], true ) < 1 then  --and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
				 --Draw3DText2(-212.28,-1617.97,34.87, tostring("~w~Press ~g~[E]~w~ To Interact")) -- Messy but will work
				 Draw3DText2(1088.68, -3187.57, -39.0 + 0.3, tostring("~w~~g~[E]~w~ Exit")) -- Messy but will work
					if(IsControlJustPressed(1, InteractKey)) then
						local ped = GetPlayerPed(-1)
	  					SetEntityCoordsNoOffset(ped, -497.75, 80.24, 55.93, false, false, false, true)
	  					SetEntityHeading(ped, 79.46)
	  					FreezeEntityPosition(ped, true)
	  					Citizen.Wait(200)
	  					FreezeEntityPosition(ped, false)
	 					DoScreenFadeIn(500)
						insidemarkercheck = true
						insidemarkercheck = true
					end
				end
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), drugdoorCoords4[1], drugdoorCoords4[2], drugdoorCoords4[3], true ) > 1 then -- and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
				end
			end
	end
end)



Citizen.CreateThread(function ()
	while true do
		Citizen.Wait(0)
			for i = 1, #CokeStation do
				drugCoords3 = CokeStation[i]
				DrawMarker(-27, drugCoords3[1], drugCoords3[2], drugCoords3[3], 0, 0, 0, 0, 0, 0, 5.0, 5.0, 2.0, 0, 157, 0, 155, 0, 0, 2, 0, 0, 0, 0)
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), drugCoords3[1], drugCoords3[2], drugCoords3[3], true ) < 2 then  --and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
				 --Draw3DText2(-2044.33,-355.13,22.5, tostring("~w~Press ~g~[E]~w~ To Interact")) -- Messy but will work
				 Draw3DText2(1653.36, 4741.54, 41.03 + 1, tostring("~w~Press ~g~[E]~w~ To Interact")) -- Messy but will work
					if(IsControlJustPressed(1, InteractKey)) then
						DrugCokeMenu()
						insidemarkercheck = true
					end
				end
				if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), drugCoords3[1], drugCoords3[2], drugCoords3[3], true ) > 2 then -- and PlayerData.job ~= nil and PlayerData.job.name == 'mecano'
					    if ESX.UI.Menu.IsOpen('default', GetCurrentResourceName(), 'coke_menu') then
       						ESX.UI.Menu.CloseAll()
   					end
				end
			end
	end
end)
local menuEnabled = false 
function ToggleActionMenu()
	-- Make the menuEnabled variable not itself 
	-- e.g. not true = false, not false = true 
	menuEnabled = not menuEnabled

	if ( menuEnabled ) then 
		-- Focuses on the NUI, the second parameter toggles the 
		-- onscreen mouse cursor. 
		SetNuiFocus( true, true )

		-- Sends a message to the JavaScript side, telling it to 
		-- open the menu. 
		SendNUIMessage({
			showmenu = true 
		})
	else 
		-- Bring the focus back to the game
		SetNuiFocus( false )

		-- Sends a message to the JavaScript side, telling it to
		-- close the menu.
		SendNUIMessage({
			hidemenu = true 
		})
	end 
end 
--DO-NOT-EDIT-BELLOW-THIS-LINE--
--DO-NOT-EDIT-BELLOW-THIS-LINE--
--DO-NOT-EDIT-BELLOW-THIS-LINE--
--DO-NOT-EDIT-BELLOW-THIS-LINE--
--DO-NOT-EDIT-BELLOW-THIS-LINE--


--DO-NOT-EDIT-BELLOW-THIS-LINE--
--DO-NOT-EDIT-BELLOW-THIS-LINE--
--DO-NOT-EDIT-BELLOW-THIS-LINE--
--DO-NOT-EDIT-BELLOW-THIS-LINE--

--[[ 

		Regular Repair Option Event
]]

RegisterNetEvent('esx_drugdealer:successcoke')
AddEventHandler('esx_drugdealer:successcoke', function(price)
local ped = GetPlayerPed(-1)
	RequestAnimDict("mp_common")
TaskPlayAnim(npc2, 'mp_common','givetake1_a' ,3.0, -1, -1, 50, 0, false, false, false)
TaskPlayAnim(PlayerPedId(), 'mp_common','givetake1_a' ,3.0, -1, -1, 50, 0, false, false, false)
FreezeEntityPosition(ped, true)
FreezeEntityPosition(npc2, true)
Citizen.Wait(3000)
ClearPedTasksImmediately(PlayerPedId())
ClearPedTasksImmediately(npc2)
FreezeEntityPosition(ped, false)
PlayAmbientSpeechWithVoice(npc2, 'GENERIC_THANKS', 'S_M_Y_HWAYCOP_01_BLACK_FULL_02', 'SPEECH_PARAMS_FORCE_SHOUTED', 0)
end)


RegisterNetEvent('esx_drugdealer:successweed')
AddEventHandler('esx_drugdealer:successweed', function(price)
	local ped = GetPlayerPed(-1)
	RequestAnimDict("mp_common")
TaskPlayAnim(npc, 'mp_common','givetake1_a' ,3.0, -1, -1, 50, 0, false, false, false)
TaskPlayAnim(PlayerPedId(), 'mp_common','givetake1_a' ,3.0, -1, -1, 50, 0, false, false, false)
FreezeEntityPosition(ped, true)
FreezeEntityPosition(npc, true)
Citizen.Wait(3000)
ClearPedTasksImmediately(PlayerPedId())
ClearPedTasksImmediately(npc)
FreezeEntityPosition(ped, false)
PlayAmbientSpeechWithVoice(npc, 'GENERIC_THANKS', 'S_M_Y_HWAYCOP_01_BLACK_FULL_02', 'SPEECH_PARAMS_FORCE_SHOUTED', 0)
end)

RegisterNetEvent('esx_drugdealer:intro')
AddEventHandler('esx_drugdealer:intro', function()
 PlayAmbientSpeechWithVoice(npc, 'GENERIC_HI_01', 'A_F_M_BEACH_01_WHITE_FULL_01', 'GENERIC_HI', 0)
	end)
--[[ 

		Premium Repair Option Event
]]
    --[[ 

	Not enough money display for Regular Option

	]]

RegisterNetEvent('esx_drugdealer:notenoughmoneycoke')
AddEventHandler('esx_drugdealer:notenoughmoneycoke', function(moneyleft)
--	TriggerEvent('chatMessage', 'Bilvasken', {255, 0, 0}, "Du har ikke penge nok, du mangler ^1kr" .. moneyleft .. "") -- danish
	TriggerEvent('chatMessage', 'Drug Dealer', {255, 0, 0}, "You are to damn broke. You're missing ^1$" .. moneyleft .. "") 
	PlayAmbientSpeechWithVoice(np2, 'GENERIC_INSULT', 'S_M_Y_HWAYCOP_01_BLACK_FULL_01', 'SPEECH_PARAMS_FORCE_SHOUTED', 0)
	DrawSpecialText(msg, 5000)
	Wait(5000)
end)

RegisterNetEvent('esx_drugdealer:notenoughmoneyweed')
AddEventHandler('esx_drugdealer:notenoughmoneyweed', function(moneyleft)
--	TriggerEvent('chatMessage', 'Bilvasken', {255, 0, 0}, "Du har ikke penge nok, du mangler ^1kr" .. moneyleft .. "") -- danish
	TriggerEvent('chatMessage', 'Drug Dealer', {255, 0, 0}, "You are t damn broke. You're missing ^1$" .. moneyleft .. "") 
	PlayAmbientSpeechWithVoice(npc, 'GENERIC_INSULT', 'S_M_Y_HWAYCOP_01_BLACK_FULL_01', 'SPEECH_PARAMS_FORCE_SHOUTED', 0)
	DrawSpecialText(msg, 5000)
	Wait(5000)
end)
    --[[ 

	Not enough money display for Premium Option

	]]

    --[[ 

	3DTextDisplay

	]]

function Draw3DText(x, y, z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)
 
    local scale = (1/dist)*1
    local fov = (1/GetGameplayCamFov())*100
    local scale = 1.1
   
    if onScreen then
        SetTextScale(0.0*scale, 0.25*scale)
        SetTextFont(2)
        SetTextProportional(1)
        -- SetTextScale(0.0, 0.55)
        SetTextColour(0, 0, 0, 255)
        SetTextDropshadow(0, 0, 0, 0, 255)
        SetTextEdge(2, 0, 0, 0, 150)
        SetTextDropShadow()
        SetTextOutline()
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
    end
end

function Draw3DText2(x, y, z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)
 
    local scale = (1/dist)*1
    local fov = (1/GetGameplayCamFov())*100
    local scale = 0.9
   
    if onScreen then
        SetTextScale(0.0*scale, 0.25*scale)
        SetTextFont(0)
        SetTextProportional(1)
        -- SetTextScale(0.0, 0.55)
        SetTextColour(0, 0, 0, 255)
        SetTextDropshadow(0, 0, 0, 0, 255)
        SetTextEdge(2, 0, 0, 0, 150)
        SetTextDropShadow()
        SetTextOutline()
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x,_y+0.0125, 0.013+ factor, 0.03, 41, 11, 41, 68)
    end
end


function DrugWeedMenu() -- Credits qalle for assisting with this Love ya Qalle ;) NO HOMO

    local elements = {
        { label = 'Purchase Weed Seed x1 - <font color="red">$120</font>', value = "weed_seed2" }, -- Purchase the stuff( UPDARTE PRICE IF YOU CHANGED IT IN THE CONFIG)
        { label = 'Exit', value = "weed_quit" } --- Maybe add some chance to get the location of the drug spot ;) ?
    }

    ESX.UI.Menu.Open(
        'default', GetCurrentResourceName(), 'weed_menu',
        {
            title    = "<font color='lightblue' font-size='15px'>Weed Dealer</font>",
            align    = 'center',
            elements = elements
        },
    function(data, menu)

        local action = data.current.value

        if action == "weed_seed2" then
        	TriggerServerEvent('esx_drugdealer:checkmoneyweed')
        elseif action == "weed_quit" then
        PlayAmbientSpeechWithVoice(npc, 'GENERIC_INSULT', 'S_M_Y_HWAYCOP_01_BLACK_FULL_01', 'SPEECH_PARAMS_FORCE_SHOUTED', 0)
             menu.close()
        end

        menu.close()

    end, function(data, menu)
        menu.close()
    end)

end

function DrugCokeMenu() -- Credits qalle for assisting with this Love ya Qalle ;) NO HOMO

    local elements = {
        { label = 'Purchase Coca leaf x1 - <font color="red">$200</font>', value = "coke_stuff" }, -- Purchase the stuff( UPDARTE PRICE IF YOU CHANGED IT IN THE CONFIG)
        { label = 'Exit', value = "coke_quit" } --- Maybe add some chance to get the location of the drug spot ;) ?
    }

    ESX.UI.Menu.Open(
        'default', GetCurrentResourceName(), 'coke_menu',
        {
            title    = "<font color='white' font-size='15px'>Coke Dealer</font>",
            align    = 'center',
            elements = elements
        },
    function(data, menu)

        local action = data.current.value

        if action == "coke_stuff" then
        	TriggerServerEvent('esx_drugdealer:checkmoneycoke')
        elseif action == "coke_quit" then
        PlayAmbientSpeechWithVoice(npc2, 'GENERIC_INSULT', 'S_M_Y_HWAYCOP_01_BLACK_FULL_01', 'SPEECH_PARAMS_FORCE_SHOUTED', 0)
             menu.close()
        end

        menu.close()

    end, function(data, menu)
        menu.close()
    end)

end

function GetClosestVehicleToPlayer()
	local player = PlayerId()
	local plyPed = GetPlayerPed(player)
	local plyPos = GetEntityCoords(plyPed, false)
	local plyOffset = GetOffsetFromEntityInWorldCoords(plyPed, 0.0, 1.0, 0.0)
	local radius = 3.0
	local rayHandle = StartShapeTestCapsule(plyPos.x, plyPos.y, plyPos.z, plyOffset.x, plyOffset.y, plyOffset.z, radius, 10, plyPed, 7)
	local _, _, _, _, vehicle = GetShapeTestResult(rayHandle)
	return vehicle
end
-------------- DO NOT TRADE/SELL THIS SCRIPT IT IS 100% FREE ON FIVEM FORUMS ------------------------
-------------- DO NOT TRADE/SELL THIS SCRIPT IT IS 100% FREE ON FIVEM FORUMS ------------------------
-------------- DO NOT TRADE/SELL THIS SCRIPT IT IS 100% FREE ON FIVEM FORUMS ------------------------
-------------- DO NOT TRADE/SELL THIS SCRIPT IT IS 100% FREE ON FIVEM FORUMS ------------------------
-------------- DO NOT TRADE/SELL THIS SCRIPT IT IS 100% FREE ON FIVEM FORUMS ------------------------

local weeddealer = { -- -313.52,-1630.87,30.95
    {name="weed Dealer", id=153, x =-313.52, y = -1630.87, z = 30.95, color = 6, heading=303.23, scale=0.9 },
}
local cokedealer = { -- 1653.36, 4741.54, 41.03
    {name="Coke Dealer", id=-22, x =1653.36, y =4741.54, z =41.03, color = 6, heading=103.74, scale=0.9 },
}


---------- FONCTIONS ----------

function Notify(text)
    SetNotificationTextEntry('STRING')
    AddTextComponentString(text)
    DrawNotification(false, false)
end

function ShowInfo(text, state)
    SetTextComponentFormat("STRING")
    AddTextComponentString(text)DisplayHelpTextFromStringLabel(0, state, 0, -1)
end

---------- CITIZEN COKE ----------

Citizen.CreateThread(function()
    RequestModel(GetHashKey("csb_roccopelosi"))
    while not HasModelLoaded(GetHashKey("csb_roccopelosi")) do
        Wait(1)
    end

    for _, item in pairs(cokedealer) do
        npc2 = CreatePed(4, 0xaa64168c, 1653.36, 4741.54, 41.03, item.heading, false, true)
        SetEntityHeading(npc2, item.heading)
        FreezeEntityPosition(npc2, true)
        SetEntityInvincible(npc2, true)
        SetBlockingOfNonTemporaryEvents(npc2, true)
    end
end)



--[[

WEEED 
]]
---------- CITIZEN COKE ----------

Citizen.CreateThread(function()
    RequestModel(GetHashKey("ig_claypain"))
    while not HasModelLoaded(GetHashKey("ig_claypain")) do
        Wait(1)
    end

    for _, item in pairs(weeddealer) do
        npc = CreatePed(4, 0x9d0087a8, -313.52,-1630.87,30.95, item.heading, false, true)
        SetEntityHeading(npc, item.heading)
        FreezeEntityPosition(npc, true)
        SetEntityInvincible(npc, true)
        SetBlockingOfNonTemporaryEvents(npc, true)
    end
end)