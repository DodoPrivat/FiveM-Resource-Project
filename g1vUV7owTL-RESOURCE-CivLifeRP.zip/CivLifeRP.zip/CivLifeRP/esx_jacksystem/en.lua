Locales['en'] = {
  ['911'] = 'Central: A car alarm just triggered.',
  ['please_wait'] = 'Break-in takes ~b~ %s seconds~s~',
  ['stolen_car'] = 'Car stolen',
  ['vehicle_notunlocked'] = 'Break-in ~r~failed~s~',
  ['vehicle_unlocked'] = 'Break-in ~g~succes~s~',
  ['not_work_with_player_car'] = 'You can\'t steal other players car',
  ['cancel_message'] = 'Press ~r~E~s~ to stop the break-in',
}
