ESX              = nil
local PlayerData = {}
local taskbartimer = 34000
Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
	
	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end
	
	PlayerData = ESX.GetPlayerData()
end)


function getNearestVeh(pos)
	local entityWorld = GetOffsetFromEntityInWorldCoords(GetPlayerPed(-1), 0.0, 20.0, 0.0)
	local rayHandle = CastRayPointToPoint(pos.x, pos.y, pos.z, entityWorld.x, entityWorld.y, entityWorld.z, 10, GetPlayerPed(-1), 0)
	local _, _, _, _, vehicleHandle = GetRaycastResult(rayHandle)
	return vehicleHandle
end

function getVehUnder(pos)
	local entityWorld = GetOffsetFromEntityInWorldCoords(GetPlayerPed(-1), 0.0, 0.0, -10.0)
	local rayHandle = CastRayPointToPoint(pos.x, pos.y, pos.z, entityWorld.x, entityWorld.y, entityWorld.z, 10, GetPlayerPed(-1), 0)
	local _, _, _, _, vehicleHandle = GetRaycastResult(rayHandle)
	return vehicleHandle
end

-- Script that checks whether the player tries to attack the car, and then make the NPC run away, to prevent the NPC from "taking the fight"
Citizen.CreateThread(function()
	while true do
		local pos = GetEntityCoords(PlayerPedId())
		if (IsShockingEventInSphere(105, pos.x, pos.y, pos.z, 10.0) or IsPedInMeleeCombat(GetPlayerPed(-1))) then
			local veh = getNearestVeh(pos)
			if(not IsEntityAVehicle(veh)) then
				veh = getVehUnder(pos)
			end
			if IsEntityAVehicle(veh) then
				local ped = GetPedInVehicleSeat(veh, -1)
				if (ped ~= 0) then
					TaskSetBlockingOfNonTemporaryEvents(ped, true)
					TaskVehicleMissionPedTarget(ped, veh, PlayerPedId(), 8, 15.0, 790564, 300.0, 15.0, 1)
				end
			end
		end
	Citizen.Wait(0)
	end
end)


Citizen.CreateThread(function()
	local recentlyEntered = ""
	while true do
		-- gets if player is entering vehicle
		if DoesEntityExist(GetVehiclePedIsTryingToEnter(PlayerPedId())) then
		
			-- gets vehicle player is trying to enter
			local veh = GetVehiclePedIsTryingToEnter(PlayerPedId())
			local plate = GetVehicleNumberPlateText(veh)
			-- First a simple check to avoid spam-enter bugs
			if(recentlyEntered ~= plate) then
				recentlyEntered = plate
				local lock = GetVehicleDoorLockStatus(veh)
				local ped = GetPedInVehicleSeat(veh, -1)
				-- Check that vehicle is not locked and has a pedestrian in it
				if(lock < 2 and ped ~= 0 and IsPedAPlayer(ped) == false) then
					local xPlayer = ESX.GetPlayerData()
				
					-- check if got lucky
					local lucky = (math.random(100) < 10)
				
					if not lucky then
						TaskSetBlockingOfNonTemporaryEvents(ped, true)
						TriggerServerEvent('esx_nocarjack:setVehicleDoorsForEveryone', veh, 2, plate)
					end
				end
			end
		end
	Citizen.Wait(0)
	end
end)

RegisterNetEvent('esx_nocarjack:setVehicleDoors')
AddEventHandler('esx_nocarjack:setVehicleDoors', function(veh, doors)
	--Redo check on each client for security
	local lock = GetVehicleDoorLockStatus(veh)
	local ped = GetPedInVehicleSeat(veh, -1)
	if(lock < 2 and ped ~= 0 and IsPedAPlayer(ped) == false) then
		SetVehicleDoorsLocked(veh, doors)
		TaskVehicleMissionPedTarget(ped, veh, PlayerPedId(), 8, 15.0, 790564, 300.0, 15.0, 1)
	end
end)

--
--
-- Parked cars
--
--
Config = {}
local callCopsChance = 100
local successChance = 60 
Config.Locale        = 'en'

local seconds    = 1000
local vehicle    = nil
local carAlarm   = false
local cops       = 0
local callcops   = 0
local carblips   = {}
local timer      = 0
local isStealing = false
local vehunlock  = false
local vehplate   = nil
local alarm      = false
local SystemType = 0

Citizen.CreateThread(function()
	local recentlyEntered = ""
	while true do
		-- gets if player is entering vehicle
		if DoesEntityExist(GetVehiclePedIsTryingToEnter(PlayerPedId())) then
		
			-- gets vehicle player is trying to enter
			local veh = GetVehiclePedIsTryingToEnter(PlayerPedId())
			local plate = GetVehicleNumberPlateText(veh)
			-- First a simple check to avoid spam-enter bugs
			if(recentlyEntered ~= plate) then
				recentlyEntered = plate
				local lock = GetVehicleDoorLockStatus(veh)
				local ped = GetPedInVehicleSeat(veh, -1)
				-- Check that vehicle is not locked and has a pedestrian in it
				if(lock == 7 and ped == 0) then
					SetVehicleDoorsLocked(veh, 2)
					SetVehicleDoorsLockedForAllPlayers(veh, true)
				end
			end
		end
	Citizen.Wait(0)
	end
end)

-- Check that player does not move
Citizen.CreateThread(function()
local playerPed = PlayerPedId()
	while true do
		Citizen.Wait(0)
		if isStealing then
			local coordx,coordy,coordz = table.unpack(GetEntityCoords(playerPed,true))
			Citizen.Wait(1 * seconds)
			local newx,newy,newz = table.unpack(GetEntityCoords(playerPed,true))
			if GetDistanceBetweenCoords(coordx,coordy,coordz, newx,newy,newz) > 2 then
				isStealing = false
				timer      = 0
			end
		end
	end
end)

-- Animation loop when picking a car lock
Citizen.CreateThread(function()
local playerPed = PlayerPedId()
	while true do
		Citizen.Wait(0)
		if timer > (15 * seconds) and isStealing then
			Citizen.Wait(19 * seconds)
			if timer > (4 * seconds) and isStealing then
				if(isStealing) then
					local ad 			  = "missheistfbisetup1"
					loadAnimDict( ad )
					TaskPlayAnim( playerPed, ad, "hassle_intro_loop_f", 8.0, 1.0, -1, 33, 0, 0, 0, 0 )
				end
			end
		end
	end
end)

---
---	Net events
---

-- Update number of online cops
RegisterNetEvent('esx_ownedcarthief:howmanycops2')
AddEventHandler('esx_ownedcarthief:howmanycops2', function(data)
  cops = data
end)

-- Show notification that a car is being stolen
RegisterNetEvent('esx_ownedcarthief:911')
AddEventHandler('esx_ownedcarthief:911', function(gx, gy, gz, blipt)
	local XBlipTime = blipt
	local transG = 250
	local crimeBlip = AddBlipForCoord(gx, gy, gz)
	SetBlipSprite(crimeBlip , 161)
	SetBlipScale(crimeBlip , 2.0)
	SetBlipColour(crimeBlip, 1)
	PulseBlip(crimeBlip)
	while transG ~= 0 do
		Wait(30 * XBlipTime)
		transG = transG - 1
		if transG == 0 then
			SetBlipSprite(crimeBlip,  2)
			return
		end
	end
end)

-- Start stealing a car
RegisterNetEvent('esx_ownedcarthief:stealcar')
AddEventHandler('esx_ownedcarthief:stealcar', function(item)

    vehicle    = ESX.Game.GetVehicleInDirection()
    isStealing = false
    timer      = 0
local playerPed       = PlayerPedId()
local coords          = GetEntityCoords(playerPed, true)
local vehicleData     = ESX.Game.GetVehicleProperties(vehicle)
local CheckOwnedPlate = false
local itemused        = item
local ad 			  = "missheistfbisetup1"
	  vehplate        = vehicleData.plate
	  

	TriggerServerEvent('esx_ownedcarthief:howmanycops')
	ESX.UI.Menu.CloseAll()
	if IsAnyVehicleNearPoint(coords.x, coords.y, coords.z, 3.0) and not IsPedInAnyVehicle(playerPed, true) and vehicleData ~= nil then
		ESX.TriggerServerCallback('esx_ownedcarthief:isPlateTaken', function (isPlateTaken)
			if isPlateTaken then
				--ESX.ShowNotification(_U('not_work_with_player_car'))
				TriggerEvent('notification', 'You cannot steal other players vehicles', 2)
			elseif not isPlateTaken then
				TriggerServerEvent('esx_ownedcarthief:itemused', itemused)
				if itemused == "hammerwirecutter" then
					timer = (20 * seconds)
					callcops = 1
					loadAnimDict( ad )
					TaskPlayAnim( playerPed, ad, "hassle_intro_loop_f", 8.0, 1.0, -1, 33, 0, 0, 0, 0 )
					if taskbartimer ~= 100 then
				exports["t0sic_loadingbar"]:StartDelayedFunction("Attemting to lockpick...", taskbartimer, function()

				end)
			end
				end
				
				isStealing = true
				ShowTimer()

				if callcops <= callCopsChance then
					-- Start alarm thread
					Citizen.CreateThread(function()
						while timer > 0 and isStealing do
							SetVehicleAlarmTimeLeft(vehicle, 20000)
							SetVehicleAlarm(vehicle, 1)
							StartVehicleAlarm(vehicle)
							local waitFrom = timer
							while 20000 > waitFrom - timer and isStealing do
								Citizen.Wait(50)
							end
						end
					end)
					TriggerServerEvent('esx_ownedcarthief:callcops', coords.x, coords.y, coords.z)			
				end
			end
		end, vehicleData.plate)
	end
end)

function loadAnimDict(dict)
    while (not HasAnimDictLoaded(dict)) do
        RequestAnimDict(dict)
        Citizen.Wait(5)
    end
end

-- Functionality for GPS
RegisterNetEvent('esx_ownedcarthief:GPSBlip')
AddEventHandler('esx_ownedcarthief:GPSBlip', function(id, data)
	local AlarmStatus = data
	local PID  = id
	local veh  = GetVehiclePedIsIn(GetPlayerPed(GetPlayerFromServerId(PID)), false)
	local veh2 = ESX.Game.GetVehicleInDirection()
	if AlarmStatus then
		createBlip(veh)
		alarm = true
	else
		removeBlip(veh)
		removeBlip(veh2)
		alarm     = false
		vehunlock = false
	end

end)

-- Functionality for GPS
RegisterNetEvent('esx_ownedcarthief:removeBlip')
AddEventHandler('esx_ownedcarthief:removeBlip', function()
	TriggerServerEvent('esx_ownedcarthief:alarmgps', false ,false)
end)


---------
--		Functions
---------

function removeBlip(data)
	local existingBlip = data

	for k, existingBlip in pairs(carblips) do
		RemoveBlip(existingBlip)
	end
end

function ShowTimer()

	Citizen.CreateThread(function()
		while timer > 0 do
			Citizen.Wait(5)
			local   playerPed  = PlayerPedId()
			-- Info(_U('cancel_message'))
			-- If E is pressed, cancel the theft
			--[[
			if(IsControlJustPressed(1, 38)) then
				isStealing = false
				timer = 0
				taskbartimer = 100
				ClearPedTasksImmediately(playerPed)
				return
			end
			]]
			-- If vehicle moves away, cancel the theft
			local coords = GetEntityCoords(playerPed, true)
			if(not IsAnyVehicleNearPoint(coords.x, coords.y, coords.z, 3.0)) then
				isStealing = false
				timer = 0
				ClearPedTasksImmediately(playerPed)
				return
			end
			
			-- If player is hit by something, cancel the theft
			if(IsPedRagdoll(playerPed)) then
				isStealing = false
				timer = 0
				ClearPedTasksImmediately(playerPed)
				return
			end
			
			raw_seconds = timer/1000
			secondsString = stringsplit(raw_seconds, ".")[1]


			timer = timer - 10
		end
		
		while timer == 0 and isStealing do
			        isStealing = false
			local 	vehicle2   = ESX.Game.GetVehicleInDirection()
			local   playerPed  = PlayerPedId()
			local   succes     = math.random(1,101)

			ClearPedTasksImmediately(playerPed)
			if vehicle == vehicle2 then
				if succes <= successChance then
					SetVehicleDoorsLocked(vehicle, 1)
					SetVehicleDoorsLockedForAllPlayers(vehicle, false)
					if callcops <= callCopsChance then
						vehunlock = true
					end
					--SetVehicleDoorBroken(vehicle2, 0, false)
					--ESX.ShowNotification(_U('vehicle_unlocked'))
					TriggerEvent('notification', 'Vehincle unlocked.')
				else
					--ESX.ShowNotification(_U('vehicle_notunlocked'))
					TriggerEvent('notification', 'Break-in: Failed', 2)
				end
			end
		end
	end)
end

function stringsplit(inputstr, sep)
  if sep == nil then
      sep = "%s"
  end
  local t={} ; i=1
  for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
      t[i] = str
      i = i + 1
  end
  return t
end

function Info(text, loop)
			SetTextComponentFormat("STRING")
			AddTextComponentString(text)
			DisplayHelpTextFromStringLabel(0, loop, 1, 0)
end

function createBlip(id)
	local veh  = id
	local blip = GetBlipFromEntity(veh)

	if not DoesBlipExist(blip) then -- Add blip and create head display on player
		blip = AddBlipForEntity(veh)
		SetBlipSprite(blip, 161)
		ShowHeadingIndicatorOnBlip(blip, true) -- Player Blip indicator
		SetBlipRotation(blip, math.ceil(GetEntityHeading(veh))) -- update rotation
		BeginTextCommandSetBlipName("STRING")
		AddTextComponentString(_U('stolen_car'))
		EndTextCommandSetBlipName(blip)
		SetBlipScale(blip, 1.5) -- set scale
		SetBlipAsShortRange(blip, true)
		
		table.insert(carblips, blip) -- add blip to array so we can remove it later
	end
end