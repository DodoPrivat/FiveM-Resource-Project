Locales['sv'] = {
	['used_bread'] = 'du käkade upp en bit ~b~bröd~s~',
	['used_water'] = 'du drack upp en ~b~vattenflaska~s~',
}