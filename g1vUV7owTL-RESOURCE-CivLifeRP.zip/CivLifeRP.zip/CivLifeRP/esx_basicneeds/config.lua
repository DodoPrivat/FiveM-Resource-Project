Config = {}
Config.Locale = 'en'