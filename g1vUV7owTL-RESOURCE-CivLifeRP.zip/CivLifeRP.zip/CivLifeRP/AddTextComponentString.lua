--- Adds an arbitrary string as a text component placeholder, replacing `~a~` in the current text command's text label.
-- See the documentation on text formatting for more information.
-- @param text A string to add of up to 99 characters. This can contain additional `~` formatting directives.
function Global.AddTextComponentString(text)
	return _in(0x6C188BE134E074AA, _ts(text))
end
