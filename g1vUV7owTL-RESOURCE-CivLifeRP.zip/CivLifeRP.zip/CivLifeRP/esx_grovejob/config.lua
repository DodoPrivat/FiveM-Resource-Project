Config                            = {}

Config.DrawDistance               = 100.0
Config.MarkerType                 = 2
Config.MarkerSize                 = { x = 0.5, y = 0.5, z = 0.5 }
Config.MarkerColor                = { r = 7, g = 176, b = 44 }

Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- enable if you're using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false -- enable if you're using esx_license

Config.EnableHandcuffTimer        = true -- enable handcuff timer? will unrestrain player after the time ends
Config.HandcuffTimer              = 10 * 60000 -- 10 mins

Config.EnableJobBlip              = false -- enable blips for colleagues, requires esx_society

Config.MaxInService               = -1
Config.Locale = 'en'

Config.GroveStations = {

	Grove = {
	

		-- https://wiki.rage.mp/index.php?title=Weapons
		AuthorizedWeapons = {
			{ name = 'WEAPON_MICROSMG',     price = 11000 },
			--{ name = 'WEAPON_STUNGUN',     price = 1000 },
			--{ name = 'WEAPON_MICROSMG',     price = 25000 },
			--{ name = 'WEAPON_PUMPSHOTGUN',     price = 35000 },
			--{ name = 'WEAPON_REVOLVER_MK2',     price = 80000 },
			--{ name = 'WEAPON_SAWNOFFSHOTGUN',     price = 40000 },
			--{ name = 'WEAPON_PISTOL50',     price = 35000 },
			--{ name = 'WEAPON_MACHETE',     price = 750 },
            --{ name = 'WEAPON_HATCHET',     price = 800 },
            --{ name = 'WEAPON_KNUCKLE',     price = 2500 },
            --{ name = 'WEAPON_MOLOTOV',     price = 7000 },
            --{ name = 'WEAPON_PISTOL_MK2',     price = 40000 },
            --{ name = 'WEAPON_VINTAGEPISTOL',     price = 25000 },
            --{ name = 'WEAPON_GUSENBERG',     price = 180000 },
            --{ name = 'WEAPON_COMBATPDW',     price = 250000 },
            --{ name = 'WEAPON_ASSAULTRIFLE',     price = 120000 },
            --{ name = 'WEAPON_COMPACTRIFLE',     price = 160000 },
            --{ name = 'WEAPON_DOUBLEACTION',     price = 350000 },
            --{ name = 'WEAPON_BULLPUPRIFLE_MK2',     price = 600000 },
		},

		Cloakrooms = {
			{ x = -18.316884994507, y = -1438.61328125, z = 31.101543426514 },
		},

		Armories = {
			{ x = -17.134414672852, y = -1430.4561767578, z = 31.101528167725 },
		},

		Vehicles = {
			{
				Spawner    = { x = -25.224924087524, y = -1434.8931884766, z = 30.653142929077 },
				SpawnPoints = {
					{ x = -24.449729919434, y = -1441.3275146484, z = 30.653142929077, heading = 90.0, radius = 6.0 }
				}
			}
		},

		VehicleDeleters = {
			{ x = -26.673856735229, y = -1427.6628417969, z = 30.672258377075 }
		},

		BossActions = {
			{ x = -9.7409744262695, y = -1434.5415039063, z = 31.101552963257}
		},

	},

}

-- https://wiki.rage.mp/index.php?title=Vehicles
Config.AuthorizedVehicles = {
	Shared = {
		{
			model = 'dubsta',
			label = 'Dubsta'
		},
		{
			model = 'faction3',
			label = 'Donk'
		}
	},

	babygangsta = {

	},

	gangsta = {

	},

	og = {

	},

	chef = {

	},

	boss = {

	}
}


-- CHECK SKINCHANGER CLIENT MAIN.LUA for matching elements

Config.Uniforms = {
	babygangsta_wear = {
		male = {

		},
		female = {

		}
	},
	gangsta_wear = {
		male = {

		},
		female = {

		}
	},
	og_wear = {
		male = {

		},
		female = {

		}
	},
	boss_wear = { -- currently the same as chef_wear
		male = {

		},
		female = {

		}
	},
	bullet_wear = {
		male = {
			['bproof_1'] = 11,  ['bproof_2'] = 1
		},
		female = {
			['bproof_1'] = 13,  ['bproof_2'] = 1
		}
	},
	gilet_wear = {
		male = {
			['tshirt_1'] = 59,  ['tshirt_2'] = 1
		},
		female = {
			['tshirt_1'] = 36,  ['tshirt_2'] = 1
		}
	}

}