function Global.EndFindVehicle(findHandle)
	return _in(0x9227415a, findHandle)
end
