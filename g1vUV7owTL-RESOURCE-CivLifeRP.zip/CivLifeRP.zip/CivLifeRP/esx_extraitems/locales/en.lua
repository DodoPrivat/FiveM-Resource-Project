Locales ['en'] = {
	-- Weapon Clip
	--['clip_use'] = 'You have used a loader',
	--['clip_no_weapon'] = 'You do not have a weapon in your hand',
	--['clip_not_suitable'] = 'These ammunitions are not suitable for this weapon',
}
