function Global.CellCamActivate(p0, p1)
	return _in(0xFDE8F069C542D126, p0, p1)
end
