--- Sets property to int.
function Global.DecorSetInt(entity, propertyName, value)
	return _in(0x0CE3AA5E1CA19E10, entity, _ts(propertyName), value, _r)
end
