Locales['en'] = {
  ['valid_purchase'] = 'validate this purchase?',
  ['yes'] = 'yes',
  ['no'] = 'no',
  ['not_enough_money'] = 'you do not have enough money',
  ['press_access'] = 'press ~INPUT_CONTEXT~ to access the ~g~barber store~s~',
  ['barber_blip'] = 'barber Shop',
  ['you_paid'] = 'you paid $%s',
}
