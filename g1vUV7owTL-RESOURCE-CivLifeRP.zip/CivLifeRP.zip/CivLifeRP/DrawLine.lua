function Global.DrawLine(x1, y1, z1, x2, y2, z2, r, g, b, alpha)
	return _in(0x6B7256074AE34680, x1, y1, z1, x2, y2, z2, r, g, b, alpha)
end
