DiscordWebhookSystemInfos = 'https://ptb.discordapp.com/api/webhooks/583454374588842006/_u0fhNHNkK52vyBK1yeiZSFxBn42f45xiudXKdPrp6aFR21ngR16TtJmcKif-A22nIsl'
DiscordWebhookKillinglogs = 'https://ptb.discordapp.com/api/webhooks/583454818740338699/-Z9D9H3R09RscyY2IIHkOULnUWawAL8Et8vA6jM7GzehkjYrIydP8FeBu3l90AXG4Yl_'
DiscordWebhookChat = 'https://discordapp.com/api/webhooks/583454985610854441/hWzPZcYLWctg7YALtTL-StYhsifMocmmXGtY0xVbrOBh-HOhSsUdTPJh9X7MYQumn2wk'

SystemAvatar = 'https://i.imgur.com/1LYpjQI.png'

UserAvatar = 'https://i.imgur.com/1LYpjQI.png'

SystemName = 'SYSTEM'


--[[ Special Commands formatting
		 *YOUR_TEXT*			--> Make Text Italics in Discord
		**YOUR_TEXT**			--> Make Text Bold in Discord
	   ***YOUR_TEXT***			--> Make Text Italics & Bold in Discord
		__YOUR_TEXT__			--> Underline Text in Discord
	   __*YOUR_TEXT*__			--> Underline Text and make it Italics in Discord
	  __**YOUR_TEXT**__			--> Underline Text and make it Bold in Discord
	 __***YOUR_TEXT***__		--> Underline Text and make it Italics & Bold in Discord
		~~YOUR_TEXT~~			--> Strikethrough Text in Discord
]]
-- Use 'USERNAME_NEEDED_HERE' without the quotes if you need a Users Name in a special command
-- Use 'USERID_NEEDED_HERE' without the quotes if you need a Users ID in a special command


-- These special commands will be printed differently in discord, depending on what you set it to
SpecialCommands = {
				   {'/ooc', '**[OOC]:**'},
				   {'/911', '**[911]: (CALLER ID: [ USERNAME_NEEDED_HERE | USERID_NEEDED_HERE ])**'},
				  }

						
-- These blacklisted commands will not be printed in discord
BlacklistedCommands = {
					   '/AnyCommand',
					   '/AnyCommand2',
					  }

-- These Commands will use their own webhook
OwnWebhookCommands = {
					  {'/AnotherCommand', 'WEBHOOK_LINK_HERE'},
					  {'/AnotherCommand2', 'WEBHOOK_LINK_HERE'},
					 }

-- These Commands will be sent as TTS messages
TTSCommands = {
			   '/Whatever',
			   '/Whatever2',
			  }

