Locales['en'] = {
  ['male'] = 'male',
  ['female'] = 'female',
  ['carjack'] = '~b~[DISPATCH] ~g~10-35 ~o~Carjack in progress~s~: a ~r~%s~s~ was spotted jacking an ~o~%s~s~ at ~y~%s~s~',
  ['combat'] = '~b~[DISPATCH] ~g~10-35 ~o~Fight in progress~s~: a ~r~%s~s~ has been spotted fighting at ~y~%s~s~',
  ['gunshot'] = '~b~[DISPATCH] ~g~10-35 ~o~Shots fired~s~ by a ~r~%s~s~ at ~y~%s~s~',
  ['speed'] = '~b~[DISPATCH] ~g~10-35 ~o~Speeding~s~ by a ~r~%s~s~ at ~y~%s~s~',
}