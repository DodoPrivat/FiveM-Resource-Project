function Global.ClearDrawOrigin()
	return _in(0xFF0B610F6BE0D7AF)
end
