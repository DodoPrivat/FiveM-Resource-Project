function Global.ClearPedTasks(ped)
	return _in(0xE1EF3C1216AFF2CD, ped)
end
