Locales ['en'] = {
	['tattoo_shop_nearby'] = 'press ~INPUT_PICKUP~ to access the ~g~tattoo shop~s~.',
	['money_amount']       = '<span style="color:green;">$%s</span>',
	['part']               = 'part %s',
	['go_back_to_menu']    = '< Go back',
	['tattoo_item']        = 'tattoo %s - %s',
	['tattoos']            = 'tattoos',
	['tattoo_shop']        = 'tattoo Shop',
	['bought_tattoo']      = 'you bought a tattoo for $%s',
	['not_enough_money']   = 'you don\'t have enough money for that tattoo!',
	['missing_money']   = 'you are missing $%s'
}