Locales ['sv'] = {
	['tattoo_shop_nearby'] = 'tryck ~INPUT_PICKUP~ för att öppna ~y~tatueringsaffären~s~.',
	['money_amount']       = '<span style="color:green;">%s SEK</span>',
	['part']               = 'sida %s',
	['go_back_to_menu']    = '< Gå tillbaka',
	['tattoo_item']        = 'tatuering nummer %s - %s',
	['tattoos']            = 'tatueringar',
	['tattoo_shop']        = 'tatueringsaffär',
	['bought_tattoo']      = 'du köpte ~y~en tatuering~s~ för ~r~%s SEK~s~',
	['not_enough_money']   = 'du har ~r~inte råd~s~ för denna ~y~tatuering~s~! Du saknar ~r~%s SEK~s~'
}