ui_page "ui.html"

files {
    "ui.html",
    "ui.css",
    "MagmaWave.otf",
    "hungericon.png",
    "thirsticon.png",
    "blood20.png",
    "blood45.png",
    "vest20.png",
    "vest45.png",
    "vest100.png",
    "MagmaWave.otf",
    'bloodscreen.png',
    'energyfull.png',
    'energyout.png',
    "ui.js",
    "broken1.png",
    "broken2.png",
    "tried.png"
}

client_script {
    'client.lua'
}