Config = {}
Config.Locale = 'en'

Config.RequiredCopsRob = 2
Config.MaxWindows = 15
Config.SecBetwNextRob = 1800 --1 hour
Config.EnableMarker = true
Config.NeedBag = false

Config.Borsoni = {40, 41, 44, 45}

Stores = {
	["burgershot"] = {
		position = { ['x'] = -1196.31, ['y'] = -893.96, ['z'] = 14.0 },
		nameofstore = "Burgershot (Vespucci Canals)",
		lastrobbed = 0
	}
}