Config = {}
Config.Locale = 'en'

Config.DoorList = {

	--
	-- Mission Row First Floor
	--

	-- Entrance Doors
	{
		textCoords = vector3(434.7, -982.0, 31.5),
		authorizedJobs = { 'police' },
		locked = false,
		distance = 2.5,
		doors = {
			{
				objName = 'v_ilev_ph_door01',
				objYaw = -90.0,
				objCoords = vector3(434.7, -980.6, 30.8)
			},

			{
				objName = 'v_ilev_ph_door002',
				objYaw = -90.0,
				objCoords = vector3(434.7, -983.2, 30.8)
			}
		}
	},

	-- To locker room & roof
	{
		objName = 'v_ilev_ph_gendoor004',
		objYaw = 90.0,
		objCoords  = vector3(449.6, -986.4, 30.6),
		textCoords = vector3(450.1, -986.3, 31.7),
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Rooftop
	{
		objName = 'v_ilev_gtdoor02',
		objYaw = 90.0,
		objCoords  = vector3(464.3, -984.6, 43.8),
		textCoords = vector3(464.3, -984.0, 44.8),
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Hallway to roof
	{
		objName = 'v_ilev_arm_secdoor',
		objYaw = 90.0,
		objCoords  = vector3(461.2, -985.3, 30.8),
		textCoords = vector3(461.5, -986.0, 31.5),
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Armory
	{
		objName = 'v_ilev_arm_secdoor',
		objYaw = -90.0,
		objCoords  = vector3(452.6, -982.7, 30.6),
		textCoords = vector3(453.0, -982.6, 31.7),
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Captain Office
	{
		objName = 'v_ilev_ph_gendoor002',
		objYaw = -180.0,
		objCoords  = vector3(447.2, -980.6, 30.6),
		textCoords = vector3(447.2, -980.0, 31.7),
		authorizedJobs = { 'police' },
		locked = true
	},

	-- To downstairs (double doors)
	{
		textCoords = vector3(444.6, -989.4, 31.7),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4,
		doors = {
			{
				objName = 'v_ilev_ph_gendoor005',
				objYaw = 180.0,
				objCoords = vector3(443.9, -989.0, 30.6)
			},

			{
				objName = 'v_ilev_ph_gendoor005',
				objYaw = 0.0,
				objCoords = vector3(445.3, -988.7, 30.6)
			}
		}
	},

	-- new double doors 1
	{
		textCoords = vector3(443.33, -993.23, 31),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2,
		doors = {
			{
				objName = 'v_ilev_ph_gendoor006',
				objCoords  = vector3(442.97, -993.66, 30.69),
			},

			{
				objName = 'v_ilev_ph_gendoor006',
				objCoords  = vector3(443.07, -992.78, 30.69)
			}
		}
	},

	-- new double doors 2
	{
		textCoords = vector3(446.61, -986.42, 27),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2,
		doors = {
			{
				objName = 'v_ilev_ph_gendoor003',
				objCoords  = vector3(446.11, -986.92, 26.67),
			},

			{
				objName = 'v_ilev_ph_gendoor003',
				objCoords  = vector3(446.19, -986.02, 26.67)
			}
		}
	},

	-- new double doors 3
	{
		textCoords = vector3(452.07, -984.22, 27),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2,
		doors = {
			{
				objName = 'v_ilev_ph_gendoor003',
				objCoords  = vector3(451.56, -983.95, 26.67),
			},

			{
				objName = 'v_ilev_ph_gendoor003',
				objCoords  = vector3(452.6, -983.89, 26.67)
			}
		}
	},

	-- new double doors 4
	{
		textCoords = vector3(465.1, -990.01, 25.20),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2,
		doors = {
			{
				objName = 'v_ilev_ph_gendoor003',
				objCoords  = vector3(465.53, -989.61, 24.91),
			},

			{
				objName = 'v_ilev_ph_gendoor003',
				objCoords  = vector3(465.6, -990.53, 24.91)
			}
		}
	},

	-- new double doors 5
	{
		textCoords = vector3(469.68, -1010.49, 27),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2,
		doors = {
			{
				objName = 'v_ilev_ph_gendoor003',
				objCoords  = vector3(469.97, -1009.98, 26.39),
			},

			{
				objName = 'v_ilev_ph_gendoor003',
				objCoords  = vector3(469.91, -1010.99, 26.39)
			}
		}
	},

	-- new double doors 6 labas
	{
		textCoords = vector3(445.86, -999.48, 31),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2,
		doors = {
			{
				objName = 'v_ilev_gtdoor',
				objCoords  = vector3(445.32, -998.98, 30.72),
			},

			{
				objName = 'v_ilev_gtdoor',
				objCoords  = vector3(446.52, -998.98, 30.72)
			}
		}
	},

	--
	-- Mission Row Cells
	--

	-- Main Cells
	{
		objName = 'v_ilev_ph_cellgate',
		objYaw = 0.0,
		objCoords  = vector3(463.8, -992.6, 24.9),
		textCoords = vector3(463.3, -992.6, 25.1),
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 1
	{
		objName = 'v_ilev_ph_cellgate',
		objYaw = -90.0,
		objCoords  = vector3(462.3, -993.6, 24.9),
		textCoords = vector3(461.8, -993.3, 25.0),
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 2
	{
		objName = 'v_ilev_ph_cellgate',
		objYaw = 90.0,
		objCoords  = vector3(462.3, -998.1, 24.9),
		textCoords = vector3(461.8, -998.8, 25.0),
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 3
	{
		objName = 'v_ilev_ph_cellgate',
		objYaw = 90.0,
		objCoords  = vector3(462.7, -1001.9, 24.9),
		textCoords = vector3(461.8, -1002.4, 25.0),
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 4
	{
		objName = 'v_ilev_gtdoor',
		objCoords = vector3(468.02, -996.43, 25),
		textCoords = vector3(468.02, -996.43, 25),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2
	},

	-- Cell 5
	{
		objName = 'v_ilev_gtdoor',
		objCoords = vector3(472.29, -996.53, 25),
		textCoords = vector3(472.29, -996.53, 25),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2
	},

	-- Cell 6
	{
		objName = 'v_ilev_gtdoor',
		objCoords = vector3(476.53, -996.5, 25),
		textCoords = vector3(476.53, -996.5, 25),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2
	},

	-- Cell 7
	{
		objName = 'v_ilev_gtdoor',
		objCoords = vector3(480.82, -996.57, 25),
		textCoords = vector3(480.82, -996.57, 25),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2
	},

	-- Cell 8
	{
		objName = 'v_ilev_gtdoor',
		objCoords = vector3(480.92, -1003.47, 25),
		textCoords = vector3(480.92, -1003.47, 25),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2
	},

	-- Cell 9
	{
		objName = 'v_ilev_gtdoor',
		objCoords = vector3(476.19, -1003.55, 25),
		textCoords = vector3(476.19, -1003.55, 25),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2
	},

	-- Cell 10
	{
		objName = 'v_ilev_gtdoor',
		objCoords = vector3(472.37, -1003.51, 25),
		textCoords = vector3(472.37, -1003.51, 25),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2
	},

	-- Cell 11
	{
		objName = 'v_ilev_gtdoor',
		objCoords = vector3(467.66, -1003.51, 25),
		textCoords = vector3(467.66, -1003.51, 25),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2
	},

	-- To Back
	{
		objName = 'v_ilev_gtdoor',
		objYaw = 0.0,
		objCoords  = vector3(463.4, -1003.5, 25.0),
		textCoords = vector3(464.0, -1003.5, 25.5),
		authorizedJobs = { 'police' },
		locked = true
	},

	--
	-- Mission Row Back
	--

	-- Back (double doors)
	{
		textCoords = vector3(468.6, -1014.4, 27.1),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2,
		doors = {
			{
				objName = 'v_ilev_rc_door2',
				objYaw = 0.0,
				objCoords  = vector3(467.3, -1014.4, 26.5)
			},

			{
				objName = 'v_ilev_rc_door2',
				objYaw = 180.0,
				objCoords  = vector3(469.9, -1014.4, 26.5)
			}
		}
	},

	-- Back Gate
	{
		objName = 'hei_prop_station_gate',
		objYaw = 90.0,
		objCoords  = vector3(488.8, -1017.2, 27.1),
		textCoords = vector3(488.8, -1020.2, 30.0),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 14,
		size = 2
	},

	--
	-- Sandy Shores
	--

	-- Entrance
	{
		objName = 'v_ilev_shrfdoor',
		objYaw = 30.0,
		objCoords  = vector3(1855.1, 3683.5, 34.2),
		textCoords = vector3(1855.1, 3683.5, 35.0),
		authorizedJobs = { 'police' },
		locked = false
	},

	--
	-- Paleto Bay
	--

	-- Entrance (double doors)
	{
		textCoords = vector3(-443.5, 6016.3, 32.0),
		authorizedJobs = { 'police' },
		locked = false,
		distance = 2.5,
		doors = {
			{
				objName = 'v_ilev_shrf2door',
				objYaw = -45.0,
				objCoords  = vector3(-443.1, 6015.6, 31.7),
			},

			{
				objName = 'v_ilev_shrf2door',
				objYaw = 135.0,
				objCoords  = vector3(-443.9, 6016.6, 31.7)
			}
		}
	},

	--
	-- Bolingbroke Penitentiary
	--

	-- Entrance (Two big gates)
	{
		objName = 'prop_gate_prison_01',
		objCoords  = vector3(1844.9, 2604.8, 44.6),
		textCoords = vector3(1844.9, 2608.5, 48.0),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 12,
		size = 2
	},

	{
		objName = 'prop_gate_prison_01',
		objCoords  = vector3(1818.5, 2604.8, 44.6),
		textCoords = vector3(1818.5, 2608.4, 48.0),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 12,
		size = 2
	},

	--
	-- Addons
	--

	--[[
	-- Entrance Gate (Mission Row mod) https://www.gta5-mods.com/maps/mission-row-pd-ymap-fivem-v1
	{
		objName = 'prop_gate_airport_01',
		objCoords  = vector3(420.1, -1017.3, 28.0),
		textCoords = vector3(420.1, -1021.0, 32.0),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 14,
		size = 2
	}
	--]]
	
	-- PRINCIPAL BANK
	-- Entrance (grades)
	--{
        --objName = 'hei_v_ilev_bk_gate2_pris',
        --objCoords  = vector3(261.99899291992, 221.50576782227, 106.68346405029),
        --textCoords = vector3(0, 0, 0),
        --authorizedJobs = { 'police' },
        --locked = true,
        --distance = 12,
        --size = 2
    --},

	{
		objName = 'hei_v_ilev_bk_gate2_pris',
		objYaw = 90.0,
		objCoords  = vector3(-105.11, 6472.81, 31.63),
		textCoords = vector3(0, 0, 0),
		authorizedJobs = { 'police' },
		locked = true,
		distance = 0,
		size = 0
	},
	
	--
	-- Ambulance Hospital
	--

	-- Operating Area
	{
		textCoords = vector3(331.08, -571.17, 43.82),
		authorizedJobs = { 'ambulance' },
		locked = false,
		distance = 7,
		doors = {
			{
				objName = 'v_ilev_bl_doorsl_r',
				objCoords  = vector3(331.08, -571.17, 43.32),
			},

			{
				objName = 'v_ilev_bl_doorsl_l',
				objCoords  = vector3(331.08, -571.17, 43.32)
			}
		}
	},
	-- new operating area
	{
		textCoords = vector3(373.83, -1406.95, 32.51),
		authorizedJobs = { 'ambulance' },
		locked = true,
		distance = 7,
		doors = {
			{
				objName = 'v_ilev_ph_gendoor003',
				objCoords  = vector3(373, -1406.51, 32.51),
			},

			{
				objName = 'v_ilev_ph_gendoor003',
				objCoords  = vector3(374.26, -1407.04, 32.51)
			}
		}
	},
	-- new looker room
	{
		textCoords = vector3(365.79, -1416.59, 32.51),
		authorizedJobs = { 'ambulance' },
		locked = true,
		distance = 7,
		doors = {
			{
				objName = 'v_ilev_ph_gendoor003',
				objCoords  = vector3(366.13, -1416.92, 32.51),
			},

			{
				objName = 'v_ilev_ph_gendoor003',
				objCoords  = vector3(365.42, -1416.44, 32.51)
			}
		}
	},
	-- pokoj 1 --
	{
		textCoords = vector3(348.43, -1432.36, 32.51),
		authorizedJobs = { 'ambulance' },
		locked = true,
		distance = 7,
		doors = {
			{
				objName = 'v_ilev_cor_doorglassa',
				objCoords  = vector3(348.94, -1432.23, 32.51),
			},

			{
				objName = 'v_ilev_cor_doorglassb',
				objCoords  = vector3(348, -1431.67, 32.51)
			}
		}
	},
	-- pokoj 2 --
	{
		textCoords = vector3(331.21, -1419.78, 32.51),
		authorizedJobs = { 'ambulance' },
		locked = true,
		distance = 7,
		doors = {
			{
				objName = 'v_ilev_cor_doorglassa',
				objCoords  = vector3(331.47, -1420.2, 32.51),
			},

			{
				objName = 'v_ilev_cor_doorglassb',
				objCoords  = vector3(330.69, -1420.99, 32.51)
			}
		}
	},
	-- door --
	{
		objName = 'v_ilev_gendoor02',
		objCoords = vector3(376.26, -1425.75, 32.51),
		textCoords = vector3(376.26, -1425.75, 32.51),
		authorizedJobs = { 'ambulance' },
		locked = true,
		distance = 2
	},


	
	
	--
	-- Mafia
	--

	-- Payaman(Ganghouse1)
	{
		objName = 'prop_lrggate_01c_r',
		objCoords = vector3(-2652.32, 1326.59, 147.05),
		textCoords = vector3(-2652.32, 1326.59, 148.05),
		authorizedJobs = { 'payaman' , 'police'},
		locked = true,
		distance = 2
	},
	{
		objName = 'apa_p_mp_Yacht_Door_01',
		objCoords = vector3(-2667.58, 1326.31, 146.43),
		textCoords = vector3(-2667.58, 1326.31, 147.93),
		authorizedJobs = { 'payaman' , 'police'},
		locked = true,
		distance = 2
	},
	{
		objName = 'apa_Prop_SS1_MPint_Garage2',
		objCoords = vector3(-2652.44, 1307.36, 147.67),
		textCoords = vector3(-2652.44, 1307.36, 148.67),
		authorizedJobs = { 'payaman' , 'police'},
		locked = true,
		distance = 15
	},

	
	-- Chinese Temple
	-- {
		-- textCoords = vector3(-882.19, -1438.98, 8.0),
		-- authorizedJobs = { 'admin' },
		-- locked = true,
		-- distance = 2,
		-- doors = {
			-- {
				-- objName = 'prop_sm1_11_doorr',
				-- objCoords  = vector3(-882.19, -1438.98, 7.53),
			-- },

			-- {
				-- objName = 'prop_sm1_11_doorl',
				-- objCoords  = vector3(-882.19, -1438.98, 7.53)
			-- }
		-- }
	-- },
	-- {
		-- textCoords = vector3(-879.64, -1444.82, 8.53),
		-- authorizedJobs = { 'admin' },
		-- locked = true,
		-- distance = 2,
		-- doors = {
			-- {
				-- objName = 'prop_grumandoor_l',
				-- objCoords  = vector3(-879.64, -1444.82, 7.53),
			-- },

			-- {
				-- objName = 'prop_grumandoor_r',
				-- objCoords  = vector3(-879.64, -1444.82, 7.53)
			-- }
		-- }
	-- },
	-- {
		-- textCoords = vector3(-894.26, -1463.08, 8.53),
		-- authorizedJobs = { 'admin' },
		-- locked = true,
		-- distance = 2,
		-- doors = {
			-- {
				-- objName = 'prop_grumandoor_l',
				-- objCoords  = vector3(-894.26, -1463.08, 7.53),
			-- },

			-- {
				-- objName = 'prop_grumandoor_r',
				-- objCoords  = vector3(-894.26, -1463.08, 7.53)
			-- }
		-- }
	-- },
	-- {
		-- textCoords = vector3(-899.17, -1450.01, 8.53),
		-- authorizedJobs = { 'admin' },
		-- locked = true,
		-- distance = 2,
		-- doors = {
			-- {
				-- objName = 'prop_grumandoor_l',
				-- objCoords  = vector3(-899.17, -1450.01, 7.53),
			-- },

			-- {
				-- objName = 'prop_grumandoor_r',
				-- objCoords  = vector3(-899.17, -1450.01, 7.53)
			-- }
		-- }
	-- },
	-- {
		-- textCoords = vector3(-876.33, -1454.64, 8.53),
		-- authorizedJobs = { 'admin' },
		-- locked = true,
		-- distance = 2,
		-- doors = {
			-- {
				-- objName = 'prop_grumandoor_l',
				-- objCoords  = vector3(-876.33, -1454.64, 7.53),
			-- },

			-- {
				-- objName = 'prop_grumandoor_r',
				-- objCoords  = vector3(-876.33, -1454.64, 7.53)
			-- }
		-- }
	-- },
	-- {
		-- textCoords = vector3(-874.47, -1460.72, 8.0),
		-- authorizedJobs = { 'admin' },
		-- locked = true,
		-- distance = 2,
		-- doors = {
			-- {
				-- objName = 'prop_sm1_11_doorr',
				-- objCoords  = vector3(-874.47, -1460.72, 7.53),
			-- },

			-- {
				-- objName = 'prop_sm1_11_doorl',
				-- objCoords  = vector3(-874.47, -1460.72, 7.53)
			-- }
		-- }
	-- },
	
	-- (Michael House)

	-- {
		-- objName = 'v_ilev_mm_doorw',
		-- objCoords = vector3(-809.88, 177.14, 76.74),
		-- textCoords = vector3(-809.87, 177.57, 77.3),
		-- authorizedJobs = { 'redskull' , 'police'},
		-- locked = true,
		-- distance = 2
	-- },
	-- {
		-- objName = 'v_ilev_mm_doorson',
		-- objCoords = vector3(-806.5, 173.25, 76.74),
		-- textCoords = vector3(-806.5, 173.25, 77.3),
		-- authorizedJobs = { 'redskull' , 'police'},
		-- locked = true,
		-- distance = 2
	-- },
	-- {
		-- textCoords = vector3(-816.23, 178.36, 73.23),
		-- authorizedJobs = { 'redskull' , 'police'},
		-- locked = true,
		-- distance = 3,
		-- doors = {
			-- {
				-- objName = 'v_ilev_mm_doorm_l',
				-- objCoords  = vector3(-817.11, 178.15, 72.23),
			-- },

			-- {
				-- objName = 'v_ilev_mm_doorm_r',
				-- objCoords  = vector3(-817.11, 178.15, 72.23)
			-- }
		-- }
	-- },
	-- {
		-- textCoords = vector3(-795.48, 177.61, 73.34),
		-- authorizedJobs = { 'redskull' , 'police'},
		-- locked = true,
		-- distance = 2,
		-- doors = {
			-- {
				-- objName = 'prop_bh1_48_backdoor_r',
				-- objCoords  = vector3(-795.48, 177.61, 72.84),
			-- },

			-- {
				-- objName = 'prop_bh1_48_backdoor_l',
				-- objCoords  = vector3(-795.48, 177.61, 72.84)
			-- }
		-- }
	-- },
	-- {
		-- textCoords = vector3(-793.66, 181.56, 73.34),
		-- authorizedJobs = { 'redskull' , 'police'},
		-- locked = true,
		-- distance = 2,
		-- doors = {
			-- {
				-- objName = 'prop_bh1_48_backdoor_r',
				-- objCoords  = vector3(-793.66, 181.56, 72.84),
			-- },

			-- {
				-- objName = 'prop_bh1_48_backdoor_l',
				-- objCoords  = vector3(-793.66, 181.56, 72.84)
			-- }
		-- }
	-- },
	-- {
		-- objName = 'prop_bh1_48_gate_1',
		-- objCoords = vector3(-848.82, 178.48, 69.82),
		-- textCoords = vector3(-848.79, 178.71, 70.35),
		-- authorizedJobs = { 'redskull' , 'police'},
		-- locked = true,
		-- distance = 2
	-- },
	-- {
		-- objName = 'prop_ld_garaged_01',
		-- objCoords = vector3(-815.14, 186.19, 72.48),
		-- textCoords = vector3(-815.14, 186.19, 72.98),
		-- authorizedJobs = { 'redskull' , 'police'},
		-- locked = true,
		-- distance = 8.5
	-- },
	
		-- Loghouse
	-- {
		-- objName = 'ex_Prop_Door_LowBank_Ent_R',
		-- objCoords = vector3(-783.62890000, 5678.46600000, 25.33710000),
		-- textCoords = vector3(-783.08, 5677.91, 25.84),
		-- authorizedJobs = { 'morte' , 'police'},
		-- locked = true,
		-- distance = 3
	-- },
	-- {
		-- objName = 'apa_p_mp_door_ApartFRT_door',
		-- objCoords = vector3(-781.53860000, 5672.55700000, 25.29154000),
		-- textCoords = vector3(-781.71, 5673.26, 25.8),
		-- authorizedJobs = { 'morte' , 'police'},
		-- locked = true,
		-- distance = 3
	-- },
	-- {
		-- objName = 'apa_p_mp_door_ApartFRT_door',
		-- objCoords = vector3(-787.67730000, 5670.88700000, 25.30216000),
		-- textCoords = vector3(-787.15, 5670.33, 25.8),
		-- authorizedJobs = { 'morte' , 'police'},
		-- locked = true,
		-- distance = 3
	-- },
	-- {
		-- objName = 'apa_p_mp_door_Stilt_door',
		-- objCoords = vector3(-780.44180000, 5676.74200000, 29.11217000),
		-- textCoords = vector3(-781.03, 5677.28, 29.5),
		-- authorizedJobs = { 'morte' , 'police'},
		-- locked = true,
		-- distance = 3
	-- },
	-- {
		-- textCoords = vector3(-781.21, 5664.43, 26.2),
		-- authorizedJobs = { 'morte' , 'police'},
		-- locked = true,
		-- distance = 5,
		-- doors = {
			-- {
				-- objName = 'Prop_LD_garageD_01',
				-- objCoords  = vector3(-781.46490000, 5665.35700000, 25.70537000),
			-- },

			-- {
				-- objName = 'Prop_LD_garageD_01',
				-- objCoords  = vector3(-781.93540000, 5663.97100000, 25.70537000)
			-- }
		-- }
	-- },
	-- {
		-- textCoords = vector3(-790.34, 5677.27, 29.8),
		-- authorizedJobs = { 'morte' , 'police'},
		-- locked = true,
		-- distance = 3,
		-- doors = {
			-- {
				-- objName = 'apa_Prop_SS1_MPint_Door_L',
				-- objCoords  = vector3(-790.33960000, 5676.12500000, 29.46621000),
			-- },

			-- {
				-- objName = 'apa_Prop_SS1_MPint_Door_L',
				-- objCoords  = vector3(-789.65230000, 5678.16100000, 29.46562000)
			-- }
		-- }
	-- },
	
	-- Morte(NEW VINEWOOD)
	{
		objName = 'v_ilev_fh_frontdoor',
		objCoords = vector3(7.81, 538.83, 176.03),
		textCoords = vector3(7.81, 538.83, 176.03 + 0.8),
		authorizedJobs = { 'morte' },
		locked = true,
		objYaw = 152.0,
		distance = 3
	},
	
	{
		objName = 'prop_ch_025c_g_door_01',
		objCoords = vector3(18.98, 546.32, 176.03),
		textCoords = vector3(18.98, 546.32, 176.03 + 0.8),
		authorizedJobs = { 'morte' },
		locked = true,
		--objYaw = 152.0,
		distance = 10
	},
	
	-- Humane Laboratory
	-- {
		-- objName = 'v_ilev_bl_shutter2',
		-- objCoords = vector3(3627.95, 3746.63, 28.69),
		-- textCoords = vector3(3627.95, 3746.63, 28.69 + 0.8),
		-- authorizedJobs = { 'admin' , 'police'},
		-- locked = true,
		-- distance = 8
	-- },
	-- {
		-- objName = 'v_ilev_bl_shutter2',
		-- objCoords = vector3(3620.69, 3751.54, 28.69),
		-- textCoords = vector3(3620.69, 3751.54, 28.69 + 0.8),
		-- authorizedJobs = { 'admin' , 'police'},
		-- locked = true,
		-- distance = 8
	-- },
	-- {
		-- objName = 'v_ilev_bl_doorsl_r',
		-- objCoords = vector3(3558.15, 3669.88, 28.12),
		-- textCoords = vector3(3558.15, 3669.88, 28.12 + 0.8),
		-- authorizedJobs = { 'admin' , 'police'},
		-- locked = true,
		-- distance = 5
	-- },
	-- {
		-- textCoords = vector3(3566.23, 3684.2, 28.12 + 0.8),
		-- authorizedJobs = { 'admin' , 'police'},
		-- locked = true,
		-- distance = 5,
		-- doors = {
			-- {
				-- objName = 'v_ilev_bl_doorsl_r',
				-- objCoords  = vector3(3566.23, 3684.2, 28.12),
			-- },

			-- {
				-- objName = 'v_ilev_bl_doorsl_l',
				-- objCoords  = vector3(3566.23, 3684.2, 28.12)
			-- }
		-- }
	-- },
	-- {
		-- textCoords = vector3(3532.57, 3664.67, 28.12 + 0.8),
		-- authorizedJobs = { 'admin' , 'police'},
		-- locked = true,
		-- distance = 5,
		-- doors = {
			-- {
				-- objName = 'v_ilev_bl_doorsl_r',
				-- objCoords  = vector3(3532.57, 3664.67, 28.12),
			-- },

			-- {
				-- objName = 'v_ilev_bl_doorsl_l',
				-- objCoords  = vector3(3532.57, 3664.67, 28.12)
			-- }
		-- }
	-- },
	-- {
		-- textCoords = vector3(3540.44, 3674.0, 28.12 + 0.8),
		-- authorizedJobs = { 'admin' , 'police'},
		-- locked = true,
		-- distance = 5,
		-- doors = {
			-- {
				-- objName = 'v_ilev_bl_doorel_r',
				-- objCoords  = vector3(3540.44, 3674.0, 28.12),
			-- },

			-- {
				-- objName = 'v_ilev_bl_doorel_l',
				-- objCoords  = vector3(3540.44, 3674.0, 28.12)
			-- }
		-- }
	-- },
	
	-- Hospital (Sandy Shores)
	{
		objName = 'xm_Prop_IAA_BASE_Door_02',
		objCoords = vector3(1827.38, 3680.22, 40.88),
		textCoords = vector3(1827.38, 3680.22, 40.88 -0.4),
		objYaw = 120.0,
		authorizedJobs = { 'ambulance' },
		locked = true,
		distance = 2
	},
	{
		objName = 'Prop_CH3_04_door_01R',
		objCoords = vector3(1828.79, 3687.37, 39.83),
		textCoords = vector3(1828.79, 3687.37, 39.83 +0.8),
		objYaw = 30.0,
		authorizedJobs = { 'ambulance' },
		locked = true,
		distance = 2
	}, 
	{
		objName = 'ex_p_mp_door_Office_door01',
		objCoords = vector3(1835.05, 3691.33, 39.83),
		textCoords = vector3(1835.05, 3691.33, 39.83 +0.8),
		objYaw = 210.0,
		authorizedJobs = { 'ambulance' },
		locked = true,
		distance = 2
	},
	{
		objName = 'ba_Prop_Door_Club_Glass',
		objCoords = vector3(1832.07, 3680.64, 39.88),
		textCoords = vector3(1832.07, 3680.64, 39.88 +0.8),
		objYaw = 275.0,
		authorizedJobs = { 'ambulance' },
		locked = true,
		distance = 2
	},
	-- Yankee Brotherhood(Kalye Trese)
	{
		objName = 'prop_sc1_21_g_door_01',
		objCoords = vector3(-25.41, -1431.63, 30.62),
		textCoords = vector3(-25.41, -1431.63, 30.62 +0.8),
		authorizedJobs = { 'yankee' , 'police'},
		locked = true,
		distance = 7
	},
	{
		objName = 'v_ilev_fa_frontdoor',
		objCoords = vector3(-14.01, -1441.09, 31.1),
		textCoords = vector3(-14.01, -1441.09, 31.1 +0.8),
		authorizedJobs = { 'yankee' , 'police'},
		locked = true,
		distance = 4
	},
	-- BURGLARY
	{
		objName = 'v_ilev_trev_doorfront',
		objCoords = vector3(-1150.14, -1521.71, 9.75),
		textCoords = vector3(0,0,0),
		objYaw = 32.0,
		authorizedJobs = {'admin', 'police'},
		locked = true,
		distance = 4
	},		
	{
		objName = 'v_ilev_trevtraildr',
		objCoords = vector3(1973.56, 3815.34, 33.42),
		textCoords = vector3(0,0,0),
		objYaw = 32.0,
		authorizedJobs = {'admin', 'police'},
		locked = true,
		distance = 4
	},	
	
	-- BAR
	{
		objName = 'v_ilev_door_orangesolid',
		objCoords = vector3(114.28, -1296.52, 29.39),
		textCoords = vector3(0,0,0),
		objYaw = 300.0,
		authorizedJobs = {'admin'},
		locked = true,
		distance = 4
	},

	-- RedSkull
	{
		textCoords = vector3(-2502.57, 754.86, 304.0),
		authorizedJobs = {'redskull' ,'police' },
		locked = true,
		distance = 4,
		doors = {
			{
				objName = 'hei_prop_hei_bankdoor_new',
				--objYaw = 0.0,
				objCoords  = vector3(-2502.57, 754.86, 303.4)
			},

			{
				objName = 'hei_prop_hei_bankdoor_new',
				--objYaw = 180.0,
				objCoords  = vector3(-2502.22, 755.3, 303.4)
			}
		}
	},
	{
		objName = 'prop_facgate_07b',
		objCoords = vector3(-180.26, -1292.8, 31.3),
		textCoords = vector3(-187.36, -1293.42, 32.0),
		--objYaw = 300.0,
		authorizedJobs = {'mechanic'},
		locked = true,
		distance = 12
	},
	--CARDEALER
	{
		textCoords = vector3(-799.98, -217.84, 38),
		authorizedJobs = {'cardealer'},
		locked = true,
		distance = 2.5,
		doors = {
			{
				objName = 'v_ilev_fib_door2',
				objCoords  = vector3(-800.54, -218.12, 37.08)
			},

			{
				objName = 'v_ilev_fib_door2',
				objCoords  = vector3(-799.42, -217.49, 37.08)
			}
		}
	},
	{
		textCoords = vector3(-803.7, -210.34, 38),
		authorizedJobs = {'cardealer'},
		locked = true,
		distance = 2.5,
		doors = {
			{
				objName = 'v_ilev_fib_door2',
				objCoords  = vector3(-804.15, -210.69, 37.08)
			},

			{
				objName = 'v_ilev_fib_door2',
				objCoords  = vector3(-803.21, -210.07, 37.08)
			}
		}
	},
	
	-- PRINCIPAL BANK
	{
		objName = 'hei_v_ilev_bk_gate_pris',
		objCoords  = vector3(256.3116, 220.6579, 106.4296),
		textCoords = vector3(0.0, 0.0, -1000.0), 
		authorizedJobs = { 'police' },
		locked = true,
		distance = 12,
        size = 2
	},
	{
		objName = 'hei_v_ilev_bk_gate2_pris',
		objCoords  = vector3(261.99899291992, 221.50576782227, 106.68346405029),
		textCoords = vector3(0.0, 0.0, -1000.0), 
		authorizedJobs = { 'police' },
		locked = true,
		distance = 12,
        size = 2
	},
	{
		objName = 'v_ilev_bk_safegate',
		objCoords  = vector3(251.8576, 221.0655, 101.8324),
		textCoords = vector3(0.0, 0.0, -1000.0), 
		authorizedJobs = { 'police' },
		locked = true,
        distance = 12,
        size = 2
	},
	{
		objName = 'hei_v_ilev_bk_safegate_pris',
		objCoords  = vector3(261.3004, 214.5051, 101.8324),
		textCoords = vector3(0.0, 0.0, 1000.0), 
		authorizedJobs = { 'police' },
		locked = true,
        distance = 12,
        size = 2
	},
	
}