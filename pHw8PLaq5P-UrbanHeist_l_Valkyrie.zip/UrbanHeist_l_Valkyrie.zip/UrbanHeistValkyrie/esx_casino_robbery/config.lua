Config = {}
Config.Locale = 'en'

Config.RequiredCopsRob = 5
Config.MaxWindows = 35
Config.SecBetwNextRob = 1800 --1 hour
Config.EnableMarker = true
Config.NeedBag = true

Config.Borsoni = {40, 41, 44, 45}

Stores = {
	["casino"] = {
		position = { ['x'] = 943.25, ['y'] = 35.06, ['z'] = 75.32 },
		nameofstore = "Casino (Vinewood Hills)",
		lastrobbed = 0
	}
}