local holdingup = false
local store = ""
local blipRobbery = nil
local vetrineRotte = 0 

local vetrine = {
	{x = 1031.86, y = 65.31, z = 72.48, heading = 173.15, isOpen = false},
	{x = 1030.69, y = 59.53, z = 72.48, heading = 273.41, isOpen = false},
	{x = 1024.21, y = 59.16, z = 72.48, heading = 184.71, isOpen = false},
	{x = 1023.9, y = 61.54, z = 72.48, heading = 13.34, isOpen = false},
	{x = 1017.57, y = 69.73, z = 73.28, heading = 85.66, isOpen = false},
	{x = 1009.87, y = 67.77, z = 73.28, heading = 288.87, isOpen = false},
	{x = 1022.45, y = 49.02, z = 73.28, heading = 106.48, isOpen = false},
	{x = 1014.72, y = 47.2, z = 73.28, heading = 280.62, isOpen = false},
	{x = 1013.45, y = 55.97, z = 73.28, heading = 177.08, isOpen = false},
	{x = 1011.26, y = 59.71, z = 73.28, heading = 338.45, isOpen = false},
	{x = 1012.14, y = 61.84, z = 73.28, heading = 167.92, isOpen = false},
	{x = 1007.25, y = 54.84, z = 73.28, heading = 78.62, isOpen = false},
	{x = 1007.06, y = 57.01, z = 73.28, heading = 105.11, isOpen = false},
	{x = 1004.95, y = 59.36, z = 73.28, heading = 129.42, isOpen = false},
	{x = 1001.86, y = 59.83, z = 74.28, heading = 123.66, isOpen = false},
	{x = 998.03, y = 58.86, z = 74.28, heading = 250.47, isOpen = false},
	{x = 976.69, y = 81.07, z = 73.08, heading = 12.51, isOpen = false},
	{x = 976.66, y = 83.91, z = 73.08, heading = 10.22, isOpen = false},
	{x = 981.42, y = 82.2, z = 73.08, heading = 5.53, isOpen = false},
	{x = 983.32, y = 82.63, z = 73.08, heading = 7.73, isOpen = false},
	{x = 988.07, y = 83.69, z = 73.08, heading = 5.72, isOpen = false},
	{x = 986.92, y = 86.24, z = 73.08, heading = 12.77, isOpen = false},
	{x = 982.67, y = 85.46, z = 73.08, heading = 14.05, isOpen = false},
	{x = 980.88, y = 84.82, z = 73.08, heading = 7.95, isOpen = false},
	{x = 986.83, y = 48.51, z = 74.48, heading = 229.17, isOpen = false},
	{x = 985.89, y = 45.47, z = 74.48, heading = 261.24, isOpen = false},
	{x = 983.27, y = 48.27, z = 74.48, heading = 187.23, isOpen = false},
	{x = 982.38, y = 51.27, z = 74.48, heading = 312.96, isOpen = false},
	{x = 984.05, y = 53.11, z = 74.48, heading = 104.32, isOpen = false},
	{x = 984.51, y = 56.14, z = 74.48, heading = 10.57, isOpen = false},
	{x = 981.5, y = 57.08, z = 74.48, heading = 320.56, isOpen = false},
	{x = 978.53, y = 57.08, z = 74.48, heading = 195.91, isOpen = false},
	{x = 977.86, y = 54.29, z = 74.48, heading = 328.65, isOpen = false},
	{x = 974.4, y = 54.0, z = 74.48, heading = 143.63, isOpen = false},
	{x = 971.51, y = 53.7, z = 74.48, heading = 244.85, isOpen = false},
	{x = 951.01, y = 26.74, z = 74.88, heading = 291.26, isOpen = false},
}

ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

function DrawText3D(x, y, z, text, scale)
	local onScreen, _x, _y = World3dToScreen2d(x, y, z)
	local pX, pY, pZ = table.unpack(GetGameplayCamCoords())

	SetTextScale(scale, scale)
	SetTextFont(4)
	SetTextProportional(1)
	SetTextEntry("STRING")
	SetTextCentre(1)
	SetTextColour(255, 255, 255, 215)

	AddTextComponentString(text)
	DrawText(_x, _y)

end

function DisplayHelpText(str)
	SetTextComponentFormat("STRING")
	AddTextComponentString(str)
	DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end

RegisterNetEvent("mt:missiontext")
AddEventHandler("mt:missiontext", function(text, time)
    ClearPrints()
    SetTextEntry_2("STRING")
    AddTextComponentString(text)
    DrawSubtitleTimed(time, 1)
end)

function loadAnimDict( dict )  
    while ( not HasAnimDictLoaded( dict ) ) do
        RequestAnimDict( dict )
        Citizen.Wait( 5 )
    end
end 

RegisterNetEvent('esx_casino_robbery:currentlyrobbing')
AddEventHandler('esx_casino_robbery:currentlyrobbing', function(robb)
	holdingup = true
	store = robb
end)

RegisterNetEvent('esx_casino_robbery:killblip')
AddEventHandler('esx_casino_robbery:killblip', function()
    RemoveBlip(blipRobbery)
end)

RegisterNetEvent('esx_casino_robbery:setblip')
AddEventHandler('esx_casino_robbery:setblip', function(position)
    blipRobbery = AddBlipForCoord(position.x, position.y, position.z)
    SetBlipSprite(blipRobbery , 161)
    SetBlipScale(blipRobbery , 2.0)
    SetBlipColour(blipRobbery, 3)
    PulseBlip(blipRobbery)
end)

RegisterNetEvent('esx_casino_robbery:toofarlocal')
AddEventHandler('esx_casino_robbery:toofarlocal', function(robb)
	holdingup = false
	ESX.ShowNotification(_U('robbery_cancelled'))
	robbingName = ""
	incircle = false
end)


RegisterNetEvent('esx_casino_robbery:robberycomplete')
AddEventHandler('esx_casino_robbery:robberycomplete', function(robb)
	holdingup = false
	ESX.ShowNotification(_U('robbery_complete'))
	store = ""
	incircle = false
end)

Citizen.CreateThread(function()
	for k,v in pairs(Stores)do
		local ve = v.position

		local blip = AddBlipForCoord(ve.x, ve.y, ve.z)
		SetBlipSprite(blip, 490)
		SetBlipColour(blip, 1)
		SetBlipScale(blip, 1.3)
		SetBlipAsShortRange(blip, true)
		BeginTextCommandSetBlipName("STRING")
		AddTextComponentString('Casino Robbery')
		EndTextCommandSetBlipName(blip)
	end
end)

animazione = false
incircle = false
soundid = GetSoundId()

function drawTxt(x, y, scale, text, red, green, blue, alpha)
	SetTextFont(4)
	SetTextProportional(1)
	SetTextScale(0.64, 0.64)
	SetTextColour(red, green, blue, alpha)
	SetTextDropShadow(0, 0, 0, 0, 255)
	SetTextEdge(1, 0, 0, 0, 255)
	SetTextDropShadow()
	SetTextOutline()
	SetTextEntry("STRING")
	AddTextComponentString(text)
    DrawText(0.155, 0.935)
end

local borsa = nil

Citizen.CreateThread(function()
	while true do
	  Citizen.Wait(1000)
	  TriggerEvent('skinchanger:getSkin', function(skin)
		borsa = skin['bags_1']
	  end)
	  Citizen.Wait(1000)
	end
end)

Citizen.CreateThread(function()
      
	while true do
		local pos = GetEntityCoords(GetPlayerPed(-1), true)

		for k,v in pairs(Stores)do
			local pos2 = v.position

			if(Vdist(pos.x, pos.y, pos.z, pos2.x, pos2.y, pos2.z) < 15.0)then
				if not holdingup then
					DrawMarker(27, v.position.x, v.position.y, v.position.z-0.9, 0, 0, 0, 0, 0, 0, 2.001, 2.0001, 0.5001, 255, 0, 0, 200, 0, 0, 0, 0)

					if(Vdist(pos.x, pos.y, pos.z, pos2.x, pos2.y, pos2.z) < 1.0)then
						if (incircle == false) then
							DisplayHelpText(_U('press_to_rob'))
						end
						incircle = true
						if IsPedShooting(GetPlayerPed(-1)) then
							if Config.NeedBag then
							    if borsa == 40 or borsa == 41 or borsa == 44 or borsa == 45 then
							        ESX.TriggerServerCallback('esx_casino_robbery:conteggio', function(CopsConnected)
								        if CopsConnected >= Config.RequiredCopsRob then
							                TriggerServerEvent('esx_casino_robbery:rob', k)
									        PlaySoundFromCoord(soundid, "VEHICLES_HORNS_AMBULANCE_WARNING", pos2.x, pos2.y, pos2.z)
								        else
									        TriggerEvent('esx:showNotification', _U('min_two_police') .. Config.RequiredCopsRob .. _U('min_two_police2'))
								        end
							        end)		
						        else
							        TriggerEvent('esx:showNotification', _U('need_bag'))
								end
							else
								ESX.TriggerServerCallback('esx_casino_robbery:conteggio', function(CopsConnected)
									if CopsConnected >= Config.RequiredCopsRob then
										TriggerServerEvent('esx_casino_robbery:rob', k)
										PlaySoundFromCoord(soundid, "VEHICLES_HORNS_AMBULANCE_WARNING", pos2.x, pos2.y, pos2.z)
									else
										TriggerEvent('esx:showNotification', _U('min_two_police') .. Config.RequiredCopsRob .. _U('min_two_police2'))
									end
								end)	
							end	
                        end
					elseif(Vdist(pos.x, pos.y, pos.z, pos2.x, pos2.y, pos2.z) > 1.0)then
						incircle = false
					end		
				end
			end
		end

		if holdingup then
			drawTxt(0.3, 1.4, 0.45, _U('smash_case') .. ' :~r~ ' .. vetrineRotte .. '/' .. Config.MaxWindows, 185, 185, 185, 255)

			for i,v in pairs(vetrine) do 
				if(GetDistanceBetweenCoords(pos, v.x, v.y, v.z, true) < 10.0) and not v.isOpen and Config.EnableMarker then 
					DrawMarker(20, v.x, v.y, v.z, 0, 0, 0, 0, 0, 0, 0.6, 0.6, 0.6, 0, 255, 0, 200, 1, 1, 0, 0)
				end
				if(GetDistanceBetweenCoords(pos, v.x, v.y, v.z, true) < 0.75) and not v.isOpen then 
					DrawText3D(v.x, v.y, v.z, '~w~[~g~E~w~] ' .. _U('press_to_collect'), 0.6)
					if IsControlJustPressed(0, 38) then
						animazione = true
					    SetEntityCoords(GetPlayerPed(-1), v.x, v.y, v.z-0.95)
					    SetEntityHeading(GetPlayerPed(-1), v.heading)
						v.isOpen = true 
						-- PlaySoundFromCoord(-1, "Glass_Smash", v.x, v.y, v.z, "", 0, 0, 0)
					    -- if not HasNamedPtfxAssetLoaded("scr_jewelheist") then
					    -- RequestNamedPtfxAsset("scr_jewelheist")
					    -- end
					    -- while not HasNamedPtfxAssetLoaded("scr_jewelheist") do
					    -- Citizen.Wait(0)
					    -- end
					    --SetPtfxAssetNextCall("scr_jewelheist")
					    --StartParticleFxLoopedAtCoord("scr_jewel_cab_smash", v.x, v.y, v.z, 0.0, 0.0, 0.0, 1.0, false, false, false, false)
					     loadAnimDict( "anim@heists@ornate_bank@grab_cash" ) 
						 TaskPlayAnim(GetPlayerPed(-1), "anim@heists@ornate_bank@grab_cash", "grab", 8.0, 1.0, -1, 2, 0, 0, 0, 0 ) 
						TriggerEvent("mt:missiontext", _U('collectinprogress'), 3000)
					    --DisplayHelpText(_U('collectinprogress'))
					    DrawSubtitleTimed(5000, 1)
					    Citizen.Wait(5000)
					    ClearPedTasksImmediately(GetPlayerPed(-1))
					    TriggerServerEvent('esx_casino_robbery:gioielli')
					    PlaySound(-1, "PICK_UP", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0, 0, 1)
					    vetrineRotte = vetrineRotte+1
					    animazione = false

						if vetrineRotte == Config.MaxWindows then 
						    for i,v in pairs(vetrine) do 
								v.isOpen = false
								vetrineRotte = 0
							end
							TriggerServerEvent('esx_casino_robbery:endrob', store)
						    ESX.ShowNotification(_U('robbery_complete'))
						    holdingup = false
						    StopSound(soundid)
						end
					end
				end	
			end

			local pos2 = Stores[store].position

			if (GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), 984.2, 60.27, 78.49, true) > 150.5 ) then
				TriggerServerEvent('esx_casino_robbery:toofar', store)
				holdingup = false
				for i,v in pairs(vetrine) do 
					v.isOpen = false
					vetrineRotte = 0
				end
				StopSound(soundid)
			end

		end

		Citizen.Wait(0)
	end
end)


Citizen.CreateThread(function()
      
	while true do
		Wait(1)
		if animazione == true then
			if not IsEntityPlayingAnim(PlayerPedId(), 'anim@heists@ornate_bank@grab_cash', 'grab', 3) then
				TaskPlayAnim(PlayerPedId(), 'anim@heists@ornate_bank@grab_cash', 'grab', 8.0, 8.0, -1, 17, 1, false, false, false)
			end
		end
	end
end)
