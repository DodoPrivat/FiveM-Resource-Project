Locales['en'] = {
  -- regulars
  	['duty'] = 'Press ~INPUT_CONTEXT~ to ~g~enter~s~/~r~exit~s~ duty',
	['onduty'] = 'You went onduty.',
	['offduty'] = 'You went offduty.',
	['notben'] = 'You are not a bennys mechanic.',
	['notmec'] = 'You are not a ls mechanic.',
}
