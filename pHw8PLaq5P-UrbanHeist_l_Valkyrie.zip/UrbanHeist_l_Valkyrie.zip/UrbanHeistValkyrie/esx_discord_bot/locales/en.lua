Locales['en'] = {
	['server'] = 'server',
	['server_start'] = 'server start',
	['server_chat'] = 'chat',

	['server_connecting'] = 'new connexion',
	['user_connecting'] = 'is connecting',

	['server_disconnecting'] = 'new disconnection',
	['user_disconnecting'] = 'is disconnecting',

	['server_item_transfer'] = 'new transaction (item)',
	['server_money_transfer'] = 'new transaction (money)',
	
	['server_item_transfer_property'] = 'new property transaction (item)',
	['server_moneybank_transfer_property'] = 'new property transaction (moneybank)',
	['server_weapon_transfer_property'] = 'new property transaction (weapon)',
	
	['server_item_transfer_trunk'] = 'new trunk transaction (item)',
	['server_moneybank_transfer_trunk'] = 'new trunk transaction (moneybank)',
	['server_weapon_transfer_trunk'] = 'new trunk transaction (weapon)',
	
	['server_item_transfer_mafia'] = 'new mafia transaction (item)',
	['server_moneybank_transfer_mafia'] = 'new mafia transaction (moneybank)',
	['server_weapon_transfer_mafia'] = 'new mafia transaction (weapon)',
	
	['user_kill_environnement'] = 'died.',
	['server_moneybank_transfer'] = 'new transaction (moneybank)',
	['server_weapon_transfer'] = 'new transaction (weapon)',

	['user_gives_to'] = 'gives to',
	['user_put_object'] = 'put object',
	['user_get_object'] = 'get object',
	['user_buy_weapon'] = 'bought object',
	
	['server_washingmoney'] = 'washing money alert',
	['user_washingmoney'] = 'has washed',

	['server_blacklistedvehicle'] = 'blacklisted vehicle alert',
	['user_entered_in'] = 'entered in :',

	['server_policecar'] = 'police vehicle alert',
	['server_carjacking'] = 'stolen vehicle alert',
	['client_carjacking'] = 'has stolen',

	['user_kill'] = 'has been killed by',
	['server_kill'] = 'new death',
	['client_kill'] = 'has been killed by',
	['client_kill_environnement'] = 'is dead by suicide or PNJ attack',
	['with'] ='with',
	
	['new_robbery'] = 'New Robbery Alert :',
	['robbery_started'] = 'The robbery has been started by : ',
	['robbery_ended'] = 'The robbery has been ended at',
	['robbery_canceled'] = 'The robbery has been canceled at',
	
	['new_deposit'] = 'New Deposit(Society) Alert',	
	['depositaccount'] = 'deposited society money to ',	
	['withdrawaccount'] = 'withdrawn society money to ',	
	
	['new_bill'] = 'New Billing Alert',	
}
