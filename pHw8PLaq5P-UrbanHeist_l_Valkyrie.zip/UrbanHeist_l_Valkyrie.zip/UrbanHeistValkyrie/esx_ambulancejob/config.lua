Config                            = {}

Config.DrawDistance               = 100.0

Config.Marker                     = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false }

Config.ReviveReward               = 6000  -- revive reward, set to 0 if you don't want it enabled
Config.AntiCombatLog              = true -- enable anti-combat logging?
Config.LoadIpl                    = false -- disable if you're using fivem-ipl or other IPL loaders

Config.EnableJobBlip              = true

Config.Locale = 'en'

local second = 1000
local minute = 60 * second

Config.EarlyRespawnTimer          = 15 * minute  -- Time til respawn is available
Config.EarlyRespawnTimerPolice    = 5 * minute  -- Time til respawn is available
Config.BleedoutTimer              = 5 * minute -- Time til the player bleeds out

Config.EnablePlayerManagement     = true

Config.RemoveWeaponsAfterRPDeath  = true
Config.RemoveCashAfterRPDeath     = true
Config.RemoveItemsAfterRPDeath    = true

-- Let the player pay for respawning early, only if he can afford it.
Config.EarlyRespawnFine           = true
Config.EarlyRespawnFineCombatLog  = 100000
Config.EarlyRespawnFineAmount     = 50000

Config.RespawnPoint = { coords = vector3(298.68, -584.54, 43.26), heading = 58.64 }

Config.Hospitals = {

	CentralLosSantos = {

		Blip = {
			coords = vector3(342.88, -1398.03, 33.51),
			sprite = 61,
			scale  = 1.2,
			color  = 2
		},

		AmbulanceActions = {
		--LOCKER ROOM
			vector3(360, -1425.88, 31.51), 
			--vector3(1832.71, 3693.38, 39.78),
		},

		Pharmacies = {
		--MEDKIT  BANDAGE
			vector3(380.23, -1405.52, 31.51),
			vector3(1827.1, 3691.13, 39.83 -0.9),
		},

		Vehicles = { --pillbox
			{
				--GARAGE FOR  EMS
				Spawner = vector3(393.51, -1431.31, 29.44),
				InsideShop = vector3(228.5, -993.5, -99.5),
				Marker = { type = 36, x = 1.0, y = 1.0, z = 1.0, r = 0, g = 225, b = 0, a = 100, rotate = true },
				SpawnPoints = {
					{ coords = vector3(398.74, -1429.47, 29.45), heading = 238.48, radius = 4.0 }
				}
			}
		},
		
		Vehicles_2 = { --sandyshores
			{
				--GARAGE FOR  EMS
				Spawner = vector3(1836.76, 3696.12, 34.27),
				InsideShop = vector3(228.5, -993.5, -99.5),
				Marker = { type = 36, x = 1.0, y = 1.0, z = 1.0, r = 0, g = 225, b = 0, a = 100, rotate = true },
				SpawnPoints = {
					{ coords = vector3(1827.09, 3693.53, 34.22), heading = 297.86, radius = 4.0 },
					
				}
			}
		},

		Helicopters = {
			{
				--GARAGE FOR  EMS HELICOPTER
				Spawner = vector3(307.08, -1458.47, 46.51),
				InsideShop = vector3(-75.24, -818.98, 325.18),
				Marker = { type = 34, x = 1.0, y = 1.0, z = 1.0, r = 0, g = 255, b = 0, a = 100, rotate = true },
				SpawnPoints = {
					{ coords = vector3(299.42, -1453.37, 46.51), heading = 143.35, radius = 10.0 }
					
				}
			}
		},
		
		Helicopters_2 = {
			{
				--GARAGE FOR  EMS HELICOPTER
				Spawner = vector3(1836.29, 3685.37, 44.66),
				InsideShop = vector3(-75.24, -818.98, 325.18),
				Marker = { type = 34, x = 1.0, y = 1.0, z = 1.0, r = 0, g = 255, b = 0, a = 100, rotate = true },
				SpawnPoints = {
					{ coords = vector3(1828.68, 3675.44, 45.04), heading = 114.84, radius = 10.0 },
					
				}
			}
		},

		FastTravels = {
			{
				--ELEVATOR TO HELICOPTER CITY
				From = vector3(275.3, -1361, -99.9),
				To = { coords = vector3(295.8, -1446.5, -99.9), heading = 0.0 },
				Marker = { type = 1, x = 2.0, y = 2.0, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false }	
			},

			{
				--HELICOPTER TO ELEVATOR CITY
				From = vector3(275.3, -1361, -99.9),
				To = { coords = vector3(295.8, -1446.5, -99.9), heading = 0.0 },
				Marker = { type = 1, x = 2.0, y = 2.0, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false }
			},

			{
			-----1ST FLOOR TO GROUND FLOOR
				From = vector3(247.3, -1371.5, -99.9),
				To = { coords = vector3(333.1, -1434.9, -99.9), heading = 138.6 },
				Marker = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false }
			},

			{
			----GROUND FLOOR TO 1ST FLOOR
			From = vector3(335.5, -1432.0, -99.9),
			To = { coords = vector3(249.1, -1369.6, -99.9), heading = 0.0 },
			Marker = { type = 1, x = 2.0, y = 2.0, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false }
			},

			{
				From = vector3(234.5, -1373.7, -99.9),
				To = { coords = vector3(320.9, -1478.6, -99.9), heading = 0.0 },
				Marker = { type = 1, x = 1.5, y = 1.5, z = 1.0, r = 102, g = 0, b = 102, a = 100, rotate = false }
			},

			{
				From = vector3(317.9, -1476.1, -99.9),
				To = { coords = vector3(238.6, -1368.4, -99.9), heading = 0.0 },
				Marker = { type = 1, x = 1.5, y = 1.5, z = 1.0, r = 102, g = 0, b = 102, a = 100, rotate = false }
			}
		},

		FastTravelsPrompt = {
			{
				From = vector3(237.4, -1373.8, -99.9),
				To = { coords = vector3(251.9, -1363.3, 38.5), heading = 0.0 },
				Marker = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false },
				Prompt = _U('fast_travel')
			},

			{
				From = vector3(256.5, -1357.7, -99.9),
				To = { coords = vector3(235.4, -1372.8, 26.3), heading = 0.0 },
				Marker = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false },
				Prompt = _U('fast_travel')
			}
		}

	}
}

Config.AuthorizedVehicles = {

	ambulance = {
		{ model = 'lsambulance', label = 'Ambulance Van 1', price = 5000},
		{ model = 'ambulance22', label = 'Ambulance Van 2', price = 5000}
	},

	doctor = {
		{ model = 'lsambulance', label = 'Ambulance Van 1', price = 5000},
		{ model = 'ambulance22', label = 'Ambulance Van 2', price = 5000},
		{ model = 'ems', label = 'Ambulance Car', price = 5000}
	},

	chief_doctor = {
		{ model = 'lsambulance', label = 'Ambulance Van 1', price = 5000},
		{ model = 'ambulance22', label = 'Ambulance Van 2', price = 5000},
		{ model = 'ems', label = 'Ambulance Car', price = 5000},
		{ model = 'dodgeEMS', label = 'Dodge Ems', price = 5000}
	},

	boss = {
		{ model = 'lsambulance', label = 'Ambulance Van 1', price = 5000},
		{ model = 'ambulance22', label = 'Ambulance Van 2', price = 5000},
		{ model = 'ems', label = 'Ambulance Car', price = 5000},
		{ model = 'dodgeEMS', label = 'Dodge Ems', price = 5000}
	}

}

Config.AuthorizedHelicopters = {

	ambulance = {},

	doctor = {
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 200000 },
		{ model = 'seasparrow', label = 'Sea Sparrow', price = 200000 }
	},

	chief_doctor = {
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 150000 },
		{ model = 'seasparrow', label = 'Sea Sparrow', price = 150000 },
		{ model = 'supervolito', label = 'Ambulance Gamerful Chopper', price = 300000 }
	},

	boss = {
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 100000 },
		{ model = 'seasparrow', label = 'Sea Sparrow', price = 100000 },
		{ model = 'supervolito', label = 'Ambulance Gamerful Chopper', price = 250000 }
	}

}