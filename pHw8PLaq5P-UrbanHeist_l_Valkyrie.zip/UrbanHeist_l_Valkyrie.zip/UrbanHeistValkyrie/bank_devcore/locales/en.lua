Locales['en'] = {
    ['invalid_amount'] = 'Invalid Amount',
    ['atm_blip'] = 'ATM',
    ['bank_blip'] = 'Bank',
    ['atm_open'] = 'Press ~INPUT_PICKUP~ to access your account ~b~',
    ['no_money'] = 'You dont have enough money.',
    ['recieved1'] = 'You have received money ',
    ['recieved2'] = 'You received the money ',
    ['recieved3'] = ' dollars',
    ['removed1'] = 'Confirmation of payment ',
    ['removed2'] = 'Your payment ',
    ['removed3'] = ' dollars has been updated.',
}
