Config              = {}
Config.MarkerType   = 27
Config.DrawDistance = 100.0
Config.ZoneSize     = {x = 3.0, y = 3.0, z = 1.0}
Config.MarkerColor  = {r = 250, g = 0, b = 0}
Config.ZDiff        = 2.0
Config.BlipSprite   = 431
Config.Locale       = 'en'

Config.WASH = {
--- Original Wash
    { ['x'] =  1129.47,  ['y'] = -3194.5,  ['z'] = -40.4},
	
--- Chinese Temple
	--{ ['x'] =  -924.99,  ['y'] = -1467.21,  ['z'] = 5.2},
	
--- Payaman(Ganghouse1)
	{ ['x'] =  -2675.5,  ['y'] = 1315.68,  ['z'] = 153.04},
	
--- Morte Family
	{ ['x'] =  -6.33,  ['y'] = 527.52,  ['z'] = 175.03},
	
--- Humane Laboratory
	-- { ['x'] =  3561.87,  ['y'] = 3678.9,  ['z'] = 29.12},
	
--- Michael House
	-- { ['x'] =  -801.57,  ['y'] = 171.52,  ['z'] = 77.43},
	
-- RedSkull
	{ ['x'] =  -2514.05,  ['y'] = 779.53,  ['z'] = 312.97},
	
--- Yankee Brotherhood
	{ ['x'] =  -16.62,  ['y'] = -1430.32,  ['z'] = 32.1},
	
--- LSPD 
	{ ['x'] =  452.89,  ['y'] = -973.51,  ['z'] = 30.69}
}
Config.Map = {
  {name="Money Wash",  		color=6, scale=0.8, id=500, x = 137.792, y = -1707.263, z = 28.291}
}