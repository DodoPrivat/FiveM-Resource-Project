Config = {}
Config.DrawDistance = 100.0
Config.EnablePlayerManagement = false
Config.EnableVaultManagement = false
Config.EnableMoneyWash = false
Config.MaxInService = -1
Config.Locale = 'en'
Config.MissCraft = 1 -- %

Config.Blips = {
    Blip = {
        Pos = {x = 113.9, y = -1296.64, z = 29.27},
        Sprite = 614,
        Display = 4,
        Scale = 1.0,
        Colour = 61
    }
}

Config.Zones = {
    Entry = {
        Pos = {x = 113.9, y = -1296.64, z = 29.27},
        Size = {x = 0.5, y = 0.5, z = 0.5},
        Color = {r = 182, g = 0, b = 255},
        Type = 21,
        open = true
    },
    Exit = {
        Pos = {x = -1569.37, y = -3017.49, z = -74.30},
        Size = {x = 0.5, y = 0.5, z = 0.5},
        Color = {r = 182, g = 0, b = 255},
        Type = 21,
        open = true
    },
    -----------------------
    -------- SHOPS --------

    Flacons = {
        Pos = { x = -1586.97, y = -3012.73, z = -76.00 },
        Size = {x = 0.5, y = 0.5, z = 0.5},
        Color = {r = 182, g = 0, b = 255},
        Type = 29,
		open = true,
        Items = {
			{name = 'gin', label = 'Gin Bilog', price = 100},
            {name = 'jager', label = _U('jager'), price = 300},
            {name = 'vodka', label = _U('vodka'), price = 400},
			{name = 'whisky', label = 'Banayad Whisky', price = 400},
            {name = 'rhum', label = 'Tanduay Rhum', price = 200},
            {name = 'tequila', label = _U('tequila'), price = 200},
            {name = 'martini', label = _U('martini'), price = 500},
            {name = 'beer', label = 'San Miguel Beer', price = 150}
        }
    },
    NoAlcool = {
        Pos = { x = -1577.56, y = -3014.65, z = -79.01 },
        Size = {x = 0.5, y = 0.5, z = 0.5},
        Color = {r = 182, g = 0, b = 255},
        Type = 29,
		open = true,
        Items = {
            {name = 'water', label = 'Water', price = 22},
            {name = 'soda', label = 'Coca Cola', price = 45},         
            {name = 'icetea', label = 'Nestea IceTea', price = 35},
			{name = 'juice', label = 'Tang Orange', price = 35},
            {name = 'energy', label = 'Cobra', price = 35},
            {name = 'powerade', label = 'Powerade', price = 35},
            {name = 'limonade', label = 'C2', price = 35}
        }
    }
}

