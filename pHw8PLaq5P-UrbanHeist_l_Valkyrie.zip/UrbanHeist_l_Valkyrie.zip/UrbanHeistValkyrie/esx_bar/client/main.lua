local PlayerData = {}
local HasAlreadyEnteredMarker = false
local LastZone = nil
local CurrentAction = nil
local CurrentActionMsg = ''
local CurrentActionData = {}
local isInMarker = false

ESX = nil
Citizen.CreateThread(
    function()
        while ESX == nil do
            TriggerEvent(
                'esx:getSharedObject',
                function(obj)
                    ESX = obj
                end
            )
            Citizen.Wait(0)
        end
    end
)

-- Create blips
Citizen.CreateThread(
    function()
        local blipMarker = Config.Blips.Blip
        local blipCoord = AddBlipForCoord(blipMarker.Pos.x, blipMarker.Pos.y, blipMarker.Pos.z)

        SetBlipSprite(blipCoord, blipMarker.Sprite)
        SetBlipDisplay(blipCoord, blipMarker.Display)
        SetBlipScale(blipCoord, blipMarker.Scale)
        SetBlipColour(blipCoord, blipMarker.Colour)
        SetBlipAsShortRange(blipCoord, true)

        BeginTextCommandSetBlipName('STRING')
        AddTextComponentString(_U('map_blip'))
        EndTextCommandSetBlipName(blipCoord)
    end
)

function TPClub(enter)
    local pos 
    local playerPed = GetPlayerPed(-1)
    if enter then
        pos = Config.Zones.Exit.Pos
    elseif not enter then
        pos = Config.Zones.Entry.Pos
    end
    --DoScreenFadeOut(500)
    --Citizen.Wait(500)
    ESX.Game.Teleport(playerPed, pos)
    CurrentAction = nil
    --Citizen.Wait(1000)
    --DoScreenFadeIn(1000)
end

function OpenShopMenu(zone)
    local elements = {}
    for i = 1, #Config.Zones[zone].Items, 1 do
        local item = Config.Zones[zone].Items[i]

        table.insert(
            elements,
            {
                label = item.label .. ' - <span style="color:green;">$' .. item.price .. ' </span>',
                realLabel = item.label,
                value = item.name,
                price = item.price
            }
        )
    end

    ESX.UI.Menu.CloseAll()

    ESX.UI.Menu.Open(
        'default',
        GetCurrentResourceName(),
        'nightclub_shop',
        {
            title = _U('shop'),
            align = 'right',
            elements = elements
        },
        function(data, menu)
            TriggerServerEvent('esx_bar:buyItem', data.current.value, data.current.price, data.current.realLabel)
        end,
        function(data, menu)
            menu.close()
        end
    )
end

RegisterNetEvent('esx:playerLoaded')
AddEventHandler(
    'esx:playerLoaded',
    function(xPlayer)
        PlayerData = xPlayer
    end
)

RegisterNetEvent('esx:setJob')
AddEventHandler(
    'esx:setJob',
    function(job)
        PlayerData.job = job
    end
)

-- EVENT
AddEventHandler(
    'esx_bar:hasEnteredMarker',
    function(zone)
        if zone == 'Entry' then
            CurrentAction = 'entry_club'
            CurrentActionMsg = 'Press ~INPUT_CONTEXT~ to enter the Club.'
            CurrentActionData = {}
        end

        if zone == 'Exit' then
            CurrentAction = 'exit_club'
            CurrentActionMsg = 'Press ~INPUT_CONTEXT~ to exit the Club.'
            CurrentActionData = {}
        end
		
        if zone == 'Flacons' or zone == 'NoAlcool' then
            CurrentAction = 'menu_shop'
            CurrentActionMsg = _U('shop_menu')
            CurrentActionData = {zone = zone}
        end

		
    end
)

AddEventHandler(
    'esx_bar:hasExitedMarker',
    function(zone)
        CurrentAction = nil
        ESX.UI.Menu.CloseAll()
    end
)

-- Display markers
Citizen.CreateThread(
    function()
        while true do
            Citizen.Wait(0)

            local coords = GetEntityCoords(GetPlayerPed(-1))
            local isInMarker = false
            local currentZone = nil
            local letSleep = true

            for k, v in pairs(Config.Zones) do
                if (v.open == true) then
                    if (v.Type ~= -1 and GetDistanceBetweenCoords(coords, v.Pos.x, v.Pos.y, v.Pos.z, true) < Config.DrawDistance) then
                        DrawMarker(v.Type, v.Pos.x, v.Pos.y, v.Pos.z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, v.Size.x, v.Size.y, v.Size.z, v.Color.r, v.Color.g, v.Color.b, 100, false, false, 2, true, false, false, false)
                        letSleep = false
                    end

                    if (GetDistanceBetweenCoords(coords, v.Pos.x, v.Pos.y, v.Pos.z, true) < 2.0) then
                        isInMarker = true
                        currentZone = k
                    end
                end
            end

            if (isInMarker and not HasAlreadyEnteredMarker) or (isInMarker and LastZone ~= currentZone) then
                HasAlreadyEnteredMarker = true
                LastZone = currentZone
                TriggerEvent('esx_bar:hasEnteredMarker', currentZone)
            end

            if not isInMarker and HasAlreadyEnteredMarker then
                HasAlreadyEnteredMarker = false
                TriggerEvent('esx_bar:hasExitedMarker', LastZone)
            end

            if letSleep then
                Citizen.Wait(500)
            end
        end
    end
)


--Key Controls
Citizen.CreateThread(
    function()
        while true do
            Citizen.Wait(10)

            if CurrentAction ~= nil then
                SetTextComponentFormat('STRING')
                AddTextComponentString(CurrentActionMsg)
                DisplayHelpTextFromStringLabel(0, 0, 1, -1)

					if IsControlJustReleased(0, 38) then
						if CurrentAction == 'entry_club' then
							TPClub(true)
						end

						if CurrentAction == 'exit_club' then
							TPClub(false)
						end
						if CurrentAction == 'menu_shop' then
							OpenShopMenu(CurrentActionData.zone)
						end
					end

 
				end
			end
    end
)