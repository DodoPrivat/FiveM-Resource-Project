Locales['en'] = {
    -- Cloakroom
    ['cloakroom'] = 'Cloakroom',
    ['citizen_wear'] = 'Civil Clothing',
    ['barman_outfit'] = 'Barman outfit',
    ['security_outfit'] = 'Security Clothing',
    ['dancer_outfit_1'] = 'Dancer 1 Clothing',
    ['dancer_outfit_2'] = 'Dancer 2 Clothing',
    ['dancer_outfit_3'] = 'Dancer 3 Clothing',
    ['no_outfit'] = "There is no uniform at your size....",
    ['open_cloackroom'] = 'Press ~INPUT_CONTEXT~ to change you.',
    -- Vault
    ['get_weapon'] = 'Take weapon',
    ['put_weapon'] = 'Store weapon',
    ['get_weapon_menu'] = 'Vault - Take weapon',
    ['put_weapon_menu'] = 'Vault - Store weapon',
    ['get_object'] = 'Take object',
    ['put_object'] = 'Store object',
    ['vault'] = 'Vault',
    ['open_vault'] = 'Press ~INPUT_CONTEXT~ to access the vault.',
    -- Fridge
    ['fridge'] = 'Fridge',
    ['open_fridge'] = 'Press ~INPUT_CONTEXT~ to access the fridge.',
    ['nightclub_fridge_stock'] = 'Nightclub Fridge',
    ['fridge_inventory'] = 'Fridge contents',
    -- Shops
    ['shop'] = 'Nightclub Bar',
    ['shop_menu'] = 'Press ~INPUT_CONTEXT~ to bring out a drink.',
    ['bought'] = 'You bought ~b~ 1x',
    ['not_enough_money'] = 'You don\'t have enough money.',
    ['not_in_vehicle'] = '~r~You\'re not in the limo.',
    ['max_item'] = "You can\'t carry more than that.",
    -- Boss Menu
    ['take_company_money'] = 'Withdraw money',
    ['deposit_money'] = 'Deposit money',
    ['amount_of_withdrawal'] = 'Withdrawal amount',
    ['invalid_amount'] = 'Invalid amount',
    ['amount_of_deposit'] = 'Deposit amount',
    ['open_bossmenu'] = 'Press ~INPUT_CONTEXT~ to manage the company.',
    ['invalid_quantity'] = 'Invalid quantity',
    ['you_removed'] = 'You have removed x',
    ['you_added'] = 'You have added x',
    ['quantity'] = 'Quantity',
    ['inventory'] = 'Inventory',
    ['nightclub_stock'] = 'Nightclub Stock',
    -- Billing Menu
    ['billing'] = 'Invoices',
    ['no_players_nearby'] = 'No players close by.',
    ['billing_amount'] = 'Billing',
    ['amount_invalid'] = 'Invalid amount',
    -- Crafting Menu
    ['crafting'] = 'Cocktails',

    ['icetea'] = 'Lipton IceTea',
    ['energy'] = 'Redbull',
    ['limonade'] = '7up',
    ['soda'] = 'Coca-cola',
    ['jusfruit'] = 'Tropicana',

    ['tequila'] = 'Don Juan',
    ['whiskey'] = 'Jack Daniels',
    ['martini'] = 'Martini',
    ['jager'] = 'J�germeister',
    ['vodka'] = 'Vodka',
    ['rhum'] = 'Havana Club',
	

    ['ice'] = 'Ice',
    ['menthe'] = 'Mint',

    ['jagerbomb'] = 'J�gerbomb',
    ['whiskycoca'] = 'Whiskey-coca',
    ['vodkaenergy'] = 'Vodka-redbull',
    ['vodkafruit'] = 'Vodka-fruit',
    ['rhumfruit'] = 'Rum-fruit',
    ['teqpaf'] = "Teq'paf",
    ['rhumcoca'] = 'Rhum-coca',
    ['mojito'] = 'Mojito',

    ['assembling_cocktail'] = 'Mixing of ingredients in progress....',
    ['craft_miss'] = 'You missed the cocktails...',
    ['not_enough'] = 'Not enough ~r~ ',
    ['craft'] = 'You\'re done mixing ~g~',
    -- Misc
    ['start_security'] = 'Press ~INPUT_CONTEXT~ to start security.',
    ['spawn_car'] = 'Press ~INPUT_CONTEXT~ to get a limousine out.',
    ['despawn_car'] = 'Press ~INPUT_CONTEXT~ to return the limousine.',
    ['mission'] = 'Limousine Driver',
    ['map_blip'] = 'Nightclub',
    ['nightclub'] = 'Nightclub',
    ['you_win'] = 'You have won ~g~+',
    ['your_comp_earned'] = 'Your company has won ~g~+',
    ['exit_club'] = "Press ~INPUT_CONTEXT~ to exit the Club.",
    ['enter_club'] = "Press ~INPUT_CONTEXT~ to enter the Club.",
    ['search'] = "Search",
    ['guns_label'] = '--- Weapons ---',
    ['inventory_label'] = '--- Inventory ---',
    ['license_label'] = ' --- Licenses ---',
    ['confiscate'] = 'confiscate %s',
    ['confiscate_weapon'] = 'confiscate %s with %s ammunition',
    ['confiscate_inv'] = 'confiscate %sx %s',
    ['confiscate_dirty'] = 'confiscate dirty money: <span style="color:red;">�%s</span>',
    ['you_confiscated'] = 'you confiscated ~y~%sx~s~ ~b~%s~s~ � ~b~%s~s~',
    ['got_confiscated'] = '~y~%sx~s~ ~b~%s~s~ were confiscated by ~y~%s~s~',
    ['you_confiscated_account'] = 'you confiscated ~g~$%s~s~ (%s) � ~b~%s~s~',
    ['got_confiscated_account'] = '~g~$%s~s~ (%s) were confiscated by ~y~%s~s~',
    ['you_confiscated_weapon'] = 'you confiscated ~b~%s~s~ to ~b~%s~s~s~ with ~o~%s~s~ bullets',
    ['got_confiscated_weapon'] = 'your ~b~%s~s~s~ with ~o~%s~s~bullets has been confiscated by ~y~%s~s~s~',
    -- Phone
    ['nightclub_phone'] = 'Nightclub',
    ['nightclub_customer'] = 'Client'
}