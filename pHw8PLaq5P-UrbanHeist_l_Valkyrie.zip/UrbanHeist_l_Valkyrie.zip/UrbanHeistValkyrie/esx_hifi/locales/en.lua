Locales ['en'] = {
	['put_hifi'] = 'You have just dropped the BoomBox',
	['get_hifi'] = 'Pick up the BoomBox',
	['play_music'] = 'Start the music',
	['stop_music'] = 'Stop the music',
	['volume_music'] = 'Adjust the volume',
	['hifi_alreadyOne'] = 'You already have a BoomBox on you',
	['set_volume'] = 'Enter the volume level (between 0 and 100)',
	['play_id'] = 'Enter the id of the YouTube video',
	['sound_limit'] = 'The volume must be between 0 and 100',
	['hifi_help'] = 'press ~INPUT_PICKUP~ to adjust the music'
}
