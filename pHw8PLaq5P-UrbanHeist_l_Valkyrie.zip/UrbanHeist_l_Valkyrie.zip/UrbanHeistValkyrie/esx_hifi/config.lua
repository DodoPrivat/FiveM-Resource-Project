Config = {}
Config.Locale = 'en'
Config.distance = 8