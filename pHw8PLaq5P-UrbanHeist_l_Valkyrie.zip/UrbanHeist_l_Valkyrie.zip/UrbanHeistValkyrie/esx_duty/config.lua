Config                            = {}
Config.DrawDistance               = 100.0
--language currently available EN and SV
Config.Locale = 'en'

Config.Zones = {

  PoliceDuty = {
    Pos   = { x = 441.01, y = -976.05, z = 29.69 },
    Size  = { x = 1.5, y = 1.5, z = 1.0 },
    Color = { r = 255, g = 255, b = 255 },  
    Type  = 27,
  },

  AmbulanceDuty = {
    Pos = { x = 361.95, y = -1413.88, z = 31.59 },
    Size = { x = 1.0, y = 1.0, z = 1.0 },
    Color = { r = 255, g = 255, b = 255 },
    Type = 27,
  },
}