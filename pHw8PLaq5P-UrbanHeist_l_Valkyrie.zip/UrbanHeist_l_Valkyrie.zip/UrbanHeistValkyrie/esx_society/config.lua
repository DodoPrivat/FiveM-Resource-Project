Config = {}

Config.Locale = 'en'
Config.EnableESXIdentity = false
Config.MaxSalary = 9999999
