Locales ['de'] = {
  ['buy_license'] = 'buy weapon license?',
  ['yes'] = '%s',
  ['no'] = 'no',
  ['weapon_bought'] = 'purchased for %s EUR',
  ['not_enough_black'] = 'du hast nicht genug Schwarzgeld',
  ['not_enough'] = 'du hast nicht genug Geld',
  ['already_owned'] = 'you already own this weapon!',
  ['shop_menu_title'] = 'geschäft',
  ['shop_menu_prompt'] = 'drücke ~INPUT_CONTEXT~ um auf das Geschäft zuzugreifen.',
  ['shop_menu_item'] = '%s EUR',
  ['map_blip'] = 'waffenladen',
}
