Config                            = {}

Config.Teleporters = {
	['PD'] = {
		['Job'] = 'police',
		['Enter'] = { 
			['x'] = 470.63, 
			['y'] = -984.93, 
			['z'] = 29.69,
			['Information'] = '[E] Travel to HeliPad',
		},
		['Exit'] = {
			['x'] = 463.68, 
			['y'] = -984.05, 
			['z'] = 42.69, 
			['Information'] = '[E] Travel to 1st Floor Hospital' 
		}
	},

	['HP'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 298.59, 
			['y'] = -599.28, 
			['z'] = 42.29,
			['Information'] = '[E] Travel to Hospital Ground Floor' 
		},

		['Exit'] = {
			['x'] = 340.91, 
			['y'] = -595.53, 
			['z'] = 27.79, 
			['Information'] = '[E] Travel to 1st Floor Hospital' 
		}
	},

	['HPHELIPAD'] = {
		['Job'] = 'ambulance',
		['Enter'] = { 
			['x'] = 372.24, 
			['y'] = -1421.18, 
			['z'] = 31.51,
			['Information'] = '[E] Travel to HeliPad' 
		},

		['Exit'] = {
			['x'] = 335.95, 
			['y'] = -1433.15, 
			['z'] = 45.51, 
			['Information'] = '[E] Travel to 1st Floor Hospital' 
		}
	},

	['HPSANDYSHORE'] = {
		['Job'] = 'ambulance',
		['Enter'] = { 
			['x'] = 334.26, 
			['y'] = -1431.6, 
			['z'] = 45.51,
			['Information'] = '[E] Travel to HP Sandy Shore' 
		},

		['Exit'] = {
			['x'] = 1827.31, 
			['y'] = 3664.67, 
			['z'] = 38.87, 
			['Information'] = '[E] Travel to 1st Floor Hospital' 
		}
	}

	--Next here
}


