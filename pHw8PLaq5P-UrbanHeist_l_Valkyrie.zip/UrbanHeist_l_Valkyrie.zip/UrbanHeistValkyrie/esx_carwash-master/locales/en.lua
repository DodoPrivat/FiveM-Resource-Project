Locales['en'] = {
  ['prompt_wash'] = 'press ~INPUT_CONTEXT~ to wash this vehicle',
  ['prompt_wash_paid'] = 'press ~INPUT_CONTEXT~ to wash this vehicle for ~g~$%s~s~',
  ['wash_failed'] = 'you cannot afford an car wash',
  ['wash_failed_clean'] = 'your vehicle does not need a car wash.',
  ['wash_successful'] = 'your vehicle has been washed',
  ['wash_successful_paid'] = 'your vehicle has been washed for ~g~$%s~s~',
  ['blip_carwash'] = 'car Wash',
}
