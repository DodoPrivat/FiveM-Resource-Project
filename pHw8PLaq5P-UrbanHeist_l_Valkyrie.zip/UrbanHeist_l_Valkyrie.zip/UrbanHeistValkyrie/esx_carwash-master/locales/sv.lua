Locales['sv'] = {
  ['prompt_wash'] = 'tryck ~INPUT_CONTEXT~ för att tvätta fordonet',
  ['prompt_wash_paid'] = 'tryck ~INPUT_CONTEXT~ för att tvätta fordonet för ~g~%s SEK~s~',
  ['wash_failed'] = 'du har inte råd med en biltvätt',
  ['wash_failed_clean'] = 'ditt fordon behöver ej en biltvätt.',
  ['wash_successful'] = 'ditt fordon har tvättats',
  ['wash_successful_paid'] = 'ditt fordon har tvättats för ~g~%s SEK~s~',
  ['blip_carwash'] = 'biltvätt',
}
