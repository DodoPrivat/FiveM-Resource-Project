Citizen.CreateThread(function()
	while true do
		SetDiscordAppId(625813700967661571) --Discord app id
		SetDiscordRichPresenceAsset('SPACEFIN') --Big picture asset name
        SetDiscordRichPresenceAssetText('Urban Heist') --Big picture hover text
        SetDiscordRichPresenceAssetSmall('SPACEFIN') --Small picture asset name
        SetDiscordRichPresenceAssetSmallText('Dev Server') --Small picture hover text
		Citizen.Wait(600000) --How often should this script check for updated assets? (in MS)
	end
end)
--No Need to mess with anything pass this point!
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(2500)
		local player = PlayerId()
        local name = GetPlayerName(player)
		local id = GetPlayerServerId(player)
		SetRichPresence(" " .. name .. "		| ".. #GetActivePlayers() .."/64 Players")
    end
end)