Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerColor                = { r = 120, g = 120, b = 240 }
Config.EnablePlayerManagement     = true -- enables the actual car dealer job. You'll need esx_addonaccount, esx_billing and esx_society
Config.EnableOwnedVehicles        = true
Config.EnableSocietyOwnedVehicles = false -- use with EnablePlayerManagement disabled, or else it wont have any effects
Config.ResellPercentage           = 0

Config.Locale = 'en'

Config.LicenseEnable = false -- require people to own drivers license when buying vehicles? Only applies if EnablePlayerManagement is disabled. Requires esx_license

-- looks like this: 'LLL NNN'
-- The maximum plate length is 8 chars (including spaces & symbols), don't go past it!
Config.PlateLetters  = 3
Config.PlateNumbers  = 4
Config.PlateUseSpace = true

Config.Zones = {

	ShopEntering = {
		Pos   = { x = -793.96, y = -218.67, z = 36.08 },
		Size  = { x = 1.5, y = 1.5, z = 1.0 },
		Type  = 27
	},

	ShopInside = {
		Pos     = { x = -783.45, y = -223.77, z = 36.32 },
		Size    = { x = 1.5, y = 1.5, z = 1.0 },
		Heading = 49.45,
		Type    = -1
	},

	ShopOutside = {
		Pos     = { x = -783.36, y = -223.5, z = 36.32 },
		Size    = { x = 1.5, y = 1.5, z = 1.0 },
		Heading = 134.35,
		Type    = -1
	},

	BossActions = {
		Pos   = { x = -788.37, y = -215.93, z = 37.08 },
		Size  = { x = 1.5, y = 1.5, z = 1.0 },
		Type  = -1
	},

	GiveBackVehicle = {
		Pos   = { x = 223.27, y = -170.33, z = 55.38 },
		Size  = { x = 3.0, y = 3.0, z = 1.0 },
		Type  = -1
	}

}
