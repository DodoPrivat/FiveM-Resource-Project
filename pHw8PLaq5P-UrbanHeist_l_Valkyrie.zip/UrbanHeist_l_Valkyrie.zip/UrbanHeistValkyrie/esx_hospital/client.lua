local cJ = false
local eJE = false
local inBedDict = "anim@gangops@morgue@table@"
local inBedAnim = "ko_front"
local getOutDict = 'switch@franklin@bed'
local getOutAnim = 'sleep_getup_rubeyes'
--ESX base

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
end)

-- Bed 1

RegisterNetEvent("HB1")
AddEventHandler("HB1", function(hT)
	Citizen.Trace('Sent To Hospital Bed 1')
	if cJ == true then
		return
	end
	local pP = GetPlayerPed(-1)
	if DoesEntityExist(pP) then
			
		Citizen.CreateThread(function()
			local playerOldLoc = GetEntityCoords(pP, true)
			SetEntityCoords(pP, 351.95, -568.57, 27.72)--{x = 459.5500793457,y = -994.46508789063,z = 23.914855957031 },
			RequestAnimDict(inBedDict)
				while not HasAnimDictLoaded(inBedDict) do
					Citizen.Wait(0)
				end
			SetEntityHeading(PlayerPedId(), 155.87 + 180)
			TaskPlayAnim(PlayerPedId(), inBedDict , inBedAnim ,8.0, -8.0, -1, 1, 0, false, false, false )	
			cJ = true
			eJE = false
			while hT > 0 and not eJE do
				timecheck(hT)
				pP = GetPlayerPed(-1)
				RemoveAllPedWeapons(pP, true)
				SetEntityInvincible(pP, true)
				if IsPedInAnyVehicle(pP, false) then
					ClearPedTasksImmediately(pP)
				end
				if hT % 60 == 0 then
				exports.pNotify:SetQueueMax("left", 1)
			        exports.pNotify:SendNotification({
			            text = "You have " .. hT / 60 .. " days left until your fully healed." ,
			            type = "error",
			            timeout = math.random(1000, 10000),
			            layout = "centerLeft",
			            queue = "left"
			        })
				end
				Citizen.Wait(500)
				local pL = GetEntityCoords(pP, true)
				local D = Vdist(351.95, -568.57, 27.72, pL['x'], pL['y'], pL['z'])
				if D > 2 then -- distance#######################################################################################
					
					
					SetEntityCoords(pP, 351.95, -568.57, 27.72)
					if D > 4 then
						hT = hT + 30 -- change back to 60
						if hT > 1500 then
							hT = 1500
						end
						Citizen.Trace('GUESS I TRIED TO GET UP')
						TriggerEvent('chatMessage', 'DOCTOR', { 255, 0, 0 }, "You were given more time to heal because you ripped out your stitches!")
					end
				end
				hT = hT - 0.5
			end
			Citizen.Trace('IM FREE')
			TriggerServerEvent('HospitalReleaseTime') -- UDPATE DB TO RELESE PLAYER
			TriggerServerEvent('chatMessageEntered', "SYSTEM", { 255, 0, 0 }, GetPlayerName(PlayerId()) .." was released from the hospital.")
			SetEntityCoords(pP, 351.95, -568.57, 27.72)--{x = 432.95864868164,y = -981.41455078125,z = 29.710334777832 },
			RequestAnimDict(getOutDict) --HOSPITAL RELEASE
			while not HasAnimDictLoaded(getOutDict) do
				Citizen.Wait(0)
			end
			SetEntityHeading(PlayerPedId(), 155.87 - 90)
			TaskPlayAnim(PlayerPedId(), getOutDict , getOutAnim ,8.0, -8.0, -1, 0, 0, false, false, false )
			cJ = false
			SetEntityInvincible(pP, false)
		end)
	end
end)

-- Bed 2

RegisterNetEvent("HB2")
AddEventHandler("HB2", function(hT)
	Citizen.Trace('Sent To Hospital Bed 2')
	if cJ == true then
		return
	end
	local pP = GetPlayerPed(-1)
	if DoesEntityExist(pP) then
			
		Citizen.CreateThread(function()
			local playerOldLoc = GetEntityCoords(pP, true)
			SetEntityCoords(pP, 357.69, -563.4, 29.72)--{x = 459.5500793457,y = -994.46508789063,z = 23.914855957031 },
			RequestAnimDict(inBedDict)
				while not HasAnimDictLoaded(inBedDict) do
					Citizen.Wait(0)
				end
			SetEntityHeading(PlayerPedId(), 335.6 + 180)
			TaskPlayAnim(PlayerPedId(), inBedDict , inBedAnim ,8.0, -8.0, -1, 1, 0, false, false, false )	
			cJ = true
			eJE = false
			while hT > 0 and not eJE do
				timecheck(hT)
				pP = GetPlayerPed(-1)
				RemoveAllPedWeapons(pP, true)
				SetEntityInvincible(pP, true)
				if IsPedInAnyVehicle(pP, false) then
					ClearPedTasksImmediately(pP)
				end
				if hT % 60 == 0 then
				exports.pNotify:SetQueueMax("left", 1)
			        exports.pNotify:SendNotification({
			            text = "You have " .. hT / 60 .. " days left until your fully healed." ,
			            type = "error",
			            timeout = math.random(1000, 10000),
			            layout = "centerLeft",
			            queue = "left"
			        })
				end
				Citizen.Wait(500)
				local pL = GetEntityCoords(pP, true)
				local D = Vdist(357.69, -563.4, 29.72, pL['x'], pL['y'], pL['z'])
				if D > 2 then -- distance#######################################################################################
					
					
					SetEntityCoords(pP, 357.69, -563.4, 29.72)
					if D > 4 then
						hT = hT + 30 -- change back to 60
						if hT > 1500 then
							hT = 1500
						end
						Citizen.Trace('GUESS I TRIED TO GET UP')
						TriggerEvent('chatMessage', 'DOCTOR', { 255, 0, 0 }, "You were given more time to heal because you ripped out your stitches!")
					end
				end
				hT = hT - 0.5
			end
			Citizen.Trace('IM FREE')
			TriggerServerEvent('HospitalReleaseTime') -- UDPATE DB TO RELESE PLAYER
			TriggerServerEvent('chatMessageEntered', "SYSTEM", { 255, 0, 0 }, GetPlayerName(PlayerId()) .." was released from the hospital.")
			SetEntityCoords(pP, 357.69, -563.4, 29.72) --RELESE COORDS
			RequestAnimDict(getOutDict) --HOSPITAL RELEASE
			while not HasAnimDictLoaded(getOutDict) do
				Citizen.Wait(0)
			end
			SetEntityHeading(PlayerPedId(), 335.6 - 90)
			TaskPlayAnim(PlayerPedId(), getOutDict , getOutAnim ,8.0, -8.0, -1, 0, 0, false, false, false )
			cJ = false
			SetEntityInvincible(pP, false)
		end)
	end
end)


-- Bed 3


RegisterNetEvent("HB3")
AddEventHandler("HB3", function(hT)
	Citizen.Trace('Sent To Hospital Bed 3')
	if cJ == true then
		return
	end
	local pP = GetPlayerPed(-1)
	if DoesEntityExist(pP) then
			
		Citizen.CreateThread(function()
			local playerOldLoc = GetEntityCoords(pP, true)
			SetEntityCoords(pP, 348.76, -570.99, 29.5)--{x = 459.5500793457,y = -994.46508789063,z = 23.914855957031 },
			RequestAnimDict(inBedDict)
				while not HasAnimDictLoaded(inBedDict) do
					Citizen.Wait(0)
				end
			SetEntityHeading(PlayerPedId(), 66.91 + 180)
			TaskPlayAnim(PlayerPedId(), inBedDict , inBedAnim ,8.0, -8.0, -1, 1, 0, false, false, false )	
			cJ = true
			eJE = false
			while hT > 0 and not eJE do
				timecheck(hT)
				pP = GetPlayerPed(-1)
				RemoveAllPedWeapons(pP, true)
				SetEntityInvincible(pP, true)
				if IsPedInAnyVehicle(pP, false) then
					ClearPedTasksImmediately(pP)
				end
				if hT % 60 == 0 then
				exports.pNotify:SetQueueMax("left", 1)
			        exports.pNotify:SendNotification({
			            text = "You have " .. hT / 60 .. " days left until your fully healed." ,
			            type = "error",
			            timeout = math.random(1000, 10000),
			            layout = "centerLeft",
			            queue = "left"
			        })
				end
				Citizen.Wait(500)
				local pL = GetEntityCoords(pP, true)
				local D = Vdist(348.76, -570.99, 29.5, pL['x'], pL['y'], pL['z'])
				if D > 2 then -- distance#######################################################################################
					
					
					SetEntityCoords(pP, 348.76, -570.99, 29.5)
					if D > 4 then
						hT = hT + 30 -- change back to 60
						if hT > 1500 then
							hT = 1500
						end
						Citizen.Trace('GUESS I TRIED TO GET UP')
						TriggerEvent('chatMessage', 'DOCTOR', { 255, 0, 0 }, "You were given more time to heal because you ripped out your stitches!")
					end
				end
				hT = hT - 0.5
			end
			Citizen.Trace('IM FREE')
			TriggerServerEvent('HospitalReleaseTime') -- UDPATE DB TO RELESE PLAYER
			TriggerServerEvent('chatMessageEntered', "SYSTEM", { 255, 0, 0 }, GetPlayerName(PlayerId()) .." was released from the hospital.")
			SetEntityCoords(pP, 348.76, -570.99, 29.5) --RELESE COORDS
			RequestAnimDict(getOutDict) --HOSPITAL RELEASE
			while not HasAnimDictLoaded(getOutDict) do
				Citizen.Wait(0)
			end
			SetEntityHeading(PlayerPedId(), 66.91 - 90)
			TaskPlayAnim(PlayerPedId(), getOutDict , getOutAnim ,8.0, -8.0, -1, 0, 0, false, false, false )
			cJ = false
			SetEntityInvincible(pP, false)
		end)
	end
end)

-- Bed 1 - SANDYSHORES


RegisterNetEvent("HB4")
AddEventHandler("HB4", function(hT)
	Citizen.Trace('Sent To Hospital Bed 1 (Sandy Shores Hospital)')
	if cJ == true then
		return
	end
	local pP = GetPlayerPed(-1)
	if DoesEntityExist(pP) then
			
		Citizen.CreateThread(function()
			local playerOldLoc = GetEntityCoords(pP, true)
			SetEntityCoords(pP, 1838.22, 3672.2, 40.79)--{x = 459.5500793457,y = -994.46508789063,z = 23.914855957031 },
			RequestAnimDict(inBedDict)
				while not HasAnimDictLoaded(inBedDict) do
					Citizen.Wait(0)
				end
			SetEntityHeading(PlayerPedId(), 210.51 + 180)
			TaskPlayAnim(PlayerPedId(), inBedDict , inBedAnim ,8.0, -8.0, -1, 1, 0, false, false, false )	
			cJ = true
			eJE = false
			while hT > 0 and not eJE do
				timecheck(hT)
				pP = GetPlayerPed(-1)
				RemoveAllPedWeapons(pP, true)
				SetEntityInvincible(pP, true)
				if IsPedInAnyVehicle(pP, false) then
					ClearPedTasksImmediately(pP)
				end
				if hT % 60 == 0 then
				exports.pNotify:SetQueueMax("left", 1)
			        exports.pNotify:SendNotification({
			            text = "You have " .. hT / 60 .. " days left until your fully healed." ,
			            type = "error",
			            timeout = math.random(1000, 10000),
			            layout = "centerLeft",
			            queue = "left"
			        })
				end
				Citizen.Wait(500)
				local pL = GetEntityCoords(pP, true)
				local D = Vdist(1838.22, 3672.2, 40.79, pL['x'], pL['y'], pL['z'])
				if D > 2 then -- distance#######################################################################################
					
					
					SetEntityCoords(pP, 1838.22, 3672.2, 40.79)
					if D > 4 then
						hT = hT + 30 -- change back to 60
						if hT > 1500 then
							hT = 1500
						end
						Citizen.Trace('GUESS I TRIED TO GET UP')
						TriggerEvent('chatMessage', 'DOCTOR', { 255, 0, 0 }, "You were given more time to heal because you ripped out your stitches!")
					end
				end
				hT = hT - 0.5
			end
			Citizen.Trace('IM FREE')
			TriggerServerEvent('HospitalReleaseTime') -- UDPATE DB TO RELESE PLAYER
			TriggerServerEvent('chatMessageEntered', "SYSTEM", { 255, 0, 0 }, GetPlayerName(PlayerId()) .." was released from the hospital.")
			SetEntityCoords(pP, 1838.22, 3672.2, 40.79) --RELESE COORDS
			RequestAnimDict(getOutDict) --HOSPITAL RELEASE
			while not HasAnimDictLoaded(getOutDict) do
				Citizen.Wait(0)
			end
			SetEntityHeading(PlayerPedId(), 210.51 - 90)
			TaskPlayAnim(PlayerPedId(), getOutDict , getOutAnim ,8.0, -8.0, -1, 0, 0, false, false, false )
			cJ = false
			SetEntityInvincible(pP, false)
		end)
	end
end)

RegisterNetEvent("HB5")
AddEventHandler("HB5", function(hT)
	Citizen.Trace('Sent To Hospital Bed 2 (Sandy Shores Hospital)')
	if cJ == true then
		return
	end
	local pP = GetPlayerPed(-1)
	if DoesEntityExist(pP) then
			
		Citizen.CreateThread(function()
			local playerOldLoc = GetEntityCoords(pP, true)
			SetEntityCoords(pP, 1841.24, 3674.5, 40.79)--{x = 459.5500793457,y = -994.46508789063,z = 23.914855957031 },
			RequestAnimDict(inBedDict)
				while not HasAnimDictLoaded(inBedDict) do
					Citizen.Wait(0)
				end
			SetEntityHeading(PlayerPedId(), 210.51 + 180)
			TaskPlayAnim(PlayerPedId(), inBedDict , inBedAnim ,8.0, -8.0, -1, 1, 0, false, false, false )	
			cJ = true
			eJE = false
			while hT > 0 and not eJE do
				timecheck(hT)
				pP = GetPlayerPed(-1)
				RemoveAllPedWeapons(pP, true)
				SetEntityInvincible(pP, true)
				if IsPedInAnyVehicle(pP, false) then
					ClearPedTasksImmediately(pP)
				end
				if hT % 60 == 0 then
				exports.pNotify:SetQueueMax("left", 1)
			        exports.pNotify:SendNotification({
			            text = "You have " .. hT / 60 .. " days left until your fully healed." ,
			            type = "error",
			            timeout = math.random(1000, 10000),
			            layout = "centerLeft",
			            queue = "left"
			        })
				end
				Citizen.Wait(500)
				local pL = GetEntityCoords(pP, true)
				local D = Vdist(1841.24, 3674.5, 40.79, pL['x'], pL['y'], pL['z'])
				if D > 2 then -- distance#######################################################################################
					
					
					SetEntityCoords(pP, 1841.24, 3674.5, 40.79)
					if D > 4 then
						hT = hT + 30 -- change back to 60
						if hT > 1500 then
							hT = 1500
						end
						Citizen.Trace('GUESS I TRIED TO GET UP')
						TriggerEvent('chatMessage', 'DOCTOR', { 255, 0, 0 }, "You were given more time to heal because you ripped out your stitches!")
					end
				end
				hT = hT - 0.5
			end
			Citizen.Trace('IM FREE')
			TriggerServerEvent('HospitalReleaseTime') -- UDPATE DB TO RELESE PLAYER
			TriggerServerEvent('chatMessageEntered', "SYSTEM", { 255, 0, 0 }, GetPlayerName(PlayerId()) .." was released from the hospital.")
			SetEntityCoords(pP, 1841.24, 3674.5, 40.79) --RELESE COORDS
			RequestAnimDict(getOutDict) --HOSPITAL RELEASE
			while not HasAnimDictLoaded(getOutDict) do
				Citizen.Wait(0)
			end
			SetEntityHeading(PlayerPedId(), 210.51 - 90)
			TaskPlayAnim(PlayerPedId(), getOutDict , getOutAnim ,8.0, -8.0, -1, 0, 0, false, false, false )
			cJ = false
			SetEntityInvincible(pP, false)
		end)
	end
end)

RegisterNetEvent("HB6")
AddEventHandler("HB6", function(hT)
	Citizen.Trace('Sent To Hospital Bed 3 (Sandy Shores Hospital)')
	if cJ == true then
		return
	end
	local pP = GetPlayerPed(-1)
	if DoesEntityExist(pP) then
			
		Citizen.CreateThread(function()
			local playerOldLoc = GetEntityCoords(pP, true)
			SetEntityCoords(pP, 1844.01, 3675.68, 40.8)--{x = 459.5500793457,y = -994.46508789063,z = 23.914855957031 },
			RequestAnimDict(inBedDict)
				while not HasAnimDictLoaded(inBedDict) do
					Citizen.Wait(0)
				end
			SetEntityHeading(PlayerPedId(), 204.48 + 180)
			TaskPlayAnim(PlayerPedId(), inBedDict , inBedAnim ,8.0, -8.0, -1, 1, 0, false, false, false )	
			cJ = true
			eJE = false
			while hT > 0 and not eJE do
				timecheck(hT)
				pP = GetPlayerPed(-1)
				RemoveAllPedWeapons(pP, true)
				SetEntityInvincible(pP, true)
				if IsPedInAnyVehicle(pP, false) then
					ClearPedTasksImmediately(pP)
				end
				if hT % 60 == 0 then
				exports.pNotify:SetQueueMax("left", 1)
			        exports.pNotify:SendNotification({
			            text = "You have " .. hT / 60 .. " days left until your fully healed." ,
			            type = "error",
			            timeout = math.random(1000, 10000),
			            layout = "centerLeft",
			            queue = "left"
			        })
				end
				Citizen.Wait(500)
				local pL = GetEntityCoords(pP, true)
				local D = Vdist(1844.01, 3675.68, 40.8, pL['x'], pL['y'], pL['z'])
				if D > 2 then -- distance#######################################################################################
					
					
					SetEntityCoords(pP, 1844.01, 3675.68, 40.8)
					if D > 4 then
						hT = hT + 30 -- change back to 60
						if hT > 1500 then
							hT = 1500
						end
						Citizen.Trace('GUESS I TRIED TO GET UP')
						TriggerEvent('chatMessage', 'DOCTOR', { 255, 0, 0 }, "You were given more time to heal because you ripped out your stitches!")
					end
				end
				hT = hT - 0.5
			end
			Citizen.Trace('IM FREE')
			TriggerServerEvent('HospitalReleaseTime') -- UDPATE DB TO RELESE PLAYER
			TriggerServerEvent('chatMessageEntered', "SYSTEM", { 255, 0, 0 }, GetPlayerName(PlayerId()) .." was released from the hospital.")
			SetEntityCoords(pP, 1844.01, 3675.68, 40.8) --RELESE COORDS
			RequestAnimDict(getOutDict) --HOSPITAL RELEASE
			while not HasAnimDictLoaded(getOutDict) do
				Citizen.Wait(0)
			end
			SetEntityHeading(PlayerPedId(), 204.48 - 90)
			TaskPlayAnim(PlayerPedId(), getOutDict , getOutAnim ,8.0, -8.0, -1, 0, 0, false, false, false )
			cJ = false
			SetEntityInvincible(pP, false)
		end)
	end
end)


RegisterNetEvent("UnHB")
AddEventHandler("UnHB", function()
	eJE = true
end)

AddEventHandler('playerSpawned', function(spawn)
	Citizen.Trace('Check For If I Am Hospitalized')
    TriggerServerEvent('HospitalCheck')
end)

function timecheck(Time)
	if Time % 5 == 0 then
		TriggerServerEvent('HospitalUpdate', Time)
	elseif Time == 1 then
                TriggerServerEvent('HospitalReleaseTime')
                TriggerServerEvent('HospitalUpdate', 0)
	end
end
