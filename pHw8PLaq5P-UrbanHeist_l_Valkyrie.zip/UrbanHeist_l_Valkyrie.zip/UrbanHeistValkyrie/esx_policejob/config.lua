Config                            = {}

Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 0.5 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }

Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- enable if you're using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableLicenses             = true -- enable if you're using esx_license

Config.EnableHandcuffTimer        = false -- enable handcuff timer? will unrestrain player after the time ends
Config.HandcuffTimer              = 10 * 60000 -- 10 mins

Config.EnableJobBlip              = true -- enable blips for colleagues, requires esx_society

Config.MaxInService               = -1
Config.Locale = 'en'

Config.PoliceStations = {

	LSPD = {

		Blip = {
			Coords  = vector3(425.1, -979.5, 30.7),
			Sprite  = 60,
			Display = 4,
			Scale   = 1.2,
			Colour  = 29
		},

		Cloakrooms = {
			vector3(456.87, -990.72, 30.6),
		},

		Armories = {
			vector3(451.56, -980.08, 30.69),
		},

		Vehicles = {
			{
				Spawner = vector3(454.6, -1017.4, 28.4),
				InsideShop = vector3(228.5, -993.5, -99.5),
				SpawnPoints = {
					{ coords = vector3(438.4, -1018.3, 27.7), heading = 90.0, radius = 6.0 },
					{ coords = vector3(441.0, -1024.2, 28.3), heading = 90.0, radius = 6.0 },
					{ coords = vector3(453.5, -1022.2, 28.0), heading = 90.0, radius = 6.0 },
					{ coords = vector3(450.9, -1016.5, 28.1), heading = 90.0, radius = 6.0 }
				}
			},

			{
				Spawner = vector3(473.3, -1018.8, 28.0),
				InsideShop = vector3(228.5, -993.5, -99.0),
				SpawnPoints = {
					{ coords = vector3(475.9, -1021.6, 28.0), heading = 276.1, radius = 6.0 },
					{ coords = vector3(484.1, -1023.1, 27.5), heading = 302.5, radius = 6.0 }
				}
			}
		},

		Helicopters = {
			{
				Spawner = vector3(461.1, -981.5, 43.6),
				InsideShop = vector3(477.0, -1106.4, 43.0),
				SpawnPoints = {
					{ coords = vector3(449.5, -981.2, 43.6), heading = 92.6, radius = 10.0 }
				}
			}
		},

		Boats = {
			{
				Spawner = vector3(-1210.17, -1801.07, 3.91),
				InsideShop = vector3(-1277.3, -1892.6, 0.44),
				SpawnPoints = {
					{ coords = vector3(-1302.7, -1840.70, 1.40), heading = 137.61, radius = 10.0 }
				}
			}
		},
		
		BossActions = {
			vector3(448.4, -973.2, 30.6)
		}

	}

}

Config.BoatGarage = {
	Garage = {
		SpawnPoint = {-1210.17, -1801.07, 3.91}
	}
}

Config.AuthorizedWeapons = {

	recruit = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 10000 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 10 },
		{ weapon = 'WEAPON_STUNGUN', price = 10 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 80 }
	},

	po1 = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 10, 10, nil }, price = 1000 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 10, 10, 10, 10, nil }, price = 5000 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 10 },
		{ weapon = 'WEAPON_STUNGUN', price = 10 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 10 }
	},

	spo1 = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 10, 10, nil }, price = 1000 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 10, 10, 10, 10, nil }, price = 5000 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 10 },
		{ weapon = 'WEAPON_STUNGUN', price = 10 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 10 }
	},
	
	spo2 = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 10, 10, nil }, price = 1000 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 10, 10, 10, 10, nil }, price = 5000 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 10 },
		{ weapon = 'WEAPON_STUNGUN', price = 10 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 10 }
	},
	
	inspector = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 10, 10, nil }, price = 1000 },
		{ weapon = 'WEAPON_CARBINERIFLE', components = { 0, 10, 10, 10, 10, 10, nil }, price = 5000 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', components = { 10, 10, nil }, price = 7000 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 10 },
		{ weapon = 'WEAPON_STUNGUN', price = 10 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 10 }
	},

	srinspector = {
		{ weapon = 'WEAPON_MUSKET',  price = 10000 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 10, 10, nil }, price = 1000 },
		{ weapon = 'WEAPON_CARBINERIFLE', components = { 0, 10, 10, 10, 10, 10, nil }, price = 5000 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', components = { 10, 10, nil }, price = 7000 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 10 },
		{ weapon = 'WEAPON_STUNGUN', price = 10 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 10 }
	},
	
	
	chiefinspector = {
		{ weapon = 'WEAPON_MUSKET',  price = 10000 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 10, 10, nil }, price = 1000 },
		{ weapon = 'WEAPON_CARBINERIFLE', components = { 0, 10, 10, 10, 10, 10, nil }, price = 5000 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', components = { 10, 10, nil }, price = 7000 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 10 },
		{ weapon = 'WEAPON_STUNGUN', price = 10 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 10 }
	},

	director = {
		{ weapon = 'WEAPON_MUSKET',  price = 10000 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 10, 10, nil }, price = 1000 },
		{ weapon = 'WEAPON_CARBINERIFLE', components = { 0, 10, 10, 10, 10, 10, nil }, price = 5000 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', components = { 10, 10, nil }, price = 7000 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 10 },
		{ weapon = 'WEAPON_STUNGUN', price = 10 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 10 }
	},

	boss = {
		{ weapon = 'WEAPON_MUSKET', price = 10000 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 10, 10, nil }, price = 1000 },
		{ weapon = 'WEAPON_CARBINERIFLE', components = { 0, 10, 10, 10, 10, 10, nil }, price = 5000 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', components = { 10, 10, nil }, price = 7000 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 10 },
		{ weapon = 'WEAPON_STUNGUN', price = 10 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 10 }
	}
}

Config.AuthorizedVehicles = {
	Shared = {
	},

	recruit = {
		{ model = 'police3', label = 'Police Cruiser', price = 5000 },
		{ model = '1200RT', label = 'BMW S1000', price = 100000 },
	},
		
	po1 = {
		{ model = 'charger', label = 'Dodge Police', price = 50000 },
		{ model = '2015polstang', label = 'Mustang GT 2015', price = 50000 },
		{ model = 'camarorb', label = 'Camaro ZL1', price = 200000 },
		{ model = 'pol718', label = 'Porsche 718 Cayman', price = 800000 },
		{ model = 'polchiron', label = 'Bugatti Chiron Police', price = 2000000 },
		{ model = '1200RT', label = 'BMW S1000', price = 100000 },
		{ model = 'r1custom', label = 'Robocops', price = 400000 }
	},

	spo1 = {
		{ model = 'charger', label = 'Dodge Police', price = 50000 },
		{ model = '2015polstang', label = 'Mustang GT 2015', price = 50000 },
		{ model = 'camarorb', label = 'Camaro ZL1', price = 200000 },
		{ model = 'pol718', label = 'Porsche 718 Cayman', price = 800000 },
		{ model = 'polchiron', label = 'Bugatti Chiron Police', price = 2000000 },
		{ model = '1200RT', label = 'BMW S1000', price = 100000 },
		{ model = 'fbi2', label = 'FBI SUV', price = 10000 },
		{ model = 'pbus', label = 'Police Prison Bus', price = 500 }
	},
	
	spo2 = {
		{ model = 'charger', label = 'Dodge Police', price = 50000 },
		{ model = 'polmp4', label = 'Mclaren MP4 Police', price = 50000 },
		{ model = '2015polstang', label = 'Mustang GT 2015', price = 50000 },
		{ model = 'camarorb', label = 'Camaro ZL1', price = 200000 },
		{ model = 'pol718', label = 'Porsche 718 Cayman', price = 800000 },
		{ model = 'polchiron', label = 'Bugatti Chiron Police', price = 2000000 },
		{ model = '1200RT', label = 'BMW S1000', price = 100000 },
		{ model = 'fbi2', label = 'FBI SUV', price = 10000 },
		{ model = 'pbus', label = 'Police Prison Bus', price = 500 }
	},

	inspector = {
		{ model = 'charger', label = 'Dodge Police', price = 50000 },
		{ model = 'polmp4', label = 'Mclaren MP4 Police', price = 50000 },
		{ model = '2015polstang', label = 'Mustang GT 2015', price = 50000 },
		{ model = 'camarorb', label = 'Camaro ZL1', price = 200000 },
		{ model = 'pol718', label = 'Porsche 718 Cayman', price = 800000 },
		{ model = 'polchiron', label = 'Bugatti Chiron Police', price = 2000000 },
		{ model = '1200RT', label = 'BMW S1000', price = 100000 },
		{ model = 'fbi2', label = 'FBI SUV', price = 10000 },
		{ model = 'pbus', label = 'Police Prison Bus', price = 500 }
	},

	srinspector = {
		{ model = 'charger', label = 'Dodge Police', price = 50000 },
		{ model = 'polmp4', label = 'Mclaren MP4 Police', price = 50000 },
		{ model = '2015polstang', label = 'Mustang GT 2015', price = 50000 },
		{ model = 'camarorb', label = 'Camaro ZL1', price = 200000 },
		{ model = 'pol718', label = 'Porsche 718 Cayman', price = 800000 },
		{ model = 'polchiron', label = 'Bugatti Chiron Police', price = 2000000 },
		{ model = '1200RT', label = 'BMW S1000', price = 100000 },
		{ model = 'fbi2', label = 'FBI SUV', price = 10000 },
		{ model = 'pbus', label = 'Police Prison Bus', price = 500 }
	},

	chiefinspector = {
		{ model = 'charger', label = 'Dodge Police', price = 50000 },
		{ model = 'polmp4', label = 'Mclaren MP4 Police', price = 50000 },
		{ model = '2015polstang', label = 'Mustang GT 2015', price = 50000 },
		{ model = 'camarorb', label = 'Camaro ZL1', price = 200000 },
		{ model = 'pol718', label = 'Porsche 718 Cayman', price = 800000 },
		{ model = 'polchiron', label = 'Bugatti Chiron Police', price = 2000000 },
		{ model = '1200RT', label = 'BMW S1000', price = 100000 },
		{ model = 'fbi2', label = 'FBI SUV', price = 10000 },
		{ model = 'pbus', label = 'Police Prison Bus', price = 500 }
	},

	director = {
		{ model = 'charger', label = 'Dodge Police', price = 50000 },
		{ model = 'polmp4', label = 'Mclaren MP4 Police', price = 50000 },
		{ model = '2015polstang', label = 'Mustang GT 2015', price = 50000 },
		{ model = 'camarorb', label = 'Camaro ZL1', price = 200000 },
		{ model = 'pol718', label = 'Porsche 718 Cayman', price = 800000 },
		{ model = 'polchiron', label = 'Bugatti Chiron Police', price = 2000000 },
		{ model = '1200RT', label = 'BMW S1000', price = 100000 },
		{ model = 'fbi2', label = 'FBI SUV', price = 10000 },
		{ model = 'pbus', label = 'Police Prison Bus', price = 500 }
	},
	
	boss = {
		{ model = 'charger', label = 'Dodge Police', price = 50000 },
		{ model = 'polmp4', label = 'Mclaren MP4 Police', price = 50000 },
		{ model = '2015polstang', label = 'Mustang GT 2015', price = 50000 },
		{ model = 'camarorb', label = 'Camaro ZL1', price = 200000 },
		{ model = 'pol718', label = 'Porsche 718 Cayman', price = 800000 },
		{ model = 'polchiron', label = 'Bugatti Chiron Police', price = 2000000 },
		{ model = '1200RT', label = 'BMW S1000', price = 100000 },
		{ model = 'fbi2', label = 'FBI SUV', price = 10000 },
		{ model = 'pbus', label = 'Police Prison Bus', price = 500 }
	}
}

Config.AuthorizedHelicopters = {
	recruit = {},

	po1 = {
	    { model = 'polmav', label = 'Police Maverick', livery = 0, price = 300000 },
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 250000 }
	},

	spo1 = {
	    { model = 'polmav', label = 'Police Maverick', livery = 0, price = 250000 },
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 200000 }
	},

	spo2 = {
	    { model = 'polmav', label = 'Police Maverick', livery = 0, price = 250000 },
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 200000 }
	},

	inspector = {
		{ model = 'polmav', label = 'Police Maverick', livery = 0, price = 200000 },
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 200000 }
	},

	srinspector = {
		{ model = 'polmav', label = 'Police Maverick', livery = 0, price = 150000 },
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 150000 }
	},

	chiefinspector = {
		{ model = 'polmav', label = 'Police Maverick', livery = 0, price = 100000 },
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 100000 }
	},
	
	director = {
		{ model = 'polmav', label = 'Police Maverick', livery = 0, price = 100000 },
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 100000 }
	},
	
	boss = {
		{ model = 'polmav', label = 'Police Maverick', livery = 0, price = 100000 },
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 100000 }
	}
}

Config.AuthorizedBoats = {
	recruit = {},
	
	po1 = {
	    { model = 'predator', label = 'Police Predator', livery = 0, price = 5000},
		{ model = 'dinghy3', label = 'Police Dinghy 3', livery = 0, price = 5000}
	},
	
	spo1 = {
	    { model = 'predator', label = 'Police Predator', livery = 0, price = 5000},
		{ model = 'dinghy3', label = 'Police Dinghy 3', livery = 0, price = 5000}
	},
	spo2 = {
	    { model = 'predator', label = 'Police Predator', livery = 0, price = 5000},
		{ model = 'rboat', label = 'Police Rapid', livery = 0, price = 5000},
		{ model = 'dinghy3', label = 'Police Dinghy 3', livery = 0, price = 5000}
	},
		
	inspector = {
	    { model = 'predator', label = 'Police Predator', livery = 0, price = 5000},
		{ model = 'rboat', label = 'Police Rapid', livery = 0, price = 5000},
		{ model = 'dinghy3', label = 'Police Dinghy 3', livery = 0, price = 5000}
	},

	srinspector = {
	    { model = 'predator', label = 'Police Predator', livery = 0, price = 5000},
		{ model = 'rboat', label = 'Police Rapid', livery = 0, price = 5000},	
		{ model = 'dinghy3', label = 'Police Dinghy 3', livery = 0, price = 5000}
	},

	chiefinspector = {
	    { model = 'predator', label = 'Police Predator', livery = 0, price = 5000},
		{ model = 'rboat', label = 'Police Rapid', livery = 0, price = 5000},
		{ model = 'dinghy3', label = 'Police Dinghy 3', livery = 0, price = 5000}
	},
	
	director = {
	    { model = 'predator', label = 'Police Predator', livery = 0, price = 5000},
		{ model = 'rboat', label = 'Police Rapid', livery = 0, price = 5000},
		{ model = 'dinghy3', label = 'Police Dinghy 3', livery = 0, price = 5000}
	},
	
	boss = {
	    { model = 'predator', label = 'Police Predator', livery = 0, price = 5000},
		{ model = 'rboat', label = 'Police Rapid', livery = 0, price = 5000},
		{ model = 'dinghy3', label = 'Police Dinghy 3', livery = 0, price = 5000}
	}
}

-- CHECK SKINCHANGER CLIENT MAIN.LUA for matching elements

Config.Uniforms = {
	recruit_wear = {
		male = {
		    ['tshirt_1'] = 57,   ['tshirt_2'] = 0,
			['torso_1'] = 93,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 19,
			['pants_1'] = 31,   ['pants_2'] = 2,
			['shoes_1'] = 24,   ['shoes_2'] = 0,
			['helmet_1'] = 10,  ['helmet_2'] = 6,
			['chain_1'] = 125,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 24,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		}
	},
	officer_wear = {
		male = {
		    ['tshirt_1'] = 57,   ['tshirt_2'] = 0,
			['torso_1'] = 93,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 19,
			['pants_1'] = 31,   ['pants_2'] = 2,
			['shoes_1'] = 24,   ['shoes_2'] = 0,
			['helmet_1'] = 10,  ['helmet_2'] = 6,
			['chain_1'] = 125,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 93,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 14,
			['pants_1'] = 54,   ['pants_2'] = 1,
			['shoes_1'] = 24,   ['shoes_2'] = 0,
			['helmet_1'] = 10,  ['helmet_2'] = 1,
			['chain_1'] = 1,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		}
	},
	sergeant_wear = {
		male = {
		    ['tshirt_1'] = 57,   ['tshirt_2'] = 0,
			['torso_1'] = 93,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 19,
			['pants_1'] = 31,   ['pants_2'] = 2,
			['shoes_1'] = 24,   ['shoes_2'] = 0,
			['helmet_1'] = 10,  ['helmet_2'] = 6,
			['chain_1'] = 125,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 93,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 14,
			['pants_1'] = 54,   ['pants_2'] = 1,
			['shoes_1'] = 24,   ['shoes_2'] = 0,
			['helmet_1'] = 10,  ['helmet_2'] = 1,
			['chain_1'] = 1,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		}
	},
	intendent_wear = {
		male = {
		    ['tshirt_1'] = 57,   ['tshirt_2'] = 0,
			['torso_1'] = 93,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 19,
			['pants_1'] = 31,   ['pants_2'] = 2,
			['shoes_1'] = 24,   ['shoes_2'] = 0,
			['helmet_1'] = 10,  ['helmet_2'] = 6,
			['chain_1'] = 125,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 93,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 14,
			['pants_1'] = 54,   ['pants_2'] = 1,
			['shoes_1'] = 24,   ['shoes_2'] = 0,
			['helmet_1'] = 10,  ['helmet_2'] = 1,
			['chain_1'] = 1,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		}
	},
	lieutenant_wear = { -- currently the same as intendent_wear
		male = {
		    ['tshirt_1'] = 57,   ['tshirt_2'] = 0,
			['torso_1'] = 93,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 19,
			['pants_1'] = 31,   ['pants_2'] = 2,
			['shoes_1'] = 24,   ['shoes_2'] = 0,
			['helmet_1'] = 10,  ['helmet_2'] = 6,
			['chain_1'] = 125,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 93,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 14,
			['pants_1'] = 54,   ['pants_2'] = 1,
			['shoes_1'] = 24,   ['shoes_2'] = 0,
			['helmet_1'] = 10,  ['helmet_2'] = 1,
			['chain_1'] = 1,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		}
	},
	chief_wear = {
		male = {
		    ['tshirt_1'] = 15,   ['tshirt_2'] = 0,
			['torso_1'] = 102,   ['torso_2'] = 0,
			['decals_1'] = 8,   ['decals_2'] = 2,
			['arms'] = 43,
			['pants_1'] = 59,   ['pants_2'] = 0,
			['shoes_1'] = 24,   ['shoes_2'] = 0,
			['helmet_1'] = 10,  ['helmet_2'] = 6,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 93,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 14,
			['pants_1'] = 54,   ['pants_2'] = 1,
			['shoes_1'] = 24,   ['shoes_2'] = 0,
			['helmet_1'] = 10,  ['helmet_2'] = 1,
			['chain_1'] = 1,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		}
	},
	boss_wear = { -- currently the same as chef_wear
		male = {
		    ['tshirt_1'] = 15,   ['tshirt_2'] = 0,
			['tshirt_1'] = 129,  ['tshirt_2'] = 0,
			['torso_1'] = 102,   ['torso_2'] = 0,
			['decals_1'] = 8,   ['decals_2'] = 2,
			['arms'] = 41,
			['pants_1'] = 59,   ['pants_2'] = 0,
			['shoes_1'] = 24,   ['shoes_2'] = 0,
			['helmet_1'] = 10,  ['helmet_2'] = 6,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 93,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 14,
			['pants_1'] = 54,   ['pants_2'] = 1,
			['shoes_1'] = 24,   ['shoes_2'] = 0,
			['helmet_1'] = 10,  ['helmet_2'] = 1,
			['chain_1'] = 1,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		}
	},
	noose_wear = { -- currently the same as chef_wear
		male = {
		    ['tshirt_1'] = 15,   ['tshirt_2'] = 0,
			['torso_1'] = 53,   ['torso_2'] = 0,
			['decals_1'] = 5,   ['decals_2'] = 0,
			['arms'] = 39,
			['bproof_1'] = 16,  ['bproof_2'] = 2,
			['pants_1'] = 37,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 59,  ['helmet_2'] = 0,
			['mask_1'] = 52,  ['mask_2'] = 0,
			['chain_1'] = 1,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 31,  ['tshirt_2'] = 0,
			['torso_1'] = 93,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 14,
			['pants_1'] = 54,   ['pants_2'] = 1,
			['shoes_1'] = 24,   ['shoes_2'] = 0,
			['helmet_1'] = 10,  ['helmet_2'] = 1,
			['chain_1'] = 1,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		}
	},
	bullet_wear = {
		male = {
			['bproof_1'] = 7,  ['bproof_2'] = 0
		},
		female = {
			['bproof_1'] = 7,  ['bproof_2'] = 4
		}
	},
	gilet_wear = {
		male = {
			['tshirt_1'] = 59,  ['tshirt_2'] = 1
		},
		female = {
			['tshirt_1'] = 36,  ['tshirt_2'] = 1
		}
	}

}