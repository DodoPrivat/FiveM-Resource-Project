Locales['fr'] = {

	['robbery_cancelled'] = 'Le braquage a été annulé, vous ne gagnerez rien!',
	['robbery_successful'] = 'Braquage réussi, vous avez obtenu des! ~g~$',
	['bank_robbery'] = 'Braquage de banque',
	['press_to_rob'] = 'Appuyez sur ~INPUT_CONTEXT~ pour braquer ~b~',
	['press_to_cancel'] = 'Appuyez sur ~INPUT_CONTEXT~ pour annuler le braquage ~b~',
	['press_to_hack'] = 'Appuyez sur ~INPUT_CONTEXT~ pour lancer le hack ~b~',
	['press_to_bomb'] = 'Appuyez sur ~INPUT_CONTEXT~ pour placer la bombe ~b~',
	['robbery_of'] = 'Braquage de banque: ~r~',
	['bomb_of'] = 'Bombe plantée: ~r~',
	['hack_of'] = 'Hacking de la banque: ~r~',
	['seconds_remaining'] = '~w~ secondes restantes',
	['robbery_cancelled_at'] = '~r~ a été annulé à: ~b~',
	['robbery_has_cancelled'] = '~r~ Le braquage a été annulé: ~b~',
	['already_robbed'] = 'Cette banque a déjà été braquée. Revenez dans: ',
	['seconds'] = 'secondes.',
	['rob_in_prog'] = '~r~ Braquage en cours à: ~b~',
	['started_to_rob'] = 'Vous avez débuter un braquage ',
	['started_to_hack'] = 'Vous avez commencé à hack ',
	['started_to_plantbomb'] = 'Vous avez commencé à planter la bombe ',
	['do_not_move'] = ', Ne bougez pas!',
	['alarm_triggered'] = 'Les alarmes ont été déclanchées',
	['hack_failed'] = 'Votre tentative de hacking de la porte a échouée!',
	['hold_pos'] = 'Tenez la banque pendant 5 minutes et l\'argent est à vous!',
	['hold_pos_hack'] = 'Tenez la banque pendant que vous piratez la porte blindée et vous accéderez à l\'intérieur!',
	['hold_pos_plantbomb'] = 'Tenez la banque pendant que vous plantez la bombe, vous êtes presque!',
	['leave'] = 'Appuyez sur ~INPUT_CONTEXT~ pour quitter ',
	['robbery_complete'] = '~r~ Braquage réussi.~s~ ~h~ Courrez! ',
	['hack_complete'] = '~r~ Piratage réussi. Au boulot, courrez! ',
	['robbery_complete_at'] = '~r~ Braquage terminée à: ~b~',
	['min_two_police'] = 'Nombre d\'officiers de policer nécéssaire: ',
	['robbery_already'] = '~r~ There is already a robbery in progress.',
	['bombplanted_run'] = 'Vous avez planter la bombe, courrez et planquez vous! Elle explosera dans 20 secondes',
	['bombplanted_at'] = 'Une bombe a été plantée à: ~b~ !',
	['rasperry_needed'] = 'Vous avez besoin d\'un rasperry pour pirater!',
	['c4_needed'] = 'Vous avez besoin de pains de C4 pour exploser la porte!',
	['blowtorch_needed'] = 'Vous avez besoin d\'un chalumeau pour ouvrir les casiers!',

}
