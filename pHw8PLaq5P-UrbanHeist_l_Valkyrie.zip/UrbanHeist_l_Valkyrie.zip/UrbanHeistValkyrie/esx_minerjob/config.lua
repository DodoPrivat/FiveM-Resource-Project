Config = {}
Config.Locale = 'en'

Config.CloakroomX = -287.18
Config.CloakroomY = 2535.58
Config.CloakroomZ = 75.47

Config.WashingX = 1926.12
Config.WashingY = 413.85
Config.WashingZ = 161.3

Config.RemeltingX = 1109.03
Config.RemeltingY = -2007.61
Config.RemeltingZ = 30.94

Config.SellX = -621.43
Config.SellY = -230.4
Config.SellZ = 37.05

Config.DiamondPrice = 5000
Config.GoldPrice = 1000
Config.IronPrice = 500
Config.CopperPrice = 50
