Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.EnableJobBlip              = true
Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.AuthorizedWeapons = {
	coordinator = {
	  { weapon = 'WEAPON_BAT',        	   	 price = 1000 },	
	  { weapon = 'WEAPON_SWITCHBLADE',     	 price = 500 },
      { weapon = 'WEAPON_FLAREGUN',      	 price = 3000 },	  
      { weapon = 'WEAPON_MACHINEPISTOL',     price = 20000 },	
      { weapon = 'WEAPON_BULLPUPSHOTGUN',    price = 25000 },	
      { weapon = 'WEAPON_SMG',               price = 25000 },	
	  { weapon = 'WEAPON_GUSENBERG',       	 price = 35500 },	
	  { weapon = 'WEAPON_ASSAULTRIFLE',      price = 50000 },
	  { weapon = 'WEAPON_COMBATMG',          price = 120000 },
	},
	boss = {
	  { weapon = 'WEAPON_BAT',        	   	 price = 1000 },	
	  { weapon = 'WEAPON_SWITCHBLADE',     	 price = 500 },
      { weapon = 'WEAPON_FLAREGUN',      	 price = 3000 },	  
      { weapon = 'WEAPON_MACHINEPISTOL',     price = 20000 },	
      { weapon = 'WEAPON_BULLPUPSHOTGUN',    price = 25000 },	
      { weapon = 'WEAPON_SMG',               price = 25000 },	
	  { weapon = 'WEAPON_GUSENBERG',       	 price = 35500 },	
	  { weapon = 'WEAPON_ASSAULTRIFLE',      price = 50000 },
	  { weapon = 'WEAPON_COMBATMG',          price = 120000 },
	}
}


-- CHECK SKINCHANGER CLIENT MAIN.LUA for matching elements

Config.Uniforms = {
	redskull_wear = {
		male = {
			['tshirt_1'] = 15,  ['tshirt_2'] = 0,
			['torso_1'] = 86,   ['torso_2'] = 2,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 1,
			['pants_1'] = 78,   ['pants_2'] = 2,
			['shoes_1'] = 16,   ['shoes_2'] = 0,
			['helmet_1'] = -1,   ['helmet_2'] = 8,
			['chain_1'] = 0,  ['chain_2'] = 0,
			['glasses_1'] = 0,  ['glasses_2'] = 0,
			['ears_1'] = -1,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 24,  ['tshirt_2'] = 0,
			['torso_1'] = 28,   ['torso_2'] = 13,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 20,
			['pants_1'] = 27,   ['pants_2'] = 1,
			['shoes_1'] = 13,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	}
}

Config.RedskullStations = {

  Redskull = {
  
    Blip = {
      Pos     = { x = -2458.19, y = 777.32, z = 287.02 },
      Sprite  = 487,
      Display = 4,
      Scale   = 1.3,
      Colour  = 29,
    },

	  AuthorizedVehicles = {
		  { name = 'kuruma',  label = 'Kuruma', price = 3000000 },
		  { name = 'contender',      label = 'Contender', price = 300000 }
	  },

    Cloakrooms = {
      { x = -2523.95, y = 743.25, z = 312.28 -.9},
    },

    Armories = {
      { x = -2512.97, y = 777.71, z = 307.85 },
    },

    Vehicles = {
      {
        Spawner    = { x = -2469.37, y = 748.67, z = 299.02 - .9},
        SpawnPoint = { x = -2467.82, y = 757.92, z = 295.03 },
        Heading    = 332.94,
      }
    },


    VehicleDeleters = {
      { x = -2475.81, y = 765.1, z = 294.75 - .7}
    },

    BossActions = {
      { x = -2512.25, y = 778.47, z = 303.89 -1.40}
    },

  },

}
