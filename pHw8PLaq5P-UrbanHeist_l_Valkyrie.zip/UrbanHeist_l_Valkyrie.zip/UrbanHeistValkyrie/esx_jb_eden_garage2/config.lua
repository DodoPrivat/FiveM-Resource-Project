Config = {}
Config.Blip			= {sprite= 524, color = 30}
Config.BoatBlip		= {sprite= 410, color = 30}
Config.AirplaneBlip	= {sprite= 524, color = 188}
Config.MecanoBlip	= {sprite= 357, color = 26}
Config.Price		= 2000 -- pound price to get vehicle back
Config.SwitchGaragePrice		= 10000 -- price to pay to switch vehicles in garage
Config.StoreOnServerStart = true -- Store all vehicles in garage on server start?
Config.PoundOnDisc = true
Config.Locale = 'en'

Config.Garages = {
	Garage_Centre = {
		Pos = {x=-463.92, y=-624.59, z=30.55},
		Marker = { w= -1.5, h= 1.0,r = 204, g = 204, b = 0},
		Name = _U('garage_name'),
		HelpPrompt = _U('open_car_garage'),
		SpawnPoint = {
			Pos = {x=-463.72, y= -619.38, z= 31.17},
			Heading = 88.93,
			Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
			HelpPrompt = _U('spawn_car')
		},
		DeletePoint = {
			Pos = {x=-515.95, y=-597.47, z=30.3},
			Marker = { w= 2.0, h= 1.0,r=255,g=0,b=0},
			HelpPrompt = _U('store_car')
		}, 	
	},
	Garage_Paleto = {
		Pos = {x=105.359, y=6613.586, z=32.3973},
		Marker = { w= 1.5, h= 1.0,r = 204, g = 204, b = 0},
		Name = _U('garage_name'),
		HelpPrompt = _U('open_car_garage'),
		SpawnPoint = {
			Pos = {x=128.7822, y= 6622.9965, z= 31.7828},
			Heading = 160.0,
			Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
			HelpPrompt = _U('spawn_car')
		},
		DeletePoint = {
			Pos = {x=126.3572, y=6608.4150, z=31.8565},
			Marker = { w= 1.5, h= 1.0,r=255,g=0,b=0},
			HelpPrompt = _U('store_car')
		}, 	
	},
	--Garage_SandyShore = {
		--Pos = {x=1694.571, y=3610.924, z=35.319},
		--Marker = { w= 1.5, h= 1.0,r = 204, g = 204, b = 0},
		--Name = _U('garage_name'),
		--HelpPrompt = _U('open_car_garage'),
		--SpawnPoint = {
			--Pos = {x=1713.492, y= 3598.938, z= 35.338},
			--Heading = 160.0,
			--Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
			--HelpPrompt = _U('spawn_car')
		--},
	--DeletePoint = {
			--Pos = {x = 1695.156,y = 3601.061,z = 35.530},
			--Marker = { w= 1.5, h= 1.0,r=255,g=0,b=0},
			--HelpPrompt = _U('store_car')
		--}, 	
	--},
	--Garage_Ocean1 = {
		--Pos = {x = -3140.323,y = 1124.463,z = 20.706},
		--Marker = { w= 1.5, h= 1.0,r = 204, g = 204, b = 0},
		--Name = _U('garage_name'),
		--HelpPrompt = _U('open_car_garage'),
		--SpawnPoint = {
			--Pos = {x = -3132.638,y = 1126.662,z = 20.667},
			--Heading = 160.0,
			--Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
			--HelpPrompt = _U('spawn_car')
		--},
		--DeletePoint = {
			--Pos = {x = -3136.902,y = 1102.685,z = 20.654},
			--Marker = { w= 1.5, h= 1.0,r=255,g=0,b=0},
			--HelpPrompt = _U('store_car')
		--}, 	
	--},
	--Garage_Lake = {
		--Pos = {x = -73.165504455566,y = 908.08734130859,z = 235.62712097168 },
		--Marker = { w= 1.0, h= 1.0,r = 204, g = 204, b = 0},
		--Name = _U('garage_name'),
		--HelpPrompt = _U('open_car_garage'),
		--SpawnPoint = {
			--Pos = {x = -72.099822998047,y = 902.85479736328,z = 235.63186645508 },
			--Heading = 134.409,
			--Marker = { w= 1.0, h= 1.0,r=0,g=255,b=0},
			--HelpPrompt = _U('spawn_car')
		--},
		--DeletePoint = {
			--Pos = {x = -66.987632751465,y = 891.65881347656,z = 235.55270385742 },
			--Marker = { w= 1.0, h= 1.0,r=255,g=0,b=0},
			--HelpPrompt = _U('store_car')
		--}, 	
	--},
	--Garage_Occaz = {
		--Pos = {x = 1136.3771972656,y = 2666.6303710938,z = 38.013275146484 },
		--Marker = { w= 1.5, h= 1.0,r = 204, g = 204, b = 0},
		--Name = _U('garage_name'),
		--HelpPrompt = _U('open_car_garage'),
		--SpawnPoint = {
			--Pos = {x = 1120.9813232422,y = 2668.8684082031,z = 38.048095703125 },
			--Heading = 179.84,
			--Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
			--HelpPrompt = _U('spawn_car')
		--},
		--DeletePoint = {
			--Pos = {x = 1121.9963378906,y = 2660.1179199219,z = 37.996875762939 },
			--Marker = { w= 1.5, h= 1.0,r=255,g=0,b=0},
			--HelpPrompt = _U('store_car')
		--}, 	
	--},
	--Garage_banque = {
		--Pos = {x = 363.48370361328,y = 296.83682250977,z = 103.50011444092 },
		--Marker = { w= 1.5, h= 1.0,r = 204, g = 204, b = 0},
		--Name = _U('garage_name'),
		--HelpPrompt = _U('open_car_garage'),
		--SpawnPoint = {
			--Pos = {x = 378.00622558594,y = 288.13024902344,z = 103.1661529541 },
			--Heading = 62.22,
			--Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
			--HelpPrompt = _U('spawn_car')
		--},
		--DeletePoint = {
			--Pos = {x = 364.76132202148,y = 285.18911743164,z = 103.37410736084 },
			--Marker = { w= 1.5, h= 1.0,r=255,g=0,b=0},
			--HelpPrompt = _U('store_car')
		--}, 	
	--},
	--Garage_mirrorpark = {
		--Pos = {x = 1033.9229736328,y = -767.10662841797,z = 58.003326416016 },
		--Marker = { w= 1.5, h= 1.0,r = 204, g = 204, b = 0},
		--Name = _U('garage_name'),
		--HelpPrompt = _U('open_car_garage'),
		--SpawnPoint = {
			--Pos = {x = 1040.6834716797,y = -778.18170166016,z = 58.022853851318 },
			--Heading = 359.92,
			--Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
			--HelpPrompt = _U('spawn_car')
		--},
		--DeletePoint = {
			--Pos = {x = 1022.7816772461,y = -763.78955078125,z = 57.961227416992 },
			--Marker = { w= 1.5, h= 1.0,r=255,g=0,b=0},
			--HelpPrompt = _U('store_car')
		--}, 	
	--},
	--Garage_YellowJack = {
		--Pos = {x = 2008.0589599609,y = 3051.5148925781,z = 47.156224822998 },
		--Marker = { w= 1.5, h= 1.0,r = 204, g = 204, b = 0},
		--Name = _U('garage_name'),
		--HelpPrompt = _U('open_car_garage'),
		--SpawnPoint = {
			--Pos = {x = 2009.0740966797,y = 3061.3701171875,z = 47.050121307373 },
			--Heading = 330.90,
			--Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
			--HelpPrompt = _U('spawn_car')
		---},
		--DeletePoint = {
			--Pos = {x = 1984.5550537109,y = 3067.1560058594,z = 47.023329772949 },
			--Marker = { w= 1.5, h= 1.0,r=255,g=0,b=0},
			--HelpPrompt = _U('store_car')
		--}, 	
	--},
}

Config.GaragesMecano = {
	Bennys = {
		Name = _U('bennys_pound'),
		SpawnPoint = {
			Pos = {x = -182.16,y = -1277.56,z = 31.30},
			Heading = 90.31,
			Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
			HelpPrompt = _U('take_from_pound')
		},
		DeletePoint = {
			Pos = {x = -180.41,y = -1324.47,z = 31.30},
			Marker = { w= 1.5, h= 1.0,r=255,g=0,b=0},
			HelpPrompt = _U('store_in_pound')
		}, 	
	},
	police = {
		Name = _U('police_pound'),
		SpawnPoint = {
			Pos = {x = 449.253,y = -1024.322,z = 28.57},
			Heading = 100.0,
			Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
			HelpPrompt = _U('take_from_pound')
		},
		DeletePoint = {
			Pos = {x = 452.305,y = -996.752,z = 25.776},
			Marker = { w= 1.5, h= 1.0,r=255,g=0,b=0},
			HelpPrompt = _U('store_in_pound')
		}, 	
	},
}

Config.BoatGarages = {
	BoatGarage_Centre = {
		Pos = {x = -742.47064208984,y = -1332.4702148438,z = 1.59 },
		Marker = { w= 1.5, h= 1.0,r = 204, g = 204, b = 0},
		Name = _U('boat_garage_name'),
		HelpPrompt = _U('open_boat_garage'),
		SpawnPoint = {
			Pos = {x = -736.47064208984,y = -1342.4702148438,z = 1.0 },
			MarkerPos = {x = -733.58,y = -1338.62,z = 1.5 },
			Heading = 230.0,
			Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
			HelpPrompt = _U('spawn_boat')
		},
		DeletePoint = {
			Pos = {x = -740.06408691406,y = -1361.8474121094,z = 1.8801808655262 },
			Marker = { w= 3.5, h= 1.0,r=255,g=0,b=0},
			HelpPrompt = _U('store_boat')
		}, 	
	},
}

Config.AirplaneGarages = {
	AirplaneGarage_Centre = {
		Pos = {x = -1280.1153564453,y = -3378.1647949219,z = 13.940155029297 },
		Marker = { w= 1.5, h= 1.0,r = 204, g = 204, b = 0},
		Name = _U('plane_garage_name'),
		HelpPrompt = _U('open_plane_garage'),
		SpawnPoint = {
			Pos = {x = -1285.1153564453,y = -3382.1647949219,z = 13.940155029297 },
			Heading = 160.0,
			Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
			HelpPrompt = _U('spawn_plane')
		},
		DeletePoint = {
			Pos = {x = -1287.5788574219,y = -3390.4025878906,z = 13.940155029297 },
			Marker = { w= 1.5, h= 1.0,r=255,g=0,b=0},
			HelpPrompt = _U('store_plane')
		}, 	
	},
}


Config.SocietyGarages = {
	police =  { -- database job name
		{
			Pos = {x = 446.39,y = -984.844,z = 30.696 },
			Marker = { w= 1.5, h= 1.0,r = 204, g = 204, b = 0},
			Name = _U('police_garage_name'),
			HelpPrompt = _U('open_police_garage'),
			SpawnPoint = {
				Pos = {x = -1285.1153564453,y = -3382.1647949219,z = 13.940155029297 },
				Heading = 160.0,
				Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
				HelpPrompt = _U('spawn_police_garage')
			},
			DeletePoint = {
				Pos = {x = -1287.5788574219,y = -3390.4025878906,z = 13.940155029297 },
				Marker = { w= 1.5, h= 1.0,r=255,g=0,b=0},
				HelpPrompt = _U('store_police_garage')
			}, 	
		},
		{
			Pos = {x = 448.1153564453,y = -976.86,z = 30.696 },
			Marker = { w= 1.5, h= 1.0,r = 204, g = 204, b = 0},
			Name = _U('police_garage_name'),
			HelpPrompt = _U('open_police_garage'),
			SpawnPoint = {
				Pos = {x = -1285.1153564453,y = -3382.1647949219,z = 13.940155029297 },
				Heading = 160.0,
				Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
				HelpPrompt = _U('spawn_police_garage')
			},
			DeletePoint = {
				Pos = {x = -1287.5788574219,y = -3390.4025878906,z = 13.940155029297 },
				Marker = { w= 1.5, h= 1.0,r=255,g=0,b=0},
				HelpPrompt = _U('store_police_garage')
			}, 	
		},
	},
	ambulance =  {
		{
			Pos = {x = 443.1153564453,y = -993.86,z = 30.696 },
			Marker = { w= 1.5, h= 1.0,r = 204, g = 204, b = 0},
			Name = _U('ambulance_garage_name'),
			HelpPrompt = _U('open_ambulance_garage'),
			SpawnPoint = {
				Pos = {x = -1285.1153564453,y = -3382.1647949219,z = 13.940155029297 },
				Heading = 160.0,
				Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
				HelpPrompt = _U('spawn_ambulance_garage')
			},
			DeletePoint = {
				Pos = {x = -1287.5788574219,y = -3390.4025878906,z = 13.940155029297 },
				Marker = { w= 1.5, h= 1.0,r=255,g=0,b=0},
				HelpPrompt = _U('store_ambulance_garage')
			}, 	
		},
	},
	taxi =  {
		{
			Pos = {x = 443.1153564453,y = -993.86,z = 30.696 },
			Marker = { w= 1.5, h= 1.0,r = 204, g = 204, b = 0},
			Name = _U('taxi_garage_name'),
			HelpPrompt = _U('open_taxi_garage'),
			SpawnPoint = {
				Pos = {x = -1285.1153564453,y = -3382.1647949219,z = 13.940155029297 },
				Heading = 160.0,
				Marker = { w= 1.5, h= 1.0,r=0,g=255,b=0},
				HelpPrompt = _U('spawn_taxi_garage')
			},
			DeletePoint = {
				Pos = {x = -1287.5788574219,y = -3390.4025878906,z = 13.940155029297 },
				Marker = { w= 1.5, h= 1.0,r=255,g=0,b=0},
				HelpPrompt = _U('store_taxi_garage')
			}, 	
		},
    },
}
