Config = {}

Config.nightclubs = {
	nightclubBahamas = {
		dancefloor = {
			Pos = {x = -1387.0628662109, y=  -618.31188964844, z = 30.81955909729},
			Marker = { w= 25.0, h= 1.0,r = 204, g = 204, b = 0},
			HelpPrompt = "Press ~INPUT_PICKUP~ to display the dance menu",
		}, 
		djbooth = {
			Pos = {x = -1384.628662109, y=  -627.31188964844, z = 30.81955909729}, 
			Marker = { w= 1.0, h= 0.5,r = 204, g = 204, b = 0},
			HelpPrompt = "Press ~INPUT_PICKUP~ to take your place as a dj",
		},
	},	
	nightclubUnicorn = {
		dancefloor = {
			Pos = {x = 110.13, y=  -1288.70, z = 28.85},
			Marker = { w= 25.0, h= 1.0,r = 204, g = 204, b = 0},
			HelpPrompt = "Press ~INPUT_PICKUP~ to display the dance menu",
		}, 
		djbooth = {
			Pos = {x = 118.6188, y=  -1288.85, z = 28.81955909729}, 
			Marker = { w= 1.0, h= 0.5,r = 204, g = 204, b = 0},
			HelpPrompt = "Press ~INPUT_PICKUP~ to take your place as a dj",
		},
	},	
	nightclubunderground = {
		dancefloor = {
			Pos = {x = -1592.275, y=  -3012.131, z = -78.00},
			Marker = { w= 25.0, h= 1.0,r = 204, g = 204, b = 0},
			HelpPrompt = "Press ~INPUT_PICKUP~ to display the dance menu",
		}, 
		djbooth = {
			Pos = {x = -1603.98, y=  -3012.802, z = -77.79}, 
			Marker = { w= 1.0, h= 0.5,r = 204, g = 204, b = 0},
			HelpPrompt = "Press ~INPUT_PICKUP~ to take your place as a dj",
		},
	},
}

Config.Songs = {
	-- SONGS = Youtube Video ID Ex.: www.youtube.com/watch?v=((jfreFPe99GU)) catch only jfreFPe99GU
	-- SONGS = ID do video  do Youtube Exemplo: www.youtube.com/watch?v=((jfreFPe99GU)) pegue apenas jfreFPe99GU

	{song = "DmiGLSG8wYE", label ="Jingle Bells Remix"},
	{song = "xYJJ0Y92eEk", label ="Boom Tarat Tarat"},
	{song = "A9eo-Dgf1EA", label ="Mariah Carey - All I Want For Christmas Is You"},
	{song = "DR7b-VpfRdI", label ="Tatak Pinoy All - Stars - A Perfect Christmas"},
	{song = "TN7PBdQu_PY", label ="Ariana Grande - Santa Tell Me"},
	-- {song = "b6tNlTBOKhA", label ="Nik Makino - Neneng B"},
	-- {song = "wKNUGzaRjow", label ="Family Is Forever"},
	-- {song = "l482T0yNkeo", label ="AC/DC - Highway to Hell"},
	-- {song = "mhTRhAX_QBA", label ="Queen - We Will Rock You"},
	-- {song = "UprcpdwuwCg", label ="Twenty one pilots: Heathens"},
	-- {song = "UWkkpBzYgXI", label ="Nik Makino - Lexi"},
	-- {song = "b6tNlTBOKhA", label ="Nik Makino - Neneng B"},
	-- {song = "TC4jNKh-6b0", label ="PSYCHEDELIC BOYZ - RAWSTARR 'TIL I DIE 🤘🏼 (BATANG PASAWAY)"},
	-- {song = "yF0sUNmq59A", label ="ALLMO$T - Miracle Nights (ft. L.A.GOON$ & Peso Mercado)"},
}