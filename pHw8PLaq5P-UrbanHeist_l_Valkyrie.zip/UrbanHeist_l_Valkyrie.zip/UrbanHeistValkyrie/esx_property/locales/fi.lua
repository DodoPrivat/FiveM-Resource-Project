Locales['fi'] = {
  ['have_withdrawn'] = 'sinä nostit ~y~x%s~s~ ~b~%s~s~',
  ['have_deposited'] = 'sinä talletit ~y~x%s~s~ ~b~%s~s~',
  ['free_prop'] = 'vapaa kiinteistö',
  ['property'] = 'asunto',
  ['enter'] = 'sisään',
  ['leave'] = 'myy',
  ['buy'] = 'osta',
  ['rent'] = 'vuokraa',
  ['visit'] = 'vieraile',
  ['press_to_menu'] = 'paina ~INPUT_CONTEXT~ avataksesi talon valikko',
  ['owned_properties'] = 'omistuksessa olevat asunnot',
  ['available_properties'] = 'vapaat asunnot',
  ['invite_player'] = 'kutsu pelaaja',
  ['you_invited'] = 'sinä kutsuit henkilön ~y~%s~s~ kiinteistöösi',
  ['player_clothes'] = 'asut',
  ['remove_cloth'] = 'poista asu',
  ['removed_cloth'] = 'asu poistettiin vaatekaapistasi!',
  ['remove_object'] = 'poista esine',
  ['deposit_object'] = 'talleta esine',
  ['invite'] = 'kutsu',
  ['dirty_money'] = 'likainen raha: <span style="color: red;">$%s</span>',
  ['inventory'] = 'reppu',
  ['amount'] = 'määrä?',
  ['amount_invalid'] = 'virheellinen määrä',
  ['press_to_exit'] = 'paina ~INPUT_CONTEXT~ poistuaksesi kiinteistöstä',
  ['rented_for'] = 'sinä vuokrasit kiinteistön hintaan ~g~$%s~s~',
  ['purchased_for'] = 'sinä ostit kiinteistön hintaan ~g~$%s~s~',
  ['made_property'] = 'sinä teit kiinteistön',
  ['not_enough'] = 'sinulla ei ole tarpeeksi rahaa',
  ['invalid_quantity'] = 'virheellinen määrä',
  ['paid_rent'] = 'sinä ~g~maksoit~s~ vuokraasi: ~g~$%s~s~',
  ['not_enough_in_property'] = 'täällä ei ole enempää ~r~tätä itemiä~s~ tässä kiinteistössä!',
  ['player_cannot_hold'] = 'sinulla ~r~ei ole~s~ tarpeeksi ~y~vapaata tilaa~s~ repussasi!',
}