Locales['br'] = {
  ['have_withdrawn'] = 'você retirou ~y~x%s~s~ ~b~%s~s~',
  ['have_deposited'] = 'você depositou ~y~x%s~s~ ~b~%s~s~',
  ['free_prop'] = 'Propriedade a Venda',
  ['property'] = 'Propriedade',
  ['enter'] = 'Entrar',
  ['leave'] = 'Sair',
  ['buy'] = 'Comprar',
  ['rent'] = 'Alugar',
  ['visit'] = 'Visitar',
  ['press_to_menu'] = 'Pressione ~INPUT_CONTEXT~ para acessar o menu',
  ['owned_properties'] = 'Propriedades adquiridas',
  ['available_properties'] = 'Propriedades disponíveis',
  ['invite_player'] = 'Convidar um jogador',
  ['you_invited'] = 'you invited ~y~%s~s~ to your property',
  ['player_clothes'] = 'Roupas',
  ['remove_cloth'] = 'tire a roupa',
  ['removed_cloth'] = 'a roupa foi removida do seu guarda-roupa!',
  ['remove_object'] = 'Remover objeto',
  ['deposit_object'] = 'Depositar objeto',
  ['invite'] = 'Convidar',
  ['dirty_money'] = 'Dinheiro sujo: <span style="color: red;">$%s</span>',
  ['inventory'] = 'Inventário',
  ['amount'] = 'valor?',
  ['amount_invalid'] = 'quantidade inválida',
  ['press_to_exit'] = 'Pressione ~INPUT_CONTEXT~ para sair da propriedade',
  ['rented_for'] = 'Você alugou uma propriedade por ~g~$%s~s~',
  ['purchased_for'] = 'Você comprou uma propriedade por ~g~$%s~s~',
  ['made_property'] = 'Você criou uma propriedade',
  ['not_enough'] = 'Você não tem dinheiro suficiente',
  ['invalid_quantity'] = 'Quantidade inválida',
  ['paid_rent'] = 'Você ~g~pagou~s~ seu aluguel: ~g~$%s~s~',
  ['not_enough_in_property'] = 'não há o suficiente de que esse item esteja na propriedade!',
  ['player_cannot_hold'] = 'você não tem espaço suficiente em seu inventário!',
}
