Config = {}
Config.EAS = {}
Config.EAS.Volume = 0.2 --(0.2 = 20% Volume)
Config.EAS.Departments = {
    LSPD    = {
    
        name = "Los Santos Police Department"
    
    },
    
    LSSD    = {
    
        name = "Los Santos Sheriff's Department"
    
    },

    purge   = {
    
        name = "Gamerful City Government"
    
    }
}