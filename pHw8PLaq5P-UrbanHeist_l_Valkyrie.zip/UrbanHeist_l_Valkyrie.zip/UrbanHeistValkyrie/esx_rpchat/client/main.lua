--[[

  ESX RP Chat

--]]

 Citizen.CreateThread(function()
	TriggerEvent('chat:addSuggestion', '/twt', 'To tweet a message', {
		{ name="message", help="your message here." }
	})
	TriggerEvent('chat:addSuggestion', '/ad', 'To advertise something', {
		{ name="message", help="your message here." }
	})
	TriggerEvent('chat:addSuggestion', '/code4', 'To use code4 chat command(For police only)', {
		{ name="message", help="your message here." }
	})
	TriggerEvent('chat:addSuggestion', '/pol', 'To use police chat command(For police only)', {
		{ name="message", help="your message here." }
	})	
	TriggerEvent('chat:addSuggestion', '/wanted', 'To declare a wanted person(For police only)', {
		{ name="message", help="your message here." }
	})	
	TriggerEvent('chat:addSuggestion', '/mech', 'To use mechanic chat command(For mechanic only)', {
		{ name="message", help="your message here." }
	})	
	TriggerEvent('chat:addSuggestion', '/taxi', 'To use taxi chat command(For taxi only)', {
		{ name="message", help="your message here." }
	})	
	TriggerEvent('chat:addSuggestion', '/twn', 'To use reporter chat command(For reporter only)', {
		{ name="message", help="your message here." }
	})
	--MAFIA
	TriggerEvent('chat:addSuggestion', '/clt', 'To use celestial chat command(For celestial only)', {
		{ name="message", help="your message here." }
	})	
	TriggerEvent('chat:addSuggestion', '/mf', 'To use morte family chat command(For morte family only)', {
		{ name="message", help="your message here." }
	})	
	TriggerEvent('chat:addSuggestion', '/onsc', 'To use onsc chat command(For onsc only)', {
		{ name="message", help="your message here." }
	})
	TriggerEvent('chat:addSuggestion', '/af', 'To use asian familia chat command(For asian familia only)', {
		{ name="message", help="your message here." }
	})	
	--EMS 
	TriggerEvent('chat:addSuggestion', '/ems', 'To use ems chat command(For ems only)', {
		{ name="message", help="your message here." }
	})	
	TriggerEvent('chat:addSuggestion', '/med', 'To check vitals signs of a patient(For ems only)', {
		{ name="id", help="user id of the patient" }
	})
	TriggerEvent('chat:addSuggestion', '/dead', 'To declare a dead player(For ems only)', {
		{ name="firstname", help="firstname of the patient" },
		{ name="lastname", help="lastname of the patient" },
		{ name="cause of", help="Brain" },
		{ name="death", help="Dead" }
	})
	TriggerEvent('chat:addSuggestion', '/bed1', 'To admit a patient(Pillbox Hospital)', {
		{ name="id", help="user id of the patient" }
	})
	TriggerEvent('chat:addSuggestion', '/bed2', 'To admit a patient(Pillbox Hospital)', {
		{ name="id", help="user id of the patient" }
	})
	TriggerEvent('chat:addSuggestion', '/bed3', 'To admit a patient(Pillbox Hospital)', {
		{ name="id", help="user id of the patient" }
	})
	TriggerEvent('chat:addSuggestion', '/sbed1', 'To admit a patient(Sandy Shores Hospital)', {
		{ name="id", help="user id of the patient" }
	})
	TriggerEvent('chat:addSuggestion', '/sbed2', 'To admit a patient(Sandy Shores Hospital)', {
		{ name="id", help="user id of the patient" }
	})
	TriggerEvent('chat:addSuggestion', '/sbed3', 'To admit a patient(Sandy Shores Hospital)', {
		{ name="id", help="user id of the patient" }
	})
	
 end)

RegisterNetEvent('sendProximityMessage')
AddEventHandler('sendProximityMessage', function(id, name, message)
  local myId = PlayerId()
  local pid = GetPlayerFromServerId(id)
  if pid == myId then
    TriggerEvent('chatMessage', "^4" .. name .. "", {0, 153, 204}, "^7 " .. message)
  elseif GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(myId)), GetEntityCoords(GetPlayerPed(pid)), true) < 19.999 then
    TriggerEvent('chatMessage', "^4" .. name .. "", {0, 153, 204}, "^7 " .. message)
  end
end)

RegisterNetEvent('sendProximityMessageMe')
AddEventHandler('sendProximityMessageMe', function(id, name, message)
  local myId = PlayerId()
  local pid = GetPlayerFromServerId(id)
  if pid == myId then
    TriggerEvent('chat:addMessage', {
      template = '<div style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(86, 125, 188, 0.6); border-radius: 3px;"><i class="fas fa-user-circle"></i> {0}:<br> {1}</div>',
      args = { name, message }
    })
  elseif GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(myId)), GetEntityCoords(GetPlayerPed(pid)), true) < 19.999 then
    TriggerEvent('chat:addMessage', {
      template = '<div style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(86, 125, 188, 0.6); border-radius: 3px;"><i class="fas fa-user-circle"></i> {0}:<br> {1}</div>',
      args = { name, message }
    })
  end
end)

RegisterNetEvent('sendProximityMessageDo')
AddEventHandler('sendProximityMessageDo', function(id, name, message)
  local myId = PlayerId()
  local pid = GetPlayerFromServerId(id)
  if pid == myId then
    TriggerEvent('chatMessage', "", {255, 0, 0}, " ^0* " .. name .."  ".."^0  " .. message)
  elseif GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(myId)), GetEntityCoords(GetPlayerPed(pid)), true) < 19.999 then
    TriggerEvent('chatMessage', "", {255, 0, 0}, " ^0* " .. name .."  ".."^0  " .. message)
  end
end)

-- AddEventHandler('esx-qalle-chat:me', function(id, name, message)
--     local myId = PlayerId()
--     local pid = GetPlayerFromServerId(id)

--     if pid == myId then
--         TriggerEvent('chat:addMessage', {
--             template = '<div style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(86, 125, 188, 0.6); border-radius: 3px;"><i class="fas fa-user-circle"></i> {0}:<br> {1}</div>',
--             args = { name, message }
--         })
--     elseif GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(myId)), GetEntityCoords(GetPlayerPed(pid)), true) < 15.4 then
--         TriggerEvent('chat:addMessage', {
--             template = '<div style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(86, 125, 188, 0.6); border-radius: 3px;"><i class="fas fa-user-circle"></i> {0}:<br> {1}</div>',
--             args = { name, message }
--         })
--     end
-- end)