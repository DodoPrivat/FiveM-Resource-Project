Locales['en'] = {
  ['shop_robbery'] = 'shop Robbery',
  ['press_to_rob'] = 'press ~INPUT_CONTEXT~ to ~o~rob~s~ ~b~%s~s~',
  ['robbery_timer'] = 'store robbery: ~r~%s~s~ seconds remaning',
  ['recently_robbed'] = 'this store was recently been robbed. Please wait ~y~%s~s~ seconds until you can rob again',
  ['rob_in_prog'] = '~r~robbery in progress at ~b~%s~s~',
  ['started_to_rob'] = 'you started to rob ~y~%s~s~',
  ['alarm_triggered'] = 'the alarm has been triggered',
  ['robbery_complete'] = '~r~The robbery has been successful~s~, you ~o~stole~s~ ~g~$%s~s~',
  ['robbery_complete_at'] = '~r~Robbery successful at ~y~%s~s~',
  ['robbery_cancelled'] = 'the robbery has been cancelled!',
  ['robbery_cancelled_at'] = '~r~The robbery at ~b~%s~s~ has been cancelled!',
  ['min_police'] = 'there must be at least ~b~%s cops~s~ in town to rob.',
  ['robbery_already'] = '~r~A robbery is already in progress.',
  ['no_threat'] = 'you do not pose a threat to the store keeper',
}
