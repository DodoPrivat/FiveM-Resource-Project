DiscordWebhookSystemInfos = 'https://discordapp.com/api/webhooks/559765170369593354/mbtqS2SlrAlf6sGnzvux951vPXcQL8AT1AfatHrYO2Hn9CAuPcGnZdrtQMx0mL3Yylxb'
DiscordWebhookKillinglogs = 'https://discordapp.com/api/webhooks/556788631696572426/lduHjSPQtoK-2wj_u_BYYikuEoJznaoiF43EhhYiOdADUb8LE0vWRfeT3Le0r9ux4W9V'
DiscordWebhookChat =        'https://discordapp.com/api/webhooks/559765170369593354/mbtqS2SlrAlf6sGnzvux951vPXcQL8AT1AfatHrYO2Hn9CAuPcGnZdrtQMx0mL3Yylxb'

SystemAvatar = 'https://imgur.com/iXM4IXl'

UserAvatar = 'https://imgur.com/iXM4IXl'

SystemName = 'FloridaRP'


--[[ Special Commands formatting
		 *YOUR_TEXT*			--> Make Text Italics in Discord
		**YOUR_TEXT**			--> Make Text Bold in Discord
	   ***YOUR_TEXT***			--> Make Text Italics & Bold in Discord
		__YOUR_TEXT__			--> Underline Text in Discord
	   __*YOUR_TEXT*__			--> Underline Text and make it Italics in Discord
	  __**YOUR_TEXT**__			--> Underline Text and make it Bold in Discord
	 __***YOUR_TEXT***__		--> Underline Text and make it Italics & Bold in Discord
		~~YOUR_TEXT~~			--> Strikethrough Text in Discord
]]
-- Use 'USERNAME_NEEDED_HERE' without the quotes if you need a Users Name in a special command
-- Use 'USERID_NEEDED_HERE' without the quotes if you need a Users ID in a special command


-- These special commands will be printed differently in discord, depending on what you set it to
SpecialCommands = {
				   {'/ooc', '**[OOC]:**'},
				   {'/911', '**[911]: (CALLER ID: [ USERNAME_NEEDED_HERE | USERID_NEEDED_HERE ])**'},
				  }

						
-- These blacklisted commands will not be printed in discord
BlacklistedCommands = {
					   '/AnyCommand',
					   '/AnyCommand2',
					  }

-- These Commands will use their own webhook
OwnWebhookCommands = {
					  {'/ooc', 'https://discordapp.com/api/webhooks/559765170369593354/mbtqS2SlrAlf6sGnzvux951vPXcQL8AT1AfatHrYO2Hn9CAuPcGnZdrtQMx0mL3Yylxb'},
					  {'/AnotherCommand2', 'https://discordapp.com/api/webhooks/548147597764722739/_rg-L20pludslXn7RKsbjWL7bjq294GljmUq71GK4GHOi9SjWFux0n6enMQuQT9XDYTD'},
					 }

-- These Commands will be sent as TTS messages
TTSCommands = {
			   '/Whatever',
			   '/Whatever2',
			  }

