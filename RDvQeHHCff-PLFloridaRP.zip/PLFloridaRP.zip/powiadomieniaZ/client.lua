local cdd = true
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if not IsPauseMenuActive() then
            local ped = GetPlayerPed(-1)
            local player = PlayerPedId()
            if DoesEntityExist(ped) then 
                if IsControlJustPressed(1, 20) and cdd then
                    TriggerServerEvent('ZetkaM', " ^2Obywatel [ID : " .. GetPlayerServerId(PlayerId()) .. "] ^2przegląda listę obywateli.")
                    cd()
                end

                if IsControlJustReleased(1, 20) and GetLastInputMethod(2) and not IsPedCuffed(ped) then
                    DetachEntity(prop, 1, 1)
                    DeleteEntity(prop)
                    ClearPedTasks(ped)
                end
            end
        end
    end
end)
RegisterNetEvent('MMZet')
AddEventHandler('MMZet', function(id, message, color)
    local source = PlayerId()
    local target = GetPlayerFromServerId(id)

    if target == source then
        TriggerEvent('chat:addMessage', { args = { message }, color = color })
    elseif GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(source)), GetEntityCoords(GetPlayerPed(target)), true) < 50 then
        TriggerEvent('chat:addMessage', { args = { message }, color = color })
    end
end)

function cd()
    cdd = false
    Wait(3000)
    cdd = true
end
