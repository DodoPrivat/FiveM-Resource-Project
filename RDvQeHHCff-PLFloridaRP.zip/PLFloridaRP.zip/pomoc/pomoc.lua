RegisterCommand('pomoc', function()
    msg("Discord: https://discord.gg/Tn5aqZm")
    msg("Właściciel - xNau")
end, false)

function msg(text)
   TriggerEvent("chatMessage", "[F-RP]", {255,0,0}, text)
end    