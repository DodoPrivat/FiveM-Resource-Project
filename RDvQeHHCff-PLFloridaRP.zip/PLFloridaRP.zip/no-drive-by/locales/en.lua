Locales['en'] = {
	-- afk script
	['afk'] = '^2Anti-AFK',
	['afk_kicked_message'] = 'Zostałeś wyrzucony za bycie AFK',
	['afk_warning'] = 'Zostaniesz wyrzucony za^3%s sekund^0 bycie AFK!',

	-- gps tools
	['gpstools_setgps_ok'] = 'Współrzędne zostały dodane do twojego GPS!',
	['gpstools_tp_no_waypoint'] = 'Nie masz zestawu punktów drogi!',
	['gpstools_tp_ground'] = 'Ziemia (Z axis) nie znaleziono! Dostałeś  ~y~spadpchron~s~, powodzenia!',

	-- speed limiter
	['speedlimiter_set'] = 'Ogranicznik prędkości ustawiony na ~b~%s~s~ km/h',
	['speedlimiter_disabled'] = 'Ogranicznik prędkości został ~y~wyłączony~s~',

	-- commands
	['commands_getid'] = 'Twoje id to',
	['commands_lookup'] = 'To jest ~b~%s~s~',

	-- drift
	['drift'] = 'Drift',
	['drift_disabled'] = 'Wyłączone',
	['drift_enabled'] = 'Włączone',

	-- generic messages
	['message_left_reason'] = '~y~%s~s~ Wyszedł (%s)',
	['message_left'] = '~y~%s~s~ Wyszedł',
	['message_joined'] = '~y~%s~s~ Wszedł',

	-- no drive-by
	['nodrive_action_disabled'] = 'Drive-By jest zabroniony na tym serwerze..',
}