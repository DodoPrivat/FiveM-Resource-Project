Locales ['en'] = {
	['used_kit']					= 'Uzyłeś ~y~x1 ~b~Zestaw Naprawczy',
	['must_be_outside']				= 'Musisz być poza samochodem!',
	['no_vehicle_nearby']			= 'Nie ma s ~r~samochodu  ~w~w pobliżu',
	['finished_repair']				= '~g~Naprawiłeś samochód!',
	['abort_hint']					= 'Naciśnij ~INPUT_VEH_DUCK~ aby przerwać naprawę',
	['aborted_repair']				= '~r~Przerwałeś ~w~naprawę',
}Locales ['en'] = {
	['used_kit']					= 'Uzyłeś ~y~x1 ~b~Zestaw Naprawczy',
	['must_be_outside']				= 'Musisz być poza samochodem!',
	['no_vehicle_nearby']			= 'Nie ma s ~r~samochodu  ~w~w pobliżu',
	['finished_repair']				= '~g~Naprawiłeś samochód!',
	['abort_hint']					= 'Naciśnij ~INPUT_VEH_DUCK~ aby przerwać naprawę',
	['aborted_repair']				= '~r~Przerwałeś ~w~naprawę',
}