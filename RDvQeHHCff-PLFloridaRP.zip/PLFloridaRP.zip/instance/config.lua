Config            = {}
Config.Locale     = 'pl'
Config.MaxPlayers = 255
Config            = {}
Config.Locale     = 'pl'
Config.MaxPlayers = 255
