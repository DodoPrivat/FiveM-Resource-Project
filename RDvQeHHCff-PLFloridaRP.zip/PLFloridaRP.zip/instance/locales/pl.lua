Locales['pl'] = {
  ['left_instance'] = 'opuszczasz instancję',
  ['invite_expired'] = 'zaproszenie wygasło',
  ['press_to_enter'] = 'wciśnij ~INPUT_CONTEXT~ aby wejść do instancji',
  ['entered_instance'] = 'wchodzisz do instancji',
  ['entered_into'] = '%s wchodzi do instancji',
  ['left_out'] = '%s opuszcza instancję',
}Locales['pl'] = {
  ['left_instance'] = 'opuszczasz instancję',
  ['invite_expired'] = 'zaproszenie wygasło',
  ['press_to_enter'] = 'wciśnij ~INPUT_CONTEXT~ aby wejść do instancji',
  ['entered_instance'] = 'wchodzisz do instancji',
  ['entered_into'] = '%s wchodzi do instancji',
  ['left_out'] = '%s opuszcza instancję',
}