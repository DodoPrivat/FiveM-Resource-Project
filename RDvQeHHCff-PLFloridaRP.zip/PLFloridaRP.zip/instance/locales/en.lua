Locales['en'] = {
  ['left_instance'] = 'you have left the instance',
  ['invite_expired'] = 'invite expired',
  ['press_to_enter'] = 'press ~INPUT_CONTEXT~ to enter the instance',
  ['entered_instance'] = 'you entered the instance',
  ['entered_into'] = '%s entered the instance',
  ['left_out'] = '%s left the instance',
}
Locales['en'] = {
  ['left_instance'] = 'you have left the instance',
  ['invite_expired'] = 'invite expired',
  ['press_to_enter'] = 'press ~INPUT_CONTEXT~ to enter the instance',
  ['entered_instance'] = 'you entered the instance',
  ['entered_into'] = '%s entered the instance',
  ['left_out'] = '%s left the instance',
}
