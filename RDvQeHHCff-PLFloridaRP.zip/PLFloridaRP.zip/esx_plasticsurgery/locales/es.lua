Locales['es'] = {

    ['valid_purchase'] = '¿validar esta compra?',
    ['yes'] = 'Si',
    ['no'] = 'No',
    ['not_enough_money'] = 'No tienes suficente dinero',
    ['press_access'] = 'Presiona ~INPUT_CONTEXT~ para acceder al menú',
    ['barber_blip'] = 'FixYourFace3000',
    ['you_paid'] = 'Has pagado ',
}
