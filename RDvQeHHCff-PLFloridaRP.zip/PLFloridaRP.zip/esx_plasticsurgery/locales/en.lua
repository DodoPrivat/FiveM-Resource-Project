Locales['en'] = {

    ['valid_purchase'] = 'Potwierdzasz zakup?',
    ['yes'] = 'tak',
    ['no'] = 'nie',
    ['not_enough_money'] = 'Nie masz kasy',
    ['press_access'] = 'Kliknij ~INPUT_CONTEXT~ aby przejść operacje plastyczną - koszt 650000$',
    ['barber_blip'] = 'Operacja Plastyczna',
	['GTAOSurvival_blip'] = 'Operacja Plastyczna',
	['GTAOSurvival__blip'] = 'Operacja Plastyczna',
    ['you_paid'] = 'Zapłaciłeś ',
}