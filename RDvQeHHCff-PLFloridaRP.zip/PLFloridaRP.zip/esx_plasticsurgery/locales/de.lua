Locales['de'] = {

    ['valid_purchase'] = 'Einkauf bestätigen?',
    ['yes'] = 'ja',
    ['no'] = 'nein',
    ['not_enough_money'] = 'du hast nicht genug Geld',
    ['press_access'] = 'Drücke ~INPUT_CONTEXT~ um das Menü zu öffnen',
    ['barber_blip'] = 'FixYourFace3000',
    ['you_paid'] = 'du bezahlst ',
}