local PlayerData                = {}
ESX                             = nil

Citizen.CreateThread(function()
    while ESX == nil do
      TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
      Citizen.Wait(0)
    end
  end)  

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
  PlayerData.job = job
end)

RegisterNetEvent('esx_zlomiarz:zbieranie')
AddEventHandler('esx_zlomiarz:zbieranie', function()
    Zbieranie()
end)

RegisterNetEvent('esx_zlomiarz:zbieranieerror')
AddEventHandler('esx_zlomiarz:zbieranieerror', function()
    ESX.ShowHelpNotification("Posiadasz maksymalną ilość złomu w swoim ekwipunku!")
end)

RegisterNetEvent('esx_zlomiarz:prasowanie')
AddEventHandler('esx_zlomiarz:prasowanie', function()
    Prasowanie()
end)

RegisterNetEvent('esx_zlomiarz:prasawlaczanie')
AddEventHandler('esx_zlomiarz:prasawlaczanie', function()
    ESX.ShowHelpNotification("Trwa włączanie prasy...")
    Citizen.Wait(8000)
    ESX.ShowHelpNotification("Prasa została włączona. Poczekaj chwile...")
    Citizen.Wait(7000)
    ESX.ShowHelpNotification("Złom został sprasowany. Udaj się do punktu wymiany.")
end)

RegisterNetEvent('esx_zlomiarz:prasowanieerror')
AddEventHandler('esx_zlomiarz:prasowanieerror', function()
    ESX.ShowHelpNotification("Nie posiadasz złomu do przeprasowania!")
end)

RegisterNetEvent('esx_zlomiarz:wymiana')
AddEventHandler('esx_zlomiarz:wymiana', function()
    Wymiana()
    ESX.ShowHelpNotification("Trwa wymiana złomu...")
end)

RegisterNetEvent('esx_zlomiarz:wymianaerror') 
AddEventHandler('esx_zlomiarz:wymianaerror', function()
    ESX.ShowHelpNotification("Nie posiadasz złomu do wymiany!")
end)

RegisterNetEvent('esx_zlomiarz:kantor')
AddEventHandler('esx_zlomiarz:kantor', function()
    Sprzedaz()
    ESX.ShowHelpNotification("Trwa wymiana kwitków w kantorze...")
end)

RegisterNetEvent('esx_zlomiarz:kantorerror')
AddEventHandler('esx_zlomiarz:kantorerror', function()
    ESX.ShowHelpNotification("Nie posiadasz kwitków na sprzedaż!")
end)

RegisterNetEvent('esx_zlomiarz:timer')
AddEventHandler('esx_zlomiarz:timer', function()
    local timer = 0
    local ped = PlayerPedId()
    
    Citizen.CreateThread(function()
		while timer > -1 do
			Citizen.Wait(140)

			if timer > -1 then
				timer = timer + 1
            end
            if timer == 100 then
                break
            end
		end
    end) 
    
    Citizen.CreateThread(function()
        while true do
            Citizen.Wait(0)
                if GetDistanceBetweenCoords( Config.ZbieranieX, Config.ZbieranieY, Config.ZbieranieZ, GetEntityCoords((ped))) < 3.0 then
                    Draw3DText( Config.ZbieranieX, Config.ZbieranieY, Config.ZbieranieZ+0.5 -1.400, ('Trwa zbieranie złomu ' .. timer .. '%'), 4, 0.1, 0.1)
                end
                if timer == 100 then
                    break
                end
                if GetDistanceBetweenCoords( Config.PrasowanieX, Config.PrasowanieY, Config.PrasowanieZ, GetEntityCoords((ped))) < 3.0 then
                    Draw3DText( Config.PrasowanieX, Config.PrasowanieY, Config.PrasowanieZ+0.5 -1.400, ('Trwa prasowanie złomu ' .. timer .. '%'), 4, 0.1, 0.1)
                end
                if timer == 100 then
                    break
                end
                if GetDistanceBetweenCoords( Config.WymianaX, Config.WymianaY, Config.WymianaZ, GetEntityCoords((ped))) < 3.0 then
                    Draw3DText( Config.WymianaX, Config.WymianaY, Config.WymianaZ+0.5 -1.400, ('Trwa wymiana złomu ' .. timer .. '%'), 4, 0.1, 0.1)
                end
                if timer == 100 then
                    break
                end
                if GetDistanceBetweenCoords( Config.KantorX, Config.KantorY, Config.KantorZ, GetEntityCoords((ped))) < 3.0 then
                    Draw3DText( Config.KantorX, Config.KantorY, Config.KantorZ+0.5 -1.400, ('Trwa wymiana kwitków ' .. timer .. '%'), 4, 0.1, 0.1)
                end
                if timer == 100 then
                    break
                end
        end
    end)
end)

Citizen.CreateThread(function() -- Znaczniki na mapie 
    while true do
        Citizen.Wait(1)

        local ped = PlayerPedId()
        if PlayerData.job ~= nil and PlayerData.job.name == 'zlomiarz' and not IsEntityDead( ped ) then
            local blip1 = AddBlipForCoord(Config.ZbieranieX, Config.ZbieranieY, Config.ZbieranieZ)
                SetBlipSprite(blip1, 527)
                SetBlipColour(blip1, 18)
                BeginTextCommandSetBlipName("STRING")
                AddTextComponentString("Zbierz złom")
                EndTextCommandSetBlipName(blip1)
            local blip2 = AddBlipForCoord(Config.PrasowanieX, Config.PrasowanieY, Config.PrasowanieZ)
                SetBlipSprite(blip2, 527)
                SetBlipColour(blip2, 18)
                BeginTextCommandSetBlipName("STRING")
                AddTextComponentString("Prasuj złom")
                EndTextCommandSetBlipName(blip2)
            local blip3 = AddBlipForCoord(Config.WymianaX, Config.WymianaY, Config.WymianaZ)
                SetBlipSprite(blip3, 527)
                SetBlipColour(blip3, 18)
                BeginTextCommandSetBlipName("STRING")
                AddTextComponentString("Wymień złom")
                EndTextCommandSetBlipName(blip3)
            local blip4 = AddBlipForCoord(Config.KantorX, Config.KantorY, Config.KantorZ)
                SetBlipSprite(blip4, 527)
                SetBlipColour(blip4, 18)
                BeginTextCommandSetBlipName("STRING")
                AddTextComponentString("Wymień kwitki")
                EndTextCommandSetBlipName(blip4)
            local blip4 = AddBlipForCoord(Config.ActionsX, Config.ActionsY, Config.ActionsZ)
                SetBlipSprite(blip4, 527)
                SetBlipColour(blip4, 18)
                BeginTextCommandSetBlipName("STRING")
                AddTextComponentString("Siedziba złomiarza")
                EndTextCommandSetBlipName(blip4)    
        return
        end
    end
end)

Citizen.CreateThread(function() -- Zbieranie złomu
    while true do
        Citizen.Wait(1)

        local ped = PlayerPedId()
        
        if PlayerData.job ~= nil and PlayerData.job.name == 'zlomiarz' and not IsEntityDead( ped ) then
            if GetDistanceBetweenCoords(GetEntityCoords(ped), Config.ZbieranieX, Config.ZbieranieY, Config.ZbieranieZ, true ) < 50 then
                DrawMarker(20, Config.ZbieranieX, Config.ZbieranieY, Config.ZbieranieZ, 0, 0, 0, 0, 0, 0, 1.0, 1.0, 1.0, 0, 157, 0, 155, 0, 0, 2, 0, 0, 0, 0)
                if GetDistanceBetweenCoords(GetEntityCoords(ped), Config.ZbieranieX, Config.ZbieranieY, Config.ZbieranieZ, true ) < 1 then
                    ESX.ShowHelpNotification("Naciśnij ~INPUT_CONTEXT~ aby zbierać złom.")
                        if IsControlJustReleased(1, 51) then
                            Citizen.Wait(100)
                                TriggerServerEvent("esx_zlomiarz:zbierz")
                                Citizen.Wait(15500) 
                    end
                end
            end
        end
    end
end)

Citizen.CreateThread(function() -- Prasowanie złomu
    while true do
        Citizen.Wait(1)

        local ped = PlayerPedId()
        
        if PlayerData.job ~= nil and PlayerData.job.name == 'zlomiarz' and not IsEntityDead( ped ) then
            if GetDistanceBetweenCoords(GetEntityCoords(ped), Config.PrasowanieX, Config.PrasowanieY, Config.PrasowanieZ, true ) < 50 then
                DrawMarker(20, Config.PrasowanieX, Config.PrasowanieY, Config.PrasowanieZ, 0, 0, 0, 0, 0, 0, 1.0, 1.0, 1.0, 0, 157, 0, 155, 0, 0, 2, 0, 0, 0, 0)
                if GetDistanceBetweenCoords(GetEntityCoords(ped), Config.PrasowanieX, Config.PrasowanieY, Config.PrasowanieZ, true ) < 1 then
                    ESX.ShowHelpNotification("Naciśnij ~INPUT_CONTEXT~ aby prasować złom.")
                        if IsControlJustReleased(1, 51) then
                            Citizen.Wait(100)
                                TriggerServerEvent("esx_zlomiarz:prasuj")
                                Citizen.Wait(15500)
                    end
                end
            end
        end
    end
end)

Citizen.CreateThread(function() -- Wymiana złomu
    while true do
        Citizen.Wait(1)

        local ped = PlayerPedId()
        
        if PlayerData.job ~= nil and PlayerData.job.name == 'zlomiarz' and not IsEntityDead( ped ) then
            if GetDistanceBetweenCoords(GetEntityCoords(ped), Config.WymianaX, Config.WymianaY, Config.WymianaZ, true ) < 50 then
                DrawMarker(20, Config.WymianaX, Config.WymianaY, Config.WymianaZ, 0, 0, 0, 0, 0, 0, 1.0, 1.0, 1.0, 0, 157, 0, 155, 0, 0, 2, 0, 0, 0, 0)
                if GetDistanceBetweenCoords(GetEntityCoords(ped), Config.WymianaX, Config.WymianaY, Config.WymianaZ, true ) < 1 then
                    ESX.ShowHelpNotification("Naciśnij ~INPUT_CONTEXT~ aby wymienic zlom")
                        if IsControlJustReleased(1, 51) then
                            Citizen.Wait(100)
                                TriggerServerEvent("esx_zlomiarz:wymien")
                                Citizen.Wait(15500)
                    end
                end
            end
        end
    end
end)

Citizen.CreateThread(function() -- Wymiana kuponów 
    while true do
        Citizen.Wait(1)

        local ped = PlayerPedId()
        
        if PlayerData.job ~= nil and PlayerData.job.name == 'zlomiarz' and not IsEntityDead( ped ) then
            if GetDistanceBetweenCoords(GetEntityCoords(ped), Config.KantorX, Config.KantorY, Config.KantorZ, true ) < 50 then
                DrawMarker(20, Config.KantorX, Config.KantorY, Config.KantorZ, 0, 0, 0, 0, 0, 0, 1.0, 1.0, 1.0, 0, 157, 0, 155, 0, 0, 2, 0, 0, 0, 0)
                if GetDistanceBetweenCoords(GetEntityCoords(ped), Config.KantorX, Config.KantorY, Config.KantorZ, true ) < 1 then
                    ESX.ShowHelpNotification("Naciśnij ~INPUT_CONTEXT~ aby wymienic kwitki.")
                        if IsControlJustReleased(1, 51) then
                            Citizen.Wait(100)
                                TriggerServerEvent("esx_zlomiarz:kantor")
                                Citizen.Wait(15500)
                    end
                end
            end
        end
    end
end)

Citizen.CreateThread(function() -- Siedziba złomiarza
    while true do
        Citizen.Wait(1)

        local ped = PlayerPedId()

        if PlayerData.job ~= nil and PlayerData.job.name == 'zlomiarz' and not IsEntityDead( ped ) then
            if GetDistanceBetweenCoords(GetEntityCoords(ped), Config.ActionsX, Config.ActionsY, Config.ActionsZ, true) < 50 then
                DrawMarker(20, Config.ActionsX, Config.ActionsY, Config.ActionsZ, 0, 0, 0, 0, 0, 0, 1.0, 1.0, 1.0, 0, 157, 0, 155, 0, 0, 2, 0, 0, 0, 0)
                if GetDistanceBetweenCoords(GetEntityCoords(ped), Config.ActionsX, Config.ActionsY, Config.ActionsZ, true ) < 1 then
                    ESX.ShowHelpNotification("Naciśnij ~INPUT_CONTEXT~ aby wyświetlić menu złomiarza.")
                        if IsControlJustReleased(1, 51) then
                            Actions()
                    end
                end
            end
        end
    end
end)

Citizen.CreateThread(function() -- Usuwanie aut
    while true do
        Citizen.Wait(1)

        local ped = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(ped, false)

        if PlayerData.job ~= nil and PlayerData.job.name == 'zlomiarz' and not IsEntityDead( ped ) then
            if GetDistanceBetweenCoords(GetEntityCoords(ped), Config.RemoverX, Config.RemoverY, Config.RemoverZ, true) < 50 then
                DrawMarker(36, Config.RemoverX, Config.RemoverY, Config.RemoverZ, 0, 0, 0, 0, 0, 0, 1.0, 1.0, 1.0, 0, 157, 0, 155, 0, 0, 2, 0, 0, 0, 0)
                if GetVehiclePedIsIn(ped) then
                    if GetDistanceBetweenCoords(GetEntityCoords(ped), Config.RemoverX, Config.RemoverY, Config.RemoverZ, true) < 3 then
                        deleteCar(vehicle)
                    end
                end
            end
        end
    end
end)    


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1)
            if IsControlJustReleased(1, 194) then
                ESX.UI.Menu.CloseAll()
        end
    end
end)


function Actions()
    local elements = {
        {label = 'Ubrania cywilne',   value = 'cloakroom1'},
		{label = 'Ubrania robocze',      value = 'cloakroom2'},
        {label = 'Samochód roboczy',       value = 'pojazd'},
    }

    ESX.UI.Menu.CloseAll()

    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'zlomiarz_actions', {
        title    = 'Złomiarz',
		align    = 'bottom-right',
        elements = elements
    }, function(data, menu)
        if data.current.value == 'cloakroom1' then
            menu.close()
            ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
                TriggerEvent('skinchanger:loadSkin', skin)
            end)
        elseif data.current.value == 'cloakroom2' then
            menu.close()
            ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
                if skin.sex == 0 then
                    TriggerEvent('skinchanger:loadClothes', skin, jobSkin.skin_male)
                else
                    TriggerEvent('skinchanger:loadClothes', skin, jobSkin.skin_female)
                end
            end)
        elseif data.current.value == 'pojazd' then
            menu.close()
            RequestModel("ratloader")
            Citizen.Wait(100)
            CreateVehicle("ratloader", 2365.38, 3132.12, 48.21, 74.87, true, true)
            ESX.ShowNotification("Pojazd został wyjęty z garażu.")
        end
    end)
end

function Zbieranie() -- Animacja zbierania 
    local ped = PlayerPedId()

    Citizen.CreateThread(function()
        RequestAnimDict("amb@prop_human_bum_bin@idle_a")
        Citizen.Wait(100)
        TaskPlayAnim((ped), 'amb@prop_human_bum_bin@idle_a', 'idle_a', 8.0, 8.0, -1, 40, 0, 0, 0, 0)
        Citizen.Wait(7000)
        TaskPlayAnim((ped), 'amb@prop_human_bum_bin@idle_a', 'idle_a', 8.0, 8.0, -1, 40, 0, 0, 0, 0)
    end)
end

function Prasowanie() -- Animacja prasowania
    local ped = PlayerPedId()

    Citizen.CreateThread(function()
        TriggerServerEvent('InteractSound_SV:PlayOnSource', 'prasa', 0.2)
        Citizen.Wait(100)
        RequestAnimDict("amb@prop_human_bum_bin@idle_a")
        TaskPlayAnim((ped), 'amb@prop_human_bum_bin@idle_a', 'idle_a', 8.0, 8.0, -1, 40, 0, 0, 0, 0)
        Citizen.Wait(7000)
        TaskPlayAnim((ped), 'amb@prop_human_bum_bin@idle_a', 'idle_a', 8.0, 8.0, -1, 40, 0, 0, 0, 0)
    end)
end

function Wymiana() -- Wymiana złomu
    local ped = PlayerPedId()

    Citizen.CreateThread(function()
        RequestAnimDict("amb@prop_human_bum_bin@idle_a")
        Citizen.Wait(100)
        TaskPlayAnim((ped), 'amb@prop_human_bum_bin@idle_a', 'idle_a', 8.0, 8.0, -1, 40, 0, 0, 0, 0)
        Citizen.Wait(7000)
        TaskPlayAnim((ped), 'amb@prop_human_bum_bin@idle_a', 'idle_a', 8.0, 8.0, -1, 40, 0, 0, 0, 0)
    end)
end

function Sprzedaz() -- Wymiana kwitów
    local ped = PlayerPedId()

    Citizen.CreateThread(function()
        RequestAnimDict("amb@prop_human_bum_bin@idle_a")
        Citizen.Wait(100)
        TaskPlayAnim((ped), 'amb@prop_human_bum_bin@idle_a', 'idle_a', 8.0, 8.0, -1, 40, 0, 0, 0, 0)
        Citizen.Wait(700)
        TaskPlayAnim((ped), 'amb@prop_human_bum_bin@idle_a', 'idle_a', 8.0, 8.0, -1, 40, 0, 0, 0, 0)
        Citizen.Wait(8000)
        TriggerServerEvent('InteractSound_SV:PlayOnSource', 'sprzedaz', 0.5)
    end)
end

function text(content)
    SetTextFont(4)
    SetTextProportional(0)
    SetTextScale(1.9,1.9)
    SetTextEntry("STRING")
    AddTextComponentString(content)
    DrawText(0.9,0.7)
end

function Draw3DText(x,y,z,textInput,fontId,scaleX,scaleY)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)    
    local scale = (1/dist)*20
    local fov = (1/GetGameplayCamFov())*100 
    --D8RTGLCC4P3XUBTEYTOO
    SetTextScale(0.35, 0.35)
    SetTextFont(fontId)
    SetTextProportional(0)
    SetTextColour(255, 255, 255, 215)
    SetTextDropShadow(0, 0, 0, 0, 255)
    SetTextEdge(1, 0, 0, 0, 255)
    SetTextDropShadow()
    SetTextOutline()
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(textInput)
    SetDrawOrigin(x,y,z+2, 0)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()   
   end
    
function deleteCar( entity )
    Citizen.InvokeNative( 0xEA386986E786A54F, Citizen.PointerValueIntInitialized( entity ) )
end