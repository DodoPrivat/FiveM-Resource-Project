Config = {}


-- Kordynaty zbierania --
Config.ZbieranieX = 2363.79
Config.ZbieranieY = 3070.74
Config.ZbieranieZ = 48.19

-- Kordynaty prasowania --

Config.PrasowanieX = -517.94
Config.PrasowanieY = -1728.19
Config.PrasowanieZ = 19.22

-- Kordynaty wymiany złomu --

Config.WymianaX = -355.47
Config.WymianaY = -1536.79
Config.WymianaZ = 27.71

-- Kordynaty kantora --
Config.KantorX = 2355.18
Config.KantorY = 3142.94
Config.KantorZ = 48.21

-- Kordynaty menu złomiarza --
Config.ActionsX = 2347.83
Config.ActionsY = 3121.69
Config.ActionsZ = 48.21 

-- Kordynaty usuwania pojazdu --
Config.RemoverX = 2366.29
Config.RemoverY = 3138.2
Config.RemoverZ = 48.21

-- Wypłata --

Config.Najmniejszakwota = 2650 -- Najmniejsza kwota jaką można dostać za 10 kwitków
Config.Najwiekszakwota = 4789 -- Największa kwota jaką można dostać za 10 kwitków

-- License: D8RTGLCC4P3XUBTEYTOO