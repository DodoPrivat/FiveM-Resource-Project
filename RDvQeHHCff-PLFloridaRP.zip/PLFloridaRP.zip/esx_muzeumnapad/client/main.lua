local PlayerData                = {}
ESX                             = nil

local heist = false
local tags = false
local searched = 0
local location1 = false
local location2 = false
local location3 = false
local location4 = false
local location5 = false
local location6 = false
local location7 = false
local location8 = false
local location9 = false
local location10 = false
local location11 = false
local location12 = false
local location13 = false
local location14 = false
local location15 = false
local location16 = false
local location17 = false
local location18 = false
local location19 = false
local location20 = false

Citizen.CreateThread(function()
    while ESX == nil do
      TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
      Citizen.Wait(0)
    end
  end)  

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  PlayerData = xPlayer
end)


Citizen.CreateThread(function() -- tags  
    while true do
        Citizen.Wait(1)

        local ped = PlayerPedId()
            local yacht = AddBlipForCoord(-584.49, -586.91, 0.89)
                SetBlipSprite(yacht, 155)
                BeginTextCommandSetBlipName("STRING")
                AddTextComponentString("Napad na Muzeum")
                SetBlipAsShortRange(yacht, true)
                EndTextCommandSetBlipName(yacht)
                return
        end
    end)

Citizen.CreateThread(function()
  while true do
    Citizen.Wait(1)
      local ped = PlayerPedId()
        if heist == false then
        if GetDistanceBetweenCoords(GetEntityCoords(ped), -584.49, -586.91, 0.89, true) < 50 then
            DrawMarker(1, -584.49, -586.91, 0.00, 0, 0, 0, 0, 0, 75.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 1, 0, 2, 0, 0, 0, 0)
                if GetDistanceBetweenCoords(GetEntityCoords(ped), -584.49, -586.91, 0.89, true) < 1 then
                    ESX.ShowHelpNotification("Nacisnij ~INPUT_CONTEXT~ aby zaczac napad.")
                        if IsControlJustReleased(1, 51) then
                            TriggerServerEvent("esx_muzeum:robbery")
                        end
                    end
                end
            end
        end
    end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1)
            local ped = PlayerPedId()
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -584.49, -586.91, 0.89, true) > 100 then
                heist = false
                tags = false
            end
        end
    end)
        
RegisterNetEvent("esx_muzeum:start")
AddEventHandler("esx_muzeum:start", function()
  heist = true
  tags = true
  Citizen.CreateThread(function()
    while true do 
      Citizen.Wait(1)
        local ped = PlayerPedId()
        if location1 == false and tags == true then
            DrawMarker(20, -566.73, -585.82, 0.89, 0, 0, 0, 0, 0, 155.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -566.73, -585.82, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location1 = true
                        searched = searched+1
                    end
                end
            end
        if location2 == false and tags == true then
            DrawMarker(20, -549.02, -585.90, 0.89, 0, 0, 0, 0, 0, 155.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -549.02, -585.90, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location2 = true
                        searched = searched+1
                    end
                end
            end
        if location3 == false and tags == true then
            DrawMarker(20, -557.12, -587.88, 0.89, 0, 0, 0, 0, 0, 155.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -557.12, -587.88, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location3 = true
                        searched = searched+1
                    end
                end
            end
        if location4 == false and tags == true then
            DrawMarker(20, -552.24, -585.75, 0.89, 0, 0, 0, 0, 0, 70.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -552.24, -585.75, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location4 = true
                        searched = searched+1
                    end
                end
            end
        if location5 == false and tags == true then
            DrawMarker(20, -563.94, -586.61, 0.89, 0, 0, 0, 0, 0, 70.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -563.94, -586.61, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location5 = true
                        searched = searched+1
                    end
                end
            end
        if location6 == false and tags == true then
            DrawMarker(20, -544.57, -588.67, 0.89, 0, 0, 0, 0, 0, 70.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -544.57, -588.67, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location6 = true
                        searched = searched+1
                    end
                end
            end
        if location7 == false and tags == true then
            DrawMarker(20, -540.50, -588.76, 0.89, 0, 0, 0, 0, 0, 70.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -540.50, -588.76, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location7 = true
                        searched = searched+1
                    end
                end
            end
        if location8 == false and tags == true then
            DrawMarker(20, -537.14, -588.70, 0.89, 0, 0, 0, 0, 0, 155.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -537.14, -588.70, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location8 = true
                        searched = searched+1
                    end
                end
            end
        if location9 == false and tags == true then
            DrawMarker(20, -531.30, -587.16, 0.89, 0, 0, 0, 0, 0, 0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -531.30, -587.16, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location9 = true
                        searched = searched+1
                    end
                end
            end
        if location10 == false and tags == true then
            DrawMarker(20, -534.26, -606.86, 0.89, 0, 0, 0, 0, 0, 155.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -534.26, -606.86, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location10 = true
                        searched = searched+1
                    end
                end
            end
        if location11 == false and tags == true then
            DrawMarker(20, -2096.1, -1008.06, 5.88, 0, 0, 0, 0, 0, 170.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -2096.1, -1008.06, 5.88, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location11 = true
                        searched = searched+1
                    end
                end
            end
        if location12 == false and tags == true then
            DrawMarker(20, -570.59, -616.55, 0.89, 0, 0, 0, 0, 0, 70.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -570.59, -616.55, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location12 = true
                        searched = searched+1
                    end
                end
            end
        if location13 == false and tags == true then
            DrawMarker(20, -575.53, -616.53, 0.89, 0, 0, 0, 0, 0, 70.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -575.53, -616.53, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location13 = true
                        searched = searched+1
                    end
                end
            end
        if location14 == false and tags == true then
            DrawMarker(20, -579.65, -616.53, 0.89, 0, 0, 0, 0, 0, 70.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -579.65, -616.53, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location14 = true
                        searched = searched+1
                    end
                end
            end
        if location15 == false and tags == true then
            DrawMarker(20, -2082.85, -1012.15, 5.88, 0, 0, 0, 0, 0, 170.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -2082.85, -1012.15, 5.88, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location15 = true
                        searched = searched+1
                    end
                end
            end
        if location16 == false and tags == true then
            DrawMarker(20, -582.65, -616.53, 0.89, 0, 0, 0, 0, 0, 70.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -579.65, -616.53, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location16 = true
                        searched = searched+1
                    end
                end
            end
        if location17 == false and tags == true then
            DrawMarker(20, -576.98, -613.58, 0.89, 0, 0, 0, 0, 0, 70.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -576.98, -613.58, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location17 = true
                        searched = searched+1
                    end
                end
            end
        if location18 == false and tags == true then
            DrawMarker(20, -573.54, -613.58, 0.89, 0, 0, 0, 0, 0, 70.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -573.54, -613.58, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location18 = true
                        searched = searched+1
                    end
                end
            end
        if location19 == false and tags == true then
            DrawMarker(20, -543.35, -613.95, 0.89, 0, 0, 0, 0, 0, 70.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -543.35, -613.95, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location19 = true
                        searched = searched+1
                    end
                end
            end
        if location20 == false and tags == true then
            DrawMarker(20, -538.05, -613.95, 0.89, 0, 0, 0, 0, 0, 70.0, 1.0, 1.0, 1.0, 0, 155, 253, 155, 0, 0, 2, 0, 0, 0, 0)
            if GetDistanceBetweenCoords(GetEntityCoords(ped), -538.05, -613.95, 0.89, true) < 1 then
                ESX.ShowHelpNotification("Nacisnij ~ INPUT_CONTEXT ~, aby przeszukac to miejsce.")
                    if IsControlJustReleased(1, 51) then
                        Animacja()
                        location20 = true
                        searched = searched+1
                    end
                end
            end
        end
    end)
end)

Citizen.CreateThread(function()
    while searched < 20 do 
        Citizen.Wait(100)
            if searched == 20 then
                TriggerServerEvent("esx_muzeum:reward")
                heist = false
                tags = false
                Citizen.Wait(19000)
                ESX.ShowHelpNotification("Znaleziono walizke z pieniedzmi! Ucieknij z Muzeum, aby zakonczyc napad.")
            end
        end
    end)

function Animacja()
  local ped = PlayerPedId()
  Citizen.CreateThread(function()
    RequestAnimDict("mini@triathlon")
    Citizen.Wait(100)
    TaskPlayAnim((ped), 'mini@triathlon', 'rummage_bag', 2.0, 2.0, -1, 81, 0, 0, 0, 0)
    FreezeEntityPosition(PlayerPedId(), true)
    Citizen.Wait(19000)
    ClearPedTasks(ped)
    FreezeEntityPosition(PlayerPedId(), false)
  end)
end

RegisterNetEvent("esx_muzeum:notification")
AddEventHandler("esx_muzeum:notification", function(text)
    ESX.ShowHelpNotification(text)
end)

RegisterNetEvent("esx_muzeum:notify")
AddEventHandler("esx_muzeum:notify", function(text)
    ESX.ShowNotification("Rozpoczal sie napad na Muzeum. Nie pozwol, aby walizka z pieniedzmi zostala skradziona.")
    PlaySoundFrontend(-1, "HACKING_SUCCESS", 0, 1)
end)

RegisterCommand("neq", function()
    TriggerEvent("esx_muzeum:lspd")
end)
