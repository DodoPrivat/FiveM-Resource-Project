Config              = {}

Config.LSPD = 3
Config.Reward = 600000 