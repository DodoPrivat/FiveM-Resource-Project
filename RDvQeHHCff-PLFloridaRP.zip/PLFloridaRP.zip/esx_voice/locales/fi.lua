Locales ['fi'] = {
	['voice']   = '~y~Puhe: ~s~%s',
	['normal']  = 'normaali',
	['shout']   = 'huuto',
	['whisper'] = 'kuiskaus',
}
