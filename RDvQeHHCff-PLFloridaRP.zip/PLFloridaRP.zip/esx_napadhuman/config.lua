Config = {}
Config.Locale = 'en'
Config.NumberOfCopsRequired = 5

Banks = {

	["HumaneLabs"] = {
		position = { ['x'] = 3536.18, ['y'] = 3659.97, ['z'] = 28.12 },
		reward = math.random(750000,1550000),
		nameofbank = "Humane Labs",
		lastrobbed = 0
	}
}Config = {}
Config.Locale = 'en'
Config.NumberOfCopsRequired = 5

Banks = {

	["HumaneLabs"] = {
		position = { ['x'] = 3536.18, ['y'] = 3659.97, ['z'] = 28.12 },
		reward = math.random(750000,1550000),
		nameofbank = "Humane Labs",
		lastrobbed = 0
	}
}