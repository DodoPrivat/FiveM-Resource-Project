Locales['en'] = {

	['robbery_cancelled'] = 'Napad zostanie anulowany, nic nie zyskasz!',
	['robbery_successful'] = 'Napad udany zdobyłeś ~g~$',
	['bank_robbery'] = 'Napad Humane Labs',
	['press_to_rob'] = 'Wciśnij ~INPUT_CONTEXT~ aby rozpocząć napad ~b~',
	['robbery_of'] = 'Napad Humane Labs: ~r~',
	['seconds_remaining'] = ' pozostało ~w~ sekund.',
	['robbery_cancelled_at'] = '~r~ Napad anulowany: ~b~',
	['robbery_has_cancelled'] = '~r~ Napad został anulowany: ~b~',
	['already_robbed'] = 'Humane Labs zostało niedawno okradzione. Musisz poczekać: ',
	['seconds'] = 'sekund.',
	['rob_in_prog'] = '~r~ Napad w toku: ~b~',
	['started_to_rob'] = 'Rozpocząłeś napad ',
	['do_not_move'] = ', nie oddalaj się!',
	['alarm_triggered'] = 'Alarm został uruchomiony',
	['hold_pos'] = 'Wytrzymaj 13 minut a pieniądze będą twoje!',
	['robbery_complete'] = '~r~ Napad zakończony.~s~ ~h~ Uciekaj! ',
	['robbery_complete_at'] = '~r~ Napad zakończony w: ~b~',
	['min_two_police'] = 'Liczba potrzebnych policjantów do zrobienia napadu: ',
	['robbery_already'] = '~r~Jakiś napad jest już w toku.',

}
Locales['en'] = {

	['robbery_cancelled'] = 'Napad zostanie anulowany, nic nie zyskasz!',
	['robbery_successful'] = 'Napad udany zdobyłeś ~g~$',
	['bank_robbery'] = 'Napad Humane Labs',
	['press_to_rob'] = 'Wciśnij ~INPUT_CONTEXT~ aby rozpocząć napad ~b~',
	['robbery_of'] = 'Napad Humane Labs: ~r~',
	['seconds_remaining'] = ' pozostało ~w~ sekund.',
	['robbery_cancelled_at'] = '~r~ Napad anulowany: ~b~',
	['robbery_has_cancelled'] = '~r~ Napad został anulowany: ~b~',
	['already_robbed'] = 'Humane Labs zostało niedawno okradzione. Musisz poczekać: ',
	['seconds'] = 'sekund.',
	['rob_in_prog'] = '~r~ Napad w toku: ~b~',
	['started_to_rob'] = 'Rozpocząłeś napad ',
	['do_not_move'] = ', nie oddalaj się!',
	['alarm_triggered'] = 'Alarm został uruchomiony',
	['hold_pos'] = 'Wytrzymaj 13 minut a pieniądze będą twoje!',
	['robbery_complete'] = '~r~ Napad zakończony.~s~ ~h~ Uciekaj! ',
	['robbery_complete_at'] = '~r~ Napad zakończony w: ~b~',
	['min_two_police'] = 'Liczba potrzebnych policjantów do zrobienia napadu: ',
	['robbery_already'] = '~r~Jakiś napad jest już w toku.',

}
