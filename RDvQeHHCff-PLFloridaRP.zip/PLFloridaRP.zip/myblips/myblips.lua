local blips = {
    -- Example {title="", colour=, id=, x=, y=, z=},
	--{title="Kup Samolot", colour=5, id=419, x = -1291.7, y= -3346.99, z=13.94}, -- Samoloty
  {title="Urząd Pracy", colour=46, id=409, x = -268.07, y = -957.86, z = 31.22},-- Urząd pracy
  {title="Pole marychy #1", colour=25, id=140, x=  2213.05, y = 5576.25, z = 53},-- 
  {title="Pole marychy #2", colour=25, id=140, x = 1198.05, y = -215.25, z = 55},-- 
  {title="Pole marychy #3", colour=25, id=140, x = 706.05,  y = 1269.25, z = 358},-- 
  {title="Pole marychy #4", colour=25, id=140, x = -427.05, y = 1575.25, z = 357},-- 
	
}

Citizen.CreateThread(function()

    for _, info in pairs(blips) do
      info.blip = AddBlipForCoord(info.x, info.y, info.z)
      SetBlipSprite(info.blip, info.id)
      SetBlipDisplay(info.blip, 4)
      SetBlipScale(info.blip, 0.9)
      SetBlipColour(info.blip, info.colour)
      SetBlipAsShortRange(info.blip, true)
	  BeginTextCommandSetBlipName("STRING")
      AddTextComponentString(info.title)
      EndTextCommandSetBlipName(info.blip)
    end
end)
