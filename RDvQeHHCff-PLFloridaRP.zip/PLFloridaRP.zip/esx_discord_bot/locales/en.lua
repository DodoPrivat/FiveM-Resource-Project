Locales['en'] = {
	['server'] = 'server',
	['server_start'] = 'server start',
	['server_chat'] = 'chat',

	['server_connecting'] = 'Nowe połączenie',
	['user_connecting'] = 'Łączy się',

	['server_disconnecting'] = 'Nowe wyjście',
	['user_disconnecting'] = 'Wychodzi',

	['server_item_transfer'] = 'Transakcja itemów (item)',
	['server_money_transfer'] = 'Transakcja pieniędzy (money)',
	['server_moneybank_transfer'] = 'Transakcja przelew (moneybank)',
	['server_weapon_transfer'] = 'Transakcja broń (weapon)',

	['user_gives_to'] = 'Daje dla',

	['server_washingmoney'] = 'Pralnia',
	['user_washingmoney'] = 'Wyprał',

	['server_blacklistedvehicle'] = 'Czarna lista',
	['user_entered_in'] = 'Wszedł w :',

	['server_policecar'] = 'Policyjne auto',
	['server_carjacking'] = 'Ukradzione policyjne auto',
	['user_carjacking'] = 'Ukradł/Wsiadł do',

	['server_kill'] = 'Śmierć',
	['user_kill'] = 'Zabity przez',
	['user_kill_environnement'] = 'Samobójstwo lub zabity przez atak',
	['with'] ='z',
}
Locales['en'] = {
	['server'] = 'server',
	['server_start'] = 'server start',
	['server_chat'] = 'chat',

	['server_connecting'] = 'Nowe połączenie',
	['user_connecting'] = 'Łączy się',

	['server_disconnecting'] = 'Nowe wyjście',
	['user_disconnecting'] = 'Wychodzi',

	['server_item_transfer'] = 'Transakcja itemów (item)',
	['server_money_transfer'] = 'Transakcja pieniędzy (money)',
	['server_moneybank_transfer'] = 'Transakcja przelew (moneybank)',
	['server_weapon_transfer'] = 'Transakcja broń (weapon)',

	['user_gives_to'] = 'Daje dla',

	['server_washingmoney'] = 'Pralnia',
	['user_washingmoney'] = 'Wyprał',

	['server_blacklistedvehicle'] = 'Czarna lista',
	['user_entered_in'] = 'Wszedł w :',

	['server_policecar'] = 'Policyjne auto',
	['server_carjacking'] = 'Ukradzione policyjne auto',
	['user_carjacking'] = 'Ukradł/Wsiadł do',

	['server_kill'] = 'Śmierć',
	['user_kill'] = 'Zabity przez',
	['user_kill_environnement'] = 'Samobójstwo lub zabity przez atak',
	['with'] ='z',
}
