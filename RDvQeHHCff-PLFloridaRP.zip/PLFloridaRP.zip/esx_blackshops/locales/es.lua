Locales['es'] = {

	['shop'] = 'Tienda',
	['shops'] = 'Tiendas',
	['press_menu'] = 'Presiona ~INPUT_CONTEXT~ para acceder a la tienda.',
	['bought'] = 'Has comprado ~b~1 ',
	['not_enough'] = 'No tienes ~r~suficiente ~s~ dinero.',

}
Locales['es'] = {

	['shop'] = 'Tienda',
	['shops'] = 'Tiendas',
	['press_menu'] = 'Presiona ~INPUT_CONTEXT~ para acceder a la tienda.',
	['bought'] = 'Has comprado ~b~1 ',
	['not_enough'] = 'No tienes ~r~suficiente ~s~ dinero.',

}
