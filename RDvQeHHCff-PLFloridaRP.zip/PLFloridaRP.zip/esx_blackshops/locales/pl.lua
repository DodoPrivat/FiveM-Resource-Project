Locales['pl'] = {

	['shop'] = 'Czarny sklep',
	['shops'] = 'Sklepy',
	['press_menu'] = 'Wciśnij ~INPUT_CONTEXT~ by zrobić zakupy.',
	['bought'] = 'Kupiłeś ~b~1x ',
	['not_enough'] = 'Nie masz ~r~wystarczająco~s~ pieniędzy.',

}
Locales['pl'] = {

	['shop'] = 'Czarny sklep',
	['shops'] = 'Sklepy',
	['press_menu'] = 'Wciśnij ~INPUT_CONTEXT~ by zrobić zakupy.',
	['bought'] = 'Kupiłeś ~b~1x ',
	['not_enough'] = 'Nie masz ~r~wystarczająco~s~ pieniędzy.',

}
