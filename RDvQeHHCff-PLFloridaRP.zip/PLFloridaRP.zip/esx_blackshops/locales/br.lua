Locales['br'] = {

	['shop'] = 'Comprar',
	['shops'] = 'Lojas',
	['press_menu'] = 'Pressione ~INPUT_CONTEXT~ para acessar a loja.',
	['bought'] = 'você comprou ~b~1x ',
	['not_enough'] = 'você não tem ~r~dinheiro suficiente~s~.'

}
Locales['br'] = {

	['shop'] = 'Comprar',
	['shops'] = 'Lojas',
	['press_menu'] = 'Pressione ~INPUT_CONTEXT~ para acessar a loja.',
	['bought'] = 'você comprou ~b~1x ',
	['not_enough'] = 'você não tem ~r~dinheiro suficiente~s~.'

}
