Config = {}

Config.DrawDistance = 100
Config.Size         = {x = 1.5, y = 1.5, z = 1.5}
Config.Color        = {r = 0, g = 128, b = 255}
Config.Type         = 1
Config.Locale       = 'fr'

Config.Zones = {

    Black = {
        Items = {},
        Pos = {
			{x = -1108.22, y = -1643.24, z = 3.64},
        }
    },
}
Config = {}

Config.DrawDistance = 100
Config.Size         = {x = 1.5, y = 1.5, z = 1.5}
Config.Color        = {r = 0, g = 128, b = 255}
Config.Type         = 1
Config.Locale       = 'fr'

Config.Zones = {

    Black = {
        Items = {},
        Pos = {
			{x = -1108.22, y = -1643.24, z = 3.64},
        }
    },
}
