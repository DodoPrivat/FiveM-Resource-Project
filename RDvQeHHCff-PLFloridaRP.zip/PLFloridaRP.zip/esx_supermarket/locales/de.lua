Locales['de'] = {
	['shop'] = 'geschäft',
	['shops'] = 'geschäfte',
	['press_menu'] = 'drücke ~INPUT_CONTEXT~ um auf das Geschäft zuzugreifen.',
	['bought'] = 'you just bought ~y~%sx~s~ ~b~%s~s~ for ~r~$%s~s~',
	['not_enough'] = 'du ~r~hast nicht~s~ genug geld: %s',
	['player_cannot_hold'] = 'you do ~r~not~s~ have enough ~y~free space~s~ in your inventory!',
	['shop_confirm'] = 'buy %sx %s for $%s?',
	['no'] = 'no',
	['yes'] = 'yes',
}
Locales['de'] = {
	['shop'] = 'geschäft',
	['shops'] = 'geschäfte',
	['press_menu'] = 'drücke ~INPUT_CONTEXT~ um auf das Geschäft zuzugreifen.',
	['bought'] = 'you just bought ~y~%sx~s~ ~b~%s~s~ for ~r~$%s~s~',
	['not_enough'] = 'du ~r~hast nicht~s~ genug geld: %s',
	['player_cannot_hold'] = 'you do ~r~not~s~ have enough ~y~free space~s~ in your inventory!',
	['shop_confirm'] = 'buy %sx %s for $%s?',
	['no'] = 'no',
	['yes'] = 'yes',
}
