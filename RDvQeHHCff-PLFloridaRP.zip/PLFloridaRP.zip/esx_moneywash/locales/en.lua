Locales['en'] = {
	['moneywash'] 			= 'Pralnia Pieniędzy',
	['press_menu'] 			= 'Naciśnij ~INPUT_CONTEXT~ ,aby wyprać swoje ~y~Brudne pieniądze',
	['Nothere'] 			= 'Wróć później ...',
	['Whitening'] 			= 'Pranie w toku ...',
	['Nocash'] 				= 'Nie masz wystarczająco dużo pieniędzy do prania, minimum: $',
	['cash'] 				= 'Otrzymałeś: ~r~$',
	['cash1'] 				= 'czyste pieniądze',
	['Notification'] 		= 'Pralnia Pieniędzy',
	['wash'] 				= 'Zniszcz brudne pieniądze',
	['wash_money_amount']   = 'Ilość pieniędzy do prania',
	['invalid_amount']      = 'Nieprawidłowa ilość',
}

Locales['en'] = {
	['moneywash'] 			= 'Pralnia Pieniędzy',
	['press_menu'] 			= 'Naciśnij ~INPUT_CONTEXT~ ,aby wyprać swoje ~y~Brudne pieniądze',
	['Nothere'] 			= 'Wróć później ...',
	['Whitening'] 			= 'Pranie w toku ...',
	['Nocash'] 				= 'Nie masz wystarczająco dużo pieniędzy do prania, minimum: $',
	['cash'] 				= 'Otrzymałeś: ~r~$',
	['cash1'] 				= 'czyste pieniądze',
	['Notification'] 		= 'Pralnia Pieniędzy',
	['wash'] 				= 'Zniszcz brudne pieniądze',
	['wash_money_amount']   = 'Ilość pieniędzy do prania',
	['invalid_amount']      = 'Nieprawidłowa ilość',
}

