Config = {}
Config.Locale = 'sv'
Config = {}
Config.Locale = 'sv'
