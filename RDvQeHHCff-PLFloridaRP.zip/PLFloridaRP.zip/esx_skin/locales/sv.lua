Locales['sv'] = {
  ['skin_menu'] = 'Menu Wyglądu',
  ['use_rotate_view'] = 'Użyj ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ lub ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ aby obrocić ekran.',
  ['skin'] = 'Zmień Wygląd',
  ['saveskin'] = 'Zapisz Wygląd do Pliku',
}
Locales['sv'] = {
  ['skin_menu'] = 'Menu Wyglądu',
  ['use_rotate_view'] = 'Użyj ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ lub ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ aby obrocić ekran.',
  ['skin'] = 'Zmień Wygląd',
  ['saveskin'] = 'Zapisz Wygląd do Pliku',
}
