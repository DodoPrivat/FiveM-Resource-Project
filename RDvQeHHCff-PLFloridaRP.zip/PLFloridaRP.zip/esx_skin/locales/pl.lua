﻿Locales['pl'] = {
  ['skin_menu'] = 'Menu Wygladu',
  ['use_rotate_view'] = 'Uzyj ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ i ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ aby obrocic ekran.',
  ['skin'] = 'Zmien Wyglad',
  ['saveskin'] = 'Zapisz Wyglad',
}
﻿Locales['pl'] = {
  ['skin_menu'] = 'Menu Wygladu',
  ['use_rotate_view'] = 'Uzyj ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ i ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ aby obrocic ekran.',
  ['skin'] = 'Zmien Wyglad',
  ['saveskin'] = 'Zapisz Wyglad',
}
