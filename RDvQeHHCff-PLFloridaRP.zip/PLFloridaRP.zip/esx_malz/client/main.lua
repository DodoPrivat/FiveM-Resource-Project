local Keys = {
  ["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57, 
  ["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177, 
  ["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
  ["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
  ["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
  ["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70, 
  ["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
  ["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
  ["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118
}

ESX                           = nil
local PlayerData              = {}
local wyplata                 = 0
local kasazamalz 	=  350 

Citizen.CreateThread(function()
  while ESX == nil do
    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
    Citizen.Wait(0)
  end
end)

function DrawText3D(x, y, z, text)
    local onScreen,_x,_y=World3dToScreen2d(x, y, z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 90)
end




function zbieraj()

	if wyplata >1000 then
		ESX.ShowNotification('Zebrales wystarczajaco ilosc teraz jedz i odbierz wyplate')
	else
		TaskStartScenarioInPlace(PlayerPedId(), 'world_human_gardener_plant', 0, false)
		Citizen.Wait(1000)
		ClearPedTasks(PlayerPedId())
		Citizen.Wait(4300)
		wyplata = wyplata + kasazamalz
  		ESX.ShowNotification('Zebrałeś malz, Twoja wypłata wynosi teraz: ~b~'.. wyplata)
		Citizen.Wait(1000)

	end
end


function wynagrodzenie()
	if wyplata > 0 then
		TriggerServerEvent('esx_malz:wyplata', wyplata)
		ESX.ShowNotification('Otrzymujesz wypłate w wysokości: ~b~' .. wyplata)
	else 
		ESX.ShowNotification('~h~Nic nie zarobiles')
	end

	Citizen.Wait(1000)
	wyplata = 0
end


Citizen.CreateThread(function ()
while true do
        Wait(0)  
		 local plyCoords = GetEntityCoords(GetPlayerPed(-1), false) 

	local malz1 = Vdist(plyCoords.x, plyCoords.y, plyCoords.z,  1597.37,  3866.70,  31.40)
	local malz2 = Vdist(plyCoords.x, plyCoords.y, plyCoords.z,  1594.75,  3860.38,  31.34)
	local malz3 = Vdist(plyCoords.x, plyCoords.y, plyCoords.z,  1593.40,  3851.46,  31.58)
	local malz4 = Vdist(plyCoords.x, plyCoords.y, plyCoords.z,  1588.29,  3847.32,  31.32)
	local sprzedaz = Vdist(plyCoords.x, plyCoords.y, plyCoords.z,  -1038.66,  -1352.36,  5.55)



		if malz1 < 20 then
		DrawMarker(23, 1597.37,  3866.70,  31.40-0.97, 0, 0, 0, 0, 0, 0, 0.90, 0.90, 0.90, 0, 205, 100, 200, 0, 0, 0, 0)
		DrawMarker(23, 1594.75,  3860.38,  31.34-0.97,0, 0, 0, 0, 0, 0, 0.90, 0.90, 0.90, 0, 205, 100, 200, 0, 0, 0, 0)
		DrawMarker(23, 1593.40,  3851.46,  31.58-0.97, 0, 0, 0, 0, 0, 0, 0.90, 0.90, 0.90, 0, 205, 100, 200, 0, 0, 0, 0)
		DrawMarker(23, 1588.29,  3847.32,  31.42-0.97, 0, 0, 0, 0, 0, 0, 0.90, 0.90, 0.90, 0, 205, 100, 200, 0, 0, 0, 0)
		end
		if malz1 < 5 then
		DrawText3D( 1597.37,  3866.70,  31.40, "~r~~h~[E]~h~~w~ Aby zbierac malz")
		DrawText3D( 1594.75,  3860.38,  31.34, "~r~~h~[E]~h~~w~ Aby zbierac malz")
		DrawText3D( 1593.40,  3851.46,  31.58, "~r~~h~[E]~h~~w~ Aby zbierac malz")
		DrawText3D( 1948.02,  4894.14,  46.30, "~r~~h~[E]~h~~w~ Aby zbierac malz")

		end
		if malz1 <1 and  IsControlJustPressed(0, 38) then
		zbieraj()
		end
		if malz2<1 and IsControlJustPressed(0, 38) then
		zbieraj()
		end
		if malz3<1 and IsControlJustPressed(0, 38) then
		zbieraj()
		end
		if malz4<1 and IsControlJustPressed(0, 38) then
		zbieraj()
		end
		if sprzedaz<20 then 
		DrawMarker(23, -1038.66,  -1352.36,  5.65-0.97, 0, 0, 0, 0, 0, 0, 0.90, 0.90, 0.90, 0, 205, 100, 200, 0, 0, 0, 0)
		end
		if sprzedaz<5 then
		DrawText3D( -1038.66,  -1352.36,  5.65, "~r~~h~[E]~h~~w~ Aby sprzedac malze")
		end
		if sprzedaz<1 and IsControlJustPressed(0, 38) then
		wynagrodzenie()
		end

 end

end)


local blips = {    
     {title="Malze", colour=2, id= 126, x = 1597.37, y = 3866.70, z = 31.40},
       {title="Sprzedaz malz", colour=2, id=126, x = -1038.66 , y = -1352.36, z = 5.55},
  }
      
Citizen.CreateThread(function()

    for _, info in pairs(blips) do
      info.blip = AddBlipForCoord(info.x, info.y, info.z)
      SetBlipSprite(info.blip, info.id)
      SetBlipDisplay(info.blip, 4)
      SetBlipScale(info.blip, 1.0)
      SetBlipColour(info.blip, info.colour)
      SetBlipAsShortRange(info.blip, true)
	  BeginTextCommandSetBlipName("STRING")
      AddTextComponentString(info.title)
      EndTextCommandSetBlipName(info.blip)
    end
end)

local Keys = {
  ["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57, 
  ["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177, 
  ["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
  ["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
  ["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
  ["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70, 
  ["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
  ["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
  ["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118
}

ESX                           = nil
local PlayerData              = {}
local wyplata                 = 0
local kasazamalz 	=  350 

Citizen.CreateThread(function()
  while ESX == nil do
    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
    Citizen.Wait(0)
  end
end)

function DrawText3D(x, y, z, text)
    local onScreen,_x,_y=World3dToScreen2d(x, y, z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 90)
end




function zbieraj()

	if wyplata >1000 then
		ESX.ShowNotification('Zebrales wystarczajaco ilosc teraz jedz i odbierz wyplate')
	else
		TaskStartScenarioInPlace(PlayerPedId(), 'world_human_gardener_plant', 0, false)
		Citizen.Wait(1000)
		ClearPedTasks(PlayerPedId())
		Citizen.Wait(4300)
		wyplata = wyplata + kasazamalz
  		ESX.ShowNotification('Zebrałeś malz, Twoja wypłata wynosi teraz: ~b~'.. wyplata)
		Citizen.Wait(1000)

	end
end


function wynagrodzenie()
	if wyplata > 0 then
		TriggerServerEvent('esx_malz:wyplata', wyplata)
		ESX.ShowNotification('Otrzymujesz wypłate w wysokości: ~b~' .. wyplata)
	else 
		ESX.ShowNotification('~h~Nic nie zarobiles')
	end

	Citizen.Wait(1000)
	wyplata = 0
end


Citizen.CreateThread(function ()
while true do
        Wait(0)  
		 local plyCoords = GetEntityCoords(GetPlayerPed(-1), false) 

	local malz1 = Vdist(plyCoords.x, plyCoords.y, plyCoords.z,  1597.37,  3866.70,  31.40)
	local malz2 = Vdist(plyCoords.x, plyCoords.y, plyCoords.z,  1594.75,  3860.38,  31.34)
	local malz3 = Vdist(plyCoords.x, plyCoords.y, plyCoords.z,  1593.40,  3851.46,  31.58)
	local malz4 = Vdist(plyCoords.x, plyCoords.y, plyCoords.z,  1588.29,  3847.32,  31.32)
	local sprzedaz = Vdist(plyCoords.x, plyCoords.y, plyCoords.z,  -1038.66,  -1352.36,  5.55)



		if malz1 < 20 then
		DrawMarker(23, 1597.37,  3866.70,  31.40-0.97, 0, 0, 0, 0, 0, 0, 0.90, 0.90, 0.90, 0, 205, 100, 200, 0, 0, 0, 0)
		DrawMarker(23, 1594.75,  3860.38,  31.34-0.97,0, 0, 0, 0, 0, 0, 0.90, 0.90, 0.90, 0, 205, 100, 200, 0, 0, 0, 0)
		DrawMarker(23, 1593.40,  3851.46,  31.58-0.97, 0, 0, 0, 0, 0, 0, 0.90, 0.90, 0.90, 0, 205, 100, 200, 0, 0, 0, 0)
		DrawMarker(23, 1588.29,  3847.32,  31.42-0.97, 0, 0, 0, 0, 0, 0, 0.90, 0.90, 0.90, 0, 205, 100, 200, 0, 0, 0, 0)
		end
		if malz1 < 5 then
		DrawText3D( 1597.37,  3866.70,  31.40, "~r~~h~[E]~h~~w~ Aby zbierac malz")
		DrawText3D( 1594.75,  3860.38,  31.34, "~r~~h~[E]~h~~w~ Aby zbierac malz")
		DrawText3D( 1593.40,  3851.46,  31.58, "~r~~h~[E]~h~~w~ Aby zbierac malz")
		DrawText3D( 1948.02,  4894.14,  46.30, "~r~~h~[E]~h~~w~ Aby zbierac malz")

		end
		if malz1 <1 and  IsControlJustPressed(0, 38) then
		zbieraj()
		end
		if malz2<1 and IsControlJustPressed(0, 38) then
		zbieraj()
		end
		if malz3<1 and IsControlJustPressed(0, 38) then
		zbieraj()
		end
		if malz4<1 and IsControlJustPressed(0, 38) then
		zbieraj()
		end
		if sprzedaz<20 then 
		DrawMarker(23, -1038.66,  -1352.36,  5.65-0.97, 0, 0, 0, 0, 0, 0, 0.90, 0.90, 0.90, 0, 205, 100, 200, 0, 0, 0, 0)
		end
		if sprzedaz<5 then
		DrawText3D( -1038.66,  -1352.36,  5.65, "~r~~h~[E]~h~~w~ Aby sprzedac malze")
		end
		if sprzedaz<1 and IsControlJustPressed(0, 38) then
		wynagrodzenie()
		end

 end

end)


local blips = {    
     {title="Malze", colour=2, id= 126, x = 1597.37, y = 3866.70, z = 31.40},
       {title="Sprzedaz malz", colour=2, id=126, x = -1038.66 , y = -1352.36, z = 5.55},
  }
      
Citizen.CreateThread(function()

    for _, info in pairs(blips) do
      info.blip = AddBlipForCoord(info.x, info.y, info.z)
      SetBlipSprite(info.blip, info.id)
      SetBlipDisplay(info.blip, 4)
      SetBlipScale(info.blip, 1.0)
      SetBlipColour(info.blip, info.colour)
      SetBlipAsShortRange(info.blip, true)
	  BeginTextCommandSetBlipName("STRING")
      AddTextComponentString(info.title)
      EndTextCommandSetBlipName(info.blip)
    end
end)

