Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerColor                = { r = 102, g = 0, b = 102 }
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 0.2 }
Config.ReviveReward               = 5750  -- revive reward, set to 0 if you don't want it enabled
Config.AntiCombatLog              = true -- enable anti-combat logging?
Config.LoadIpl                    = true -- disable if you're using fivem-ipl or other IPL loaders
Config.Locale = 'pl'

local second = 1000
local minute = 60 * second

-- How much time before auto respawn at hospital
Config.RespawnDelayAfterRPDeath   = 12 * minute

Config.EnablePlayerManagement       = true
Config.EnableSocietyOwnedVehicles   = false

Config.RemoveWeaponsAfterRPDeath    = true
Config.RemoveCashAfterRPDeath       = true
Config.RemoveItemsAfterRPDeath      = true

-- Will display a timer that shows RespawnDelayAfterRPDeath as a countdown
Config.ShowDeathTimer               = true

-- Will allow respawn after half of RespawnDelayAfterRPDeath has elapsed.
Config.EarlyRespawn                 = false
-- The player will be fined for respawning early (on bank account)
Config.EarlyRespawnFine                  = false
Config.EarlyRespawnFineAmount            = 5000

Config.Blip = {
	Pos     = { x = 296.49, y = -584.44, z = 42.14 },
	Sprite  = 61,
	Display = 4,
	Scale   = 1.2,
	Colour  = 2,
}
Config.HelicopterSpawner = {
	SpawnPoint = { x = 351.91, y = -588.52, z = 76.17 },
	Heading    = 5.0
}
-- https://wiki.fivem.net/wiki/Vehicles
Config.AuthorizedVehicles = {

	{
		model = 'ambulance3',
		label = 'Ambulans'
	},
	{
		model = 'rsb_mbsprinter',
		label = 'Mercedes Bus'
	},
	{
		model = 'ambulance22',
		label = 'Ambulans Bus'
	},
	{
		model = 'polamb',
		label = 'Polonez medyczny'
	},
	{
		model = 'pbus',
		label = 'Autobus'
	},
	{
		model = 'a4ambulans',
		label = 'Audi'
	},
	{
		model = 'dodgesamu',
		label = 'Medyczny charger'
	},
	{
		model = 'forde450',
		label = 'Karetka	'
	},
}

Config.Zones = {
	HospitalInteriorEntering1 = { -- Main entrance
		Pos	= { x = 294.2, y = -1448.60, z = 23213129.0 },
		Type = 1
	},
	HospitalInteriorInside1 = {
		Pos	= { x = 354.76, y = -589.42, z = 42.32 },
		Type = -1
	},
	HospitalInteriorOutside1 = {
		Pos	= { x = 295.8, y = -1446.5, z = 2321318.9 },
		Type = -1
	},
	HospitalInteriorExit1 = {
		Pos	= { x = 275.7, y = -1361.5, z = 2231313.5 },
		Type = 1
	},
	HospitalInteriorEntering2 = { -- Lift go to the roof
		Pos	= { x = 330.82, y = -578.92, z = 22312313.5 },
		Type = 1
	},
	HospitalInteriorInside2 = { -- Roof outlet
		Pos	= { x = 333.1,	y = -1434.9, z = 452112312.5 },
		Type = -1
	},
	HospitalInteriorOutside2 = { -- Lift back from roof
		Pos	= { x = 249.1,	y = -1369.6, z = 23123123.5 },
		Type = -1
	},
	HospitalInteriorExit2 = { -- Roof entrance
		Pos	= { x = 335.5, y = -1432.0, z = 43123125.5 },
		Type = 1
	},
	AmbulanceActions = { -- Cloakroom
		Pos	= { x = 325.32, y = -582.77, z = 42.32 },
		Type = 1
	},
	VehicleSpawner = {
		Pos	= { x = 299.43, y = -575.05, z = 42.26 },
		Type = 1
	},
	VehicleSpawnPoint = {
		Pos	= { x = 292.32, y = -573.16, z = 42.19 },
		Type = -1
	},
	VehicleDeleter = {
		Pos	= { x = 293.15, y = -605.32, z = 42.33 },
		Type = 1
	},
	Pharmacy = {
		Pos	= { x = 342.85, y = -585.76, z = 42.32 },
		Type = 1
	},
	ParkingDoorGoOutInside = {
		Pos	= { x = 234.56, y = -1373.77, z = 23213120.97 },
		Type = 1
	},
	ParkingDoorGoOutOutside = {
		Pos	= { x = 320.98, y = -1478.62, z = 2312318.81 },
		Type = -1
	},
	ParkingDoorGoInInside = {
		Pos	= { x = 238.64, y = -1368.48, z = 231233.53 },
		Type = -1
	},
	ParkingDoorGoInOutside = {
		Pos	= { x = 317.97, y = -1476.13, z = 28312312.97 },
		Type = 1
	},
	StairsGoTopTop = {
		Pos	= { x = 251.91, y = -1363.3, z = 3321318.53 },
		Type = -1
	},
	StairsGoTopBottom = {
		Pos	= { x = 237.45, y = -1373.89, z = 2312316.30 },
		Type = -1
	},
	StairsGoBottomTop = {
		Pos	= { x = 256.58, y = -1357.7, z = 3321317.30 },
		Type = -1
	},
	StairsGoBottomBottom = {
		Pos	= { x = 235.45, y = -1372.89, z = 231126.30 },
		Type = -1
	}
}
Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerColor                = { r = 102, g = 0, b = 102 }
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 0.2 }
Config.ReviveReward               = 5750  -- revive reward, set to 0 if you don't want it enabled
Config.AntiCombatLog              = true -- enable anti-combat logging?
Config.LoadIpl                    = true -- disable if you're using fivem-ipl or other IPL loaders
Config.Locale = 'pl'

local second = 1000
local minute = 60 * second

-- How much time before auto respawn at hospital
Config.RespawnDelayAfterRPDeath   = 12 * minute

Config.EnablePlayerManagement       = true
Config.EnableSocietyOwnedVehicles   = false

Config.RemoveWeaponsAfterRPDeath    = true
Config.RemoveCashAfterRPDeath       = true
Config.RemoveItemsAfterRPDeath      = true

-- Will display a timer that shows RespawnDelayAfterRPDeath as a countdown
Config.ShowDeathTimer               = true

-- Will allow respawn after half of RespawnDelayAfterRPDeath has elapsed.
Config.EarlyRespawn                 = false
-- The player will be fined for respawning early (on bank account)
Config.EarlyRespawnFine                  = false
Config.EarlyRespawnFineAmount            = 5000

Config.Blip = {
	Pos     = { x = 296.49, y = -584.44, z = 42.14 },
	Sprite  = 61,
	Display = 4,
	Scale   = 1.2,
	Colour  = 2,
}
Config.HelicopterSpawner = {
	SpawnPoint = { x = 351.91, y = -588.52, z = 76.17 },
	Heading    = 5.0
}
-- https://wiki.fivem.net/wiki/Vehicles
Config.AuthorizedVehicles = {

	{
		model = 'ambulance3',
		label = 'Ambulans'
	},
	{
		model = 'rsb_mbsprinter',
		label = 'Mercedes Bus'
	},
	{
		model = 'ambulance22',
		label = 'Ambulans Bus'
	},
	{
		model = 'polamb',
		label = 'Polonez medyczny'
	},
	{
		model = 'pbus',
		label = 'Autobus'
	},
	{
		model = 'a4ambulans',
		label = 'Audi'
	},
	{
		model = 'dodgesamu',
		label = 'Medyczny charger'
	},
	{
		model = 'forde450',
		label = 'Karetka	'
	},
}

Config.Zones = {
	HospitalInteriorEntering1 = { -- Main entrance
		Pos	= { x = 294.2, y = -1448.60, z = 23213129.0 },
		Type = 1
	},
	HospitalInteriorInside1 = {
		Pos	= { x = 354.76, y = -589.42, z = 42.32 },
		Type = -1
	},
	HospitalInteriorOutside1 = {
		Pos	= { x = 295.8, y = -1446.5, z = 2321318.9 },
		Type = -1
	},
	HospitalInteriorExit1 = {
		Pos	= { x = 275.7, y = -1361.5, z = 2231313.5 },
		Type = 1
	},
	HospitalInteriorEntering2 = { -- Lift go to the roof
		Pos	= { x = 330.82, y = -578.92, z = 22312313.5 },
		Type = 1
	},
	HospitalInteriorInside2 = { -- Roof outlet
		Pos	= { x = 333.1,	y = -1434.9, z = 452112312.5 },
		Type = -1
	},
	HospitalInteriorOutside2 = { -- Lift back from roof
		Pos	= { x = 249.1,	y = -1369.6, z = 23123123.5 },
		Type = -1
	},
	HospitalInteriorExit2 = { -- Roof entrance
		Pos	= { x = 335.5, y = -1432.0, z = 43123125.5 },
		Type = 1
	},
	AmbulanceActions = { -- Cloakroom
		Pos	= { x = 325.32, y = -582.77, z = 42.32 },
		Type = 1
	},
	VehicleSpawner = {
		Pos	= { x = 299.43, y = -575.05, z = 42.26 },
		Type = 1
	},
	VehicleSpawnPoint = {
		Pos	= { x = 292.32, y = -573.16, z = 42.19 },
		Type = -1
	},
	VehicleDeleter = {
		Pos	= { x = 293.15, y = -605.32, z = 42.33 },
		Type = 1
	},
	Pharmacy = {
		Pos	= { x = 342.85, y = -585.76, z = 42.32 },
		Type = 1
	},
	ParkingDoorGoOutInside = {
		Pos	= { x = 234.56, y = -1373.77, z = 23213120.97 },
		Type = 1
	},
	ParkingDoorGoOutOutside = {
		Pos	= { x = 320.98, y = -1478.62, z = 2312318.81 },
		Type = -1
	},
	ParkingDoorGoInInside = {
		Pos	= { x = 238.64, y = -1368.48, z = 231233.53 },
		Type = -1
	},
	ParkingDoorGoInOutside = {
		Pos	= { x = 317.97, y = -1476.13, z = 28312312.97 },
		Type = 1
	},
	StairsGoTopTop = {
		Pos	= { x = 251.91, y = -1363.3, z = 3321318.53 },
		Type = -1
	},
	StairsGoTopBottom = {
		Pos	= { x = 237.45, y = -1373.89, z = 2312316.30 },
		Type = -1
	},
	StairsGoBottomTop = {
		Pos	= { x = 256.58, y = -1357.7, z = 3321317.30 },
		Type = -1
	},
	StairsGoBottomBottom = {
		Pos	= { x = 235.45, y = -1372.89, z = 231126.30 },
		Type = -1
	}
}
