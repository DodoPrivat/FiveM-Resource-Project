Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.GangStations = {

  Gang = {

    Blip = {
      Pos     = { x = 425.130, y = -979.558, z = 30.711 },
      Sprite  = 0,
      Display = 0,
      Scale   = 0,
      Colour  = 0,
    },

    AuthorizedWeapons = {
	  { name = 'WEAPON_POOLCUE',          price = 1000 },	  
    },

	  AuthorizedVehicles = {
		  { name = 'x5e53',  label = 'BMW X5E53' },
	  },

    Cloakrooms = {
      { x = 91212.283, y = 52128.914, z = 16129.635 },
    },

    Armories = {
      { x = -1.19, y = 535.02, z = 174.34 },
    },

    Vehicles = {
      {
        Spawner    = { x = 16.92, y = 547.25, z = 175.12 },
        SpawnPoint = { x = 12.36, y = 551.04, z = 175.28 },
        Heading    = 48,
      }
    },
	
	Helicopters = {
      {
        Spawner    = { x = 20.312, y = 535.667, z = 173.627 },
        SpawnPoint = { x = 3.40, y = 525.56, z = 177.919 },
        Heading    = 0.0,
      }
    },

    VehicleDeleters = {
      { x = 22.67, y = 544.75, z = 175.03 },
      { x = 21.96, y = 543.48, z = 175.03 },
    },

    BossActions = {
      { x = 3.95, y = 526.14, z = 173.64 }
    },

  },

}
Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.GangStations = {

  Gang = {

    Blip = {
      Pos     = { x = 425.130, y = -979.558, z = 30.711 },
      Sprite  = 0,
      Display = 0,
      Scale   = 0,
      Colour  = 0,
    },

    AuthorizedWeapons = {
	  { name = 'WEAPON_POOLCUE',          price = 1000 },	  
    },

	  AuthorizedVehicles = {
		  { name = 'x5e53',  label = 'BMW X5E53' },
	  },

    Cloakrooms = {
      { x = 91212.283, y = 52128.914, z = 16129.635 },
    },

    Armories = {
      { x = -1.19, y = 535.02, z = 174.34 },
    },

    Vehicles = {
      {
        Spawner    = { x = 16.92, y = 547.25, z = 175.12 },
        SpawnPoint = { x = 12.36, y = 551.04, z = 175.28 },
        Heading    = 48,
      }
    },
	
	Helicopters = {
      {
        Spawner    = { x = 20.312, y = 535.667, z = 173.627 },
        SpawnPoint = { x = 3.40, y = 525.56, z = 177.919 },
        Heading    = 0.0,
      }
    },

    VehicleDeleters = {
      { x = 22.67, y = 544.75, z = 175.03 },
      { x = 21.96, y = 543.48, z = 175.03 },
    },

    BossActions = {
      { x = 3.95, y = 526.14, z = 173.64 }
    },

  },

}
