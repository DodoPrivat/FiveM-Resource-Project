local Keys = {
	["ESC"] = 322, ["BACKSPACE"] = 177, ["E"] = 38, ["ENTER"] = 18,	["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173
}

ESX                           = nil
local otworzdol = false
local otworzgora = false
local PlayerData                = {}
local wlam = false
local wlam1 = false

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	Citizen.Wait(5000)
	PlayerData = ESX.GetPlayerData()
end)
RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	PlayerData.job = job
	
	Citizen.Wait(5000)

end)
local gora = nil--GetClosestObjectOfType(96.09197, -1284.854, 29.43878, 30.0, GetHashKey("prop_magenta_door"))
local dol = nil--GetClosestObjectOfType(99.08321, -1293.701, 29.41868, 30.0, GetHashKey("v_ilev_roc_door2"))
local rotacjadolu = GetEntityRotation(dol)
local rotacjagory = GetEntityRotation(gora)
local napadud = false
RegisterNetEvent('nieudalosiema:zapadka')
AddEventHandler('nieudalosiema:zapadka', function()

wlam1 = false

end)

RegisterNetEvent('koniecnapadu:klub')
AddEventHandler('koniecnapadu:klub', function()
	ESX.ShowAdvancedNotification('Napad na klub', '~y~Konto', 'Pieniądze zostały przelane na twoje konto, drzwi zamkną się za 30 sekund! ', 'CHAR_BLOCKED', 3)

TriggerServerEvent('udanonapad:klub30k')

Citizen.Wait(30000)
SetEntityRotation(dol, rotacjadolu, 0, true)
FreezeEntityPosition(gora, true)
FreezeEntityPosition(dol, true)
napadud = false
	wlam1 = false
end)


RegisterNetEvent('zamknij:dol')
AddEventHandler('zamknij:dol', function()
	ESX.ShowAdvancedNotification('Napad na klub', '~y~Włam', 'Udało Ci się otworzyć drzwi!', 'CHAR_BLOCKED', 3)
				FreezeEntityPosition(dol, false)
				napadud = true

end)

Citizen.CreateThread(function()
	Citizen.Wait(500)

Citizen.Wait(15000)
gora = GetClosestObjectOfType(96.09197, -1284.854, 29.43878, 30.0, GetHashKey("prop_magenta_door"))
dol = GetClosestObjectOfType(99.08321, -1293.701, 29.41868, 30.0, GetHashKey("v_ilev_roc_door2"))

	FreezeEntityPosition(gora, true)
	FreezeEntityPosition(dol, true)
	print('zablkono')
	while true do
		Wait(5)
		local coords      = GetEntityCoords(GetPlayerPed(-1))
		if napadud == true then
			if(GetDistanceBetweenCoords(coords, 95.370, -1293.240, 29.29, true) < 30.0) then
				ESX.Game.Utils.DrawText3D({ x = 95.780, y = -1292.850, z = 29.40 }, '~y~[E] ~w~Włącz komputer', 0.4)	
				if(GetDistanceBetweenCoords(coords, 95.370, -1293.240, 29.29, true) < 2.0) then
					if IsControlJustReleased(0, Keys['E']) then
						napad()			
					end
				end
	
			end
		end
	end
end)
function napad()
	napadud = false
	TriggerEvent('wlacz:komputerhakowanie')
end

Citizen.CreateThread(function()
	while true do

		Wait(10)
		local coords      = GetEntityCoords(GetPlayerPed(-1))
		if(GetDistanceBetweenCoords(coords, 100.270, -1293.850, 29.40, true) < 5.0) then

			if wlam1 == false then

			ESX.Game.Utils.DrawText3D({ x = 100.110, y = -1293.550, z = 29.40 }, '~y~[E] ~w~Włam się', 0.4)	
				if(GetDistanceBetweenCoords(coords, 100.270, -1293.850, 29.40, true) < 2.0) then
					
					local coords      = GetEntityCoords(GetPlayerPed(-1))
								if IsControlJustReleased(0, Keys['E']) then
									wlam()
						end
					end
				end
				end
		end -- od while
end)

function wlam()
	wlam1 = true	
	local lib, anim = "mini@safe_cracking", "idle_base"
	ESX.Streaming.RequestAnimDict(lib, function()
		TaskPlayAnim(PlayerPedId(), lib, anim, 8.0, -8.0, -1, 0, 0, false, false, false)
	end)

	ESX.ShowAdvancedNotification('Napad na klub', '~y~Włam', 'Rozwal zapadki w dobrej kolejności ~g~', 'CHAR_BLOCKED', 3)
Citizen.Wait(5000)
	TriggerEvent('wlacz:wlam')
end


RegisterNetEvent('smerfiknapad:postawblip')
AddEventHandler('smerfiknapad:postawblip', function()
	blip = AddBlipForCoord(128.06, -1297.22, 59.27)
	SetBlipSprite(blip, 363)
	SetBlipDisplay(blip, 4)
	SetBlipScale(blip, 1.0)
	SetBlipColour(blip, 83)
	SetBlipAsShortRange(blip, true)
	BeginTextCommandSetBlipName("STRING")
	AddTextComponentString('ALARM! NAPAD NA KLUB')
	EndTextCommandSetBlipName(blip)
Citizen.Wait(180000)
RemoveBlip(blip)
end)



local blips = {

	{title="Napad na klub gościu", colour=4, id=521, x = -11084.870, y = -254.150, z = 37.70}

}      




Citizen.CreateThread(function()

   for _, info in pairs(blips) do
	 info.blip = AddBlipForCoord(info.x, info.y, info.z)
	 SetBlipSprite(info.blip, info.id)
	 SetBlipDisplay(info.blip, 4)
	 SetBlipScale(info.blip, 1.0)
	 SetBlipColour(info.blip, info.colour)
	 SetBlipAsShortRange(info.blip, true)
	 BeginTextCommandSetBlipName("STRING")
	 AddTextComponentString(info.title)
	 EndTextCommandSetBlipName(info.blip)
   end

end)

function loadAnimDict(dict)
	while (not HasAnimDictLoaded(dict)) do
		RequestAnimDict(dict)
		Citizen.Wait(5)
	end
end

local Keys = {
	["ESC"] = 322, ["BACKSPACE"] = 177, ["E"] = 38, ["ENTER"] = 18,	["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173
}

ESX                           = nil
local otworzdol = false
local otworzgora = false
local PlayerData                = {}
local wlam = false
local wlam1 = false

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	Citizen.Wait(5000)
	PlayerData = ESX.GetPlayerData()
end)
RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	PlayerData.job = job
	
	Citizen.Wait(5000)

end)
local gora = nil--GetClosestObjectOfType(96.09197, -1284.854, 29.43878, 30.0, GetHashKey("prop_magenta_door"))
local dol = nil--GetClosestObjectOfType(99.08321, -1293.701, 29.41868, 30.0, GetHashKey("v_ilev_roc_door2"))
local rotacjadolu = GetEntityRotation(dol)
local rotacjagory = GetEntityRotation(gora)
local napadud = false
RegisterNetEvent('nieudalosiema:zapadka')
AddEventHandler('nieudalosiema:zapadka', function()

wlam1 = false

end)

RegisterNetEvent('koniecnapadu:klub')
AddEventHandler('koniecnapadu:klub', function()
	ESX.ShowAdvancedNotification('Napad na klub', '~y~Konto', 'Pieniądze zostały przelane na twoje konto, drzwi zamkną się za 30 sekund! ', 'CHAR_BLOCKED', 3)

TriggerServerEvent('udanonapad:klub30k')

Citizen.Wait(30000)
SetEntityRotation(dol, rotacjadolu, 0, true)
FreezeEntityPosition(gora, true)
FreezeEntityPosition(dol, true)
napadud = false
	wlam1 = false
end)


RegisterNetEvent('zamknij:dol')
AddEventHandler('zamknij:dol', function()
	ESX.ShowAdvancedNotification('Napad na klub', '~y~Włam', 'Udało Ci się otworzyć drzwi!', 'CHAR_BLOCKED', 3)
				FreezeEntityPosition(dol, false)
				napadud = true

end)

Citizen.CreateThread(function()
	Citizen.Wait(500)

Citizen.Wait(15000)
gora = GetClosestObjectOfType(96.09197, -1284.854, 29.43878, 30.0, GetHashKey("prop_magenta_door"))
dol = GetClosestObjectOfType(99.08321, -1293.701, 29.41868, 30.0, GetHashKey("v_ilev_roc_door2"))

	FreezeEntityPosition(gora, true)
	FreezeEntityPosition(dol, true)
	print('zablkono')
	while true do
		Wait(5)
		local coords      = GetEntityCoords(GetPlayerPed(-1))
		if napadud == true then
			if(GetDistanceBetweenCoords(coords, 95.370, -1293.240, 29.29, true) < 30.0) then
				ESX.Game.Utils.DrawText3D({ x = 95.780, y = -1292.850, z = 29.40 }, '~y~[E] ~w~Włącz komputer', 0.4)	
				if(GetDistanceBetweenCoords(coords, 95.370, -1293.240, 29.29, true) < 2.0) then
					if IsControlJustReleased(0, Keys['E']) then
						napad()			
					end
				end
	
			end
		end
	end
end)
function napad()
	napadud = false
	TriggerEvent('wlacz:komputerhakowanie')
end

Citizen.CreateThread(function()
	while true do

		Wait(10)
		local coords      = GetEntityCoords(GetPlayerPed(-1))
		if(GetDistanceBetweenCoords(coords, 100.270, -1293.850, 29.40, true) < 5.0) then

			if wlam1 == false then

			ESX.Game.Utils.DrawText3D({ x = 100.110, y = -1293.550, z = 29.40 }, '~y~[E] ~w~Włam się', 0.4)	
				if(GetDistanceBetweenCoords(coords, 100.270, -1293.850, 29.40, true) < 2.0) then
					
					local coords      = GetEntityCoords(GetPlayerPed(-1))
								if IsControlJustReleased(0, Keys['E']) then
									wlam()
						end
					end
				end
				end
		end -- od while
end)

function wlam()
	wlam1 = true	
	local lib, anim = "mini@safe_cracking", "idle_base"
	ESX.Streaming.RequestAnimDict(lib, function()
		TaskPlayAnim(PlayerPedId(), lib, anim, 8.0, -8.0, -1, 0, 0, false, false, false)
	end)

	ESX.ShowAdvancedNotification('Napad na klub', '~y~Włam', 'Rozwal zapadki w dobrej kolejności ~g~', 'CHAR_BLOCKED', 3)
Citizen.Wait(5000)
	TriggerEvent('wlacz:wlam')
end


RegisterNetEvent('smerfiknapad:postawblip')
AddEventHandler('smerfiknapad:postawblip', function()
	blip = AddBlipForCoord(128.06, -1297.22, 59.27)
	SetBlipSprite(blip, 363)
	SetBlipDisplay(blip, 4)
	SetBlipScale(blip, 1.0)
	SetBlipColour(blip, 83)
	SetBlipAsShortRange(blip, true)
	BeginTextCommandSetBlipName("STRING")
	AddTextComponentString('ALARM! NAPAD NA KLUB')
	EndTextCommandSetBlipName(blip)
Citizen.Wait(180000)
RemoveBlip(blip)
end)



local blips = {

	{title="Napad na klub gościu", colour=4, id=521, x = -11084.870, y = -254.150, z = 37.70}

}      




Citizen.CreateThread(function()

   for _, info in pairs(blips) do
	 info.blip = AddBlipForCoord(info.x, info.y, info.z)
	 SetBlipSprite(info.blip, info.id)
	 SetBlipDisplay(info.blip, 4)
	 SetBlipScale(info.blip, 1.0)
	 SetBlipColour(info.blip, info.colour)
	 SetBlipAsShortRange(info.blip, true)
	 BeginTextCommandSetBlipName("STRING")
	 AddTextComponentString(info.title)
	 EndTextCommandSetBlipName(info.blip)
   end

end)

function loadAnimDict(dict)
	while (not HasAnimDictLoaded(dict)) do
		RequestAnimDict(dict)
		Citizen.Wait(5)
	end
end

