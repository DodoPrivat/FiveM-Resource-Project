Locales['en'] = {
  ['tattoo_shop_prompt'] = 'Naciśnij ~INPUT_PICKUP~ aby zobaczyć ofertę ~y~tatuażysty~s~.',
  ['money_amount']       = '<span style="color:green;">$%s</span>',
  ['part']               = 'część %s',
  ['go_back_to_menu']    = '< Wróć',
  ['tattoo_item']        = 'tatuaż %s - %s',
  ['tattoos']            = 'tatuaże',
  ['tattoo_shop']        = 'Tatuażysta',
  ['bought_tattoo']      = 'Zrobiłeś se ~y~dziarkę~s~ za ~r~$%s~s~',
  ['not_enough_money']   = 'Nie posiadasz ~r~wystarczająco pieniędzy~s~ na ten tatuaż ~r~$%s~s~'
}Locales['en'] = {
  ['tattoo_shop_prompt'] = 'Naciśnij ~INPUT_PICKUP~ aby zobaczyć ofertę ~y~tatuażysty~s~.',
  ['money_amount']       = '<span style="color:green;">$%s</span>',
  ['part']               = 'część %s',
  ['go_back_to_menu']    = '< Wróć',
  ['tattoo_item']        = 'tatuaż %s - %s',
  ['tattoos']            = 'tatuaże',
  ['tattoo_shop']        = 'Tatuażysta',
  ['bought_tattoo']      = 'Zrobiłeś se ~y~dziarkę~s~ za ~r~$%s~s~',
  ['not_enough_money']   = 'Nie posiadasz ~r~wystarczająco pieniędzy~s~ na ten tatuaż ~r~$%s~s~'
}