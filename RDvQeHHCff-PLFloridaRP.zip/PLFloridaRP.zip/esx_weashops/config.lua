Config                = {}
Config.DrawDistance   = 100
Config.Size           = { x = 1.5, y = 1.5, z = 1.5 }
Config.Color          = { r = 0, g = 128, b = 255 }
Config.Type           = 1
Config.Locale         = 'en'
Config.EnableLicense  = false -- only turn this on if you are using esx_license
Config.LicensePrice   = 15000

Config.Zones = {

    GunShop = {
        legal = 0,
        Items = {},
        Pos   = {

            { x = 22.09,      y = -1107.28,   z = 28.80 },
            { x = -329.81,    y = 6082.98,    z = 30.45 },


        }
    },

    BlackWeashop = {
        legal = 1,
        Items = {},
        Pos   = {
            { x = 1598.55,   y = -1687.27,  z = 88.36 },
        }
    },

}
Config                = {}
Config.DrawDistance   = 100
Config.Size           = { x = 1.5, y = 1.5, z = 1.5 }
Config.Color          = { r = 0, g = 128, b = 255 }
Config.Type           = 1
Config.Locale         = 'en'
Config.EnableLicense  = false -- only turn this on if you are using esx_license
Config.LicensePrice   = 15000

Config.Zones = {

    GunShop = {
        legal = 0,
        Items = {},
        Pos   = {

            { x = 22.09,      y = -1107.28,   z = 28.80 },
            { x = -329.81,    y = 6082.98,    z = 30.45 },


        }
    },

    BlackWeashop = {
        legal = 1,
        Items = {},
        Pos   = {
            { x = 1598.55,   y = -1687.27,  z = 88.36 },
        }
    },

}
