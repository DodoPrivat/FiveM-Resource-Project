Locales ['fi'] = {

  ['buy_license'] = 'osta lisenssi?',
  ['yes'] = 'kyllä',
  ['no'] = 'ei',
  ['buy'] = 'sinä ostit',
  ['not_enough_black'] = 'ei tarpeeksi likaista rahaa',
  ['not_enough'] = 'sinulla ei ole tarpeeksi rahaa',
  ['shop'] = 'kauppa',
  ['shop_menu'] = 'paina ~INPUT_CONTEXT~ avataksesi kauppa ikkuna.',
  ['map_blip'] = 'asekauppa',

}
Locales ['fi'] = {

  ['buy_license'] = 'osta lisenssi?',
  ['yes'] = 'kyllä',
  ['no'] = 'ei',
  ['buy'] = 'sinä ostit',
  ['not_enough_black'] = 'ei tarpeeksi likaista rahaa',
  ['not_enough'] = 'sinulla ei ole tarpeeksi rahaa',
  ['shop'] = 'kauppa',
  ['shop_menu'] = 'paina ~INPUT_CONTEXT~ avataksesi kauppa ikkuna.',
  ['map_blip'] = 'asekauppa',

}
