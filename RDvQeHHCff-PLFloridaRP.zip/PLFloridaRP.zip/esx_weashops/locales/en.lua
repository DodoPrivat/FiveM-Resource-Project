Locales ['en'] = {

  ['buy_license'] = 'Kupić licencję?',
  ['yes'] = 'Tak',
  ['no'] = 'Nie',
  ['buy'] = 'Kupiłeś',
  ['not_enough_black'] = 'nie masz wystarczająco brudnych pieniędzy',
  ['not_enough'] = 'nie masz wystarczająco pieniędzy',
  ['shop'] = 'sklep',
  ['shop_menu'] = 'naciśnij ~INPUT_CONTEXT~ ,aby uzyskać dostęp do sklepu.',
  ['map_blip'] = 'Sklep z bronią',

}
Locales ['en'] = {

  ['buy_license'] = 'Kupić licencję?',
  ['yes'] = 'Tak',
  ['no'] = 'Nie',
  ['buy'] = 'Kupiłeś',
  ['not_enough_black'] = 'nie masz wystarczająco brudnych pieniędzy',
  ['not_enough'] = 'nie masz wystarczająco pieniędzy',
  ['shop'] = 'sklep',
  ['shop_menu'] = 'naciśnij ~INPUT_CONTEXT~ ,aby uzyskać dostęp do sklepu.',
  ['map_blip'] = 'Sklep z bronią',

}
