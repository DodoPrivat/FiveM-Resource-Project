FixePhone = {
    -- Posterunek policji
    ['911'] = { name =  "Recepcja na posterunku policji", coords = { x = 441.2, y = -979.7, z = 30.58 } },

    -- Budka w pobliżu komisariatu policji
    ['008-0001'] = { name = "Budka telefoniczna", coords = { x = 372.25, y = -965.75, z = 28.58 } },
}

ShowNumberNotification = true -- Pokaż numer lub nazwę kontaktu po otrzymaniu nowego SMS-a
FixePhone = {
    -- Posterunek policji
    ['911'] = { name =  "Recepcja na posterunku policji", coords = { x = 441.2, y = -979.7, z = 30.58 } },

    -- Budka w pobliżu komisariatu policji
    ['008-0001'] = { name = "Budka telefoniczna", coords = { x = 372.25, y = -965.75, z = 28.58 } },
}

ShowNumberNotification = true -- Pokaż numer lub nazwę kontaktu po otrzymaniu nowego SMS-a
