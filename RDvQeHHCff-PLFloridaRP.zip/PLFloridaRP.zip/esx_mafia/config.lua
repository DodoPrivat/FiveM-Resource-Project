Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.MafiaStations = {

  Mafia = {

    Blip = {
      Pos     = { x = 425.130, y = -979.558, z = 30.711 },
      Sprite  = 0,
      Display = 0,
      Scale   = 0,
      Colour  = 0,
    },

    AuthorizedWeapons = {
	  { name = 'WEAPON_POOLCUE',          price = 10000 },
           { name = 'WEAPON_CARABINERIFLE',          price = 350000 },
             { name = 'WEAPON_MICROSMG',          price = 150000 },
               { name = 'WEAPON_HEAVYPISTOL',          price = 100000 },	  
    },

	  AuthorizedVehicles = {
		  { name = 'g65amg',  label = 'Mercedes G Klasa' },
	  },

    Cloakrooms = {
      { x = 91212.283, y = 52128.914, z = 16129.635 },
    },

    Armories = {
      { x = -127.77, y = -633.46, z = 167.82 }, 
    },

    Vehicles = {
      {
        Spawner    = { x = -139.48, y = -586.69, z = 31.42 }, 
        SpawnPoint = { x = -139.08, y = -590.78, z = 31.95 }, 
        Heading    = 324,
      }
    },
	
	Helicopters = {
      {
        Spawner    = { x = 20.312, y = 535.667, z = 173.627 }, 
        SpawnPoint = { x = -139.08, y = -590.78, z = 177.919 },    
        Heading    = 0.0,
      }
    },

    VehicleDeleters = {
      { x = -144.44, y = -577.64, z = 31.42 }, 
      { x = -145.44, y = -578.64, z = 31.42 },
    },

    BossActions = {
      { x = -125.64, y = -640.62, z = 167.84 }
    },

  },

}
Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.MafiaStations = {

  Mafia = {

    Blip = {
      Pos     = { x = 425.130, y = -979.558, z = 30.711 },
      Sprite  = 0,
      Display = 0,
      Scale   = 0,
      Colour  = 0,
    },

    AuthorizedWeapons = {
	  { name = 'WEAPON_POOLCUE',          price = 10000 },
           { name = 'WEAPON_CARABINERIFLE',          price = 350000 },
             { name = 'WEAPON_MICROSMG',          price = 150000 },
               { name = 'WEAPON_HEAVYPISTOL',          price = 100000 },	  
    },

	  AuthorizedVehicles = {
		  { name = 'g65amg',  label = 'Mercedes G Klasa' },
	  },

    Cloakrooms = {
      { x = 91212.283, y = 52128.914, z = 16129.635 },
    },

    Armories = {
      { x = -127.77, y = -633.46, z = 167.82 }, 
    },

    Vehicles = {
      {
        Spawner    = { x = -139.48, y = -586.69, z = 31.42 }, 
        SpawnPoint = { x = -139.08, y = -590.78, z = 31.95 }, 
        Heading    = 324,
      }
    },
	
	Helicopters = {
      {
        Spawner    = { x = 20.312, y = 535.667, z = 173.627 }, 
        SpawnPoint = { x = -139.08, y = -590.78, z = 177.919 },    
        Heading    = 0.0,
      }
    },

    VehicleDeleters = {
      { x = -144.44, y = -577.64, z = 31.42 }, 
      { x = -145.44, y = -578.64, z = 31.42 },
    },

    BossActions = {
      { x = -125.64, y = -640.62, z = 167.84 }
    },

  },

}
