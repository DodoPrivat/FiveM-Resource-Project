
local busy = false
local PlayerData = {}
local losulosu = false
local blipRobbery3
local taked = false
local plate = 'ZS'
local workBlip
local electro = 1
local clothesOn = false
ESX = nil




AddEventHandler('base', function()
while ESX.GetPlayerData().job.name == 'electro' do
Citizen.Wait(3000)
	local ped = GetPlayerPed(-1)
		if (GetDistanceBetweenCoords(GetEntityCoords(ped), Config.veh.x, Config.veh.y, Config.veh.z, true) <  25) then
		while (GetDistanceBetweenCoords(GetEntityCoords(ped), Config.veh.x, Config.veh.y, Config.veh.z, true) <  26) do
		Citizen.Wait(3)
		Citizen.Trace('p')
		DrawMarker(Config.MarkerType, Config.veh.x, Config.veh.y, Config.veh.z - 1.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 1.0, 1.2, 1.2, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 80, false, true, 2, false, false, false, false)
		DrawMarker(Config.MarkerType, Config.cloth.x, Config.cloth.y, Config.cloth.z - 1.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 1.0, 1.2, 1.2, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 80, false, true, 2, false, false, false, false)
			if (GetDistanceBetweenCoords(GetEntityCoords(ped), Config.veh.x, Config.veh.y, Config.veh.z, true) <  3) then
				if taked and IsPedInAnyVehicle(ped, true) then
				local p = GetVehiclePedIsIn(ped, false)
				if plate == GetVehicleNumberPlateText(p) then
					HelpText('Wciśnij ~INPUT_DETONATE~ aby oddać pojazd służbowy')
				if(IsControlPressed(0,58)) then
				DeleteVehicle(p)
				Citizen.Wait(1528)
				end
				end
			
				elseif not IsPedInAnyVehicle(ped, true) then
	
				HelpText('Wciśnij ~INPUT_DETONATE~ aby pobrać pojazd służbowy')
				if(IsControlPressed(0,58)) then
				taked = true
					local vehiclehash = GetHashKey(Config.car)
					RequestModel(vehiclehash)
						while not HasModelLoaded(vehiclehash) do
							Citizen.Wait(10)
						end
					
					local car = CreateVehicle(vehiclehash, Config.veh.x, Config.veh.y, Config.veh.z, 150.5, 1, 0)
					 SetPedIntoVehicle(ped, car, -1)
					 plate = GetVehicleNumberPlateText(car)
					 Citizen.Wait(4000)
					 
				end
				end
				elseif (GetDistanceBetweenCoords(GetEntityCoords(ped), Config.cloth.x, Config.cloth.y, Config.cloth.z, true) <  3) then
				HelpText('Wciśnij ~INPUT_DETONATE~ aby się przebrać')
				if(IsControlPressed(0,58)) then
				
				TriggerEvent('skinchanger:getSkin', function(skin)    
				clothesOn = false				
			if skin.sex == 0 then
			  if skin.tshirt_1 == Config.Uniforms.male.tshirt_1 and skin.torso_1 == Config.Uniforms.male.torso_1 then
					ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin2)
					TriggerEvent('skinchanger:loadSkin', skin2)
                end)
			else
			
			if Config.Uniforms.male ~= nil then
				TriggerEvent('skinchanger:loadClothes', skin, Config.Uniforms.male)
				clothesOn = true
			end
			end

			
		else
		  if skin.tshirt_1 == Config.Uniforms.famale.tshirt_1 and skin.torso_1 == Config.Uniforms.male.torso_1 then
					ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin2)
					TriggerEvent('skinchanger:loadSkin', skin2)
                end)
				else
			if Config.Uniforms[job].female ~= nil then
				TriggerEvent('skinchanger:loadClothes', skin, Config.Uniforms.female)
			end
			end

		end
	end)
				Citizen.Wait(2128)
				end
			
			end
		
		end
		end
end
RemoveBlip(workBlip)
clothesOn = false		
end)

Citizen.CreateThread(function()

Citizen.Trace('TMM_elektryk: Init')


	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end
 
	PlayerData = ESX.GetPlayerData()
	
	while ESX.GetPlayerData().job.name ~= 'electro' do
		Citizen.Wait(5120)
	end
		workBlip = AddBlipForCoord(Config.cloth.x, Config.cloth.y, Config.cloth.z)

				SetBlipSprite(workBlip, 354)
				SetBlipScale(workBlip, 1.3)
				SetBlipColour(workBlip, 28)

				PulseBlip(workBlip)
				BeginTextCommandSetBlipName("STRING")
				AddTextComponentString("Przebieralnia elektryków")
				EndTextCommandSetBlipName(workBlip)
	TriggerEvent('base')
	
	while ESX.GetPlayerData().job.name == 'electro' do
	Citizen.Wait(2800)
         

	if clothesOn == true then
				
                

	if  math.random(1, 100) < Config.chance then
	electro = math.random(1, #Config.electro)
	electro = 1
				blipRobbery3 = AddBlipForCoord(Config.electro[electro][0].x, Config.electro[electro][0].y, Config.electro[electro][0].z)

				SetBlipSprite(blipRobbery3, 354)
				SetBlipScale(blipRobbery3, 1.2)
				SetBlipColour(blipRobbery3, 71)

				PulseBlip(blipRobbery3)
				BeginTextCommandSetBlipName("STRING")
				AddTextComponentString("Awaria sieci elektrycznej")
				EndTextCommandSetBlipName(blipRobbery3)
				HelpText('Potrzebny elektryk!')
				SetNewWaypoint(Config.electro[electro][0].x, Config.electro[electro][0].y)
				busy = true
	end
	end
	
	
	
	local ped = GetPlayerPed(-1)
		
			--busy = true
			
			
		if busy then
		while busy do
			Citizen.Wait(2)
			local fpf = Config.fixPerFix
			local now = 1
			local clicked = false
			local once = false
			local color = 0
				while (GetDistanceBetweenCoords(GetEntityCoords(ped), Config.electro[electro][1].x, Config.electro[electro][1].y, Config.electro[electro][1].z, true) <  112) and busy do	
						
						Citizen.Wait(2)				
						DrawMarker(2, Config.electro[electro][0].x, Config.electro[electro][0].y, Config.electro[electro][0].z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 1.0, 1.2, 1.2, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 80, false, true, 2, false, false, false, false)
						DrawMarker(Config.MarkerType, Config.electro[electro][1].x, Config.electro[electro][1].y, Config.electro[electro][1].z - 1.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 1.0, 1.2, 1.2, Config.MarkerColorR.r, Config.MarkerColorR.g, Config.MarkerColorR.b, 80, false, true, 2, false, false, false, false)
						DrawMarker(Config.MarkerType, Config.electro[electro][2].x, Config.electro[electro][2].y, Config.electro[electro][2].z - 1.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 1.0, 1.2, 1.2, Config.MarkerColorG.r, Config.MarkerColorG.g, Config.MarkerColorG.b, 80, false, true, 2, false, false, false, false)
						DrawMarker(Config.MarkerType, Config.electro[electro][3].x, Config.electro[electro][3].y, Config.electro[electro][3].z - 1.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 1.0, 1.2, 1.2, Config.MarkerColorB.r, Config.MarkerColorB.g, Config.MarkerColorB.b, 80, false, true, 2, false, false, false, false)
						DrawMarker(Config.MarkerType, Config.electro[electro][4].x, Config.electro[electro][4].y, Config.electro[electro][4].z - 1.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 1.0, 1.2, 1.2, Config.MarkerColorY.r, Config.MarkerColorY.g, Config.MarkerColorY.b, 80, false, true, 2, false, false, false, false)
						DrawMarker(Config.MarkerType, Config.electro[electro][5].x, Config.electro[electro][5].y, Config.electro[electro][5].z - 1.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 1.0, 1.2, 1.2, Config.MarkerColorPu.r, Config.MarkerColorPu.g, Config.MarkerColorPu.b, 80, false, true, 2, false, false, false, false)
						DrawMarker(Config.MarkerType, Config.electro[electro][6].x, Config.electro[electro][6].y, Config.electro[electro][6].z - 1.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 1.0, 1.2, 1.2, Config.MarkerColorPi.r, Config.MarkerColorPi.g, Config.MarkerColorPi.b, 80, false, true, 2, false, false, false, false)
						
						
						if (GetDistanceBetweenCoords(GetEntityCoords(ped), Config.electro[electro][0].x, Config.electro[electro][0].y, Config.electro[electro][0].z, true) <  4) and busy then
							if not clicked then
							clicked = true
							color = math.random(1, #Config.electro)
							once = false
							end
							if color == 1 then
							HelpText("Napraw ~r~czerwoną ~s~ przetwornicę!")
							elseif color == 2 then
							HelpText("Napraw ~g~zieloną ~s~ przetwornicę!")
							elseif color == 3 then
							HelpText("Napraw ~b~niebieską ~s~ przetwornicę!")
							elseif color == 4 then
							HelpText("Napraw ~y~żółtą ~s~ przetwornicę!")
							elseif color == 5 then
							HelpText("Napraw ~p~fioletową ~s~ przetwornicę!")
							elseif color == 6 then
							HelpText("Napraw ~o~pomarańczową ~s~ przetwornicę!")
							end
						
						
						end
						
						for i = 1, 6 do
							if not once and (GetDistanceBetweenCoords(GetEntityCoords(ped), Config.electro[electro][i].x, Config.electro[electro][i].y, Config.electro[electro][i].z, true) <  2) then
								HelpText('Wciśnij ~INPUT_DETONATE~ aby naprawić popsutą przetwornicę')
									if(IsControlPressed(0,58)) then
										TaskStartScenarioInPlace(GetPlayerPed(-1), "WORLD_HUMAN_HAMMERING", 0, false)
										Citizen.Wait(Config.fixingTime * 1000)
										clicked = false
										once = true
										if i == color then
										ClearPedTasks(ped)
										fpf = fpf - 1
										if fpf == 0 then break end
										else
										Citizen.Wait(2000)									
										if Config.BOOM == true then
										AddExplosion(Config.electro[electro][i].x, Config.electro[electro][i].y, Config.electro[electro][i].z, 71, 2.8, true, true, 2.1)																				
										end
										Citizen.Wait(2000)
										HelpText('~r~Spaliłeś~s~ przetwornicę!')
										ClearPedTasks(ped)
										Citizen.Wait(4000)
										RemoveBlip(blipRobbery3)
										HelpText('Tą awarie naprawi już ktoś inny...')
										busy = false
										fpf = Config.fixPerFix
										Citizen.Wait(Config.Cooldown * 1000)
										end
										
									end
							end
						end
						
						if fpf == 0 then
						RemoveBlip(blipRobbery3)
							HelpText('Naprawiono sieć energetyczną!')
							Citizen.Wait(4000)
							HelpText('Zarobiłeś ~g~' .. Config.prize .. ' $')
							TriggerServerEvent('TMM_elektryk:cash', Config.prize)
							fpf = Config.fixPerFix
							Citizen.Wait(Config.Cooldown * 1000)
							busy = false
						end
						
				end
			end
			end
				
			
			
		
		
		
	end
		--	Citizen.Wait(5 * 60000)
			--	RemoveBlip(blipRobbery3)
end)
	function HelpText(text)
  SetTextComponentFormat("STRING")
  AddTextComponentString(text)
  DisplayHelpTextFromStringLabel(0, 0, 0, -1)
end