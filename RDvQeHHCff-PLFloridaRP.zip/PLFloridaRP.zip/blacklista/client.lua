--TA PACZKA JEST DARMOWA ZNAJDZIESZ JĄ NA MOIM KANALE--
--https://youtube.com/c/aries98--

--#################################################--

---WAZNE GOSTECZKU PRZECZYTAJ TO U GÓRY--
--TA PACZKA JEST DARMOWA ZNAJDZIESZ JĄ NA MOIM KANALE--
--https://youtube.com/c/aries98--

--#################################################--

---WAZNE GOSTECZKU PRZECZYTAJ TO U GÓRY--
--TA PACZKA JEST DARMOWA ZNAJDZIESZ JĄ NA MOIM KANALE--
--https://youtube.com/c/aries98--

--#################################################--

---WAZNE GOSTECZKU PRZECZYTAJ TO U GÓRY--
--TA PACZKA JEST DARMOWA ZNAJDZIESZ JĄ NA MOIM KANALE--
--https://youtube.com/c/aries98--

--#################################################--

---WAZNE GOSTECZKU PRZECZYTAJ TO U GÓRY--



Config = {

	VehicleBlacklistEnabled = true,
	VehicleBlacklist = {
		["APC"] = true,
		["BARRACKS"] = true,
		["BARRACKS2"] = true,
		["BARRACKS3"] = true,
		["CRUSADER"] = true,
		["HALFTRACK"] = true,
		["RHINO"] = true,
		["KHANJALI"] = true,
		["TRAILERSMALL2"] = true,
		["INSURGENT"] = true,
		["INSURGENT2"] = true,

		["VALKYRIE"] = true,
		["VALKYRIE2"] = true,
		["SWIFT"] = true,
		["SWIFT2"] = true,
		["SUPERVOLITO"] = true,
		["SUPERVOLITO2"] = true,
		["SKYLIFT"] = true,
		["SAVAGE"] = true,
		["MAVERICK"] = true,
		["FROGGER"] = true,
		["FROGGER2"] = true,
		["CARGOBOB"] = true,
		["CARGOBOB2"] = true,
		["CARGOBOB3"] = true,
		["CARGOBOB4"] = true,
		["BUZZARD"] = true,
		["BUZZARD2"] = true,
		["ANNIHILATOR"] = true,
		["cargoplane"] = true,

		["DUNE2"] = true,
		["DUMP"] = true,
		["CUTTER"] = true,

		["HYDRA"] = true,
		["CARGOPLANE"] = true,
		["LAZER"] = true
	},
}

ESX = nil
Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

if Config.VehicleBlacklistEnabled then
	Citizen.CreateThread(function()
		while true do
			Citizen.Wait(0)

			local playerPed = GetPlayerPed(-1)
			if Config.VehicleBlacklistEnabled then
				local vehicle = GetVehiclePedIsIn(playerPed, false)
				if vehicle and Config.VehicleBlacklist[GetDisplayNameFromVehicleModel(GetEntityModel(vehicle))] then
					ESX.Game.DeleteVehicle(vehicle)
				end

				local x, y, z = table.unpack(GetEntityCoords(playerPed, true))
				for model, _ in pairs(Config.VehicleBlacklist) do
					vehicle = GetClosestVehicle(x, y, z, 100.0, GetHashKey(model), 70)
					if vehicle then
						ESX.Game.DeleteVehicle(vehicle)
					end
				end
			end
		end
	end)
end