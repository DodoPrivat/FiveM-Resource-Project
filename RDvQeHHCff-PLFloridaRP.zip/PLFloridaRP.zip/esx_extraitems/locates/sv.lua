Locales ['sv'] = {
	['dive_suit_on']     = 'du satte på dig masken och säkrade bägarna. Oxygen: ~g~100~w~',
	['oxygen_notify']    = 'kvarstående ~b~oxygen~y~ i tanken: %s%s~w~',
	['redgull_consumed'] = 'du känner dig hypad och energifull. Du kan nu springa ~y~5~w~ minuter ~o~utan att bli trött~w~!',
	['redgull_end']      = 'du känner din att puls återgår till en normal nivå',
}
Locales ['sv'] = {
	['dive_suit_on']     = 'du satte på dig masken och säkrade bägarna. Oxygen: ~g~100~w~',
	['oxygen_notify']    = 'kvarstående ~b~oxygen~y~ i tanken: %s%s~w~',
	['redgull_consumed'] = 'du känner dig hypad och energifull. Du kan nu springa ~y~5~w~ minuter ~o~utan att bli trött~w~!',
	['redgull_end']      = 'du känner din att puls återgår till en normal nivå',
}
