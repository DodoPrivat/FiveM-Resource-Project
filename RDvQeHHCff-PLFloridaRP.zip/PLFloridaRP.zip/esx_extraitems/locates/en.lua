Locales ['en'] = {
	['dive_suit_on']     = 'Wkładasz maske do nurkowania i odpalasz zbiornik z tlenem. Poziom tlenu: ~g~100~w~',
	['oxygen_notify']    = 'pozostało ~b~tlenu~y~ w butli: %s%s~w~',
	['redgull_consumed'] = 'Poczułeś przypływ energi, możesz teraz biegać przez ~y~5~w~ minut ~o~bez przerwy~w~!',
	['redgull_end']      = 'Tętno powraca do normy, nie możesz już biegać bez przerwy',
}
Locales ['en'] = {
	['dive_suit_on']     = 'Wkładasz maske do nurkowania i odpalasz zbiornik z tlenem. Poziom tlenu: ~g~100~w~',
	['oxygen_notify']    = 'pozostało ~b~tlenu~y~ w butli: %s%s~w~',
	['redgull_consumed'] = 'Poczułeś przypływ energi, możesz teraz biegać przez ~y~5~w~ minut ~o~bez przerwy~w~!',
	['redgull_end']      = 'Tętno powraca do normy, nie możesz już biegać bez przerwy',
}
