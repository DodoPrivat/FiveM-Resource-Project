Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.CartelStations = {

  Cartel = {

    Blip = {
      Pos     = { x = 425.130, y = -979.558, z = 30.711 },
      Sprite  = 0,
      Display = 0,
      Scale   = 0,
      Colour  = 0,
    },

    AuthorizedWeapons = {
	  { name = 'WEAPON_POOLCUE',          price = 1000 },	  
    },

	  AuthorizedVehicles = {
		  { name = 'x5e53',  label = 'BMW X5E53' },
	  },

    Cloakrooms = {
      { x = 91212.283, y = 52128.914, z = 16129.635 },
    },

    Armories = {
      { x = -2602.55, y =  1895.33, z = 162.75 },   
    },

    Vehicles = {
      {
        Spawner    = { x = -2592.81, y = 1930.37, z = 166.3 },
        SpawnPoint = { x = -2585.03, y = 1931.31, z = 166.84 },
        Heading    = 272.44,
      }
    },
	
	Helicopters = {
      {
        Spawner    = { x = 20.312, y = 535.667, z = 173.627 },
        SpawnPoint = { x = 3.40, y = 525.56, z = 177.919 },
        Heading    = 0.0,
      }
    },

    VehicleDeleters = {
      { x = -2599.59, y = 1929.79, z = 166.79 },
      { x = -2601.59, y = 1931.79, z = 166.79 },
      
    },

    BossActions = {
      { x = -2602.59, y = 1913.36, z = 166.32 },  
    },

  },

}
