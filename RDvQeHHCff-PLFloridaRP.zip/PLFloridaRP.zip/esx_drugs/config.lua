Config              = {}
Config.MarkerType   = 27
Config.DrawDistance = 40.0
Config.ZoneSize     = {x = 5.0, y = 5.0, z = 3.0}
Config.MarkerColor  = {r = 100, g = 204, b = 100}
Config.ShowBlips   = false  --markers visible on the map? (false to hide the markers on the map)

Config.RequiredCopsCoke  = 2
Config.RequiredCopsMeth  = 2
Config.RequiredCopsWeed  = 2
Config.RequiredCopsOpium = 2

Config.TimeToFarm    = 3 * 1000
Config.TimeToProcess = 3 * 1000
Config.TimeToSell    = 0.1  * 1000

Config.Locale = 'pl'

Config.Zones = {
	CokeField =			{x = 701.77,	y = -692.23,	    z = 30.75,	name = _U('coke_field'),		sprite = 501,	color = 40}, --done
	CokeProcessing =	{x = 1101.77,	y = -3194.3,	z = -39.77,	name = _U('coke_processing'),	sprite = 478,	color = 40},
--	CokeDealer =		{x = -1756.19,	y = 427.31,		z = 126.68,	name = _U('coke_dealer'),		sprite = 500,	color = 75},
	MethField =			{x = -2157.59,	y = 228.39,	z = 184.17,	name = _U('meth_field'),		sprite = 499,	color = 26},
	MethProcessing =	{x = 1013.63,	y = -3195.64,	z = -39.77,	name = _U('meth_processing'),	sprite = 499,	color = 26},
--	MethDealer =		{x = -63.59,	y = -1224.07,	z = 27.76,	name = _U('meth_dealer'),		sprite = 500,	color = 75},
	WeedField =			{x = 1054.88,	y = -3201.05,	z = -39.56,	name = _U('weed_field'),		sprite = 496,	color = 52},
	WeedProcessing =	{x = 1041.68,	y = -3198.7,	z = -38.76,	name = _U('weed_processing'),	sprite = 496,	color = 52},
--	WeedDealer =		{x = -54.24,	y = -1443.36,	z = 31.06,	name = _U('weed_dealer'),		sprite = 500,	color = 75},
	OpiumField =		{x = 705.28,	y = 4184.11,	z = 39.71,	name = _U('opium_field'),		sprite = 51,	color = 60},
	OpiumProcessing =	{x = 259.22,	y = 2586.35,	z = 43.95,	name = _U('opium_processing'),	sprite = 51,	color = 60}, --done
--	OpiumDealer =		{x = 12331.08,	y = 2570.22,	z = 45.30,	name = _U('opium_dealer'),		sprite = 500,	color = 75}
}



