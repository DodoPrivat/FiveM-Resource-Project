Locales['br'] = {
	['press_collect_coke'] = 'Pressione ~INPUT_CONTEXT~ para coletar coca',
	['press_process_coke'] = 'Pressione ~INPUT_CONTEXT~ para processar a coca',
	['press_sell_coke'] = 'Pressione ~INPUT_CONTEXT~ para vender coca',
	['press_collect_meth'] = 'Pressione ~INPUT_CONTEXT~ para coletar metanfetamina',
	['press_process_meth'] = 'Pressione ~INPUT_CONTEXT~ para processar metanfetamina',
	['press_sell_meth'] = 'Pressione ~INPUT_CONTEXT~ para vender metanfetamina',
	['press_collect_weed'] = 'Pressione ~INPUT_CONTEXT~ para coletar erva',
	['press_process_weed'] = 'Pressione ~INPUT_CONTEXT~ para processar erva',
	['press_sell_opium'] = 'Pressione ~INPUT_CONTEXT~ para vender ópio',
	['press_collect_opium'] = 'Pressione ~INPUT_CONTEXT~ para coletar ópio',
	['press_process_opium'] = 'Pressione ~INPUT_CONTEXT~ para processar ópio',
	['press_sell_weed'] = 'Pressione ~INPUT_CONTEXT~ para vender erva',
	['act_imp_police'] = 'Ação ~r~impossivel~s~, ~b~polícia~s~: ~o~%s~s~/~y~%s~s~ online',
	['inv_full_coke'] = 'Você não pode mais coletar a Cocaína, seu estoque está ~r~cheio~s~',
	['pickup_in_prog'] = '~y~Colheita em progresso~s~...',
	['too_many_pouches'] = 'Você tem muitas trouxinhas',
	['not_enough_coke'] = 'Você não tem folha de coca suficiente para ~r~empacotar~s~',
	['packing_in_prog'] = '~y~Empacotamento em progresso~s~...',
	['no_pouches_sale'] = 'Você não tem mais trouxinhas para ~r~vender~s~',
	['sold_one_coke'] = 'Você vendeu ~g~x1 Trouxinha de Cocaína~s~',
	['sale_in_prog'] = '~g~Venda em progresso~s~...',
	['inv_full_meth'] = 'Você não pode mais coletar metanfetamina, seu inventário está ~r~cheio~s~',
	['not_enough_meth'] = 'Você não tem metanfetamina suficiente para ~r~embalar~s~',
	['sold_one_meth'] = 'Você vendeu ~g~x1 Trouxinha de Metanfetamina~s~',
	['inv_full_weed'] = 'Você não pode mais coletar erva, seu inventário está ~r~cheio~s~',
	['not_enough_weed'] = 'Você não tem erva suficiente para ~r~embalar~s~',
	['sold_one_weed'] = 'Você vendeu ~g~x1 Trouxinha de erva~s~',
	['used_one_weed'] = 'Você usou 1 trouxinha de ~b~erva',
	['inv_full_opium'] = 'Você não pode mais coletar ópio, seu inventário está ~r~cheio~s~',
	['not_enough_opium'] = 'Você não tem ópio suficiente para ~r~embalar~s~',
	['sold_one_opium'] = 'Você vendeu ~g~x1 Trouxinha de ópio~s~',
	['used_one_opium'] = 'Você usou 1 trouxinha de ~b~ópio',
	['exit_marker'] = 'press ~INPUT_CONTEXT~ to cancel the ~y~process~s~',
	-- Blips
	['coke_field'] = 'cocaine Field',
	['coke_processing'] = 'cocaine Processing',
	['coke_dealer'] = 'cocaine Dealer',
	['meth_field'] = 'meth Field',
	['meth_processing'] = 'meth Processing',
	['meth_dealer'] = 'meth Dealer',
	['weed_field'] = 'weed Field',
	['weed_processing'] = 'weed Processing',
	['weed_dealer'] = 'weed Dealer',
	['opium_field'] = 'opium Field',
	['opium_processing'] = 'opium Processing',
	['opium_dealer'] = 'opium Dealer',
}