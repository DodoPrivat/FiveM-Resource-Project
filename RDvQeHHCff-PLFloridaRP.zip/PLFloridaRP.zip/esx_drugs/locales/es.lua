Locales['es'] = {
	['press_collect_coke'] = 'Presiona ~INPUT_CONTEXT~ para cosechar la Coca',
	['press_process_coke'] = 'Presiona ~INPUT_CONTEXT~ para tratar la Coca',
	['press_sell_coke'] = 'Presiona ~INPUT_CONTEXT~ para vender la Coca',
	['press_collect_meth'] = 'Presiona ~INPUT_CONTEXT~ para recoger ingredientes del LSD',
	['press_process_meth'] = 'Presiona ~INPUT_CONTEXT~ para cocinar el LSD',
	['press_sell_meth'] = 'Presiona ~INPUT_CONTEXT~ para vender el LSD',
	['press_collect_weed'] = 'Presiona ~INPUT_CONTEXT~ para cosechar el Hierbón',
	['press_process_weed'] = 'Presiona ~INPUT_CONTEXT~ para embolsar el Hierbón',
	['press_sell_weed'] = 'Presiona ~INPUT_CONTEXT~ para vender el Hierbón',
	['press_collect_opium'] = "Presiona ~INPUT_CONTEXT~ para cosechar el Opio",
	['press_process_opium'] = "Presiona ~INPUT_CONTEXT~ para tratar el Opio",
	['press_sell_opium'] = "Presiona ~INPUT_CONTEXT~ para vender el Opio",
	['act_imp_police'] = 'Acción ~r~imposible~s~, ~b~policias~s~: ~o~%s~s~/~y~%s~s~ online',
	['inv_full_coke'] = 'No puedes recoger mas cocaina, tu inventario está ~r~lleno~s~',
	['pickup_in_prog'] = '~y~Recogida en curso~s~...',
	['too_many_pouches'] = 'Tienes demasiadas bolsas',
	['not_enough_coke'] = 'No tienes suficiente hoja de coca para ~r~fabricar~s~',
	['packing_in_prog'] = '~y~Fabricación en curso~s~...',
	['no_pouches_sale'] = 'No tienes mas bolsas para ~r~vender~s~',
	['sold_one_coke'] = 'Has vendido ~g~1 Gramo de Coca~s~',
	['sale_in_prog'] = '~g~Venta en curso~s~...',
	['inv_full_meth'] = 'No puedes recoger mas ingredientes, tu inventario está ~r~lleno~s~',
	['not_enough_meth'] = 'No tienes suficientes ingredientes para ~r~fabricar~s~ mas LSD',
	['sold_one_meth'] = 'Has vendido ~g~1 Bote de LSD~s~',
	['inv_full_weed'] = 'No puedes recoger mas hierba, tu inventario está ~r~lleno~s~',
	['not_enough_weed'] = 'No tienes suficiente hierba para ~r~embolsar~s~',
	['sold_one_weed'] = 'Has vendido ~g~1 Bolsa de Hierbón~s~',
	['used_one_weed'] = 'Has gastado una bolsa de ~b~hierbón',
	['inv_full_opium'] = 'No puedes recoger mas hierba, tu inventario está ~r~lleno~s~',
	['not_enough_opium'] = 'No tienes sufiente Opio para ~r~fabricar~s~',
	['sold_one_opium'] = 'Has vendido ~g~1 Bolsa de Opio~s~',
	['used_one_opium'] = 'Has gastado una bolsa de ~b~Opio',
	['exit_marker'] = 'press ~INPUT_CONTEXT~ to cancel the ~y~process~s~',
	-- Blips
	['coke_field'] = 'cocaine Field',
	['coke_processing'] = 'cocaine Processing',
	['coke_dealer'] = 'cocaine Dealer',
	['meth_field'] = 'meth Field',
	['meth_processing'] = 'meth Processing',
	['meth_dealer'] = 'meth Dealer',
	['weed_field'] = 'weed Field',
	['weed_processing'] = 'weed Processing',
	['weed_dealer'] = 'weed Dealer',
	['opium_field'] = 'opium Field',
	['opium_processing'] = 'opium Processing',
	['opium_dealer'] = 'opium Dealer',
}