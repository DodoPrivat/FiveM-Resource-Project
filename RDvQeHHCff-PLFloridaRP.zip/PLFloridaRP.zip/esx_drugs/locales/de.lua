Locales['de'] = {
	['press_collect_coke'] = 'drücke ~INPUT_CONTEXT~ um Koks zu sammeln',
	['press_process_coke'] = 'drücke ~INPUT_CONTEXT~ um Koks zu verarbeiten',
	['press_sell_coke'] = 'drücke ~INPUT_CONTEXT~ um Koks zu verkaufen',
	['press_collect_meth'] = 'drücke ~INPUT_CONTEXT~ um Meth zu sammeln',
	['press_process_meth'] = 'drücke ~INPUT_CONTEXT~ um Meth zu verarbeiten',
	['press_sell_meth'] = 'drücke ~INPUT_CONTEXT~ um Meth zu verkaufen',
	['press_collect_weed'] = 'drücke ~INPUT_CONTEXT~ um Grass zu sammeln',
	['press_process_weed'] = 'drücke ~INPUT_CONTEXT~ um Grass zu verarbeiten',
	['press_sell_weed'] = 'drücke ~INPUT_CONTEXT~ um Grass zu verkaufen',
	['press_collect_opium'] = 'drücke ~INPUT_CONTEXT~ um Opium zu sammeln',
	['press_process_opium'] = 'drücke ~INPUT_CONTEXT~ um Opium zu verarbeiten',
	['press_sell_opium'] = 'drücke ~INPUT_CONTEXT~ um Opium zu verkaufen',
	['act_imp_police'] = 'aktion ~r~nihct möglich~s~, ~b~Polizisten~s~: ~o~%s~s~/~y~%s~s~ online',
	['inv_full_coke'] = 'Du kannst nicht länger Koks sammeln, dein Inventar ist ~r~VOLL~s~',
	['pickup_in_prog'] = '~y~Sammeln im gange~s~...',
	['too_many_pouches'] = 'du hast zuviele Pakete',
	['not_enough_coke'] = 'du hast nicht genug Koks zum ~r~verpacken~s~',
	['packing_in_prog'] = '~y~Verarbeitung im gange~s~...',
	['no_pouches_sale'] = 'Du hast nicht genug Portionen zum ~r~verkaufen~s~',
	['sold_one_coke'] = 'du verkaufst ~g~x1 Portion Koks~s~',
	['sale_in_prog'] = '~g~Verkauf im gange~s~...',
	['inv_full_meth'] = 'Du kannst nicht länger Meth sammeln, dein Inventar ist ~r~VOLL~s~',
	['not_enough_meth'] = 'du hast nicht genug Meth zum ~r~verpacken~s~',
	['sold_one_meth'] = 'du verkaufst ~g~x1 Portion Meth~s~',
	['inv_full_weed'] = 'Du kannst nicht länger Grass sammeln, dein Inventar ist ~r~VOLL~s~',
	['not_enough_weed'] = 'du hast nicht genug Grass zum ~r~verarbeiten~s~',
	['sold_one_weed'] = 'du verkaufst ~g~x1 Portion Grass~s~',
	['used_one_weed'] = 'du benutzt 1x ~b~Grass',
	['inv_full_opium'] = 'Du kannst nicht länger Opium sammeln, dein Inventar ist ~r~VOLL~s~',
	['not_enough_opium'] = 'du hast nicht genug Opium zum ~r~verarbeiten~s~',
	['sold_one_opium'] = 'du verkaufst ~g~x1 Portion Opium~s~',
	['used_one_opium'] = 'du benutzt 1x ~b~Opium',
	['exit_marker'] = 'press ~INPUT_CONTEXT~ to cancel the ~y~process~s~',
	-- Blips
	['coke_field'] = 'cocaine Field',
	['coke_processing'] = 'cocaine Processing',
	['coke_dealer'] = 'cocaine Dealer',
	['meth_field'] = 'meth Field',
	['meth_processing'] = 'meth Processing',
	['meth_dealer'] = 'meth Dealer',
	['weed_field'] = 'weed Field',
	['weed_processing'] = 'weed Processing',
	['weed_dealer'] = 'weed Dealer',
	['opium_field'] = 'opium Field',
	['opium_processing'] = 'opium Processing',
	['opium_dealer'] = 'opium Dealer',
}