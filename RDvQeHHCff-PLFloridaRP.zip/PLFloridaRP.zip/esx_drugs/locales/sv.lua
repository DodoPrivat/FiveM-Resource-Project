Locales['sv'] = {
	['press_collect_coke'] = 'klicka ~INPUT_CONTEXT~ för att plocka kokain',
	['press_process_coke'] = 'klicka ~INPUT_CONTEXT~ för att bearbeta kokain',
	['press_sell_coke'] = 'klicka ~INPUT_CONTEXT~ för att sälja coke',
	['press_collect_meth'] = 'klicka ~INPUT_CONTEXT~ för att plocka meth',
	['press_process_meth'] = 'klicka ~INPUT_CONTEXT~ för att bearbeta meth',
	['press_sell_meth'] = 'klicka ~INPUT_CONTEXT~ för att sälja meth',
	['press_collect_weed'] = 'klicka ~INPUT_CONTEXT~ för att plocka cannabis',
	['press_process_weed'] = 'klicka ~INPUT_CONTEXT~ för att bearbeta cannabis',
	['press_sell_weed'] = 'klicka ~INPUT_CONTEXT~ för att sälja cannabis',
	['press_collect_opium'] = 'klicka ~INPUT_CONTEXT~ för att plocka opium',
	['press_process_opium'] = 'klicka ~INPUT_CONTEXT~ för att bearbeta opium',
	['press_sell_opium'] = 'klicka ~INPUT_CONTEXT~ för att sälja opium',
	['act_imp_police'] = 'Du kan inte delta i olagliga aktiviteter om det inte finns tillräckligt med poliser (~o~%s~s~/~y~%s~s~ online)',
	['inv_full_coke'] = 'Du kan inte längre plocka kokain, du har inte plats ~r~fullt~s~',
	['pickup_in_prog'] = '~y~Plockning pågår~s~...',
	['too_many_pouches'] = 'Du har för många väskor',
	['not_enough_coke'] = 'Du har inte tillräckligt med kokain för att ~r~bearbeta~s~',
	['packing_in_prog'] = '~y~Förpackning pågår~s~...',
	['no_pouches_sale'] = 'Du har inga mer väskor att ~r~sälja~s~',
	['sold_one_coke'] = 'du har sålt ~y~1x~s~ ~b~väska med kokain~s~',
	['sale_in_prog'] = '~g~Försäljning pågår~s~...',
	['inv_full_meth'] = 'Du kan inte längre plocka meth, du har inte plats ~r~fullt~s~',
	['not_enough_meth'] = 'Du har inte tillräckligt med meth för att ~r~bearbeta~s~',
	['sold_one_meth'] = 'du har sålt ~y~1x~s~ ~b~väska med meth~s~',
	['inv_full_weed'] = 'Du kan inte längre plocka cannabis, du har inte plats ~r~fullt~s~',
	['not_enough_weed'] = 'Du har inte tillräckligt med annabis för att ~r~bearbeta~s~',
	['sold_one_weed'] = 'du har sålt ~y~1x~s~ ~b~väska med cannabis~s~',
	['used_one_weed'] = 'Du använde 1 väska ~b~cannabis',
	['inv_full_opium'] = 'Du kan inte längre plocka opium, du har inte plats ~r~fullt~s~',
	['not_enough_opium'] = 'Du har inte tillräckligt med opium för att ~r~bearbeta~s~',
	['sold_one_opium'] = 'du har sålt ~y~1x~s~ ~b~väska med opium~s~',
	['used_one_opium'] = 'Du använde 1 väska ~b~opium',
	['exit_marker'] = 'tryck ~INPUT_CONTEXT~ för att avbryta pågående process',
	-- Blips
	['coke_field'] = 'coke field',
	['coke_processing'] = 'coke processing',
	['coke_dealer'] = 'coke dealer',
	['meth_field'] = 'meth field',
	['meth_processing'] = 'meth processing',
	['meth_dealer'] = 'meth dealer',
	['weed_field'] = 'weed field',
	['weed_processing'] = 'weed processing',
	['weed_dealer'] = 'weed dealer',
	['opium_field'] = 'opium field',
	['opium_processing'] = 'opium processing',
	['opium_dealer'] = 'opium dealer',
}
