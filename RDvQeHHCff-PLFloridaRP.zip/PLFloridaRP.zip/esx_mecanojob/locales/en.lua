Locales['en'] = {
  ['mechanic']                  = 'Mechanik',
  ['drive_to_indicated']        = '~y~Jedź~s~ do wskazanej lokalizacji.',
  ['mission_canceled']          = 'Misja ~r~anulowana~s~',
  ['vehicle_list']              = 'Lista Pojazdów',
  ['work_wear']                 = 'Ubrania Robocze',
  ['civ_wear']                  = 'Ubrania cywilne',
  ['deposit_stock']             = 'Depozyt',
  ['withdraw_stock']            = 'Wypłać depozyt',
  ['boss_actions']              = 'Akcje Szefa',
  ['service_vehicle']           = 'Pojazd serwisowy',
  ['flat_bed']                  = 'Laweta',
  ['tow_truck']                 = 'Holownik',
  ['service_full']              = 'Pełna usługa: ',
  ['open_actions']              = 'Naciśnij ~INPUT_CONTEXT~ aby wejść do menu.',
  ['harvest']                   = 'harvest',
  ['harvest_menu']              = 'Wciśnij ~INPUT_CONTEXT~ aby wejść do menu.',
  ['not_experienced_enough']    = 'Nie posiadasz ~r~wystarczającyh uprawnień~s~ do wykonania tej akcji.',
  ['gas_can']                   = 'butla z gazem',
  ['repair_tools']              = 'Narzędzia naprawcze',
  ['added']                     = 'Dodano do depozytu ',
  ['quantity_invalid']           = 'Nieprawidłowa ilość',    
  ['body_work_tools']           = 'Nadwozie',
  ['blowtorch']                 = 'palnik',
  ['repair_kit']                = 'Zestaw naprawczy',
  ['body_kit']                  = 'body Kit',
  ['craft']                     = 'craft',
  ['craft_menu']                = 'Wciśnij ~INPUT_CONTEXT~ aby wejść do menu crafting.',
  ['billing']                   = 'dane do faktury',
  ['hijack']                    = 'Otwórz pojazd wytrychem',
  ['repair']                    = 'napraw',
  ['clean']                     = 'umyj',
  ['imp_veh']                   = 'odholuj na parking policyjny',
  ['place_objects']             = 'Umieść Obiekt',
  ['invoice_amount']            = 'Kwota Faktury',
  ['amount_invalid']            = 'zła kwota',
  ['no_players_nearby']         = 'brak graczy w pobliżu',
  ['vehicle_unlocked']          = 'samochód ~g~Otwarty',
  ['vehicle_repaired']          = 'samochód ~g~Naprawiony',
  ['vehicle_cleaned']           = 'samochód ~g~Umyty',
  ['vehicle_impounded']         = 'samochód ~r~Odholowany',
  ['must_seat_driver']          = 'musisz siedzieć na ~r~miejscu kierowcy!',
  ['must_near']                 = 'musisz znajdować się ~r~blisko pojazdu~s~ aby go odholować.',
  ['vehicle_success_attached']  = 'samochód ~b~podczepiony~s~!.',
  ['please_drop_off']           = 'proszę zostawić samochód w salonie samochodowym',
  ['cant_attach_own_tt']        = '~r~Nie możesz~s~ podpiąć swojego holownika',
  ['no_veh_att']                = 'nie ma ~r~samochodu~s~ to podpięcia',
  ['not_right_veh']             = 'to nie jest właściwy pojazd',
  ['veh_det_succ']              = 'samochód ~b~odczepiony~s~!',
  ['imp_flatbed']               = '~r~Akcja niemożliwa!~s~ Wymagana ~b~laweta~s~',
  ['objects']                   = 'Obiekty',
  ['roadcone']                  = 'pachołki',
  ['toolbox']                   = 'skrzynka narzędziowa',
  ['mechanic_stock']            = 'narzędzia mechanika',
  ['quantity']                  = 'Ilość',
  ['invalid_quantity']          = 'Zła ilość',
  ['inventory']                 = 'inventory',
  ['veh_unlocked']              = '~g~Samochód odblokowany',
  ['hijack_failed']             = '~r~Odblokowanie nieudane',
  ['body_repaired']             = '~g~Body naprawione',
  ['veh_repaired']              = '~g~Samochód naprawiony',
  ['veh_stored']                = 'Wciśnij ~INPUT_CONTEXT~ aby usunąć samochód.',
  ['press_remove_obj']          = 'Wciśnij ~INPUT_CONTEXT~ aby usunąć obiekt',
  ['please_tow']                = 'Proszę ~y~odholować~s~ samochód',
  ['wait_five']                 = 'Musisz ~r~poczekać~s~ 5 minut',
  ['must_in_flatbed']           = 'Musisz siedzieć w lawecie żeby zacząc misje',
  ['mechanic_customer']         = 'Klient',
  ['you_do_not_room']           = '~r~Nie masz miejsca',
  ['recovery_gas_can']          = '~b~Palnik~s~ Naprawianie...',
  ['recovery_repair_tools']     = '~b~Narzędzia~s~ Naprawianie...',
  ['recovery_body_tools']       = '~b~Narzędzia blacharskie~ Naprawianie...',
  ['not_enough_gas_can']        = 'Nie posiadasz ~r~wystarczającej ilości~s~ puszek z gazem.',
  ['assembling_blowtorch']      = 'Montaż ~b~palnika do przedmuchu~s~...',
  ['not_enough_repair_tools']   = 'Nie posiadasz ~r~wystarczającej ilości~s~ narzędzi.',
  ['assembling_repair_kit']     = 'Montaż ~b~zestawu naprawczego~s~...',
  ['not_enough_body_tools']     = 'Nie posiadasz ~r~wystarczającej ilości~s~ narzędzi blacharskich.',
  ['assembling_body_kit']       = 'Montaż ~b~Przeróbek blacharskich~...',
  ['your_comp_earned']          = 'Twoja firma ~g~zarobiła~s~ ~g~$',
  ['you_used_blowtorch']        = 'Użyłeś ~b~palnika',
  ['you_used_repair_kit']       = 'Użyłeś ~b~zestawu naprawczego',
  ['you_used_body_kit']         = 'Użyłeś ~b~Zestawu Body',
  ['you_removed']               = 'Usunołeś x',
  ['you_added']                 = 'Dodałeś x',
}
Locales['en'] = {
  ['mechanic']                  = 'Mechanik',
  ['drive_to_indicated']        = '~y~Jedź~s~ do wskazanej lokalizacji.',
  ['mission_canceled']          = 'Misja ~r~anulowana~s~',
  ['vehicle_list']              = 'Lista Pojazdów',
  ['work_wear']                 = 'Ubrania Robocze',
  ['civ_wear']                  = 'Ubrania cywilne',
  ['deposit_stock']             = 'Depozyt',
  ['withdraw_stock']            = 'Wypłać depozyt',
  ['boss_actions']              = 'Akcje Szefa',
  ['service_vehicle']           = 'Pojazd serwisowy',
  ['flat_bed']                  = 'Laweta',
  ['tow_truck']                 = 'Holownik',
  ['service_full']              = 'Pełna usługa: ',
  ['open_actions']              = 'Naciśnij ~INPUT_CONTEXT~ aby wejść do menu.',
  ['harvest']                   = 'harvest',
  ['harvest_menu']              = 'Wciśnij ~INPUT_CONTEXT~ aby wejść do menu.',
  ['not_experienced_enough']    = 'Nie posiadasz ~r~wystarczającyh uprawnień~s~ do wykonania tej akcji.',
  ['gas_can']                   = 'butla z gazem',
  ['repair_tools']              = 'Narzędzia naprawcze',
  ['added']                     = 'Dodano do depozytu ',
  ['quantity_invalid']           = 'Nieprawidłowa ilość',    
  ['body_work_tools']           = 'Nadwozie',
  ['blowtorch']                 = 'palnik',
  ['repair_kit']                = 'Zestaw naprawczy',
  ['body_kit']                  = 'body Kit',
  ['craft']                     = 'craft',
  ['craft_menu']                = 'Wciśnij ~INPUT_CONTEXT~ aby wejść do menu crafting.',
  ['billing']                   = 'dane do faktury',
  ['hijack']                    = 'Otwórz pojazd wytrychem',
  ['repair']                    = 'napraw',
  ['clean']                     = 'umyj',
  ['imp_veh']                   = 'odholuj na parking policyjny',
  ['place_objects']             = 'Umieść Obiekt',
  ['invoice_amount']            = 'Kwota Faktury',
  ['amount_invalid']            = 'zła kwota',
  ['no_players_nearby']         = 'brak graczy w pobliżu',
  ['vehicle_unlocked']          = 'samochód ~g~Otwarty',
  ['vehicle_repaired']          = 'samochód ~g~Naprawiony',
  ['vehicle_cleaned']           = 'samochód ~g~Umyty',
  ['vehicle_impounded']         = 'samochód ~r~Odholowany',
  ['must_seat_driver']          = 'musisz siedzieć na ~r~miejscu kierowcy!',
  ['must_near']                 = 'musisz znajdować się ~r~blisko pojazdu~s~ aby go odholować.',
  ['vehicle_success_attached']  = 'samochód ~b~podczepiony~s~!.',
  ['please_drop_off']           = 'proszę zostawić samochód w salonie samochodowym',
  ['cant_attach_own_tt']        = '~r~Nie możesz~s~ podpiąć swojego holownika',
  ['no_veh_att']                = 'nie ma ~r~samochodu~s~ to podpięcia',
  ['not_right_veh']             = 'to nie jest właściwy pojazd',
  ['veh_det_succ']              = 'samochód ~b~odczepiony~s~!',
  ['imp_flatbed']               = '~r~Akcja niemożliwa!~s~ Wymagana ~b~laweta~s~',
  ['objects']                   = 'Obiekty',
  ['roadcone']                  = 'pachołki',
  ['toolbox']                   = 'skrzynka narzędziowa',
  ['mechanic_stock']            = 'narzędzia mechanika',
  ['quantity']                  = 'Ilość',
  ['invalid_quantity']          = 'Zła ilość',
  ['inventory']                 = 'inventory',
  ['veh_unlocked']              = '~g~Samochód odblokowany',
  ['hijack_failed']             = '~r~Odblokowanie nieudane',
  ['body_repaired']             = '~g~Body naprawione',
  ['veh_repaired']              = '~g~Samochód naprawiony',
  ['veh_stored']                = 'Wciśnij ~INPUT_CONTEXT~ aby usunąć samochód.',
  ['press_remove_obj']          = 'Wciśnij ~INPUT_CONTEXT~ aby usunąć obiekt',
  ['please_tow']                = 'Proszę ~y~odholować~s~ samochód',
  ['wait_five']                 = 'Musisz ~r~poczekać~s~ 5 minut',
  ['must_in_flatbed']           = 'Musisz siedzieć w lawecie żeby zacząc misje',
  ['mechanic_customer']         = 'Klient',
  ['you_do_not_room']           = '~r~Nie masz miejsca',
  ['recovery_gas_can']          = '~b~Palnik~s~ Naprawianie...',
  ['recovery_repair_tools']     = '~b~Narzędzia~s~ Naprawianie...',
  ['recovery_body_tools']       = '~b~Narzędzia blacharskie~ Naprawianie...',
  ['not_enough_gas_can']        = 'Nie posiadasz ~r~wystarczającej ilości~s~ puszek z gazem.',
  ['assembling_blowtorch']      = 'Montaż ~b~palnika do przedmuchu~s~...',
  ['not_enough_repair_tools']   = 'Nie posiadasz ~r~wystarczającej ilości~s~ narzędzi.',
  ['assembling_repair_kit']     = 'Montaż ~b~zestawu naprawczego~s~...',
  ['not_enough_body_tools']     = 'Nie posiadasz ~r~wystarczającej ilości~s~ narzędzi blacharskich.',
  ['assembling_body_kit']       = 'Montaż ~b~Przeróbek blacharskich~...',
  ['your_comp_earned']          = 'Twoja firma ~g~zarobiła~s~ ~g~$',
  ['you_used_blowtorch']        = 'Użyłeś ~b~palnika',
  ['you_used_repair_kit']       = 'Użyłeś ~b~zestawu naprawczego',
  ['you_used_body_kit']         = 'Użyłeś ~b~Zestawu Body',
  ['you_removed']               = 'Usunołeś x',
  ['you_added']                 = 'Dodałeś x',
}
