Locales['en'] = {
  ['valid_purchase'] = 'Potwierdzić te strzyżenie?',
  ['yes'] = 'Tak',
  ['no'] = 'Nie',
  ['not_enough_money'] = 'Nie masz wystarczająco pieniędzy',
  ['press_access'] = 'Naciśnij ~INPUT_CONTEXT~ aby zobaczyć ofertę fryzjera',
  ['barber_blip'] = 'Barber',
  ['you_paid'] = 'Zapłaciłeś za strzyżenie : $%s',
}
