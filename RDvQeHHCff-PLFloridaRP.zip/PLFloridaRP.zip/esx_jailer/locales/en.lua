Locales ['en'] = {
	['blip_name']          = 'Więzienie',
	['judge']              = 'SĘDZIA',
	['escape_attempt']     = 'Nie możesz uciec z więzienia!',
	['remaining_msg']      = 'Pozostało ~b~%s~s~ sekund do zwolnienia z więzienia',
	['jailed_msg']         = '^*%s ^2trafił do więzienia na ^7%s lat ^1| ^2Powód: ^7%s ^1| ^2Grzywna: ^7%s$',
	['unjailed']           = '%s wyszedł z więzienia!'
}
