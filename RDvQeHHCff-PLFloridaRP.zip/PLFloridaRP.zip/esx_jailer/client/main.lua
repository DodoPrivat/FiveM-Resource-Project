local IsJailed = false
local unjail = false
local JailTime = 0
local fastTimer = 0
local working = false
local jobNumber = nil
local isWorking = false
local jobDestination = nil
local CurrentAction = nil
local hasAlreadyEnteredMarker = false
local jobBlips = {}
local JailLocation = Config.JailLocation
local canwork = true
 
ESX = nil
Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
end)
 
function getJailStatus()
    return IsJailed
end
 
RegisterNetEvent('esx_jailer:jail')
AddEventHandler('esx_jailer:jail', function(jailTime)
    SetCanAttackFriendly(sourcePed, false, false)
    NetworkSetFriendlyFireOption(false)
    if IsJailed then -- don't allow multiple jails
        return
    end
 
    JailTime = jailTime
    local sourcePed = GetPlayerPed(-1)
    if DoesEntityExist(sourcePed) then
        Citizen.CreateThread(function()
       
            -- Assign jail skin to user
            TriggerEvent('skinchanger:getSkin', function(skin)
                if skin.sex == 0 then
                    TriggerEvent('skinchanger:loadClothes', skin, Config.Uniforms['prison_wear'].male)
                else
                    TriggerEvent('skinchanger:loadClothes', skin, Config.Uniforms['prison_wear'].female)
                end
            end)
           
            -- Clear player
            SetPedArmour(sourcePed, 0)
            ClearPedBloodDamage(sourcePed)
            ResetPedVisibleDamage(sourcePed)
            ClearPedLastWeaponDamage(sourcePed)
            ResetPedMovementClipset(sourcePed, 0)
 
            IsJailed = true
            unjail = false
 
            SetEntityCoords(sourcePed, JailLocation.x, JailLocation.y, JailLocation.z)
            while JailTime > 0 and not unjail do
                sourcePed = GetPlayerPed(-1)
                RemoveAllPedWeapons(sourcePed, true)
                if IsPedInAnyVehicle(sourcePed, false) then
                    ClearPedTasksImmediately(sourcePed)
                end
 
                if JailTime % 120 == 0 then
                    TriggerServerEvent('ESX_jailer:updateRemaining', JailTime)
                end
 
                Citizen.Wait(20000)
                -- Is the player trying to escape?
                if GetDistanceBetweenCoords(GetEntityCoords(sourcePed), JailLocation.x, JailLocation.y, JailLocation.z) > 150 then
                    SetEntityCoords(sourcePed, JailLocation.x, JailLocation.y, JailLocation.z)
                    TriggerEvent('chatMessage', _U('judge'), { 147, 196, 109 }, _U('escape_attempt'))
                end
               
                JailTime = JailTime - 20
            end
 
            -- jail time served
            TriggerServerEvent('esx_jailer:unjailTime', -1)
            SetEntityCoords(sourcePed, Config.JailBlip.x, Config.JailBlip.y, Config.JailBlip.z)
            IsJailed = false
 
            -- Change back the user skin
            ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
                TriggerEvent('skinchanger:loadSkin', skin)
            end)
        end)
    end
end)
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1)
 
        if JailTime > 0 and IsJailed then
            if fastTimer < 0 then
                fastTimer = JailTime
            end
 
            draw2dText(_U('remaining_msg', ESX.Math.Round(fastTimer)), { 0.175, 0.955 } )
            fastTimer = fastTimer - 0.01
        else
            Citizen.Wait(1000)
        end
    end
end)
 
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1)
        if IsJailed then
            if not working then
                CreateJob()
            else
                local isInMarker = false
                local coords = GetEntityCoords(PlayerPedId())
                if Config.Marker == true then
                    DrawMarker(Config.Jobs.Marker.Type, jobDestination.Pos.x, jobDestination.Pos.y, jobDestination.Pos.z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, Config.Jobs.Marker.Size.x, Config.Jobs.Marker.Size.y, Config.Jobs.Marker.Size.z, Config.Jobs.Marker.Color.r, Config.Jobs.Marker.Color.g, Config.Jobs.Marker.Color.b, 100, false, true, 2, false, false, false, false)
                else   
                    if GetDistanceBetweenCoords(coords, jobDestination.Pos.x, jobDestination.Pos.y, jobDestination.Pos.z, true) < 40 then
                        ESX.Game.Utils.DrawText3D({ ["x"] = jobDestination.Pos.x, ["y"] = jobDestination.Pos.y, ["z"] = (jobDestination.Pos.z + 1), ["h"] = 137.83 }, "[E] Aby ~g~pracować", 1.0)
                    end
                end    
                    if GetDistanceBetweenCoords(coords, jobDestination.Pos.x, jobDestination.Pos.y, jobDestination.Pos.z, true) < 2 then
                        ESX.ShowHelpNotification('Wcisnij ~INPUT_CONTEXT~ aby pracować')
                        if IsControlJustReleased(0, 38) and canwork == true then
                            StartWork()
                        end
                    end
            end        
        end
    end
end)
 
function CreateJob()
    local newJob
    repeat
        newJob = math.random(1, #Config.Jobs.List)
        Citizen.Wait(1)
    until newJob ~= jobNumber
 
    working = true
    jobNumber = newJob
    jobDestination = Config.Jobs.List[jobNumber]
    CreateBlip(jobDestination)
end
 
function CreateBlip(cords)
    if jobBlips['job'] ~= nil then
        RemoveBlip(jobBlips['job'])
    end
 
    jobBlips['job'] = AddBlipForCoord(cords.Pos.x, cords.Pos.y, cords.Pos.z)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString('Praca więzienna ' .. cords.Name)
    EndTextCommandSetBlipName(jobBlips['job'])
end
 
function StartWork()
    canwork = false
    isWorking = true
    local delay = math.random(5000, 10000)
    if Config.Notify == true then
        TriggerEvent("pNotify:SetQueueMax", "work", 2)
        TriggerEvent("pNotify:SendNotification", {
            text = "Zaczynasz pracować",
            type = "error",
            queue = "work",
            timeout = 5000,
            layout = "CenterLeft"
        })
    else
        ESX.ShowAdvancedNotification('Więzienie', 'Praca', 'Zacząłeś pracować', 'CHAR_BLOCKED', 8)
    end
    FreezeEntityPosition(PlayerPedId(), true)
 
    Citizen.CreateThread(function()
        Citizen.Wait(delay)
        isWorking = false
 
        local minusTime = math.random(15,30)
        JailTime = JailTime - minusTime
        TriggerServerEvent('esx_jailer:updateRemaining', JailTime)
        fastTimer = fastTimer - minusTime
        if Config.Notify == true then
            TriggerEvent("pNotify:SetQueueMax", "work", 2)
            TriggerEvent("pNotify:SendNotification", {
                text = "Od twojej odsiadki odjęto " .. minusTime ..  " dni!",
                type = "error",
                queue = "work",
                timeout = 5000,
                layout = "CenterLeft"
            })
        else
            ESX.ShowAdvancedNotification('Więzienie', 'Praca', 'Od twojej odsiadki odjęto ~g~' .. minusTime .. ' ~w~dni!', 'CHAR_BLOCKED', 8)
        end
        CreateJob()
        FreezeEntityPosition(PlayerPedId(), false)
        canwork = true
    end)
end
RegisterNetEvent('esx_jailer:unjail')
AddEventHandler('esx_jailer:unjail', function(source)
    unjail = true
    working = false
    SetCanAttackFriendly(sourcePed, true, false)
    NetworkSetFriendlyFireOption(true)
    RemoveBlip(jobBlips['job'])
end)
 
-- When player respawns / joins
AddEventHandler('playerSpawned', function(spawn)
    if IsJailed then
        ESX.Game.Teleport(PlayerPedId(), JailLocation)
    else
        TriggerServerEvent('esx_jail:checkJail')
    end
end)
 
-- When script starts
Citizen.CreateThread(function()
    Citizen.Wait(2000) -- wait for mysql-async to be ready, this should be enough time
    TriggerServerEvent('esx_jail:checkJail')
end)
 
-- Create Blips
Citizen.CreateThread(function()
    local blip = AddBlipForCoord(Config.JailBlip.x, Config.JailBlip.y, Config.JailBlip.z)
    SetBlipSprite (blip, 188)
    SetBlipDisplay(blip, 4)
    SetBlipScale  (blip, 1.9)
    SetBlipColour (blip, 4)
    SetBlipAsShortRange(blip, true)
 
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(_U('blip_name'))
    EndTextCommandSetBlipName(blip)
end)
 
function draw2dText(text, pos)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextScale(0.45, 0.45)
    SetTextColour(255, 255, 255, 255)
    SetTextDropShadow(0, 0, 0, 0, 255)
    SetTextEdge(1, 0, 0, 0, 255)
    SetTextDropShadow()
    SetTextOutline()
 
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(table.unpack(pos))
end
 
function round(x)
    return x >= 0 and math.floor(x + 0.5) or math.ceil(x - 0.5)
end