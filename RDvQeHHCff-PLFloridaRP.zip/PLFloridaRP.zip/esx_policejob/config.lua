Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = true -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = true -- only turn this on if you are using esx_license
Config.MaxInService               = -1
Config.Locale = 'en'

Config.PoliceStations = {

	LSPD = {

		Blip = {
			Pos     = { x = 425.130, y = -979.558, z = 30.711 },
			Sprite  = 60,
			Display = 4,
			Scale   = 1.2,
			Colour  = 30,
		},
		-- https://wiki.fivem.net/wiki/Weapons
		AuthorizedWeapons = {
        { name = 'GADGET_PARACHUTE',        	price = 1000 },
	    { name = 'WEAPON_STUNGUN',          	price = 500 },
	    { name = 'WEAPON_FLASHLIGHT',       	price = 100 },
        { name = 'WEAPON_FLAREGUN',         	price = 1000 },
	    { name = 'WEAPON_NIGHTSTICK',       	price = 300 },
        { name = 'WEAPON_HEAVYPISTOL',      	price = 2000 },
        { name = 'WEAPON_PISTOL',               price = 1500 },
        { name = 'WEAPON_COMBATPISTOL',         price = 3500 },
        { name = 'WEAPON_PUMPSHOTGUN',          price = 6000 },
		{ name = 'WEAPON_CARBINERIFLE',          price = 5000 },
		{ name = 'WEAPON_ASSAULTRIFLE',          price = 5000 },
		{ name = 'WEAPON_MICROSMG',          price = 4000 },
        { name = 'WEAPON_SMG',                  price = 5000 },
		},

		Vehicles = {
		    {
			   Spawner    = { x = -459.86, y = 6015.47, z = 30.55 }, --paleto
			   SpawnPoint = { x = -471.77, y = 6034.73, z = 31.34 }
				
		    },
			
			{
			   Spawner    = { x = 455.35, y = -1015.59, z = 27.41 }, --ls
			   SpawnPoint = { x = 440.13, y = -1017.11, z = 28.72 }
				
		    },

		    {
		       Spawner    = { x = 1868.53, y = 3684.01, z = 32.75 }, --sandy
		       SpawnPoint = { x = 1870.72, y = 3690.62, z = 33.65 }	
		    }
		},
		
		Cloakrooms = {
			{ x = 450.88, y = -992.5, z = 29.70 }, --ls
			{ x = 2454.84, y = -838.85, z = -38.21 }, --paleto
			{ x = 1826.38, y = 3671.04, z = -119.75 },  --sandy
		},
		
		Armories = {
			{ x = 460.86, y = -981.88, z = 29.70 }, --ls
			{ x = 2456.26, y = -836.59, z = -38.22 }, --paleto
			{ x = 1829.3, y = 3675.44, z = -119.75 }, --sandy
		},

		
		
		Helicopters = {
			{
				Spawner    = { x = 449.31, y = -981.57, z = 42.691 }, --LS
				SpawnPoint = { x = 449.31, y = -981.57, z = 42.691}, --LS
				Heading    = 0.0, -- LS
			},
			
            {
				Spawner    = { x = -466.46, y = 5980.98, z = 33.21 }, --paleto
				SpawnPoint = { x = -466.46, y = 5980.98, z = 33.21 }, --paleto
                Heading    = 0.0, --paleto
			}

		},

		VehicleDeleters = {
			{ x = -478.65, y = 6027.36, z = 30.46 }, --paleto
			{ x = -482.03, y = 6023.89, z = 30.46 }, --paleto
			{ x = -475.39, y = 6030.81, z = 30.46 }, --paleto
			{ x = 1872.71, y = 3698.27, z = 32.45 }, --sandy
			{ x = 462.41, y = -1019.57, z = 27.18 }, --ls
		},
		
		BossActions = {
			{ x = 2443.49, y = -839.82, z = -38.17 }, -- paleto
            { x = 1842.88, y = 3675.4, z = -119.75 }, --sandy       
            { x = 450.22, y = -974.12, z = 29.74 }, --ls  								
		},

	},

}

-- https://wiki.fivem.net/wiki/Vehicles
Config.AuthorizedVehicles = {
	Shared = {
        {
            model = 'bcalamo',
            label = 'Policyjny interceptor2'
        }, 
        {
            model = 'chargerno',
            label = 'Nieoznakowany charger'
        },
        {
            model = 'fbi',
            label = 'Nieoznakowany mercedes'
        },
        {
            model = 'polgs350',
            label = 'Policyjny Lexus'
        },
        {
            model = 'mustangp',
            label = 'Nieoznakowany mustang'
        },
        {
            model = 'nboxville',
            label = 'Więźniarka'
        }, 
        {
            model = 'pol718',
            label = 'Porsche'
        },
        {
            model = 'polchiron',
            label = 'Policyjny Chiron'
        },
        {
            model = 'police',
            label = 'Chevrolet Impala'
        },
        {
            model = 'police4',
            label = 'Ford Taurus'
        }, 
        {
            model = 'police5',
            label = 'Ford Interceptor'
        },
        {
            model = 'police6',
            label = 'Tahoe K-9'
        },
        {
            model = 'police7',
            label = 'Ford Victoria'
        },
        {
            model = 'police8',
            label = 'FPIU Ford Explorer 2013'
        },
        {
            model = 'police9',
            label = 'Dodge Charger'
        },
        {
            model = 'policeb2',
            label = 'Motocykl policyjny'
        },
        {
            model = 'polmp4',
            label = 'McLaren'
        },
        {
            model = 'sandkingpol',
            label = 'Sandking-Sheriff'
        },
        {
            model = 'scoutpol',
            label = 'Policyjny Cruiser'
        },
        {
            model = 'fbi2',
            label = 'Długi FBI'
        },
        {
            model = 'policet',
            label = 'Wóz transportujący'
        },
        {
            model = 'tahoeno',
            label = 'Nieoznakowany tahoe'
        },
    },

	recruit = {
    },

	officer = {
    },


	sergeant = {
    },

	lieutenant = {
    },
	
	captain = {
    },
	
	deputy = {
    },

	boss = {
    }
}
-- CHECK SKINCHANGER CLIENT MAIN.LUA for matching elements

Config.Uniforms = {
	cadet_wear = {
		male = {
			['tshirt_1'] = 59,  ['tshirt_2'] = 1,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 52,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0,
			['bproof_1'] = 0,  ['bproof_2'] = 0,
            ['glasses_1'] = 0, ['glasses_2'] = 0
		},
		female = {
			['tshirt_1'] = 36,  ['tshirt_2'] = 1,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = 45,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	officer_wear = {
		male = {
			['tshirt_1'] = 58,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 52,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0,
			['bproof_1'] = 0,  ['bproof_2'] = 0,
            ['glasses_1'] = 0, ['glasses_2'] = 0
		},
		female = {
			['tshirt_1'] = 36,  ['tshirt_2'] = 1,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = 45,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	police_wear = {
		male = {
			['tshirt_1'] = 58,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 41,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 44,
			['pants_1'] = 30,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	sergeant_wear = {
		male = {
			['tshirt_1'] = 129,  ['tshirt_2'] = 0,
			['torso_1'] = 50,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 59,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 128,    ['chain_2'] = 0,
			['bproof_1'] = 0,  ['bproof_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 1,
			['arms'] = 44,
			['pants_1'] = 30,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	lieutenant_wear = {
		male = {
			['tshirt_1'] = 58,  ['tshirt_2'] = 0,
			['torso_1'] = 93,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 41,
			['pants_1'] = 59,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 58,  ['helmet_2'] = 2,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['bproof_1'] = 12,  ['bproof_2'] = 3,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 44,
			['pants_1'] = 30,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	swat_wear = {
		male = {
			['tshirt_1'] = 15,  ['tshirt_2'] = 0,
			['torso_1'] = 49,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 17,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 115,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0,
			['bproof_1'] = 16,  ['bproof_2'] = 2,
			['mask_1'] = 35,    ['mask_2'] = 0
		},
		female = {
			['tshirt_1'] = 156,  ['tshirt_2'] = 0,
			['torso_1'] = 46,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 18,
			['pants_1'] = 25,   ['pants_2'] = 0,
			['shoes_1'] = 33,   ['shoes_2'] = 1,
			['helmet_1'] = 117,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	commandant_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 111,   ['torso_2'] = 0,
			['decals_1'] = 8,   ['decals_2'] = 3,
			['arms'] = 17,
			['pants_1'] = 46,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 58,  ['helmet_2'] = 2,
			['chain_1'] = 125,    ['chain_2'] = 0,
			['bproof_1'] = 0,  ['bproof_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	fbi_wear = {
		male = {
			['tshirt_1'] = 92,  ['tshirt_2'] = 21,
			['torso_1'] = 39,   ['torso_2'] = 1,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 42,
			['pants_1'] = 46,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 58,  ['helmet_2'] = 2,
			['chain_1'] = 0,    ['chain_2'] = 0,
            ['ears_1'] = 0,     ['ears_2'] = 0,
            ['glasses_1'] = 0, ['glasses_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 6,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 20,
			['pants_1'] = 28,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = 58,  ['helmet_2'] = 2,
			['chain_1'] = 128,    ['chain_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		}
	},
	swat_wear = {
		male = {
			['tshirt_1'] = 15,  ['tshirt_2'] = 0,
			['torso_1'] = 49,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 17,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 117,  ['helmet_2'] = 0,
			['chain_1'] = 125,    ['chain_2'] = 0,
            ['ears_1'] = 2,     ['ears_2'] = 0,
            ['mask_1'] = 52,    ['mask_2'] = 0,
            ['glasses_1'] = 25, ['glasses_2'] = 4
		},
		female = {
			['tshirt_1'] = 124,  ['tshirt_2'] = 0,
			['torso_1'] = 53,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 38,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 125,  ['helmet_2'] = 0,
			['chain_1'] = 128,    ['chain_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		}
	},
	szef_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 111,   ['torso_2'] = 1,
			['decals_1'] = 0,   ['decals_2'] = 3,
			['arms'] = 22,
			['pants_1'] = 28,   ['pants_2'] = 0,
			['shoes_1'] = 21,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 125,    ['chain_2'] = 0,
			['bproof_1'] = 0,  ['bproof_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 73,  ['tshirt_2'] = 0,
			['torso_1'] = 11,   ['torso_2'] = 1,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 42,
			['pants_1'] = 52,   ['pants_2'] = 2,
			['shoes_1'] = 40,   ['shoes_2'] = 9,
			['helmet_1'] = 0,  ['helmet_2'] = 0,
			['chain_1'] = 125,    ['chain_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		}
	},
	bcso_wear = {
		male = {
			['tshirt_1'] = 64,  ['tshirt_2'] = 0,
			['torso_1'] = 101,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,
			['pants_1'] = 52,   ['pants_2'] = 3,
			['shoes_1'] = 26,   ['shoes_2'] = 0,
			['helmet_1'] = 58,  ['helmet_2'] = 2,
			['chain_1'] = 125,    ['chain_2'] = 0,
			['bproof_1'] = 12,  ['bproof_2'] = 1,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 73,  ['tshirt_2'] = 0,
			['torso_1'] = 11,   ['torso_2'] = 1,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 42,
			['pants_1'] = 52,   ['pants_2'] = 2,
			['shoes_1'] = 40,   ['shoes_2'] = 9,
			['helmet_1'] = 0,  ['helmet_2'] = 0,
			['chain_1'] = 125,    ['chain_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		}
	},
	bullet_wear = {
		male = {
			['bproof_1'] = 16,  ['bproof_2'] = 2
		},
		female = {
			['bproof_1'] = 16,  ['bproof_2'] = 2
		}
	},
	gilet_wear = {
		male = {
			['tshirt_1'] = 59,  ['tshirt_2'] = 1
		},
		female = {
			['tshirt_1'] = 36,  ['tshirt_2'] = 1
		}
	}

}
Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = true -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = true -- only turn this on if you are using esx_license
Config.MaxInService               = -1
Config.Locale = 'en'

Config.PoliceStations = {

	LSPD = {

		Blip = {
			Pos     = { x = 425.130, y = -979.558, z = 30.711 },
			Sprite  = 60,
			Display = 4,
			Scale   = 1.2,
			Colour  = 30,
		},
		-- https://wiki.fivem.net/wiki/Weapons
		AuthorizedWeapons = {
        { name = 'GADGET_PARACHUTE',        	price = 1000 },
	    { name = 'WEAPON_STUNGUN',          	price = 500 },
	    { name = 'WEAPON_FLASHLIGHT',       	price = 100 },
        { name = 'WEAPON_FLAREGUN',         	price = 1000 },
	    { name = 'WEAPON_NIGHTSTICK',       	price = 300 },
        { name = 'WEAPON_HEAVYPISTOL',      	price = 2000 },
        { name = 'WEAPON_PISTOL',               price = 1500 },
        { name = 'WEAPON_COMBATPISTOL',         price = 3500 },
        { name = 'WEAPON_PUMPSHOTGUN',          price = 6000 },
		{ name = 'WEAPON_CARBINERIFLE',          price = 5000 },
		{ name = 'WEAPON_ASSAULTRIFLE',          price = 5000 },
		{ name = 'WEAPON_MICROSMG',          price = 4000 },
        { name = 'WEAPON_SMG',                  price = 5000 },
		},

		Vehicles = {
		    {
			   Spawner    = { x = -459.86, y = 6015.47, z = 30.55 }, --paleto
			   SpawnPoint = { x = -471.77, y = 6034.73, z = 31.34 }
				
		    },
			
			{
			   Spawner    = { x = 455.35, y = -1015.59, z = 27.41 }, --ls
			   SpawnPoint = { x = 440.13, y = -1017.11, z = 28.72 }
				
		    },

		    {
		       Spawner    = { x = 1868.53, y = 3684.01, z = 32.75 }, --sandy
		       SpawnPoint = { x = 1870.72, y = 3690.62, z = 33.65 }	
		    }
		},
		
		Cloakrooms = {
			{ x = 450.88, y = -992.5, z = 29.70 }, --ls
			{ x = 2454.84, y = -838.85, z = -38.21 }, --paleto
			{ x = 1826.38, y = 3671.04, z = -119.75 },  --sandy
		},
		
		Armories = {
			{ x = 460.86, y = -981.88, z = 29.70 }, --ls
			{ x = 2456.26, y = -836.59, z = -38.22 }, --paleto
			{ x = 1829.3, y = 3675.44, z = -119.75 }, --sandy
		},

		
		
		Helicopters = {
			{
				Spawner    = { x = 449.31, y = -981.57, z = 42.691 }, --LS
				SpawnPoint = { x = 449.31, y = -981.57, z = 42.691}, --LS
				Heading    = 0.0, -- LS
			},
			
            {
				Spawner    = { x = -466.46, y = 5980.98, z = 33.21 }, --paleto
				SpawnPoint = { x = -466.46, y = 5980.98, z = 33.21 }, --paleto
                Heading    = 0.0, --paleto
			}

		},

		VehicleDeleters = {
			{ x = -478.65, y = 6027.36, z = 30.46 }, --paleto
			{ x = -482.03, y = 6023.89, z = 30.46 }, --paleto
			{ x = -475.39, y = 6030.81, z = 30.46 }, --paleto
			{ x = 1872.71, y = 3698.27, z = 32.45 }, --sandy
			{ x = 462.41, y = -1019.57, z = 27.18 }, --ls
		},
		
		BossActions = {
			{ x = 2443.49, y = -839.82, z = -38.17 }, -- paleto
            { x = 1842.88, y = 3675.4, z = -119.75 }, --sandy       
            { x = 450.22, y = -974.12, z = 29.74 }, --ls  								
		},

	},

}

-- https://wiki.fivem.net/wiki/Vehicles
Config.AuthorizedVehicles = {
	Shared = {
        {
            model = 'bcalamo',
            label = 'Policyjny interceptor2'
        }, 
        {
            model = 'chargerno',
            label = 'Nieoznakowany charger'
        },
        {
            model = 'fbi',
            label = 'Nieoznakowany mercedes'
        },
        {
            model = 'polgs350',
            label = 'Policyjny Lexus'
        },
        {
            model = 'mustangp',
            label = 'Nieoznakowany mustang'
        },
        {
            model = 'nboxville',
            label = 'Więźniarka'
        }, 
        {
            model = 'pol718',
            label = 'Porsche'
        },
        {
            model = 'polchiron',
            label = 'Policyjny Chiron'
        },
        {
            model = 'police',
            label = 'Chevrolet Impala'
        },
        {
            model = 'police4',
            label = 'Ford Taurus'
        }, 
        {
            model = 'police5',
            label = 'Ford Interceptor'
        },
        {
            model = 'police6',
            label = 'Tahoe K-9'
        },
        {
            model = 'police7',
            label = 'Ford Victoria'
        },
        {
            model = 'police8',
            label = 'FPIU Ford Explorer 2013'
        },
        {
            model = 'police9',
            label = 'Dodge Charger'
        },
        {
            model = 'policeb2',
            label = 'Motocykl policyjny'
        },
        {
            model = 'polmp4',
            label = 'McLaren'
        },
        {
            model = 'sandkingpol',
            label = 'Sandking-Sheriff'
        },
        {
            model = 'scoutpol',
            label = 'Policyjny Cruiser'
        },
        {
            model = 'fbi2',
            label = 'Długi FBI'
        },
        {
            model = 'policet',
            label = 'Wóz transportujący'
        },
        {
            model = 'tahoeno',
            label = 'Nieoznakowany tahoe'
        },
    },

	recruit = {
    },

	officer = {
    },


	sergeant = {
    },

	lieutenant = {
    },
	
	captain = {
    },
	
	deputy = {
    },

	boss = {
    }
}
-- CHECK SKINCHANGER CLIENT MAIN.LUA for matching elements

Config.Uniforms = {
	cadet_wear = {
		male = {
			['tshirt_1'] = 59,  ['tshirt_2'] = 1,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 52,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0,
			['bproof_1'] = 0,  ['bproof_2'] = 0,
            ['glasses_1'] = 0, ['glasses_2'] = 0
		},
		female = {
			['tshirt_1'] = 36,  ['tshirt_2'] = 1,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = 45,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	officer_wear = {
		male = {
			['tshirt_1'] = 58,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 52,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0,
			['bproof_1'] = 0,  ['bproof_2'] = 0,
            ['glasses_1'] = 0, ['glasses_2'] = 0
		},
		female = {
			['tshirt_1'] = 36,  ['tshirt_2'] = 1,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = 45,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	police_wear = {
		male = {
			['tshirt_1'] = 58,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 41,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 44,
			['pants_1'] = 30,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	sergeant_wear = {
		male = {
			['tshirt_1'] = 129,  ['tshirt_2'] = 0,
			['torso_1'] = 50,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 59,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 128,    ['chain_2'] = 0,
			['bproof_1'] = 0,  ['bproof_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 1,
			['arms'] = 44,
			['pants_1'] = 30,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	lieutenant_wear = {
		male = {
			['tshirt_1'] = 58,  ['tshirt_2'] = 0,
			['torso_1'] = 93,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 41,
			['pants_1'] = 59,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 58,  ['helmet_2'] = 2,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['bproof_1'] = 12,  ['bproof_2'] = 3,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 44,
			['pants_1'] = 30,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	swat_wear = {
		male = {
			['tshirt_1'] = 15,  ['tshirt_2'] = 0,
			['torso_1'] = 49,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 17,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 115,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0,
			['bproof_1'] = 16,  ['bproof_2'] = 2,
			['mask_1'] = 35,    ['mask_2'] = 0
		},
		female = {
			['tshirt_1'] = 156,  ['tshirt_2'] = 0,
			['torso_1'] = 46,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 18,
			['pants_1'] = 25,   ['pants_2'] = 0,
			['shoes_1'] = 33,   ['shoes_2'] = 1,
			['helmet_1'] = 117,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	commandant_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 111,   ['torso_2'] = 0,
			['decals_1'] = 8,   ['decals_2'] = 3,
			['arms'] = 17,
			['pants_1'] = 46,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 58,  ['helmet_2'] = 2,
			['chain_1'] = 125,    ['chain_2'] = 0,
			['bproof_1'] = 0,  ['bproof_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	fbi_wear = {
		male = {
			['tshirt_1'] = 92,  ['tshirt_2'] = 21,
			['torso_1'] = 39,   ['torso_2'] = 1,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 42,
			['pants_1'] = 46,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 58,  ['helmet_2'] = 2,
			['chain_1'] = 0,    ['chain_2'] = 0,
            ['ears_1'] = 0,     ['ears_2'] = 0,
            ['glasses_1'] = 0, ['glasses_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 6,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 20,
			['pants_1'] = 28,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = 58,  ['helmet_2'] = 2,
			['chain_1'] = 128,    ['chain_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		}
	},
	swat_wear = {
		male = {
			['tshirt_1'] = 15,  ['tshirt_2'] = 0,
			['torso_1'] = 49,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 17,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 117,  ['helmet_2'] = 0,
			['chain_1'] = 125,    ['chain_2'] = 0,
            ['ears_1'] = 2,     ['ears_2'] = 0,
            ['mask_1'] = 52,    ['mask_2'] = 0,
            ['glasses_1'] = 25, ['glasses_2'] = 4
		},
		female = {
			['tshirt_1'] = 124,  ['tshirt_2'] = 0,
			['torso_1'] = 53,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 38,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 125,  ['helmet_2'] = 0,
			['chain_1'] = 128,    ['chain_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		}
	},
	szef_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 111,   ['torso_2'] = 1,
			['decals_1'] = 0,   ['decals_2'] = 3,
			['arms'] = 22,
			['pants_1'] = 28,   ['pants_2'] = 0,
			['shoes_1'] = 21,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 125,    ['chain_2'] = 0,
			['bproof_1'] = 0,  ['bproof_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 73,  ['tshirt_2'] = 0,
			['torso_1'] = 11,   ['torso_2'] = 1,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 42,
			['pants_1'] = 52,   ['pants_2'] = 2,
			['shoes_1'] = 40,   ['shoes_2'] = 9,
			['helmet_1'] = 0,  ['helmet_2'] = 0,
			['chain_1'] = 125,    ['chain_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		}
	},
	bcso_wear = {
		male = {
			['tshirt_1'] = 64,  ['tshirt_2'] = 0,
			['torso_1'] = 101,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 0,
			['pants_1'] = 52,   ['pants_2'] = 3,
			['shoes_1'] = 26,   ['shoes_2'] = 0,
			['helmet_1'] = 58,  ['helmet_2'] = 2,
			['chain_1'] = 125,    ['chain_2'] = 0,
			['bproof_1'] = 12,  ['bproof_2'] = 1,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 73,  ['tshirt_2'] = 0,
			['torso_1'] = 11,   ['torso_2'] = 1,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 42,
			['pants_1'] = 52,   ['pants_2'] = 2,
			['shoes_1'] = 40,   ['shoes_2'] = 9,
			['helmet_1'] = 0,  ['helmet_2'] = 0,
			['chain_1'] = 125,    ['chain_2'] = 0,
			['ears_1'] = 1,     ['ears_2'] = 0
		}
	},
	bullet_wear = {
		male = {
			['bproof_1'] = 16,  ['bproof_2'] = 2
		},
		female = {
			['bproof_1'] = 16,  ['bproof_2'] = 2
		}
	},
	gilet_wear = {
		male = {
			['tshirt_1'] = 59,  ['tshirt_2'] = 1
		},
		female = {
			['tshirt_1'] = 36,  ['tshirt_2'] = 1
		}
	}

}
