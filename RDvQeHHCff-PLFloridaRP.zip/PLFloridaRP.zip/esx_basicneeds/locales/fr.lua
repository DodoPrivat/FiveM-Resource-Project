Locales['fr'] = {
	['used_bread'] = 'vous avez utilisé ~y~1x~s~ ~b~pain~s~',
	['used_water'] = 'vous avez utilisé ~y~1x~s~ ~b~eau~s~',
}Locales['fr'] = {
	['used_bread'] = 'vous avez utilisé ~y~1x~s~ ~b~pain~s~',
	['used_water'] = 'vous avez utilisé ~y~1x~s~ ~b~eau~s~',
}