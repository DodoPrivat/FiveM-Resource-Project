Locales['en'] = {

  ['you_paid'] = 'Zapłaciłeś ~g~$%s~s~ za teoretyczny egzamin',
  ['go_next_point'] = 'Jedź do następnego punktu!',
  ['in_town_speed'] = 'Wjechałeś do miasta, zwróć uwagę na prędkość! Ograniczenie: ~y~',
  ['next_point_speed'] = 'Jedź do następnego punktu! Ograniczenie: ~y~',
  ['stop_for_ped'] = '~r~Zatrzymaj się,~s~ aby przepuścić ~y~przechodnia',
  ['good_lets_cont'] = '~g~Dobrze~s~, kontynuuj.',
  ['stop_look_left'] = '~r~Zatrzymaj się ~s~ spójrz w lewo czy nic nie jedzie. Ograniczenie::~y~ ',
  ['good_turn_right'] = '~g~Dobrze~s~, skręć w prawo',
  ['watch_traffic_lightson'] = 'Zwróć uwagę na innych uczestników ruchu.',
  ['stop_for_passing'] = '~r~Zatrzymaj się,~s~ aby przepuścić jadące pojazdy!',
  ['hway_time'] = 'Czas na jazdę po autostradzie! Ograniczenie:~y~ ',
  ['gratz_stay_alert'] = 'Jestem pod wrażeniem, ale nei zapomnij zwracać uwagi podczas jazdy',
  ['passed_test'] = 'Wynik ~g~pozytywny,~s~ gratulacje!',
  ['failed_test'] = 'Wynik ~r~negatywny,~s~ sprobuj następnym razem.',
  ['theory_test'] = 'Teoretyczny Test na prawo jazdy',
  ['road_test_car'] = 'Prawo jazdy Kat. B',
  ['road_test_bike'] = 'Prawo jazdy Kat. A',
  ['road_test_truck'] = 'Prawo jazdy Kat. C',
  ['driving_school'] = 'Szkoła jazdy',
  ['press_open_menu'] = 'Naciśnij ~INPUT_CONTEXT~ aby otworzyć menu',
  ['driving_school_blip'] = 'Szkoła Jazdy',
  ['driving_test_complete'] = 'Test na prawo jazdy zdany!',
  ['driving_too_fast'] = '~r~Jedziesz za szybko,~s~ Aktualny limit prędkości to: ~y~%s~s~ km/h!',
  ['errors'] = 'Błędy: ~r~%s~s~/%s',
  ['you_damaged_veh'] = 'Uszkodziłeś pojazd',

}
Locales['en'] = {

  ['you_paid'] = 'Zapłaciłeś ~g~$%s~s~ za teoretyczny egzamin',
  ['go_next_point'] = 'Jedź do następnego punktu!',
  ['in_town_speed'] = 'Wjechałeś do miasta, zwróć uwagę na prędkość! Ograniczenie: ~y~',
  ['next_point_speed'] = 'Jedź do następnego punktu! Ograniczenie: ~y~',
  ['stop_for_ped'] = '~r~Zatrzymaj się,~s~ aby przepuścić ~y~przechodnia',
  ['good_lets_cont'] = '~g~Dobrze~s~, kontynuuj.',
  ['stop_look_left'] = '~r~Zatrzymaj się ~s~ spójrz w lewo czy nic nie jedzie. Ograniczenie::~y~ ',
  ['good_turn_right'] = '~g~Dobrze~s~, skręć w prawo',
  ['watch_traffic_lightson'] = 'Zwróć uwagę na innych uczestników ruchu.',
  ['stop_for_passing'] = '~r~Zatrzymaj się,~s~ aby przepuścić jadące pojazdy!',
  ['hway_time'] = 'Czas na jazdę po autostradzie! Ograniczenie:~y~ ',
  ['gratz_stay_alert'] = 'Jestem pod wrażeniem, ale nei zapomnij zwracać uwagi podczas jazdy',
  ['passed_test'] = 'Wynik ~g~pozytywny,~s~ gratulacje!',
  ['failed_test'] = 'Wynik ~r~negatywny,~s~ sprobuj następnym razem.',
  ['theory_test'] = 'Teoretyczny Test na prawo jazdy',
  ['road_test_car'] = 'Prawo jazdy Kat. B',
  ['road_test_bike'] = 'Prawo jazdy Kat. A',
  ['road_test_truck'] = 'Prawo jazdy Kat. C',
  ['driving_school'] = 'Szkoła jazdy',
  ['press_open_menu'] = 'Naciśnij ~INPUT_CONTEXT~ aby otworzyć menu',
  ['driving_school_blip'] = 'Szkoła Jazdy',
  ['driving_test_complete'] = 'Test na prawo jazdy zdany!',
  ['driving_too_fast'] = '~r~Jedziesz za szybko,~s~ Aktualny limit prędkości to: ~y~%s~s~ km/h!',
  ['errors'] = 'Błędy: ~r~%s~s~/%s',
  ['you_damaged_veh'] = 'Uszkodziłeś pojazd',

}
