ESX                           = nil
local PlayerData                = {}

Citizen.CreateThread(function()

	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

end)

--[[local color = {r = 74, g = 39, b = 216, alpha = 255} -- Color of the text 
local font = 0 -- Font of the text
local time = 7000 -- Duration of the display of the text : 1000ms = 1sec
local nbrDisplaying = 1]]

RegisterNetEvent('sendProximityMessage')
AddEventHandler('sendProximityMessage', function(id, name, message)
  local monid = PlayerId()
  local sonid = GetPlayerFromServerId(id)
  if sonid == monid then
    TriggerEvent('chatMessage',"💭" .. name, {128, 128, 128}, message)
  elseif GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(monid)), GetEntityCoords(GetPlayerPed(sonid)), true) < 19.999 then
    TriggerEvent('chatMessage',"💭" .. name, {128, 128, 128}, message)
  end
end)

RegisterNetEvent('sendProximityMessageMe')
AddEventHandler('sendProximityMessageMe', function(id, name, message)
  local myId = PlayerId()
  local pid = GetPlayerFromServerId(id)
  if pid == myId then
    TriggerEvent('chatMessage', "", {255, 0, 0}, " ^1 " .. 'Obywatel' .. '['.. GetPlayerServerId(PlayerId()) .. ']' .. "^1 " .. message)
  elseif GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(myId)), GetEntityCoords(GetPlayerPed(pid)), true) < 19.999 then
    TriggerEvent('chatMessage', "", {255, 0, 0}, " ^1 " .. 'Obywatel' .. '['.. GetPlayerServerId(PlayerId()) .. ']' .. "^1 " .. message)
  end
end)

--[[RegisterNetEvent('sendProximityMessageChmura')
AddEventHandler('sendProximityMessageChmura', function(source, args)
    local text = ' ' 
    for i = 1,#args do
        text = text .. ' ' .. args[i]
    end
    text = text .. ' *'
    TriggerServerEvent('furczat:shareDisplay', text)
end)]]

RegisterNetEvent('sendProximityMessageDo')
AddEventHandler('sendProximityMessageDo', function(id, name, message)
  local myId = PlayerId()
  local pid = GetPlayerFromServerId(id)
  if pid == myId then
    TriggerEvent('chatMessage', "", {255, 0, 0}, " ^5 " .. 'Obywatel' .. '['.. GetPlayerServerId(PlayerId()) .. ']' .. "^5 " .. message)
  elseif GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(myId)), GetEntityCoords(GetPlayerPed(pid)), true) < 19.999 then
    TriggerEvent('chatMessage', "", {255, 0, 0}, " ^5 " .. 'Obywatel' .. '['.. GetPlayerServerId(PlayerId()) .. ']' .. "^5 " .. message)
  end
end)

--[[RegisterNetEvent('furczat:triggerDisplay')
AddEventHandler('furczat:triggerDisplay', function(text, source)
    local offset = 1 + (nbrDisplaying*0.14)
    Display(GetPlayerFromServerId(source), text, offset)
end)

function Display(mePlayer, text, offset)
  local displaying = true
  Citizen.CreateThread(function()
      Wait(time)
      displaying = false
  end)
  Citizen.CreateThread(function()
      nbrDisplaying = nbrDisplaying + 1
      print(nbrDisplaying)
      while displaying do
          Wait(0)
          local coordsMe = GetEntityCoords(GetPlayerPed(mePlayer), false)
          local coords = GetEntityCoords(PlayerPedId(), false)
          local dist = GetDistanceBetweenCoords(coordsMe['x'], coordsMe['y'], coordsMe['z'], coords['x'], coords['y'], coords['z'], true)
          if dist < 50 then
              DrawText3D(coordsMe['x'], coordsMe['y'], coordsMe['z']+offset, text)
          end
      end
      nbrDisplaying = nbrDisplaying - 1
  end)
end

function DrawText3D(x,y,z, text)
  local onScreen,_x,_y=World3dToScreen2d(x,y,z)
  local px,py,pz=table.unpack(GetGameplayCamCoords())
  SetTextScale(0.35, 0.35)
  SetTextFont(4)
  SetTextProportional(1)
  SetTextColour(255, 255, 255, 215)
  SetTextEntry("STRING")
  SetTextCentre(1)
  AddTextComponentString(text)
  DrawText(_x,_y)
  local factor = (string.len(text)) / 370
  DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
end]]