Config                            = {}

Config.Teleporters = {
	['Dom la fuenta'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 1394.5, 
			['y'] = 1141.71, 
			['z'] = 113.61,
			['Information'] = 'Naciśnij [E] aby wejść do środka',
		},
		['Exit'] = {
			['x'] = 1396.51, 
			['y'] = 1141.69, 
			['z'] = 113.33, 
			['Information'] = 'Naciśnij [E] aby wyjść' 
		}
	},

	['Magazyn'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 1180.51, 
			['y'] = -3113.73, 
			['z'] = 5.03,
			['Information'] = 'Naciśnij [E] aby wejść na magazyn' 
		},

		['Exit'] = {
			['x'] = 992.82, 
			['y'] = -3097.46, 
			['z'] = -39.55, 
			['Information'] = 'Naciśnij [E] aby wyjść z magazynu' 
		}
	},

	--Next here
	
	['SzpitalSala'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 333.96, 
			['y'] = -570.37, 
			['z'] = 42.32,
			['Information'] = 'Naciśnij [E] aby wejść na sale operacyjną' 
		},

		['Exit'] = {
			['x'] = 274.99, 
			['y'] = -1360.55, 
			['z'] = 23.54, 
			['Information'] = 'Naciśnij [E] aby wrócić do szpitala' 
		}
	},

	['SzpitalWinda'] = {
		['Job'] = 'ambulance',
		['Enter'] = { 
			['x'] = 325.29, 
			['y'] = -598.66, 
			['z'] = 42.29,
			['Information'] = 'Naciśnij [E] aby wjechać na góre' 
		},

		['Exit'] = {
			['x'] = 339.6, 
			['y'] = -584.2, 
			['z'] = 73.17, 
			['Information'] = 'Naciśnij [E] aby zjechać na dół' 
		}
	},

	['WastonHome'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = -2588.07, 
			['y'] = 1912.23, 
			['z'] = 166.5,
			['Information'] = 'Naciśnij [E] aby wejsc do srodka' 
		},

		['Exit'] = {
			['x'] = -2587.34, 
			['y'] = 1908.42, 
			['z'] = 166.52, 
			['Information'] = 'Naciśnij [E] aby wyjsc na zewnatrz' 
		}
	},

	['FiBWinda'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 138.91, 
			['y'] = -762.44, 
			['z'] = 44.75,
			['Information'] = 'Naciśnij [E] aby wjechać na góre' 
		},

		['Exit'] = {
			['x'] = 136.36, 
			['y'] = -761.69, 
			['z'] = 241.15, 
			['Information'] = 'Naciśnij [E] aby zjechać na dół' 
		}
	},

	['PRALNIA ON'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = -2965.75, 
			['y'] = 23.82,
			['z'] = 7.21,
			['Information'] = 'Nacisnij E aby wejsc' 
		},

		['Exit'] = {
			['x'] = 1138.08, 
			['y'] = -3197.96, 
			['z'] = -40.40, 
			['Information'] = 'Nacisnij E aby wyjsc' 
		}
	},

		['PRALNIA OFF'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = -442.31, 
			['y'] = 6012.3,
			['z'] = 30.8,
			['Information'] = 'Nacisnij E aby wejsc' 
		},

		['Exit'] = {
			['x'] = 2459.46, 
			['y'] = -827.07, 
			['z'] = -38.25, 
			['Information'] = 'Nacisnij E aby wyjsc' 
		}
	},

	['DOM SHADOWA'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = -84.43, 
			['y'] = -821.6,
			['z'] = 35.06,
			['Information'] = 'Nacisnij E aby wjechac na gore' 
		},

		['Exit'] = {
			['x'] = -77.9, 
			['y'] = -830.18, 
			['z'] = 242.40, 
			['Information'] = 'Nacisnij E aby zjechac w dol' 
		}
	},

	['ZIOLO'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 48.34, 
			['y'] = 6305.98,
			['z'] = 30.37,
			['Information'] = 'Nacisnij E aby wejsc do srodka' 
		},

		['Exit'] = {
			['x'] = 1065.31, 
			['y'] = -3183.45, 
			['z'] = -39.56, 
			['Information'] = 'Nacisnij E aby wyjsc' 
		}
	},

	['META'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = -3169.2, 
			['y'] = 1093.56,
			['z'] = 19.86,
			['Information'] = 'Nacisnij E aby wejsc do srodka' 
		},

		['Exit'] = {
			['x'] = 997.81, 
			['y'] = -3200.59, 
			['z'] = -37.36, 
			['Information'] = 'Nacisnij E aby wyjsc' 
		}
	},
	
	['KOKA'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 94.24, 
			['y'] = -2694.37,
			['z'] = 5.0,
			['Information'] = 'Nacisnij E aby wejsc do srodka' 
		},

		['Exit'] = {
			['x'] = 1089.24, 
			['y'] = -3188.26, 
			['z'] = -39.50, 
			['Information'] = 'Nacisnij E aby wyjsc' 
		}
	},

	['URZĄD'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 238.31, 
			['y'] = -411.95,
			['z'] = 47.11,
			['Information'] = 'Nacisnij E aby wejsc do urzedu' 
		},

		['Exit'] = {
			['x'] = 1173.66, 
			['y'] = -3196.68, 
			['z'] = -39.96, 
			['Information'] = 'Nacisnij E aby wyjsc z urzedu' 
		}
	},

		['SandyShores Sheriff'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 1851.21, 
			['y'] = 3683.28,
			['z'] = 33.3,
			['Information'] = 'Nacisnij E aby wejsc' 
		},

		['Exit'] = {
			['x'] = 1849.74, 
			['y'] = 3683.16, 
			['z'] = -119.65, 
			['Information'] = 'Nacisnij E aby wyjsc' 
		}
	}
}




Config                            = {}

Config.Teleporters = {
	['Dom la fuenta'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 1394.5, 
			['y'] = 1141.71, 
			['z'] = 113.61,
			['Information'] = 'Naciśnij [E] aby wejść do środka',
		},
		['Exit'] = {
			['x'] = 1396.51, 
			['y'] = 1141.69, 
			['z'] = 113.33, 
			['Information'] = 'Naciśnij [E] aby wyjść' 
		}
	},

	['Magazyn'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 1180.51, 
			['y'] = -3113.73, 
			['z'] = 5.03,
			['Information'] = 'Naciśnij [E] aby wejść na magazyn' 
		},

		['Exit'] = {
			['x'] = 992.82, 
			['y'] = -3097.46, 
			['z'] = -39.55, 
			['Information'] = 'Naciśnij [E] aby wyjść z magazynu' 
		}
	},

	--Next here
	
	['SzpitalSala'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 333.96, 
			['y'] = -570.37, 
			['z'] = 42.32,
			['Information'] = 'Naciśnij [E] aby wejść na sale operacyjną' 
		},

		['Exit'] = {
			['x'] = 274.99, 
			['y'] = -1360.55, 
			['z'] = 23.54, 
			['Information'] = 'Naciśnij [E] aby wrócić do szpitala' 
		}
	},

	['SzpitalWinda'] = {
		['Job'] = 'ambulance',
		['Enter'] = { 
			['x'] = 325.29, 
			['y'] = -598.66, 
			['z'] = 42.29,
			['Information'] = 'Naciśnij [E] aby wjechać na góre' 
		},

		['Exit'] = {
			['x'] = 339.6, 
			['y'] = -584.2, 
			['z'] = 73.17, 
			['Information'] = 'Naciśnij [E] aby zjechać na dół' 
		}
	},

	['WastonHome'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = -2588.07, 
			['y'] = 1912.23, 
			['z'] = 166.5,
			['Information'] = 'Naciśnij [E] aby wejsc do srodka' 
		},

		['Exit'] = {
			['x'] = -2587.34, 
			['y'] = 1908.42, 
			['z'] = 166.52, 
			['Information'] = 'Naciśnij [E] aby wyjsc na zewnatrz' 
		}
	},

	['FiBWinda'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 138.91, 
			['y'] = -762.44, 
			['z'] = 44.75,
			['Information'] = 'Naciśnij [E] aby wjechać na góre' 
		},

		['Exit'] = {
			['x'] = 136.36, 
			['y'] = -761.69, 
			['z'] = 241.15, 
			['Information'] = 'Naciśnij [E] aby zjechać na dół' 
		}
	},

	['PRALNIA ON'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = -2965.75, 
			['y'] = 23.82,
			['z'] = 7.21,
			['Information'] = 'Nacisnij E aby wejsc' 
		},

		['Exit'] = {
			['x'] = 1138.08, 
			['y'] = -3197.96, 
			['z'] = -40.40, 
			['Information'] = 'Nacisnij E aby wyjsc' 
		}
	},

		['PRALNIA OFF'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = -442.31, 
			['y'] = 6012.3,
			['z'] = 30.8,
			['Information'] = 'Nacisnij E aby wejsc' 
		},

		['Exit'] = {
			['x'] = 2459.46, 
			['y'] = -827.07, 
			['z'] = -38.25, 
			['Information'] = 'Nacisnij E aby wyjsc' 
		}
	},

	['DOM SHADOWA'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = -84.43, 
			['y'] = -821.6,
			['z'] = 35.06,
			['Information'] = 'Nacisnij E aby wjechac na gore' 
		},

		['Exit'] = {
			['x'] = -77.9, 
			['y'] = -830.18, 
			['z'] = 242.40, 
			['Information'] = 'Nacisnij E aby zjechac w dol' 
		}
	},

	['ZIOLO'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 48.34, 
			['y'] = 6305.98,
			['z'] = 30.37,
			['Information'] = 'Nacisnij E aby wejsc do srodka' 
		},

		['Exit'] = {
			['x'] = 1065.31, 
			['y'] = -3183.45, 
			['z'] = -39.56, 
			['Information'] = 'Nacisnij E aby wyjsc' 
		}
	},

	['META'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = -3169.2, 
			['y'] = 1093.56,
			['z'] = 19.86,
			['Information'] = 'Nacisnij E aby wejsc do srodka' 
		},

		['Exit'] = {
			['x'] = 997.81, 
			['y'] = -3200.59, 
			['z'] = -37.36, 
			['Information'] = 'Nacisnij E aby wyjsc' 
		}
	},
	
	['KOKA'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 94.24, 
			['y'] = -2694.37,
			['z'] = 5.0,
			['Information'] = 'Nacisnij E aby wejsc do srodka' 
		},

		['Exit'] = {
			['x'] = 1089.24, 
			['y'] = -3188.26, 
			['z'] = -39.50, 
			['Information'] = 'Nacisnij E aby wyjsc' 
		}
	},

	['URZĄD'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 238.31, 
			['y'] = -411.95,
			['z'] = 47.11,
			['Information'] = 'Nacisnij E aby wejsc do urzedu' 
		},

		['Exit'] = {
			['x'] = 1173.66, 
			['y'] = -3196.68, 
			['z'] = -39.96, 
			['Information'] = 'Nacisnij E aby wyjsc z urzedu' 
		}
	},

		['SandyShores Sheriff'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 1851.21, 
			['y'] = 3683.28,
			['z'] = 33.3,
			['Information'] = 'Nacisnij E aby wejsc' 
		},

		['Exit'] = {
			['x'] = 1849.74, 
			['y'] = 3683.16, 
			['z'] = -119.65, 
			['Information'] = 'Nacisnij E aby wyjsc' 
		}
	}
}




