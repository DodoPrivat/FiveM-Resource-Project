Config                   = {}

Config.Locale            = 'pl'
Config.EnableESXIdentity = true
Config.MaxSalary         = 500
Config                   = {}

Config.Locale            = 'pl'
Config.EnableESXIdentity = true
Config.MaxSalary         = 500
