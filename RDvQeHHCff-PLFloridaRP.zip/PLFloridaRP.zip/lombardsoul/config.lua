Config = {}

Config.Map = {
  {name="Lombard", color=29, scale=1.0,id=77, x=-427.73, y=-451.98, z=43.55},
}