ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(1)
	end
end)

function LocalPed()
	return GetPlayerPed(-1)
end

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1)
			DrawMarker(23, -428.07, -455.13, 31.53, 0, 0, 0, 0, 0, 0, 1.5001, 1.5001, 1.0001, 255, 255, 102, 165, 0, 0, 0,0)
			if GetDistanceBetweenCoords(-428.07, -455.13, 32.52, GetEntityCoords(LocalPed())) < 0.8 then
				local playerPed = PlayerPedId()
				if not ESX.UI.Menu.IsOpen('default', GetCurrentResourceName(), 'lombard_menu') then
					SetTextComponentFormat('STRING');
					AddTextComponentString("Naciśnij ~INPUT_CONTEXT~ aby zapukać do ~y~drzwi");
					DisplayHelpTextFromStringLabel(0, 0, 1, -1);
						if IsControlJustReleased(0, 38) then
							ESX.ShowNotification("~y~Zapukałeś do drzwi, ~b~ poczekaj chwilę...")
							FreezeEntityPosition(GetPlayerPed(-1), true)
							Wait(3500)
							OpenActionMenuLombard()
						end
				end
			end
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
			if IsControlJustReleased(0, 177) and ESX.UI.Menu.IsOpen('default', GetCurrentResourceName(), 'lombard_menu') then
				ESX.UI.Menu.CloseAll()
			end
	end
end)

RegisterNetEvent('tel')
AddEventHandler('tel',function() 
	TriggerServerEvent("lombardsoul:telefon")
	FreezeEntityPosition(GetPlayerPed(-1), false)
	ESX.UI.Menu.CloseAll()
end)

RegisterNetEvent('nap')
AddEventHandler('nap',function() 
	TriggerServerEvent("lombardsoul:naprawka")
	FreezeEntityPosition(GetPlayerPed(-1), false)
	ESX.UI.Menu.CloseAll()
end)

RegisterNetEvent('wie')
AddEventHandler('wie',function() 
	TriggerServerEvent("lombardsoul:wiertlo")
	FreezeEntityPosition(GetPlayerPed(-1), false)
	ESX.UI.Menu.CloseAll()
end)

RegisterNetEvent('wyt')
AddEventHandler('wyt',function() 
	TriggerServerEvent("lombardsoul:wytrych")
	FreezeEntityPosition(GetPlayerPed(-1), false)
	ESX.UI.Menu.CloseAll()
end)

RegisterNetEvent('tor')
AddEventHandler('tor',function() 
	TriggerServerEvent("lombardsoul:torba")
	FreezeEntityPosition(GetPlayerPed(-1), false)
	ESX.UI.Menu.CloseAll()
end)

RegisterNetEvent('mag')
AddEventHandler('mag',function() 
	TriggerServerEvent("lombardsoul:magazynek")
	FreezeEntityPosition(GetPlayerPed(-1), false)
	ESX.UI.Menu.CloseAll()
end)

function OpenActionMenuLombard(target)

	local elements = {}

	table.insert(elements, {label = ('(700$) Telefon'), value = 'tel'})
	table.insert(elements, {label = ("(1000$) Magazynek"), value = 'mag'})
	table.insert(elements, {label = ('(1200$) Zestaw Naprawczy'), value = 'nap'})
	table.insert(elements, {label = ('(1500$) Torba na głowe'), value = 'tor'})
	table.insert(elements, {label = ("(2000$) Wytrych"), value = 'wyt'})
	table.insert(elements, {label = ("(10000$) Wiertło"), value = 'wie'})
  		ESX.UI.Menu.CloseAll()	

	ESX.UI.Menu.Open(
		'default', GetCurrentResourceName(), 'lombard_menu',
		{
			title    = ('Obstaw przedmioty - Lombard'),
			align    = 'top-left',
			elements = elements
		},
		
    function(data, menu)
		
		if data.current.value == 'tel' then
		TriggerEvent('tel')
		elseif data.current.value == 'nap' then
		TriggerEvent('nap')
		elseif data.current.value == 'wie' then
		TriggerEvent('wie')
		elseif data.current.value == 'wyt' then
		TriggerEvent('wyt')
		elseif data.current.value == 'tor' then
		TriggerEvent('tor')
		elseif data.current.value == 'mag' then
		TriggerEvent('mag')
	
		end
	end)
end

Citizen.CreateThread(function()
	
	for i=1, #Config.Map, 1 do
		
		local blip = AddBlipForCoord(Config.Map[i].x, Config.Map[i].y, Config.Map[i].z)
		SetBlipSprite (blip, Config.Map[i].id)
		SetBlipDisplay(blip, 4)
		SetBlipColour (blip, Config.Map[i].color)
		SetBlipScale (blip, Config.Map[i].scale)
		SetBlipAsShortRange(blip, true)

		BeginTextCommandSetBlipName("STRING")
		AddTextComponentString(Config.Map[i].name)
		EndTextCommandSetBlipName(blip)
		
	end

end)