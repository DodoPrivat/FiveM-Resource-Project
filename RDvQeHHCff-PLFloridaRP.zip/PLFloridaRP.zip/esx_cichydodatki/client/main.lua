

Citizen.CreateThread(function()
  while ESX == nil do
    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
    Citizen.Wait(0)
  end
end)


function skrzynkamenu()
	
  ESX.UI.Menu.CloseAll()

  ESX.UI.Menu.Open(
          'default', GetCurrentResourceName(), 'skrzynka',
          {
            title    = 'Dodatki do broni',
            align    = 'center',
            elements = {
           {label = "Zaloz Tlumik", value = 'tlumik1'},
	{label = "Zdejmij Tlumik", value = 'tlumik2'},
	  {label = "Zaloz Chwyt", value = 'chwyt1'},
	{label = "Zdejmij Chwyt", value = 'chwyt2'},
	 {label = "Zaloz latarke", value = 'latarka1'},
	{label = "Zdejmij latarke", value = 'latarka2'},
	 {label = "Zaloz powiekszony magazynek", value = 'magazynek1'},
	{label = "Zdejmij powiekszony magazynek", value = 'magazynek2'},
	{label = "Zaloz celownik", value = 'celownik1'},
	{label = "Zdejmij celownik", value = 'celownik2'},

             
            },
          },
          function(data, menu)

       
		    local ped = PlayerPedId()
			 local currentWeaponHash = GetSelectedPedWeapon(ped)


              if data.current.value == 'tlumik1' then
			if currentWeaponHash == GetHashKey("WEAPON_PISTOL") then
		  		 	GiveWeaponComponentToPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL"), GetHashKey("component_at_pi_supp_02"))  
			elseif currentWeaponHash == GetHashKey("WEAPON_SMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_AT_PI_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_COMBATPISTOL") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_COMBATPISTOL"), GetHashKey("COMPONENT_AT_PI_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PISTOL50") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_PISTOL50"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_HEAVYPISTOL") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_HEAVYPISTOL"), GetHashKey("COMPONENT_AT_PI_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_AR_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PUMPSHOTGUN") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_PUMPSHOTGUN"), GetHashKey("COMPONENT_AT_AR_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SNIPERRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SNIPERRIFLE"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))

		end
        

              elseif data.current.value == 'tlumik2' then
			if currentWeaponHash == GetHashKey("WEAPON_PISTOL") then
				 RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL"), GetHashKey("component_at_pi_supp_02"))
				
			elseif currentWeaponHash == GetHashKey("WEAPON_SMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_AT_PI_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_COMBATPISTOL") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_COMBATPISTOL"), GetHashKey("COMPONENT_AT_PI_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PISTOL50") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL50"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_HEAVYPISTOL") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_HEAVYPISTOL"), GetHashKey("COMPONENT_AT_PI_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_AR_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PUMPSHOTGUN") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PUMPSHOTGUN"), GetHashKey("COMPONENT_AT_AR_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SNIPERRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SNIPERRIFLE"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
	

				end
		 elseif data.current.value == 'chwyt1' then
			if currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PUMPSHOTGUN") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_PUMPSHOTGUN"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SNIPERRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SNIPERRIFLE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
					end
	
		 elseif data.current.value == 'chwyt2' then
			if currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PUMPSHOTGUN") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PUMPSHOTGUN"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SNIPERRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SNIPERRIFLE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
					end
			
		 elseif data.current.value == 'latarka1' then
				if currentWeaponHash == GetHashKey("WEAPON_PISTOL") then
		  		 	GiveWeaponComponentToPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL"), GetHashKey("COMPONENT_AT_PI_FLSH"))  
			elseif currentWeaponHash == GetHashKey("WEAPON_SMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_COMBATPISTOL") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_COMBATPISTOL"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PISTOL50") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_PISTOL50"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_HEAVYPISTOL") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_HEAVYPISTOL"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PUMPSHOTGUN") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_PUMPSHOTGUN"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_AT_PI_FLSH"))
				end
	
		 elseif data.current.value == 'latarka2' then
					if currentWeaponHash == GetHashKey("WEAPON_PISTOL") then
				 RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL"), GetHashKey("COMPONENT_AT_PI_FLSH"))
				
			elseif currentWeaponHash == GetHashKey("WEAPON_SMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_COMBATPISTOL") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_COMBATPISTOL"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PISTOL50") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL50"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_HEAVYPISTOL") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_HEAVYPISTOL"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PUMPSHOTGUN") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PUMPSHOTGUN"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_AT_PI_FLSH"))
				end
			

		    elseif data.current.value == 'magazynek1' then
			if currentWeaponHash == GetHashKey("WEAPON_PISTOL") then
		  		 	GiveWeaponComponentToPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL"), GetHashKey("COMPONENT_PISTOL_CLIP_02"))  
			elseif currentWeaponHash == GetHashKey("WEAPON_SMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_SMG_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_COMBATPISTOL") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_COMBATPISTOL"), GetHashKey("COMPONENT_COMBATPISTOL_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PISTOL50") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_PISTOL50"), GetHashKey("COMPONENT_PISTOL50_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_HEAVYPISTOL") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_HEAVYPISTOL"), GetHashKey("COMPONENT_HEAVYPISTOL_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_ASSAULTRIFLE_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_CARBINERIFLE_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_SPECIALCARBINE_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_MICROSMG_CLIP_02"))

		end
		
		    elseif data.current.value == 'magazynek2' then
			if currentWeaponHash == GetHashKey("WEAPON_PISTOL") then
				 RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL"), GetHashKey("COMPONENT_PISTOL_CLIP_02"))
				
			elseif currentWeaponHash == GetHashKey("WEAPON_SMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_SMG_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_COMBATPISTOL") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_COMBATPISTOL"), GetHashKey("COMPONENT_COMBATPISTOL_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PISTOL50") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL50"), GetHashKey("COMPONENT_PISTOL50_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_HEAVYPISTOL") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_HEAVYPISTOL"), GetHashKey("COMPONENT_HEAVYPISTOL_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_ASSAULTRIFLE_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_CARBINERIFLE_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_SPECIALCARBINE_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_MICROSMG_CLIP_02"))
	

				end

			   elseif data.current.value == 'celownik1' then
			 
				if currentWeaponHash == GetHashKey("WEAPON_SMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_AT_SCOPE_MACRO_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_SCOPE_MACRO"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_SCOPE_MEDIUM"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_SCOPE_MEDIUM"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SNIPERRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SNIPERRIFLE"), GetHashKey("COMPONENT_AT_SCOPE_MAX"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_AT_SCOPE_MACRO"))

		end
			       elseif data.current.value == 'celownik2' then
			if currentWeaponHash == GetHashKey("WEAPON_SMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_AT_SCOPE_MACRO_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_SCOPE_MACRO"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_SCOPE_MEDIUM"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_SCOPE_MEDIUM"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SNIPERRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SNIPERRIFLE"), GetHashKey("COMPONENT_AT_SCOPE_MAX"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_AT_SCOPE_MACRO"))
			end



       


end
	
         
      
    end,
    function(data, menu)

      menu.close()

    end
  )

end



RegisterNetEvent('cichydodatki:openmenu')
AddEventHandler('cichydodatki:openmenu', function()
		skrzynkamenu()
end)

Citizen.CreateThread(function()
  while ESX == nil do
    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
    Citizen.Wait(0)
  end
end)


function skrzynkamenu()
	
  ESX.UI.Menu.CloseAll()

  ESX.UI.Menu.Open(
          'default', GetCurrentResourceName(), 'skrzynka',
          {
            title    = 'Dodatki do broni',
            align    = 'center',
            elements = {
           {label = "Zaloz Tlumik", value = 'tlumik1'},
	{label = "Zdejmij Tlumik", value = 'tlumik2'},
	  {label = "Zaloz Chwyt", value = 'chwyt1'},
	{label = "Zdejmij Chwyt", value = 'chwyt2'},
	 {label = "Zaloz latarke", value = 'latarka1'},
	{label = "Zdejmij latarke", value = 'latarka2'},
	 {label = "Zaloz powiekszony magazynek", value = 'magazynek1'},
	{label = "Zdejmij powiekszony magazynek", value = 'magazynek2'},
	{label = "Zaloz celownik", value = 'celownik1'},
	{label = "Zdejmij celownik", value = 'celownik2'},

             
            },
          },
          function(data, menu)

       
		    local ped = PlayerPedId()
			 local currentWeaponHash = GetSelectedPedWeapon(ped)


              if data.current.value == 'tlumik1' then
			if currentWeaponHash == GetHashKey("WEAPON_PISTOL") then
		  		 	GiveWeaponComponentToPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL"), GetHashKey("component_at_pi_supp_02"))  
			elseif currentWeaponHash == GetHashKey("WEAPON_SMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_AT_PI_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_COMBATPISTOL") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_COMBATPISTOL"), GetHashKey("COMPONENT_AT_PI_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PISTOL50") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_PISTOL50"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_HEAVYPISTOL") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_HEAVYPISTOL"), GetHashKey("COMPONENT_AT_PI_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_AR_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PUMPSHOTGUN") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_PUMPSHOTGUN"), GetHashKey("COMPONENT_AT_AR_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SNIPERRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SNIPERRIFLE"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))

		end
        

              elseif data.current.value == 'tlumik2' then
			if currentWeaponHash == GetHashKey("WEAPON_PISTOL") then
				 RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL"), GetHashKey("component_at_pi_supp_02"))
				
			elseif currentWeaponHash == GetHashKey("WEAPON_SMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_AT_PI_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_COMBATPISTOL") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_COMBATPISTOL"), GetHashKey("COMPONENT_AT_PI_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PISTOL50") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL50"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_HEAVYPISTOL") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_HEAVYPISTOL"), GetHashKey("COMPONENT_AT_PI_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_AR_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PUMPSHOTGUN") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PUMPSHOTGUN"), GetHashKey("COMPONENT_AT_AR_SUPP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SNIPERRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SNIPERRIFLE"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_AT_AR_SUPP_02"))
	

				end
		 elseif data.current.value == 'chwyt1' then
			if currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PUMPSHOTGUN") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_PUMPSHOTGUN"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SNIPERRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SNIPERRIFLE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
					end
	
		 elseif data.current.value == 'chwyt2' then
			if currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PUMPSHOTGUN") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PUMPSHOTGUN"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SNIPERRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SNIPERRIFLE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
					end
			
		 elseif data.current.value == 'latarka1' then
				if currentWeaponHash == GetHashKey("WEAPON_PISTOL") then
		  		 	GiveWeaponComponentToPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL"), GetHashKey("COMPONENT_AT_PI_FLSH"))  
			elseif currentWeaponHash == GetHashKey("WEAPON_SMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_COMBATPISTOL") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_COMBATPISTOL"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PISTOL50") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_PISTOL50"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_HEAVYPISTOL") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_HEAVYPISTOL"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PUMPSHOTGUN") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_PUMPSHOTGUN"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_AT_PI_FLSH"))
				end
	
		 elseif data.current.value == 'latarka2' then
					if currentWeaponHash == GetHashKey("WEAPON_PISTOL") then
				 RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL"), GetHashKey("COMPONENT_AT_PI_FLSH"))
				
			elseif currentWeaponHash == GetHashKey("WEAPON_SMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_COMBATPISTOL") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_COMBATPISTOL"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PISTOL50") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL50"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_HEAVYPISTOL") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_HEAVYPISTOL"), GetHashKey("COMPONENT_AT_PI_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PUMPSHOTGUN") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PUMPSHOTGUN"), GetHashKey("COMPONENT_AT_AR_FLSH"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_AT_PI_FLSH"))
				end
			

		    elseif data.current.value == 'magazynek1' then
			if currentWeaponHash == GetHashKey("WEAPON_PISTOL") then
		  		 	GiveWeaponComponentToPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL"), GetHashKey("COMPONENT_PISTOL_CLIP_02"))  
			elseif currentWeaponHash == GetHashKey("WEAPON_SMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_SMG_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_COMBATPISTOL") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_COMBATPISTOL"), GetHashKey("COMPONENT_COMBATPISTOL_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PISTOL50") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_PISTOL50"), GetHashKey("COMPONENT_PISTOL50_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_HEAVYPISTOL") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_HEAVYPISTOL"), GetHashKey("COMPONENT_HEAVYPISTOL_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_ASSAULTRIFLE_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_CARBINERIFLE_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_SPECIALCARBINE_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_MICROSMG_CLIP_02"))

		end
		
		    elseif data.current.value == 'magazynek2' then
			if currentWeaponHash == GetHashKey("WEAPON_PISTOL") then
				 RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL"), GetHashKey("COMPONENT_PISTOL_CLIP_02"))
				
			elseif currentWeaponHash == GetHashKey("WEAPON_SMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_SMG_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_COMBATPISTOL") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_COMBATPISTOL"), GetHashKey("COMPONENT_COMBATPISTOL_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_PISTOL50") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL50"), GetHashKey("COMPONENT_PISTOL50_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_HEAVYPISTOL") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_HEAVYPISTOL"), GetHashKey("COMPONENT_HEAVYPISTOL_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_ASSAULTRIFLE_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_CARBINERIFLE_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_SPECIALCARBINE_CLIP_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_MICROSMG_CLIP_02"))
	

				end

			   elseif data.current.value == 'celownik1' then
			 
				if currentWeaponHash == GetHashKey("WEAPON_SMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_AT_SCOPE_MACRO_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_SCOPE_MACRO"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_SCOPE_MEDIUM"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_SCOPE_MEDIUM"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SNIPERRIFLE") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_SNIPERRIFLE"), GetHashKey("COMPONENT_AT_SCOPE_MAX"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
             			 GiveWeaponComponentToPed(GetPlayerPed(-1),GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_AT_SCOPE_MACRO"))

		end
			       elseif data.current.value == 'celownik2' then
			if currentWeaponHash == GetHashKey("WEAPON_SMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SMG"), GetHashKey("COMPONENT_AT_SCOPE_MACRO_02"))
			elseif currentWeaponHash == GetHashKey("WEAPON_ASSAULTRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("COMPONENT_AT_SCOPE_MACRO"))
			elseif currentWeaponHash == GetHashKey("WEAPON_CARBINERIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_SCOPE_MEDIUM"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SPECIALCARBINE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("COMPONENT_AT_SCOPE_MEDIUM"))
			elseif currentWeaponHash == GetHashKey("WEAPON_SNIPERRIFLE") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_SNIPERRIFLE"), GetHashKey("COMPONENT_AT_SCOPE_MAX"))
			elseif currentWeaponHash == GetHashKey("WEAPON_MICROSMG") then
				RemoveWeaponComponentFromPed(GetPlayerPed(-1), GetHashKey("WEAPON_MICROSMG"), GetHashKey("COMPONENT_AT_SCOPE_MACRO"))
			end



       


end
	
         
      
    end,
    function(data, menu)

      menu.close()

    end
  )

end



RegisterNetEvent('cichydodatki:openmenu')
AddEventHandler('cichydodatki:openmenu', function()
		skrzynkamenu()
end)