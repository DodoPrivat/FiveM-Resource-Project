Locales['de'] = {

	['by_default'] = 'default',
	['installed'] = 'installiert',
	['already_own'] = 'du besitzt bereits: ~b~',
	['not_enough_money'] = 'du hast nicht genug Geld!',
	['purchased'] = 'gekauft!',
	['press_custom'] = 'Drücke ~INPUT_PICKUP~ um dein Fahrzeug zu modifizieren.',
-- Paint Colors
	-- Black
	['black'] = 'black',
	['graphite'] = 'graphite',
	['black_metallic'] = 'black Metallic',
	['caststeel'] = 'cast Steel',
	['black_anth'] = 'black Anthracite',
	['matteblack'] = 'matte Black',
	['darknight'] = 'dark Night',
	['deepblack'] = 'deep Black',
	['oil'] = 'oil',
	['carbon'] = 'carbon',
	-- White
	['white'] = 'white',
	['vanilla'] = 'vanilla',
	['creme'] = 'creme',
	['polarwhite'] = 'polar White',
	['beige'] = 'beige',
	['mattewhite'] = 'matte White',
	['snow'] = 'snow',
	['cotton'] = 'cotton',
	['alabaster'] = 'alabaster',
	['purewhite'] = 'pure White',
	-- Grey
	['grey'] = 'grey',
	['silver'] = 'silver',
	['metallicgrey'] = 'metallic Grey',
	['laminatedsteel'] = 'laminated Steel',
	['darkgray'] = 'dark Grey',
	['rockygray'] = 'rocky Grey',
	['graynight'] = 'gray Night',
	['aluminum'] = 'aluminum',
	['graymat'] = 'matte Grey',
	['lightgrey'] = 'light Grey',
	['asphaltgray'] = 'asphalt Grey',
	['grayconcrete'] = 'concrete Grey',
	['darksilver'] = 'dark Silver',
	['magnesite'] = 'magnesite',
	['nickel'] = 'nickel',
	['zinc'] = 'zinc',
	['dolomite'] = 'dolomite',
	['bluesilver'] = 'blue Silver',
	['titanium'] = 'titanium',
	['steelblue'] = 'steel Blue',
	['champagne'] = 'champagne',
	['grayhunter'] = 'grey Hunter',
	-- Red
	['red'] = 'red',
	-- Pink
	['pink'] = 'pink',
	['electricpink'] = 'electric Pink',
	['brightpink'] = 'bright Pink',
	['salmon'] = 'salmon',
	['sugarplum'] = 'sugar Plum',
	-- Blue
	['blue'] = 'blue',
	-- Yellow
	['yellow'] = 'yellow',
	['wheat'] = 'wheat',
	['raceyellow'] = 'race Yellow',
	['paleyellow'] = 'pale Yellow',
	['lightyellow'] = 'light Yellow',
	-- Green
	['green'] = 'green',
	-- Orange
	['orange'] = 'orange',
	['tangerine'] = 'Tangerine',
	['matteorange'] = 'Matte Orange',
	['lightorange'] = 'Light Orange',
	['peach'] = 'Peach',
	['pumpkin'] = 'Pumpkin',
	['orangelambo'] = 'Orange Lambo',
	-- Brown
	['brown'] = 'brown',
	['copper'] = 'Copper',
	['lightbrown'] = 'Light Brown',
	['darkbrown'] = 'Dark Brown',
	['bronze'] = 'Bronze',
	['brownmetallic'] = 'Brown Metallic',
	['espresso'] = 'Espresso',
	['chocolate'] = 'Chocolate',
	['terracotta'] = 'Terracotta',
	['marble'] = 'Marble',
	['sand'] = 'Sand',
	['sepia'] = 'Sepia',
	['bison'] = 'Bison',
	['palm'] = 'Palm',
	['caramel'] = 'Caramel',
	['rust'] = 'Rust',
	['chestnut'] = 'Chestnut',
	['hazelnut'] = 'Hazelnut',
	['shell'] = 'Shell',
	['mahogany'] = 'Mahogany',
	['cauldron'] = 'Cauldron',
	['blond'] = 'Blond',
	['gravel'] = 'Gravel',
	['darkearth'] = 'Dark Earth',
	['desert'] = 'Desert',
	-- Purple
	['purple'] = 'purple',
	['indigo'] = 'Indigo',
	['deeppurple'] = 'Deep Purple',
	['darkviolet'] = 'Dark Violet',
	['amethyst'] = 'Amethyst',
	['mysticalviolet'] = 'Mystic Violet',
	['purplemetallic'] = 'Purple Metallic',
	['matteviolet'] = 'Matte Violet',
	['mattedeeppurple'] = 'Matte Deep Purple',
	-- Chrome
	['chrome'] = 'chrome',
	['brushedchrome'] = 'brushed Chrome',
	['blackchrome'] = 'black Chrome',
	['brushedaluminum'] = 'brushed Aluminum',
	-- Metal
	['gold'] = 'gold',
	['puregold'] = 'pure Gold',
	['brushedgold'] = 'brushed Gold',
	['lightgold'] = 'light Gold',
-- License Plates
	['blue_on_white_1'] = 'blue on white 1',
	['yellow_on_black'] = 'yellow on black',
	['yellow_blue'] = 'yellow on blue',
	['blue_on_white_2'] = 'blue on white 2',
	['blue_on_white_3'] = 'blue on white 3',
-- Upgrades
	['upgrades'] = 'upgrades',
	['engine'] = 'engine',
	['brakes'] = 'brakes',
	['transmission'] = 'transmission',
	['suspension'] = 'suspension',
	['armor'] = 'armor',
	['turbo'] = 'turbo',
	['no_turbo'] = 'keine turbo',
-- Cosmetics
	['cosmetics'] = 'cosmetics',
	-- Body Parts
	['bodyparts'] = 'body Parts',
	['leftfender'] = 'left fender',
	['rightfender'] = 'right fender',
	['spoilers'] = 'spoilers',
	['sideskirt'] = 'side skirts',
	['frame'] = 'cage',
	['hood'] = 'hood',
	['grille'] = 'grille',
	['rearbumper'] = 'rear bumper',
	['frontbumper'] = 'front bumper',
	['exhaust'] = 'exhaust',
	['roof'] = 'roof',
	-- Paint
	['respray'] = 'respray',
	['primary'] = 'primary',
	['secondary'] = 'secondary',
	['pearlescent'] = 'pearlescent',
	-- Misc
	['headlights'] = 'headlights',
	['licenseplates'] = 'license Plate',
	['windowtint'] = 'window Tint',
	['horns'] = 'horns',
	-- Neon
	['neons'] = 'neons',
	-- Wheels
	['wheels'] = 'wheels',
	['tiresmoke'] = 'tire smoke',
	['wheel_type'] = 'wheel type',
	['wheel_color'] = 'wheel color',
	['sport'] = 'sport',
	['muscle'] = 'muscle',
	['lowrider'] = 'lowrider',
	['suv'] = 'sUV',
	['allterrain'] = 'all terrain',
	['tuning'] = 'tuning',
	['motorcycle'] = 'motorcycle',
	['highend'] = 'high end',

}
Locales['de'] = {

	['by_default'] = 'default',
	['installed'] = 'installiert',
	['already_own'] = 'du besitzt bereits: ~b~',
	['not_enough_money'] = 'du hast nicht genug Geld!',
	['purchased'] = 'gekauft!',
	['press_custom'] = 'Drücke ~INPUT_PICKUP~ um dein Fahrzeug zu modifizieren.',
-- Paint Colors
	-- Black
	['black'] = 'black',
	['graphite'] = 'graphite',
	['black_metallic'] = 'black Metallic',
	['caststeel'] = 'cast Steel',
	['black_anth'] = 'black Anthracite',
	['matteblack'] = 'matte Black',
	['darknight'] = 'dark Night',
	['deepblack'] = 'deep Black',
	['oil'] = 'oil',
	['carbon'] = 'carbon',
	-- White
	['white'] = 'white',
	['vanilla'] = 'vanilla',
	['creme'] = 'creme',
	['polarwhite'] = 'polar White',
	['beige'] = 'beige',
	['mattewhite'] = 'matte White',
	['snow'] = 'snow',
	['cotton'] = 'cotton',
	['alabaster'] = 'alabaster',
	['purewhite'] = 'pure White',
	-- Grey
	['grey'] = 'grey',
	['silver'] = 'silver',
	['metallicgrey'] = 'metallic Grey',
	['laminatedsteel'] = 'laminated Steel',
	['darkgray'] = 'dark Grey',
	['rockygray'] = 'rocky Grey',
	['graynight'] = 'gray Night',
	['aluminum'] = 'aluminum',
	['graymat'] = 'matte Grey',
	['lightgrey'] = 'light Grey',
	['asphaltgray'] = 'asphalt Grey',
	['grayconcrete'] = 'concrete Grey',
	['darksilver'] = 'dark Silver',
	['magnesite'] = 'magnesite',
	['nickel'] = 'nickel',
	['zinc'] = 'zinc',
	['dolomite'] = 'dolomite',
	['bluesilver'] = 'blue Silver',
	['titanium'] = 'titanium',
	['steelblue'] = 'steel Blue',
	['champagne'] = 'champagne',
	['grayhunter'] = 'grey Hunter',
	-- Red
	['red'] = 'red',
	-- Pink
	['pink'] = 'pink',
	['electricpink'] = 'electric Pink',
	['brightpink'] = 'bright Pink',
	['salmon'] = 'salmon',
	['sugarplum'] = 'sugar Plum',
	-- Blue
	['blue'] = 'blue',
	-- Yellow
	['yellow'] = 'yellow',
	['wheat'] = 'wheat',
	['raceyellow'] = 'race Yellow',
	['paleyellow'] = 'pale Yellow',
	['lightyellow'] = 'light Yellow',
	-- Green
	['green'] = 'green',
	-- Orange
	['orange'] = 'orange',
	['tangerine'] = 'Tangerine',
	['matteorange'] = 'Matte Orange',
	['lightorange'] = 'Light Orange',
	['peach'] = 'Peach',
	['pumpkin'] = 'Pumpkin',
	['orangelambo'] = 'Orange Lambo',
	-- Brown
	['brown'] = 'brown',
	['copper'] = 'Copper',
	['lightbrown'] = 'Light Brown',
	['darkbrown'] = 'Dark Brown',
	['bronze'] = 'Bronze',
	['brownmetallic'] = 'Brown Metallic',
	['espresso'] = 'Espresso',
	['chocolate'] = 'Chocolate',
	['terracotta'] = 'Terracotta',
	['marble'] = 'Marble',
	['sand'] = 'Sand',
	['sepia'] = 'Sepia',
	['bison'] = 'Bison',
	['palm'] = 'Palm',
	['caramel'] = 'Caramel',
	['rust'] = 'Rust',
	['chestnut'] = 'Chestnut',
	['hazelnut'] = 'Hazelnut',
	['shell'] = 'Shell',
	['mahogany'] = 'Mahogany',
	['cauldron'] = 'Cauldron',
	['blond'] = 'Blond',
	['gravel'] = 'Gravel',
	['darkearth'] = 'Dark Earth',
	['desert'] = 'Desert',
	-- Purple
	['purple'] = 'purple',
	['indigo'] = 'Indigo',
	['deeppurple'] = 'Deep Purple',
	['darkviolet'] = 'Dark Violet',
	['amethyst'] = 'Amethyst',
	['mysticalviolet'] = 'Mystic Violet',
	['purplemetallic'] = 'Purple Metallic',
	['matteviolet'] = 'Matte Violet',
	['mattedeeppurple'] = 'Matte Deep Purple',
	-- Chrome
	['chrome'] = 'chrome',
	['brushedchrome'] = 'brushed Chrome',
	['blackchrome'] = 'black Chrome',
	['brushedaluminum'] = 'brushed Aluminum',
	-- Metal
	['gold'] = 'gold',
	['puregold'] = 'pure Gold',
	['brushedgold'] = 'brushed Gold',
	['lightgold'] = 'light Gold',
-- License Plates
	['blue_on_white_1'] = 'blue on white 1',
	['yellow_on_black'] = 'yellow on black',
	['yellow_blue'] = 'yellow on blue',
	['blue_on_white_2'] = 'blue on white 2',
	['blue_on_white_3'] = 'blue on white 3',
-- Upgrades
	['upgrades'] = 'upgrades',
	['engine'] = 'engine',
	['brakes'] = 'brakes',
	['transmission'] = 'transmission',
	['suspension'] = 'suspension',
	['armor'] = 'armor',
	['turbo'] = 'turbo',
	['no_turbo'] = 'keine turbo',
-- Cosmetics
	['cosmetics'] = 'cosmetics',
	-- Body Parts
	['bodyparts'] = 'body Parts',
	['leftfender'] = 'left fender',
	['rightfender'] = 'right fender',
	['spoilers'] = 'spoilers',
	['sideskirt'] = 'side skirts',
	['frame'] = 'cage',
	['hood'] = 'hood',
	['grille'] = 'grille',
	['rearbumper'] = 'rear bumper',
	['frontbumper'] = 'front bumper',
	['exhaust'] = 'exhaust',
	['roof'] = 'roof',
	-- Paint
	['respray'] = 'respray',
	['primary'] = 'primary',
	['secondary'] = 'secondary',
	['pearlescent'] = 'pearlescent',
	-- Misc
	['headlights'] = 'headlights',
	['licenseplates'] = 'license Plate',
	['windowtint'] = 'window Tint',
	['horns'] = 'horns',
	-- Neon
	['neons'] = 'neons',
	-- Wheels
	['wheels'] = 'wheels',
	['tiresmoke'] = 'tire smoke',
	['wheel_type'] = 'wheel type',
	['wheel_color'] = 'wheel color',
	['sport'] = 'sport',
	['muscle'] = 'muscle',
	['lowrider'] = 'lowrider',
	['suv'] = 'sUV',
	['allterrain'] = 'all terrain',
	['tuning'] = 'tuning',
	['motorcycle'] = 'motorcycle',
	['highend'] = 'high end',

}
