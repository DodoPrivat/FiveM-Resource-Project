Locales['en'] = {
	['by_default'] = 'standardowy',
	['installed'] = 'zainstalowany',
	['already_own'] = 'już posiadasz: ~b~',
	['not_enough_money'] = 'nie posiadasz wystarczającej ilości pieniędzy!',
	['purchased'] = 'zakupiłeś modyfikację!',
	['press_custom'] = 'wciśnij ~INPUT_PICKUP~ aby spersonalizować swój pojazd.',
	['level'] = 'level ',
	['neon'] = 'Xenon',
-- Paint Colors
	-- Black
	['black'] = 'czarny',
	['graphite'] = 'grafitowy',
	['black_metallic'] = 'czarny metalik',
	['caststeel'] = 'stalowy',
	['black_anth'] = 'czarny antracyt',
	['matteblack'] = 'czarny mat',
	['darknight'] = 'ciemna czerń',
	['deepblack'] = 'głęboka czerń',
	['oil'] = 'olej',
	['carbon'] = 'carbon',
	-- White
	['white'] = 'biały',
	['vanilla'] = 'wanilia',
	['creme'] = 'kremowy',
	['polarwhite'] = 'polarny biały',
	['beige'] = 'beżowy',
	['mattewhite'] = 'biały mat',
	['snow'] = 'śnieg',
	['cotton'] = 'bawełna',
	['alabaster'] = 'alabaster',
	['purewhite'] = 'czysta biel',
	-- Grey
	['grey'] = 'szary',
	['silver'] = 'srebrny',
	['metallicgrey'] = 'szary metalik',
	['laminatedsteel'] = 'laminowana stal',
	['darkgray'] = 'ciemna szarość',
	['rockygray'] = 'skalisty szary',
	['graynight'] = 'ciemny szary',
	['aluminum'] = 'aluminium',
	['graymat'] = 'szary mat',
	['lightgrey'] = 'jasny szary',
	['asphaltgray'] = 'asfalt szary',
	['grayconcrete'] = 'beton szary',
	['darksilver'] = 'ciemny srebrny',
	['magnesite'] = 'magnezyt',
	['nickel'] = 'nikiel',
	['zinc'] = 'cynk',
	['dolomite'] = 'dolomit',
	['bluesilver'] = 'niebieski srebrny',
	['titanium'] = 'tytan',
	['steelblue'] = 'stalowy niebieski',
	['champagne'] = 'szampanowy',
	['grayhunter'] = 'szary łowca',
	-- Red
	['red'] = 'czerowny',
	['torino_red'] = 'torino czerwony',
	['poppy'] = 'mak',
	['copper_red'] = 'czerwona miedź',
	['cardinal'] = 'mocny czerwony',
	['brick'] = 'czerwona cegła',
	['garnet'] = 'Garnet',
	['cabernet'] = 'cabernet czerwień',
	['candy'] = 'cukierkowa czerwnień',
	['matte_red'] = 'czerwony mat',
	['dark_red'] = 'ciemna czerwień',
	['red_pulp'] = 'czerwona pulpa',
	['bril_red'] = 'brylantowa czerwień',
	['pale_red'] = 'blada czerwień',
	['wine_red'] = 'czerwone wino',
	['volcano'] = 'wulkan',
	-- Pink
	['pink'] = 'różowy',
	['electricpink'] = 'elektryczny różowy',
	['brightpink'] = 'jasny różowy',
	['salmon'] = 'łosoś',
	['sugarplum'] = 'cikier śliwkowy',
	-- Blue
	['blue'] = 'niebieski',
	['topaz'] = 'topaz',
	['light_blue'] = 'jasny niebieski',
	['galaxy_blue'] = 'galaxy niebieski',
	['dark_blue'] = 'granatowy',
	['azure'] = 'błękit',
	['navy_blue'] = 'granatowy',
	['lapis'] = 'ciemny niebieski',
	['blue_diamond'] = 'diamentowy',
	['surfer'] = 'morski',
	['pastel_blue'] = 'pastelowy niebieski',
	['celeste_blue'] = 'celeste niebieski',
	['rally_blue'] = 'rally niebieski',
	['blue_paradise'] = 'niebieski raj',
	['blue_night'] = 'bardzo ciemny niebieski',
	['cyan_blue'] = 'cyjan',
	['cobalt'] = 'kobalt',
	['electric_blue'] = 'electric niebieski',
	['horizon_blue'] = 'horizon niebieski',
	['metallic_blue'] = 'metalniczny niebieski',
	['aquamarine'] = 'akwamaryn',
	['blue_agathe'] = 'niebieski agat',
	['zirconium'] = 'cyrkon',
	['spinel'] = 'spinel',
	['tourmaline'] = 'turmalin',
	['paradise'] = 'paradise',
	['bubble_gum'] = 'guma balonowa',
	['midnight_blue'] = 'północ',
	['forbidden_blue'] = 'zabroniony niebieski',
	['glacier_blue'] = 'lodowcowy',
	-- Yellow
	['yellow'] = 'żółty',
	['wheat'] = 'przeniczny',
	['raceyellow'] = 'żółty wyścigowy',
	['paleyellow'] = 'blady żółty',
	['lightyellow'] = 'jasny żółty',
	-- Green
	['green'] = 'zielony',
	['met_dark_green'] = 'mataliczny ciemny zielony',
	['rally_green'] = 'Rally zielony',
	['pine_green'] = 'sosnowy',
	['olive_green'] = 'oliwkowy',
	['light_green'] = 'jasny zielony',
	['lime_green'] = 'limonkowy',
	['forest_green'] = 'leśny',
	['lawn_green'] = 'trawiasty',
	['imperial_green'] = 'cesarski zielony',
	['green_bottle'] = 'butelkowy zielony',
	['citrus_green'] = 'cytrusowny zielony',
	['green_anis'] = 'zielony Anis',
	['khaki'] = 'Khaki',
	['army_green'] = 'moro',
	['dark_green'] = 'ciemny zielony',
	['hunter_green'] = 'łowiecki zielony',
	['matte_foilage_green'] = 'zielona matowa fiolia',
	-- Orange
	['orange'] = 'pomarańczowy',
	['tangerine'] = 'mandarynka',
	['matteorange'] = 'matowy pomaranczowy',
	['lightorange'] = 'jasny pomaranczowy',
	['peach'] = 'brzoskwiniowy',
	['pumpkin'] = 'dyniowy',
	['orangelambo'] = 'pomaranczowy lambo',
	-- Brown
	['brown'] = 'brązowy',
	['copper'] = 'miedź',
	['lightbrown'] = 'jasny brązowy',
	['darkbrown'] = 'ciemny brązowy',
	['bronze'] = 'brąz',
	['brownmetallic'] = 'brązowy metallic',
	['espresso'] = 'kawowy',
	['chocolate'] = 'czekoladowy',
	['terracotta'] = 'Terakota',
	['marble'] = 'marmurowy',
	['sand'] = 'piaskowy',
	['sepia'] = 'Sepia',
	['bison'] = 'Bizon',
	['palm'] = 'palmowy',
	['caramel'] = 'karmelowy',
	['rust'] = 'rdza',
	['chestnut'] = 'kasztan',
	['hazelnut'] = 'orzech laskowy',
	['shell'] = 'muszla',
	['mahogany'] = 'mahoń',
	['cauldron'] = 'kociołek',
	['blond'] = 'Blond',
	['gravel'] = 'żwirowy',
	['darkearth'] = 'ciemna ziemia',
	['desert'] = 'pustynny',
	-- Purple
	['purple'] = 'fioletowy',
	['indigo'] = 'Indigo',
	['deeppurple'] = 'głeboki fioletowy',
	['darkviolet'] = 'ciemny fiolet',
	['amethyst'] = 'ametyst',
	['mysticalviolet'] = 'mistyczny fiolet',
	['purplemetallic'] = 'fioletowy metalik',
	['matteviolet'] = 'matowy fiolet',
	['mattedeeppurple'] = 'głeboki matowy fiolet',
	-- Chrome
	['chrome'] = 'chrom',
	['brushedchrome'] = 'szczotkowany chrom',
	['blackchrome'] = 'czarny chrom',
	['brushedaluminum'] = 'szczotkowane aluminium',
	-- Metal
	['gold'] = 'złoty',
	['puregold'] = 'czyste złoto',
	['brushedgold'] = 'szczotkowane złoto',
	['lightgold'] = 'jasny złoty',
-- License Plates
	['blue_on_white_1'] = 'niebieski na białym 1',
	['yellow_on_black'] = 'żółty na czarnym',
	['yellow_blue'] = 'żółty na niebieskim',
	['blue_on_white_2'] = 'niebieski na białym 2',
	['blue_on_white_3'] = 'niebieski na białym 3',
-- Upgrades
	['upgrades'] = 'ulepszenia',
	['engine'] = 'silnik',
	['brakes'] = 'hamulce',
	['transmission'] = 'skrzynia biegów',
	['suspension'] = 'zawieszenie',
	['armor'] = 'pancerz',
	['turbo'] = 'turbo',
	['no_turbo'] = 'no turbo',
-- Cosmetics
	['cosmetics'] = 'detale',
	-- Body Parts
	['bodyparts'] = 'części auta',
	['leftfender'] = 'lewy błotnik',
	['rightfender'] = 'prawy błotnik',
	['spoilers'] = 'spoilery',
	['sideskirt'] = 'progi',
	['cage'] = 'klatka',
	['hood'] = 'maska',
	['grille'] = 'grile',
	['rearbumper'] = 'tylni zderzak',
	['frontbumper'] = 'przedni zderzak',
	['exhaust'] = 'tłumik',
	['roof'] = 'dach',
	-- Paint
	['respray'] = 'lakier',
	['primary'] = 'podstawowy',
	['secondary'] = 'drugi kolor',
	['pearlescent'] = 'perła',
	-- Misc
	['headlights'] = 'reflektory',
	['licenseplates'] = 'tablica rejestracyjna',
	['windowtint'] = 'przyciemniane okna',
	['horns'] = 'klakson',
	-- Neon
	['neons'] = 'neony',
	-- Wheels
	['wheels'] = 'koła',
	['tiresmoke'] = 'dym z opon',
	['wheel_type'] = 'typ kół',
	['wheel_color'] = 'kolor kół',
	['sport'] = 'sport',
	['muscle'] = 'muscle',
	['lowrider'] = 'lowrider',
	['suv'] = 'SUV',
	['allterrain'] = 'all terrain',
	['tuning'] = 'tuning',
	['motorcycle'] = 'motorcycle',
	['highend'] = 'high end',
	
	['modplateholder'] = 'tablica - Back',
	['modvanityplate'] = 'tablica - Front',
	['interior'] = 'wnętrze',
	['trim'] = 'wykończenie',
	['dashboard'] = 'deska rozdzielcza',
	['speedometer'] = 'prędkościomierz',
	['door_speakers'] = 'głosniki na drzwiach',
	['seats'] = 'fotele',
	['steering_wheel'] = 'kierownica',
	['gear_lever'] = 'dźwignia zmiany biegó',
	['quarter_deck'] = 'quarter-deck',
	['speakers'] = 'głosniki',
	['trunk'] = 'bagażnik',
	['hydraulic'] = 'hydraulika',
	['engine_block'] = 'blok silnika',
	['air_filter'] = 'filtr powietrza',
	['struts'] = 'struts',
	['arch_cover'] = 'arch cover',
	['aerials'] = 'anteny',
	['wings'] = 'skrzydła',
	['fuel_tank'] = 'bak paliwa',
	['windows'] = 'szyby',
	['stickers'] = 'naklejki',
}Locales['en'] = {
	['by_default'] = 'standardowy',
	['installed'] = 'zainstalowany',
	['already_own'] = 'już posiadasz: ~b~',
	['not_enough_money'] = 'nie posiadasz wystarczającej ilości pieniędzy!',
	['purchased'] = 'zakupiłeś modyfikację!',
	['press_custom'] = 'wciśnij ~INPUT_PICKUP~ aby spersonalizować swój pojazd.',
	['level'] = 'level ',
	['neon'] = 'Xenon',
-- Paint Colors
	-- Black
	['black'] = 'czarny',
	['graphite'] = 'grafitowy',
	['black_metallic'] = 'czarny metalik',
	['caststeel'] = 'stalowy',
	['black_anth'] = 'czarny antracyt',
	['matteblack'] = 'czarny mat',
	['darknight'] = 'ciemna czerń',
	['deepblack'] = 'głęboka czerń',
	['oil'] = 'olej',
	['carbon'] = 'carbon',
	-- White
	['white'] = 'biały',
	['vanilla'] = 'wanilia',
	['creme'] = 'kremowy',
	['polarwhite'] = 'polarny biały',
	['beige'] = 'beżowy',
	['mattewhite'] = 'biały mat',
	['snow'] = 'śnieg',
	['cotton'] = 'bawełna',
	['alabaster'] = 'alabaster',
	['purewhite'] = 'czysta biel',
	-- Grey
	['grey'] = 'szary',
	['silver'] = 'srebrny',
	['metallicgrey'] = 'szary metalik',
	['laminatedsteel'] = 'laminowana stal',
	['darkgray'] = 'ciemna szarość',
	['rockygray'] = 'skalisty szary',
	['graynight'] = 'ciemny szary',
	['aluminum'] = 'aluminium',
	['graymat'] = 'szary mat',
	['lightgrey'] = 'jasny szary',
	['asphaltgray'] = 'asfalt szary',
	['grayconcrete'] = 'beton szary',
	['darksilver'] = 'ciemny srebrny',
	['magnesite'] = 'magnezyt',
	['nickel'] = 'nikiel',
	['zinc'] = 'cynk',
	['dolomite'] = 'dolomit',
	['bluesilver'] = 'niebieski srebrny',
	['titanium'] = 'tytan',
	['steelblue'] = 'stalowy niebieski',
	['champagne'] = 'szampanowy',
	['grayhunter'] = 'szary łowca',
	-- Red
	['red'] = 'czerowny',
	['torino_red'] = 'torino czerwony',
	['poppy'] = 'mak',
	['copper_red'] = 'czerwona miedź',
	['cardinal'] = 'mocny czerwony',
	['brick'] = 'czerwona cegła',
	['garnet'] = 'Garnet',
	['cabernet'] = 'cabernet czerwień',
	['candy'] = 'cukierkowa czerwnień',
	['matte_red'] = 'czerwony mat',
	['dark_red'] = 'ciemna czerwień',
	['red_pulp'] = 'czerwona pulpa',
	['bril_red'] = 'brylantowa czerwień',
	['pale_red'] = 'blada czerwień',
	['wine_red'] = 'czerwone wino',
	['volcano'] = 'wulkan',
	-- Pink
	['pink'] = 'różowy',
	['electricpink'] = 'elektryczny różowy',
	['brightpink'] = 'jasny różowy',
	['salmon'] = 'łosoś',
	['sugarplum'] = 'cikier śliwkowy',
	-- Blue
	['blue'] = 'niebieski',
	['topaz'] = 'topaz',
	['light_blue'] = 'jasny niebieski',
	['galaxy_blue'] = 'galaxy niebieski',
	['dark_blue'] = 'granatowy',
	['azure'] = 'błękit',
	['navy_blue'] = 'granatowy',
	['lapis'] = 'ciemny niebieski',
	['blue_diamond'] = 'diamentowy',
	['surfer'] = 'morski',
	['pastel_blue'] = 'pastelowy niebieski',
	['celeste_blue'] = 'celeste niebieski',
	['rally_blue'] = 'rally niebieski',
	['blue_paradise'] = 'niebieski raj',
	['blue_night'] = 'bardzo ciemny niebieski',
	['cyan_blue'] = 'cyjan',
	['cobalt'] = 'kobalt',
	['electric_blue'] = 'electric niebieski',
	['horizon_blue'] = 'horizon niebieski',
	['metallic_blue'] = 'metalniczny niebieski',
	['aquamarine'] = 'akwamaryn',
	['blue_agathe'] = 'niebieski agat',
	['zirconium'] = 'cyrkon',
	['spinel'] = 'spinel',
	['tourmaline'] = 'turmalin',
	['paradise'] = 'paradise',
	['bubble_gum'] = 'guma balonowa',
	['midnight_blue'] = 'północ',
	['forbidden_blue'] = 'zabroniony niebieski',
	['glacier_blue'] = 'lodowcowy',
	-- Yellow
	['yellow'] = 'żółty',
	['wheat'] = 'przeniczny',
	['raceyellow'] = 'żółty wyścigowy',
	['paleyellow'] = 'blady żółty',
	['lightyellow'] = 'jasny żółty',
	-- Green
	['green'] = 'zielony',
	['met_dark_green'] = 'mataliczny ciemny zielony',
	['rally_green'] = 'Rally zielony',
	['pine_green'] = 'sosnowy',
	['olive_green'] = 'oliwkowy',
	['light_green'] = 'jasny zielony',
	['lime_green'] = 'limonkowy',
	['forest_green'] = 'leśny',
	['lawn_green'] = 'trawiasty',
	['imperial_green'] = 'cesarski zielony',
	['green_bottle'] = 'butelkowy zielony',
	['citrus_green'] = 'cytrusowny zielony',
	['green_anis'] = 'zielony Anis',
	['khaki'] = 'Khaki',
	['army_green'] = 'moro',
	['dark_green'] = 'ciemny zielony',
	['hunter_green'] = 'łowiecki zielony',
	['matte_foilage_green'] = 'zielona matowa fiolia',
	-- Orange
	['orange'] = 'pomarańczowy',
	['tangerine'] = 'mandarynka',
	['matteorange'] = 'matowy pomaranczowy',
	['lightorange'] = 'jasny pomaranczowy',
	['peach'] = 'brzoskwiniowy',
	['pumpkin'] = 'dyniowy',
	['orangelambo'] = 'pomaranczowy lambo',
	-- Brown
	['brown'] = 'brązowy',
	['copper'] = 'miedź',
	['lightbrown'] = 'jasny brązowy',
	['darkbrown'] = 'ciemny brązowy',
	['bronze'] = 'brąz',
	['brownmetallic'] = 'brązowy metallic',
	['espresso'] = 'kawowy',
	['chocolate'] = 'czekoladowy',
	['terracotta'] = 'Terakota',
	['marble'] = 'marmurowy',
	['sand'] = 'piaskowy',
	['sepia'] = 'Sepia',
	['bison'] = 'Bizon',
	['palm'] = 'palmowy',
	['caramel'] = 'karmelowy',
	['rust'] = 'rdza',
	['chestnut'] = 'kasztan',
	['hazelnut'] = 'orzech laskowy',
	['shell'] = 'muszla',
	['mahogany'] = 'mahoń',
	['cauldron'] = 'kociołek',
	['blond'] = 'Blond',
	['gravel'] = 'żwirowy',
	['darkearth'] = 'ciemna ziemia',
	['desert'] = 'pustynny',
	-- Purple
	['purple'] = 'fioletowy',
	['indigo'] = 'Indigo',
	['deeppurple'] = 'głeboki fioletowy',
	['darkviolet'] = 'ciemny fiolet',
	['amethyst'] = 'ametyst',
	['mysticalviolet'] = 'mistyczny fiolet',
	['purplemetallic'] = 'fioletowy metalik',
	['matteviolet'] = 'matowy fiolet',
	['mattedeeppurple'] = 'głeboki matowy fiolet',
	-- Chrome
	['chrome'] = 'chrom',
	['brushedchrome'] = 'szczotkowany chrom',
	['blackchrome'] = 'czarny chrom',
	['brushedaluminum'] = 'szczotkowane aluminium',
	-- Metal
	['gold'] = 'złoty',
	['puregold'] = 'czyste złoto',
	['brushedgold'] = 'szczotkowane złoto',
	['lightgold'] = 'jasny złoty',
-- License Plates
	['blue_on_white_1'] = 'niebieski na białym 1',
	['yellow_on_black'] = 'żółty na czarnym',
	['yellow_blue'] = 'żółty na niebieskim',
	['blue_on_white_2'] = 'niebieski na białym 2',
	['blue_on_white_3'] = 'niebieski na białym 3',
-- Upgrades
	['upgrades'] = 'ulepszenia',
	['engine'] = 'silnik',
	['brakes'] = 'hamulce',
	['transmission'] = 'skrzynia biegów',
	['suspension'] = 'zawieszenie',
	['armor'] = 'pancerz',
	['turbo'] = 'turbo',
	['no_turbo'] = 'no turbo',
-- Cosmetics
	['cosmetics'] = 'detale',
	-- Body Parts
	['bodyparts'] = 'części auta',
	['leftfender'] = 'lewy błotnik',
	['rightfender'] = 'prawy błotnik',
	['spoilers'] = 'spoilery',
	['sideskirt'] = 'progi',
	['cage'] = 'klatka',
	['hood'] = 'maska',
	['grille'] = 'grile',
	['rearbumper'] = 'tylni zderzak',
	['frontbumper'] = 'przedni zderzak',
	['exhaust'] = 'tłumik',
	['roof'] = 'dach',
	-- Paint
	['respray'] = 'lakier',
	['primary'] = 'podstawowy',
	['secondary'] = 'drugi kolor',
	['pearlescent'] = 'perła',
	-- Misc
	['headlights'] = 'reflektory',
	['licenseplates'] = 'tablica rejestracyjna',
	['windowtint'] = 'przyciemniane okna',
	['horns'] = 'klakson',
	-- Neon
	['neons'] = 'neony',
	-- Wheels
	['wheels'] = 'koła',
	['tiresmoke'] = 'dym z opon',
	['wheel_type'] = 'typ kół',
	['wheel_color'] = 'kolor kół',
	['sport'] = 'sport',
	['muscle'] = 'muscle',
	['lowrider'] = 'lowrider',
	['suv'] = 'SUV',
	['allterrain'] = 'all terrain',
	['tuning'] = 'tuning',
	['motorcycle'] = 'motorcycle',
	['highend'] = 'high end',
	
	['modplateholder'] = 'tablica - Back',
	['modvanityplate'] = 'tablica - Front',
	['interior'] = 'wnętrze',
	['trim'] = 'wykończenie',
	['dashboard'] = 'deska rozdzielcza',
	['speedometer'] = 'prędkościomierz',
	['door_speakers'] = 'głosniki na drzwiach',
	['seats'] = 'fotele',
	['steering_wheel'] = 'kierownica',
	['gear_lever'] = 'dźwignia zmiany biegó',
	['quarter_deck'] = 'quarter-deck',
	['speakers'] = 'głosniki',
	['trunk'] = 'bagażnik',
	['hydraulic'] = 'hydraulika',
	['engine_block'] = 'blok silnika',
	['air_filter'] = 'filtr powietrza',
	['struts'] = 'struts',
	['arch_cover'] = 'arch cover',
	['aerials'] = 'anteny',
	['wings'] = 'skrzydła',
	['fuel_tank'] = 'bak paliwa',
	['windows'] = 'szyby',
	['stickers'] = 'naklejki',
}