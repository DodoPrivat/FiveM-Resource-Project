Locales['en'] = {
  ['prompt_wash'] = 'Naciśnij ~INPUT_CONTEXT~ aby umyc pojazd',
  ['prompt_wash_paid'] = 'Naciśnij ~INPUT_CONTEXT~ aby umyć pojazd za ~g~$%s~s~',
  ['wash_failed'] = 'Nie stać cię na myjnie',
  ['wash_failed_clean'] = 'Twój pojazd jest czysty',
  ['wash_successful'] = 'Twój pojazd został umyty',
  ['wash_successful_paid'] = 'Twój pojazd został umyty za ~g~$%s~s~',
  ['blip_carwash'] = 'Myjnia Samochodowa',
}
Locales['en'] = {
  ['prompt_wash'] = 'Naciśnij ~INPUT_CONTEXT~ aby umyc pojazd',
  ['prompt_wash_paid'] = 'Naciśnij ~INPUT_CONTEXT~ aby umyć pojazd za ~g~$%s~s~',
  ['wash_failed'] = 'Nie stać cię na myjnie',
  ['wash_failed_clean'] = 'Twój pojazd jest czysty',
  ['wash_successful'] = 'Twój pojazd został umyty',
  ['wash_successful_paid'] = 'Twój pojazd został umyty za ~g~$%s~s~',
  ['blip_carwash'] = 'Myjnia Samochodowa',
}
