Config = {}

Config.Locale = 'en'

Config.EnablePrice = true
Config.Price = 50

Config.Locations = {
	vector3(26.5906, -1392.0261, 27.3634),
	vector3(167.1034, -1719.4704, 27.2916),
	vector3(-74.5693, 6427.8715, 29.4400),
	vector3(-699.6325, -932.7043, 17.0139)
}Config = {}

Config.Locale = 'en'

Config.EnablePrice = true
Config.Price = 50

Config.Locations = {
	vector3(26.5906, -1392.0261, 27.3634),
	vector3(167.1034, -1719.4704, 27.2916),
	vector3(-74.5693, 6427.8715, 29.4400),
	vector3(-699.6325, -932.7043, 17.0139)
}