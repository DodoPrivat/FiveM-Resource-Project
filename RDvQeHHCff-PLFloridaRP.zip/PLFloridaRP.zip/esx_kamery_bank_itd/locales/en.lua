Locales['en'] = {
  -- Marker Hint
  	['marker_hint'] = 'Kliknij ~INPUT_CONTEXT~ aby polaczyc sie z  ~g~kamerami~s~',
	
	-- Menu
	['securitycams_menu'] = 'Monitoring',
	['bank_menu_selection'] = 'Pacyfik Bank',
	['police_menu_selection'] = 'Komenda',
	
	-- In Cameras
	['pacific_standard_bank'] = 'Pacyfik Bank',
	['police_station'] = 'Komenda',
	
	-- Pacific Standard Bank Cameras
	['bcam'] = 'Glowne wejscie',
	['bcam2'] = 'Poczekalnia',
	['bcam3'] = 'Drugie wejscie',
	['bcam4'] = 'Schody do drugiego pietra',
	['bcam5'] = 'Schody nad skarbcem',
	['bcam6'] = 'Korytarz biurowy #1',
	['bcam7'] = 'Korytarz biurowy #2',
	['bcam8'] = 'Drugie pietro #1',
	['bcam9'] = 'Drugie pietro #2',
	['bcam10'] = 'Schody do skarbca bankowego',
	['bcam11'] = 'Poza skarbcem bankowym',
	
	-- Police Station Cameras
	['pcam'] = 'Parking',
	['pcam2'] = 'Cela 1',
	['pcam3'] = 'Cela 2',
	['pcam4'] = 'Cela 3',
	['pcam5'] = 'Policyjny parking i garaz',
	['pcam6'] = 'Dzwi wejsciowe',
	['pcam7'] = 'Poczekalnia',
}
Locales['en'] = {
  -- Marker Hint
  	['marker_hint'] = 'Kliknij ~INPUT_CONTEXT~ aby polaczyc sie z  ~g~kamerami~s~',
	
	-- Menu
	['securitycams_menu'] = 'Monitoring',
	['bank_menu_selection'] = 'Pacyfik Bank',
	['police_menu_selection'] = 'Komenda',
	
	-- In Cameras
	['pacific_standard_bank'] = 'Pacyfik Bank',
	['police_station'] = 'Komenda',
	
	-- Pacific Standard Bank Cameras
	['bcam'] = 'Glowne wejscie',
	['bcam2'] = 'Poczekalnia',
	['bcam3'] = 'Drugie wejscie',
	['bcam4'] = 'Schody do drugiego pietra',
	['bcam5'] = 'Schody nad skarbcem',
	['bcam6'] = 'Korytarz biurowy #1',
	['bcam7'] = 'Korytarz biurowy #2',
	['bcam8'] = 'Drugie pietro #1',
	['bcam9'] = 'Drugie pietro #2',
	['bcam10'] = 'Schody do skarbca bankowego',
	['bcam11'] = 'Poza skarbcem bankowym',
	
	-- Police Station Cameras
	['pcam'] = 'Parking',
	['pcam2'] = 'Cela 1',
	['pcam3'] = 'Cela 2',
	['pcam4'] = 'Cela 3',
	['pcam5'] = 'Policyjny parking i garaz',
	['pcam6'] = 'Dzwi wejsciowe',
	['pcam7'] = 'Poczekalnia',
}
