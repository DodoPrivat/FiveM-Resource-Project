Config = {}
Config.Locale = 'en'

Config.DoorList = {

	--
	-- Mission Row First Floor
	--

	-- Entrance Doors
	{
		objName = 'v_ilev_ph_door01',
		objCoords  = {x = 434.747, y = -980.618, z = 30.839},
		textCoords = {x = 434.747, y = -981.50, z = 31.50},
		authorizedJobs = { 'police' },
		locked = false,
		distance = 2.5
	},

	{
		objName = 'v_ilev_ph_door002',
		objCoords  = {x = 434.747, y = -983.215, z = 30.839},
		textCoords = {x = 434.747, y = -982.50, z = 31.50},
		authorizedJobs = { 'police' },
		locked = false,
		distance = 2.5
	},

	-- To locker room & roof
	{
		objName = 'v_ilev_ph_gendoor004',
		objCoords  = {x = 449.698, y = -986.469, z = 30.689},
		textCoords = {x = 450.104, y = -986.388, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Rooftop
	{
		objName = 'v_ilev_gtdoor02',
		objCoords  = {x = 464.361, y = -984.678, z = 43.834},
		textCoords = {x = 464.361, y = -984.050, z = 44.834},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Hallway to roof
	{
		objName = 'v_ilev_arm_secdoor',
		objCoords  = {x = 461.286, y = -985.320, z = 30.839},
		textCoords = {x = 461.50, y = -986.00, z = 31.50},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Armory
	{
		objName = 'v_ilev_arm_secdoor',
		objCoords  = {x = 452.618, y = -982.702, z = 30.689},
		textCoords = {x = 453.079, y = -982.600, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Captain Office
	{
		objName = 'v_ilev_ph_gendoor002',
		objCoords  = {x = 447.238, y = -980.630, z = 30.689},
		textCoords = {x = 447.200, y = -980.010, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- To downstairs (double doors)
	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 443.97, y = -989.033, z = 30.6896},
		textCoords = {x = 444.020, y = -989.445, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},

	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 445.37, y = -988.705, z = 30.6896},
		textCoords = {x = 445.350, y = -989.445, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},
	
	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 446.55, y = -986.23, z = 26.6896},
		textCoords = {x = 446.25, y = -985.51, z = 27.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},
	
	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 446.55, y = -987.23, z = 26.6896},
		textCoords = {x = 446.25, y = -987.51, z = 27.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},
	
	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 452.92, y = -984.11, z = 26.6896},
		textCoords = {x = 452.95, y = -984.11, z = 27.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},
	
	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 451.44, y = -984.31, z = 26.6896},
		textCoords = {x = 451.15, y = -984.11, z = 27.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},
	
	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 458.64, y = -982.61, z = 26.6896},
		textCoords = {x = 458.62, y = -982.61, z = 27.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},

	-- 
	-- Mission Row Cells
	--

	-- Main Cells
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 463.815, y = -992.686, z = 24.9149},
		textCoords = {x = 463.30, y = -992.686, z = 25.10},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 1
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 462.381, y = -993.651, z = 24.914},
		textCoords = {x = 461.806, y = -993.308, z = 25.064},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 2
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 462.331, y = -998.152, z = 24.914},
		textCoords = {x = 461.806, y = -998.800, z = 25.064},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 3
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 462.704, y = -1001.92, z = 24.9149},
		textCoords = {x = 461.806, y = -1002.450, z = 25.064},
		authorizedJobs = { 'police' },
		locked = true
	},
	
	-- Cell 4
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 465.404, y = -998.92, z = 24.9149},
		textCoords = {x = 465.906, y = -998.31, z = 25.664},
		authorizedJobs = { 'police' },
		locked = true
	},
	
	-- Cell 5
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 465.404, y = -1001.90, z = 24.9149},
		textCoords = {x = 465.906, y = -1001.90, z = 25.664},
		authorizedJobs = { 'police' },
		locked = true
	},
	
	-- Cell 6
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 441.304, y = -986.02, z = 26.67},
		textCoords = {x = 440.72,  y = -986.19, z = 27.164},
		authorizedJobs = { 'police' },
		locked = true
	},
	
	-- Cell 7
	{
		objName = 'v_ilev_gtdoor',
		objCoords  = {x = 441.304, y = -982.36, z = 26.67},
		textCoords = {x = 440.72,  y = -982.39, z = 27.164},
		authorizedJobs = { 'police' },
		locked = true
	},




	-- To Back
	{
		objName = 'v_ilev_gtdoor',
		objCoords  = {x = 463.478, y = -1003.538, z = 25.005},
		textCoords = {x = 464.00, y = -1003.50, z = 25.50},
		authorizedJobs = { 'police' },
		locked = true
	},

	--
	-- Mission Row Back
	--

	-- Back (double doors)
	{
		objName = 'v_ilev_rc_door2',
		objCoords  = {x = 467.371, y = -1014.452, z = 26.536},
		textCoords = {x = 468.09, y = -1014.452, z = 27.1362},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},

	{
		objName = 'v_ilev_rc_door2',
		objCoords  = {x = 469.967, y = -1014.452, z = 26.536},
		textCoords = {x = 469.35, y = -1014.452, z = 27.136},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},

	-- Back Gate
	{
		objName = 'hei_prop_station_gate',
		objCoords  = {x = 488.894, y = -1017.210, z = 27.146},
		textCoords = {x = 488.894, y = -1020.210, z = 30.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 14,
		size = 2
	},

	--
	-- Sandy Shores
	--

	-- Entrance
	{
		objName = 'v_ilev_shrfdoor',
		objCoords  = {x = 1855.105, y = 3683.516, z = 34.266},
		textCoords = {x = 1855.105, y = 3683.516, z = 35.00},
		authorizedJobs = { 'police' },
		locked = false
	},

	--
	-- Paleto Bay
	--


	--
	-- Bolingbroke Penitentiary
	--

	-- Entrance (Two big gates)
	{
		objName = 'prop_gate_prison_01',
		objCoords  = {x = 1844.998, y = 2604.810, z = 44.638},
		textCoords = {x = 1844.998, y = 2608.50, z = 48.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 12,
		size = 2
	},

	{
		objName = 'prop_gate_prison_01',
		objCoords  = {x = 1818.542, y = 2604.812, z = 44.611},
		textCoords = {x = 1818.542, y = 2608.40, z = 48.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 12,
		size = 2
	},
	
	-- Sandy Shores
	

	-- Wejście
	
	-- interior drzwi wejściowe
	{
		objName = 'v_ilev_cd_entrydoor',
		objCoords  = {x = 1847.803, y = 3681.012, z = -118.61},
		textCoords = {x = 1847.57, y = 3681.68, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},
	
	-- cela 1
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = 1843.56 , y = 3681.81, z = -118.61},
		textCoords = {x = 1844.18, y = 3682.28, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- cela 2
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = 1839.22 , y = 3679.32, z = -118.61},
		textCoords = {x = 1839.91, y = 3679.7, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},
	
		-- cela 3
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = 1834.82 , y = 3676.79, z = -118.61},
		textCoords = {x = 1835.5, y = 3677.2, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},
	
			-- office
	{
		objName = 'v_ilev_cf_officedoor',
		objCoords  = {x = 1840.38 , y = 3675.24, z = -118.61},
		textCoords = {x = 1839.88, y = 3674.89, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},
	
				-- magazyn
	{
		objName = 'v_ilev_ct_door03',
		objCoords  = {x = 1833.166 , y = 3672.375, z = -118.61},
		textCoords = {x = 1832.84, y = 3672.99, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},

				-- brama 1
	{
		objName = 'Prop_FacGate_07',
		objCoords  = {x =1876.56000000, y =3687.71700000, z = 32.47269000},
		textCoords = {x = 1873.37, y =3685.3, z = 34.0},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 10
	},
	
				-- brama 2
	{
			objName = 'Prop_FacGate_07',
		objCoords  = {x =1857.64200000, y =3720.23400000, z = 32.01468000},
		textCoords = {x = 1854.06, y =3718.22, z = 33.6},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 15
	},
	
	--
	-- Paleto Bay
	--

	-- Entrance (double doors)
	{
		objName = 'v_ilev_shrf2door',
		objCoords  = {x = -443.14, y = 6015.685, z = 31.716},
		textCoords = {x = -443.14, y = 6015.685, z = 32.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},

	{
		objName = 'v_ilev_shrf2door',
		objCoords  = {x = -443.951, y = 6016.622, z = 31.716},
		textCoords = {x = -443.951, y = 6016.622, z = 32.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},
	
	-- brama wjazdowa
	{
		objName = 'prop_fnclink_03gate2',
		objCoords  = {x =-455.8608, y =6030.072, z = 30.42296},
		textCoords = {x = -453.76, y =6028.48, z = 32.5},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 10
	},	
	
		-- furtka 1
	{
		objName = 'prop_fnclink_03gate5',
		objCoords  = {x =-450.5025, y =6025.146, z = 32.11588},
		textCoords = {x = -449.91, y =6024.56, z = 32.5},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},	
	
		-- furtka 2
	{
		objName = 'prop_fnclink_03gate5',
		objCoords  = {x =-429.9867, y =5985.706, z = 32.14349},
		textCoords = {x = -430.53, y =5986.24, z = 32.5},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},		
	
		-- furtka 3
	{
		objName = 'prop_fnclink_03gate5',
		objCoords  = {x =-432.3989, y =5988.055, z = 32.14349},
		textCoords = {x = -431.79, y =5987.45, z = 32.5},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},		
	
		-- furtka 4
	
	{
		objName = 'prop_fnclink_09gate1',
		objCoords  = {x =-463.5563, y =5998.9, z =31.5},
		textCoords = {x = -462.44, y = 5998.38, z =31.7},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},

	
	-- Interior #1
	{
		objName = 'v_ilev_shrf2door',
		objCoords  = {x = 2456.68359, y = -830.881104, z = -37.116539},
		textCoords = {x = 2456.99, y = -831.45, z = -37.0},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},
	
	{
		objName = 'v_ilev_shrf2door',
		objCoords  = {x = 2456.68359, y = -830.881104, z = -37.116539},
		textCoords = {x = 2457.93, y = -832.39, z = -37.0},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},
	
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = 2452.67383, y = -832.231567, z = -37.1494827},
		textCoords = {x = 2453.05, y = -831.66, z = -37.0},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},
	
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x =2446.66797, y =-837.27063, z = -37.1494827},
		textCoords = {x = 2447.26, y = -836.83, z = -37.0},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},
	
	
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x =2452.68604, y =-837.907959, z = -37.1414757},
		textCoords = {x = 2453.3, y = -837.47, z = -37.0},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},
	
	{
		objName = 'apa_v_ilev_ss_door2',
		objCoords  = {x =2448.20605, y =-839.416626, z = -37.116539},
		textCoords = {x = 2448.64, y = -840.01, z = -37.0},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},
	
	
	-- Interior #2


	-- interior drzwi wejściowe
	{
		objName = 'v_ilev_cd_entrydoor',
		objCoords  = {x = -439.6891, y = 6009.335, z = -118.6},
		textCoords = {x = -440.14, y = 6008.93, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},
	
	-- cela 1
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = -440.43 , y = 6006.09, z = -118.6},
		textCoords = {x = -439.89, y = 6005.58, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- cela 2
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = -436.8454 , y = 6002.526, z = -118.6},
		textCoords = {x = -436.29, y = 6001.94, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},

		-- cela 3
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = -433.2945 , y = 5998.974, z = -118.6},
		textCoords = {x = -432.83, y = 5998.32, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},

			-- office
	{
		objName = 'v_ilev_cf_officedoor',
		objCoords  = {x = -432.1771 , y = 6003.758, z = -118.6},
		textCoords = {x = -431.75, y = 6003.32, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},

				-- magazyn
	{
		objName = 'v_ilev_ct_door03',
		objCoords  = {x = -427.8249 , y = 5997.735, z = -118.6},
		textCoords = {x = -428.33, y = 5997.27, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},

	--
	-- Więzienie
	--

	-- Entrance (Two big gates)
	{
		objName = 'prop_gate_prison_01',
		objCoords  = {x = 1844.998, y = 2604.810, z = 44.638},
		textCoords = {x = 1844.998, y = 2608.50, z = 48.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 12,
		size = 2
	},

	{
		objName = 'prop_gate_prison_01',
		objCoords  = {x = 1818.542, y = 2604.812, z = 44.611},
		textCoords = {x = 1818.542, y = 2608.40, z = 48.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 12,
		size = 2
	},

	--
	-- Addons
	--

	--[[
	-- Entrance Gate (Mission Row mod) https://www.gta5-mods.com/maps/mission-row-pd-ymap-fivem-v1
	{
		objName = 'prop_gate_airport_01',
		objCoords  = {x = 420.133, y = -1017.301, z = 28.086},
		textCoords = {x = 420.133, y = -1021.00, z = 32.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 14,
		size = 2
	}
	--]]
}Config = {}
Config.Locale = 'en'

Config.DoorList = {

	--
	-- Mission Row First Floor
	--

	-- Entrance Doors
	{
		objName = 'v_ilev_ph_door01',
		objCoords  = {x = 434.747, y = -980.618, z = 30.839},
		textCoords = {x = 434.747, y = -981.50, z = 31.50},
		authorizedJobs = { 'police' },
		locked = false,
		distance = 2.5
	},

	{
		objName = 'v_ilev_ph_door002',
		objCoords  = {x = 434.747, y = -983.215, z = 30.839},
		textCoords = {x = 434.747, y = -982.50, z = 31.50},
		authorizedJobs = { 'police' },
		locked = false,
		distance = 2.5
	},

	-- To locker room & roof
	{
		objName = 'v_ilev_ph_gendoor004',
		objCoords  = {x = 449.698, y = -986.469, z = 30.689},
		textCoords = {x = 450.104, y = -986.388, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Rooftop
	{
		objName = 'v_ilev_gtdoor02',
		objCoords  = {x = 464.361, y = -984.678, z = 43.834},
		textCoords = {x = 464.361, y = -984.050, z = 44.834},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Hallway to roof
	{
		objName = 'v_ilev_arm_secdoor',
		objCoords  = {x = 461.286, y = -985.320, z = 30.839},
		textCoords = {x = 461.50, y = -986.00, z = 31.50},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Armory
	{
		objName = 'v_ilev_arm_secdoor',
		objCoords  = {x = 452.618, y = -982.702, z = 30.689},
		textCoords = {x = 453.079, y = -982.600, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Captain Office
	{
		objName = 'v_ilev_ph_gendoor002',
		objCoords  = {x = 447.238, y = -980.630, z = 30.689},
		textCoords = {x = 447.200, y = -980.010, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- To downstairs (double doors)
	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 443.97, y = -989.033, z = 30.6896},
		textCoords = {x = 444.020, y = -989.445, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},

	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 445.37, y = -988.705, z = 30.6896},
		textCoords = {x = 445.350, y = -989.445, z = 31.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},
	
	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 446.55, y = -986.23, z = 26.6896},
		textCoords = {x = 446.25, y = -985.51, z = 27.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},
	
	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 446.55, y = -987.23, z = 26.6896},
		textCoords = {x = 446.25, y = -987.51, z = 27.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},
	
	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 452.92, y = -984.11, z = 26.6896},
		textCoords = {x = 452.95, y = -984.11, z = 27.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},
	
	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 451.44, y = -984.31, z = 26.6896},
		textCoords = {x = 451.15, y = -984.11, z = 27.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},
	
	{
		objName = 'v_ilev_ph_gendoor005',
		objCoords  = {x = 458.64, y = -982.61, z = 26.6896},
		textCoords = {x = 458.62, y = -982.61, z = 27.739},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},

	-- 
	-- Mission Row Cells
	--

	-- Main Cells
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 463.815, y = -992.686, z = 24.9149},
		textCoords = {x = 463.30, y = -992.686, z = 25.10},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 1
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 462.381, y = -993.651, z = 24.914},
		textCoords = {x = 461.806, y = -993.308, z = 25.064},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 2
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 462.331, y = -998.152, z = 24.914},
		textCoords = {x = 461.806, y = -998.800, z = 25.064},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- Cell 3
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 462.704, y = -1001.92, z = 24.9149},
		textCoords = {x = 461.806, y = -1002.450, z = 25.064},
		authorizedJobs = { 'police' },
		locked = true
	},
	
	-- Cell 4
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 465.404, y = -998.92, z = 24.9149},
		textCoords = {x = 465.906, y = -998.31, z = 25.664},
		authorizedJobs = { 'police' },
		locked = true
	},
	
	-- Cell 5
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 465.404, y = -1001.90, z = 24.9149},
		textCoords = {x = 465.906, y = -1001.90, z = 25.664},
		authorizedJobs = { 'police' },
		locked = true
	},
	
	-- Cell 6
	{
		objName = 'v_ilev_ph_cellgate',
		objCoords  = {x = 441.304, y = -986.02, z = 26.67},
		textCoords = {x = 440.72,  y = -986.19, z = 27.164},
		authorizedJobs = { 'police' },
		locked = true
	},
	
	-- Cell 7
	{
		objName = 'v_ilev_gtdoor',
		objCoords  = {x = 441.304, y = -982.36, z = 26.67},
		textCoords = {x = 440.72,  y = -982.39, z = 27.164},
		authorizedJobs = { 'police' },
		locked = true
	},




	-- To Back
	{
		objName = 'v_ilev_gtdoor',
		objCoords  = {x = 463.478, y = -1003.538, z = 25.005},
		textCoords = {x = 464.00, y = -1003.50, z = 25.50},
		authorizedJobs = { 'police' },
		locked = true
	},

	--
	-- Mission Row Back
	--

	-- Back (double doors)
	{
		objName = 'v_ilev_rc_door2',
		objCoords  = {x = 467.371, y = -1014.452, z = 26.536},
		textCoords = {x = 468.09, y = -1014.452, z = 27.1362},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},

	{
		objName = 'v_ilev_rc_door2',
		objCoords  = {x = 469.967, y = -1014.452, z = 26.536},
		textCoords = {x = 469.35, y = -1014.452, z = 27.136},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 4
	},

	-- Back Gate
	{
		objName = 'hei_prop_station_gate',
		objCoords  = {x = 488.894, y = -1017.210, z = 27.146},
		textCoords = {x = 488.894, y = -1020.210, z = 30.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 14,
		size = 2
	},

	--
	-- Sandy Shores
	--

	-- Entrance
	{
		objName = 'v_ilev_shrfdoor',
		objCoords  = {x = 1855.105, y = 3683.516, z = 34.266},
		textCoords = {x = 1855.105, y = 3683.516, z = 35.00},
		authorizedJobs = { 'police' },
		locked = false
	},

	--
	-- Paleto Bay
	--


	--
	-- Bolingbroke Penitentiary
	--

	-- Entrance (Two big gates)
	{
		objName = 'prop_gate_prison_01',
		objCoords  = {x = 1844.998, y = 2604.810, z = 44.638},
		textCoords = {x = 1844.998, y = 2608.50, z = 48.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 12,
		size = 2
	},

	{
		objName = 'prop_gate_prison_01',
		objCoords  = {x = 1818.542, y = 2604.812, z = 44.611},
		textCoords = {x = 1818.542, y = 2608.40, z = 48.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 12,
		size = 2
	},
	
	-- Sandy Shores
	

	-- Wejście
	
	-- interior drzwi wejściowe
	{
		objName = 'v_ilev_cd_entrydoor',
		objCoords  = {x = 1847.803, y = 3681.012, z = -118.61},
		textCoords = {x = 1847.57, y = 3681.68, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},
	
	-- cela 1
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = 1843.56 , y = 3681.81, z = -118.61},
		textCoords = {x = 1844.18, y = 3682.28, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- cela 2
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = 1839.22 , y = 3679.32, z = -118.61},
		textCoords = {x = 1839.91, y = 3679.7, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},
	
		-- cela 3
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = 1834.82 , y = 3676.79, z = -118.61},
		textCoords = {x = 1835.5, y = 3677.2, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},
	
			-- office
	{
		objName = 'v_ilev_cf_officedoor',
		objCoords  = {x = 1840.38 , y = 3675.24, z = -118.61},
		textCoords = {x = 1839.88, y = 3674.89, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},
	
				-- magazyn
	{
		objName = 'v_ilev_ct_door03',
		objCoords  = {x = 1833.166 , y = 3672.375, z = -118.61},
		textCoords = {x = 1832.84, y = 3672.99, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},

				-- brama 1
	{
		objName = 'Prop_FacGate_07',
		objCoords  = {x =1876.56000000, y =3687.71700000, z = 32.47269000},
		textCoords = {x = 1873.37, y =3685.3, z = 34.0},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 10
	},
	
				-- brama 2
	{
			objName = 'Prop_FacGate_07',
		objCoords  = {x =1857.64200000, y =3720.23400000, z = 32.01468000},
		textCoords = {x = 1854.06, y =3718.22, z = 33.6},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 15
	},
	
	--
	-- Paleto Bay
	--

	-- Entrance (double doors)
	{
		objName = 'v_ilev_shrf2door',
		objCoords  = {x = -443.14, y = 6015.685, z = 31.716},
		textCoords = {x = -443.14, y = 6015.685, z = 32.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},

	{
		objName = 'v_ilev_shrf2door',
		objCoords  = {x = -443.951, y = 6016.622, z = 31.716},
		textCoords = {x = -443.951, y = 6016.622, z = 32.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},
	
	-- brama wjazdowa
	{
		objName = 'prop_fnclink_03gate2',
		objCoords  = {x =-455.8608, y =6030.072, z = 30.42296},
		textCoords = {x = -453.76, y =6028.48, z = 32.5},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 10
	},	
	
		-- furtka 1
	{
		objName = 'prop_fnclink_03gate5',
		objCoords  = {x =-450.5025, y =6025.146, z = 32.11588},
		textCoords = {x = -449.91, y =6024.56, z = 32.5},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},	
	
		-- furtka 2
	{
		objName = 'prop_fnclink_03gate5',
		objCoords  = {x =-429.9867, y =5985.706, z = 32.14349},
		textCoords = {x = -430.53, y =5986.24, z = 32.5},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},		
	
		-- furtka 3
	{
		objName = 'prop_fnclink_03gate5',
		objCoords  = {x =-432.3989, y =5988.055, z = 32.14349},
		textCoords = {x = -431.79, y =5987.45, z = 32.5},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},		
	
		-- furtka 4
	
	{
		objName = 'prop_fnclink_09gate1',
		objCoords  = {x =-463.5563, y =5998.9, z =31.5},
		textCoords = {x = -462.44, y = 5998.38, z =31.7},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},

	
	-- Interior #1
	{
		objName = 'v_ilev_shrf2door',
		objCoords  = {x = 2456.68359, y = -830.881104, z = -37.116539},
		textCoords = {x = 2456.99, y = -831.45, z = -37.0},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},
	
	{
		objName = 'v_ilev_shrf2door',
		objCoords  = {x = 2456.68359, y = -830.881104, z = -37.116539},
		textCoords = {x = 2457.93, y = -832.39, z = -37.0},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},
	
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = 2452.67383, y = -832.231567, z = -37.1494827},
		textCoords = {x = 2453.05, y = -831.66, z = -37.0},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},
	
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x =2446.66797, y =-837.27063, z = -37.1494827},
		textCoords = {x = 2447.26, y = -836.83, z = -37.0},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},
	
	
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x =2452.68604, y =-837.907959, z = -37.1414757},
		textCoords = {x = 2453.3, y = -837.47, z = -37.0},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},
	
	{
		objName = 'apa_v_ilev_ss_door2',
		objCoords  = {x =2448.20605, y =-839.416626, z = -37.116539},
		textCoords = {x = 2448.64, y = -840.01, z = -37.0},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 2.5
	},
	
	
	-- Interior #2


	-- interior drzwi wejściowe
	{
		objName = 'v_ilev_cd_entrydoor',
		objCoords  = {x = -439.6891, y = 6009.335, z = -118.6},
		textCoords = {x = -440.14, y = 6008.93, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},
	
	-- cela 1
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = -440.43 , y = 6006.09, z = -118.6},
		textCoords = {x = -439.89, y = 6005.58, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},

	-- cela 2
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = -436.8454 , y = 6002.526, z = -118.6},
		textCoords = {x = -436.29, y = 6001.94, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},

		-- cela 3
	{
		objName = 'prop_ld_jail_door',
		objCoords  = {x = -433.2945 , y = 5998.974, z = -118.6},
		textCoords = {x = -432.83, y = 5998.32, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},

			-- office
	{
		objName = 'v_ilev_cf_officedoor',
		objCoords  = {x = -432.1771 , y = 6003.758, z = -118.6},
		textCoords = {x = -431.75, y = 6003.32, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},

				-- magazyn
	{
		objName = 'v_ilev_ct_door03',
		objCoords  = {x = -427.8249 , y = 5997.735, z = -118.6},
		textCoords = {x = -428.33, y = 5997.27, z = -118.5},
		authorizedJobs = { 'police' },
		locked = true
	},

	--
	-- Więzienie
	--

	-- Entrance (Two big gates)
	{
		objName = 'prop_gate_prison_01',
		objCoords  = {x = 1844.998, y = 2604.810, z = 44.638},
		textCoords = {x = 1844.998, y = 2608.50, z = 48.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 12,
		size = 2
	},

	{
		objName = 'prop_gate_prison_01',
		objCoords  = {x = 1818.542, y = 2604.812, z = 44.611},
		textCoords = {x = 1818.542, y = 2608.40, z = 48.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 12,
		size = 2
	},

	--
	-- Addons
	--

	--[[
	-- Entrance Gate (Mission Row mod) https://www.gta5-mods.com/maps/mission-row-pd-ymap-fivem-v1
	{
		objName = 'prop_gate_airport_01',
		objCoords  = {x = 420.133, y = -1017.301, z = 28.086},
		textCoords = {x = 420.133, y = -1021.00, z = 32.00},
		authorizedJobs = { 'police' },
		locked = true,
		distance = 14,
		size = 2
	}
	--]]
}