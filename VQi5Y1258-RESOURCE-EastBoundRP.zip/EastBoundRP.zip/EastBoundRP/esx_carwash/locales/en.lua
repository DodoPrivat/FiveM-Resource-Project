Locales['en'] = {
  ['prompt_wash'] = 'Press ~INPUT_CONTEXT~ to wash this vehicle',
  ['prompt_wash_paid'] = 'Press ~INPUT_CONTEXT~ to wash this vehicle for ~g~$%s~s~',
  ['wash_failed'] = 'You cannot afford an car wash',
  ['wash_failed_clean'] = 'Your vehicle does not need a car wash.',
  ['wash_successful'] = 'Your vehicle has been washed',
  ['wash_successful_paid'] = 'Your vehicle has been washed for ~g~$%s~s~',
  ['blip_carwash'] = 'Car Wash',
}
