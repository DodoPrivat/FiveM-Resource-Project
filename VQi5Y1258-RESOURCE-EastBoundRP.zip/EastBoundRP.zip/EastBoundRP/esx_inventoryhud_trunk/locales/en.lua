Locales["en"] = {
  ["trunk_closed"] = "This trunk is closed.",
  ["no_veh_nearby"] = "There is no vehicle nearby.",
  ["trunk_in_use"] = "This trunk is already in use.",
  ["trunk_full"] = "This trunk is full.",
  ["invalid_quantity"] = "Invalid number",
  ["cant_carry_more"] = "You can no longer carry with you.",
  ["nacho_veh"] = "This is not your vehicle.",
  ["invalid_amount"] = "Invalid number",
  ["insufficient_space"] = "Too little storage space",
  ["trunk_info"] = "<h3>Trunk</h3><br><strong>License Plate:</strong> %s<br><strong>Capacity:</strong> %s / %s",
  ["player_inv_no_space"] = "There is not enough space in your inventory for this item!"
}
