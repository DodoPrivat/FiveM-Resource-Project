ESX = nil
local limping = false
local headache = false
local painkiller = false

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if GetEntityHealth(GetPlayerPed(-1)) <= 169 then --69% health
            limping = true
            RequestAnimSet("move_m@injured")
            SetPedMovementClipset(GetPlayerPed(-1), "move_m@injured", true)
		elseif painkiller == false and GetEntityHealth(GetPlayerPed(-1)) <= 140 then -- 40% health
		    headache = true
            headache()	
        elseif limping == true and GetEntityHealth(GetPlayerPed(-1)) >= 170 then -- 70% health
		    limping = false
			headache = false
            ResetPedMovementClipset(GetPlayerPed(-1))
            ResetPedWeaponMovementClipset(GetPlayerPed(-1))
            ResetPedStrafeClipset(GetPlayerPed(-1))
        end
    end
end)

function headache()
    if headache == true and painkiller == false then
        Citizen.Wait(2000)
        ShakeGameplayCam('MEDIUM_EXPLOSION_SHAKE', 0.05)
	    if GetEntityHealth(GetPlayerPed(-1)) >= 140 then
	        headache = false
	    end
	end
end

RegisterNetEvent('april:medkit')
AddEventHandler('april:medkit', function()
    if limping == true then
        SetEntityHealth(GetPlayerPed(-1), GetEntityMaxHealth(GetPlayerPed(-1)))
	else
	    TriggerServerEvent("april:return1", source)
		ESX.ShowNotification("~r~You don't need this right now.")
	end
end)

RegisterNetEvent('april:bandage')
AddEventHandler('april:bandage', function()
    if limping == true then
        SetEntityHealth(GetPlayerPed(-1), GetEntityHealth(GetPlayerPed(-1)) + 20)
	else
	    TriggerServerEvent("april:return2", source)
		ESX.ShowNotification("~r~You don't need this right now.")
	end
end)

RegisterNetEvent('april:painkiller')
AddEventHandler('april:painkiller', function()
    if painkiller == false then
	    RequestAnimDict('mp_suicide')
	    TaskPlayAnim(GetPlayerPed(-1), 'mp_suicide', 'pill', 8.0, -8.0, -1, 0, 0, false, false, false)
		Citizen.Wait(2000)
        painkiller = true
	else
	    TriggerServerEvent("april:return3", source)
		ESX.ShowNotification("~r~You don't need this right now.")
	end
end)