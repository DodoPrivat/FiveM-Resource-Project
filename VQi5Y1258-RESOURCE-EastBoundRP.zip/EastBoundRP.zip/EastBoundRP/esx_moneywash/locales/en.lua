Locales['en'] = {
	['you_have_washed'] 		= 'You have washed ~r~$',
	['dirty_money'] 			= ' dirty money.',
	['you_have_received'] 		= ' ~s~You received a total of ~g~$',
	['clean_money'] 			= ' clean money',
	['invalid_amount']			= 'You have entered an invalid amount',
	['press_menu'] 				= 'press ~INPUT_CONTEXT~ to ~r~wash your money.~s~.',
	['no'] 						= 'no',
	['wash_money']				= 'Wash Money',
	['washed_menu']				= 'Money Washing',
	['wash_money_amount']		= 'Amount of money to wash'
}