Config 					= {}

Config.Locale 			= 'en'
Config.DrawDistance 	= 100
Config.Size 			= {x = 1.5, y = 1.5, z = 1.5}
Config.Color 			= {r = 255, g = 120, b = 0}
Config.Type 			= 1

Config.taxRate = 0.95  --65% of the dirty you will get back in clean

Config.Zones = {

	laundryMat = {
		Pos = {
			{x = 1122.39 , y = -3194.86 , z = -41.60 },
			--{x = 136.92 , y = -1278.44 , z = 28.35}
		}
	},

}