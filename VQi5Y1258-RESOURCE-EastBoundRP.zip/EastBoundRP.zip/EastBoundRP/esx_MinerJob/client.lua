--------------------------------
------- Created by Hamza -------
-------------------------------- 

ESX 						= nil
local PlayerData            = nil
local MiningPos 			= {}
local WashingPos 			= {}
local SmeltingPos 			= {}
local keyPressed 			= false
local currentlyMining 		= false
local currentlyWashing 		= false
local currentlySmelting 	= false

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end
	PlayerData = ESX.GetPlayerData()
end)

-- Load Spot Status:
RegisterNetEvent('esx_MinerJob:loadSpot')
AddEventHandler('esx_MinerJob:loadSpot', function(list, list2, list3)
    MiningPos = list
    WashingPos = list2
    SmeltingPos = list3
end)

-- Update Mining Spot Status:
RegisterNetEvent('esx_MinerJob:updateStatus')
AddEventHandler('esx_MinerJob:updateStatus', function(id,status)
    if id ~= nil or status ~= nil then 
        MiningPos[id].mining = status
    end
end)

-- CreateThread Function for Mining:
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(5)
        local ped = GetPlayerPed(-1)
        local coords = GetEntityCoords(ped,true)
        for k,v in pairs(MiningPos) do
            v.spot[1] = v.spot[1]
            v.spot[2] = v.spot[2]
            v.spot[3] = v.spot[3]
			if not v.mining and not currentlyMining then
				if GetDistanceBetweenCoords(coords.x, coords.y, coords.z, v.spot[1], v.spot[2], v.spot[3], true) <= 10.0 then
					DrawMarker(Config.MiningMarker, v.spot[1], v.spot[2], v.spot[3]-0.97, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Config.MiningMarkerScale.x, Config.MiningMarkerScale.y, Config.MiningMarkerScale.z, Config.MiningMarkerColor.r, Config.MiningMarkerColor.g, Config.MiningMarkerColor.b, Config.MiningMarkerColor.a, false, true, 2, false, false, false, false)
				end    
				if GetDistanceBetweenCoords(coords.x, coords.y, coords.z, v.spot[1], v.spot[2], v.spot[3], true) <= 1.5 then
					DrawText3Ds(v.spot[1], v.spot[2], v.spot[3], Config.DrawMining3DText)
				end
				if GetDistanceBetweenCoords(coords.x, coords.y, coords.z, v.spot[1], v.spot[2], v.spot[3], true) <= 1.0 then
					if IsControlJustPressed(0,Config.KeyToStartMining) and not keyPressed then
						keyPressed = true
						ESX.TriggerServerCallback("esx_MinerJob:getPickaxe", function(pickaxe)
							if pickaxe then
								ESX.TriggerServerCallback("esx_MinerJob:getStoneLimit", function(stoneLimitOK)
									if stoneLimitOK then
										TriggerServerEvent("esx_MinerJob:spotStatus", k, true)
										currentlyMining = true
										Citizen.Wait(250)
										MiningEvent(k,v)
									else
										ESX.ShowNotification("You ~r~cannot~s~ ~b~carry more~s~ ~y~stones~s~ with you!")
										keyPressed = false
									end
								end)
							else
								ESX.ShowNotification("You need a ~y~pickaxe~s~ to ~b~mine~s~ here!")
								keyPressed = false
							end
						end)
						break;
					end
				end
			end
        end
    end
end)

-- Create Mining Blips:
Citizen.CreateThread(function()
	for i = 1, #Config.MiningPositions do
		if Config.MiningPositions[i].blipEnable then
			local blip = AddBlipForCoord(Config.MiningPositions[i].spot[1], Config.MiningPositions[i].spot[2], Config.MiningPositions[i].spot[3])
			SetBlipSprite(blip, Config.MiningPositions[i].blipSprite)
			SetBlipDisplay(blip, Config.MiningPositions[i].blipDisplay)
			SetBlipScale  (blip, Config.MiningPositions[i].blipScale)
			SetBlipColour (blip, Config.MiningPositions[i].blipColor)
			SetBlipAsShortRange(blip, true)
			BeginTextCommandSetBlipName("STRING")
			AddTextComponentString(Config.MiningPositions[i].blipName)
			EndTextCommandSetBlipName(blip)
		end
	end
end)

-- Mining Function:
function MiningEvent(k,v)

	local playerPed = PlayerPedId()
	local coords = GetEntityCoords(playerPed)
	
	FreezeEntityPosition(playerPed, true)
	SetCurrentPedWeapon(playerPed, GetHashKey('WEAPON_UNARMED'))
	Citizen.Wait(200)
	
	local pickaxe = GetHashKey("prop_tool_pickaxe")
	
	-- Loads model
	RequestModel(pickaxe)
    while not HasModelLoaded(pickaxe) do
      Wait(1)
    end
	
	local anim = "melee@hatchet@streamed_core_fps"
	local action = "plyr_front_takedown"
	
	 -- Loads animation
    RequestAnimDict(anim)
    while not HasAnimDictLoaded(anim) do
      Wait(1)
    end
	
	local object = CreateObject(pickaxe, coords.x, coords.y, coords.z, true, false, false)
	AttachEntityToEntity(object, playerPed, GetPedBoneIndex(playerPed, 57005), 0.1, 0.0, 0.0, -90.0, 25.0, 35.0, true, true, false, true, 1, true)
	
	exports['progressBars']:startUI((10000), "MINING")
	TaskPlayAnim(PlayerPedId(), anim, action, 3.0, -3.0, -1, 31, 0, false, false, false)
	Citizen.Wait(2000)
	TaskPlayAnim(PlayerPedId(), anim, action, 3.0, -3.0, -1, 31, 0, false, false, false)
	Citizen.Wait(2000)
	TaskPlayAnim(PlayerPedId(), anim, action, 3.0, -3.0, -1, 31, 0, false, false, false)
	Citizen.Wait(2000)
	TaskPlayAnim(PlayerPedId(), anim, action, 3.0, -3.0, -1, 31, 0, false, false, false)
	Citizen.Wait(2000)
	TaskPlayAnim(PlayerPedId(), anim, action, 3.0, -3.0, -1, 31, 0, false, false, false)
	Citizen.Wait(2000)
	
	TriggerServerEvent("esx_MinerJob:reward",Config.Stone,Config.StoneReward)
	TriggerServerEvent("esx_MinerJob:spotStatus", k, false)
	
	ClearPedTasks(PlayerPedId())
	FreezeEntityPosition(playerPed, false)
    DeleteObject(object)
	currentlyMining = false
	keyPressed = false
end

-- CreateThread Function for Washing:
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(5)
        local ped = GetPlayerPed(-1)
        local coords = GetEntityCoords(ped,true)
        for k,v in pairs(WashingPos) do
            v.spot[1] = v.spot[1]
            v.spot[2] = v.spot[2]
            v.spot[3] = v.spot[3]
			if not currentlyWashing then
				if GetDistanceBetweenCoords(coords.x, coords.y, coords.z, v.spot[1], v.spot[2], v.spot[3], true) <= 20.0 then
					DrawMarker(Config.WasherMarker, v.spot[1], v.spot[2], v.spot[3], 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Config.WasherMarkerScale.x, Config.WasherMarkerScale.y, Config.WasherMarkerScale.z, Config.WasherMarkerColor.r, Config.WasherMarkerColor.g, Config.WasherMarkerColor.b, Config.WasherMarkerColor.a, false, true, 2, false, false, false, false)
				end    
				if GetDistanceBetweenCoords(coords.x, coords.y, coords.z, v.spot[1], v.spot[2], v.spot[3], true) <= 1.2 then
					DrawText3Ds(v.spot[1], v.spot[2], v.spot[3], Config.DrawWasher3DText)
				end
				if GetDistanceBetweenCoords(coords.x, coords.y, coords.z, v.spot[1], v.spot[2], v.spot[3], true) <= 1.2 then
					if IsControlJustPressed(0,Config.KeyToStartWashing) and not keyPressed then
						keyPressed = true
						ESX.TriggerServerCallback("esx_MinerJob:getWashPan", function(washPan)
							if washPan then
								ESX.TriggerServerCallback("esx_MinerJob:getWashedStoneLimit", function(washedStoneLimitOK)
									if washedStoneLimitOK then
										currentlyWashing = true
										Citizen.Wait(250)
										WashingEvent(k,v)
									else
										ESX.ShowNotification("You ~r~cannot~s~ ~b~carry more~s~ ~y~washed stones~s~ with you!")
										keyPressed = false
									end
								end)
							else
								ESX.ShowNotification("You need a ~y~wash pan~s~ to ~b~wash~s~ here!")
								keyPressed = false
							end
						end)
						break;
					end
				end
			end
        end
    end
end)

-- Create Washing Blips:
Citizen.CreateThread(function()
	for i = 1, #Config.WashingPositions do
		if Config.WashingPositions[i].blipEnable then
			local blip = AddBlipForCoord(Config.WashingPositions[i].spot[1], Config.WashingPositions[i].spot[2], Config.WashingPositions[i].spot[3])
			SetBlipSprite(blip, Config.WashingPositions[i].blipSprite)
			SetBlipDisplay(blip, Config.WashingPositions[i].blipDisplay)
			SetBlipScale  (blip, Config.WashingPositions[i].blipScale)
			SetBlipColour (blip, Config.WashingPositions[i].blipColor)
			SetBlipAsShortRange(blip, true)
			BeginTextCommandSetBlipName("STRING")
			AddTextComponentString(Config.WashingPositions[i].blipName)
			EndTextCommandSetBlipName(blip)
		end
	end
end)

function WashingEvent(k,v)
	
	local playerPed = PlayerPedId()
	local coords = GetEntityCoords(playerPed)
	
	FreezeEntityPosition(playerPed, true)
	SetCurrentPedWeapon(playerPed, GetHashKey('WEAPON_UNARMED'))
	Citizen.Wait(200)
	
	ESX.TriggerServerCallback("esx_MinerJob:removeStone", function(stoneCount)
		if stoneCount then
			exports['progressBars']:startUI((10000), "WASHING STONE")
			TaskStartScenarioInPlace(playerPed, "PROP_HUMAN_BUM_BIN", 0, true)
			Citizen.Wait(10000)
			TriggerServerEvent("esx_MinerJob:reward",Config.WStone,Config.WStoneReward)	
		else
			ESX.ShowNotification("You need a ~y~10x Stone~s~ to ~b~Wash~s~ here!")
		end
		ClearPedTasks(playerPed)
		FreezeEntityPosition(playerPed, false)
		currentlyWashing = false
		keyPressed = false
	end)
end

-- CreateThread Function for Washing:
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(5)
        local ped = GetPlayerPed(-1)
        local coords = GetEntityCoords(ped,true)
        for k,v in pairs(SmeltingPos) do
            v.spot[1] = v.spot[1]
            v.spot[2] = v.spot[2]
            v.spot[3] = v.spot[3]
			if not currentlySmelting then
				if GetDistanceBetweenCoords(coords.x, coords.y, coords.z, v.spot[1], v.spot[2], v.spot[3], true) <= 20.0 then
					DrawMarker(Config.SmelterMarker, v.spot[1], v.spot[2], v.spot[3]-0.97, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Config.SmelterMarkerScale.x, Config.SmelterMarkerScale.y, Config.SmelterMarkerScale.z, Config.SmelterMarkerColor.r, Config.SmelterMarkerColor.g, Config.SmelterMarkerColor.b, Config.SmelterMarkerColor.a, false, true, 2, false, false, false, false)
				end    
				if GetDistanceBetweenCoords(coords.x, coords.y, coords.z, v.spot[1], v.spot[2], v.spot[3], true) <= 1.5 then
					DrawText3Ds(v.spot[1], v.spot[2], v.spot[3], Config.DrawSmelter3DText)
				end
				if GetDistanceBetweenCoords(coords.x, coords.y, coords.z, v.spot[1], v.spot[2], v.spot[3], true) <= 1.0 then
					if IsControlJustPressed(0,Config.KeyToStartSmelting) and not keyPressed then
						keyPressed = true
						local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
						if closestPlayer == -1 or closestDistance >= 0.7 then
							ESX.TriggerServerCallback("esx_MinerJob:getWashedStone", function(WashedStone)
								if WashedStone then
									currentlySmelting = true
									Citizen.Wait(250)
									SmeltingEvent(k,v)
								else
									ESX.ShowNotification("You need at least ~y~10x Washed Stone~s~ to ~b~Smelt~s~ here!")
									keyPressed = false
								end
							end)
						else
							ESX.ShowNotification("You are too close to another player")
							keyPressed = false
						end	
						break;
					end
				end
			end
        end
    end
end)

-- Create Smelting Blips:
Citizen.CreateThread(function()
	for i = 1, #Config.SmeltingPositions do
		if Config.SmeltingPositions[i].blipEnable then
			local blip = AddBlipForCoord(Config.SmeltingPositions[i].spot[1], Config.SmeltingPositions[i].spot[2], Config.SmeltingPositions[i].spot[3])
			SetBlipSprite(blip, Config.SmeltingPositions[i].blipSprite)
			SetBlipDisplay(blip, Config.SmeltingPositions[i].blipDisplay)
			SetBlipScale  (blip, Config.SmeltingPositions[i].blipScale)
			SetBlipColour (blip, Config.SmeltingPositions[i].blipColor)
			SetBlipAsShortRange(blip, true)
			BeginTextCommandSetBlipName("STRING")
			AddTextComponentString(Config.SmeltingPositions[i].blipName)
			EndTextCommandSetBlipName(blip)
		end
	end
end)

-- Function for Smelting:
function SmeltingEvent()
		
	local playerPed = PlayerPedId()
	local coords = GetEntityCoords(playerPed)
	
	FreezeEntityPosition(playerPed, true)
	SetCurrentPedWeapon(playerPed, GetHashKey('WEAPON_UNARMED'))
	Citizen.Wait(200)
		
	exports['progressBars']:startUI((10000), "SMELTING WASHED STONE")
	Citizen.Wait(10000)
	
	TriggerServerEvent("esx_MinerJob:rewardSmelting")
	
	FreezeEntityPosition(playerPed, false)
	currentlySmelting = false
	keyPressed = false

end

-- Refresh Spots:
Citizen.CreateThread(function()
    TriggerServerEvent("esx_MinerJob:refreshSpots")
end)

-- Function for 3D text:
function DrawText3Ds(x,y,z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())

    SetTextScale(0.32, 0.32)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 255)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 500
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 0, 0, 0, 80)
end
