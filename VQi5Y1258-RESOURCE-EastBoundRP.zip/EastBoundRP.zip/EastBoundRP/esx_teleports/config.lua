Config                            = {}

Config.Teleporters = {
	['Galaxy'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = -15.07, 
			['y'] = 216.56, 
			['z'] = 105.8,
			['Information'] = '[E] To Enter',
		},
		['Exit'] = {
			['x'] = -1569.34, 
			['y'] = -3017.53, 
			['z'] = -75.41, 
			['Information'] = '[E] To Exit' 
		}
	},

	['TGK'] = {
		['Job'] = 'gang',
		['Enter'] = { 
			['x'] = -1418.04, 
			['y'] = 655.18, 
			['z'] = 196.1,
			['Information'] = '[E] To Enter',
		},
		['Exit'] = {
			['x'] = -1418.29, 
			['y'] = 654.89, 
			['z'] = 201.15, 
			['Information'] = '[E] To Exit' 
		}
	},

	['MARTINEZ'] = {
		['Job'] = 'gang1',
		['Enter'] = { 
			['x'] = -335.15, 
			['y'] = 1116.6, 
			['z'] = 329.51,
			['Information'] = '[E] To Enter',
		},
		['Exit'] = {
			['x'] = -322.04, 
			['y'] = 1109.7, 
			['z'] = 301.17, 
			['Information'] = '[E] To Exit' 
		}
	},

	['Cardealer'] = {
		['Job'] = 'none',
		['Enter'] = { 
			['x'] = 0, 
			['y'] = 0, 
			['z'] = 0,
			['Information'] = '[E] Go Up' 
		},

		['Exit'] = {
			['x'] = 0, 
			['y'] = 0, 
			['z'] = 0, 
			['Information'] = '[E] Go Down' 
		}
	}

}


