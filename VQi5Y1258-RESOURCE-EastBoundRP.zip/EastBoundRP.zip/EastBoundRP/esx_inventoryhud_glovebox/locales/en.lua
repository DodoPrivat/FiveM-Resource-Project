Locales["en"] = {
  ["glovebox_closed"] = "This glove box is closed.",
  ["no_veh_nearby"] = "You are not in a vehicle.",
  ["glovebox_in_use"] = "This glove box is in use.",
  ["glovebox_full"] = "This glove box is full.",
  ["invalid_quantity"] = "Invalid number",
  ["cant_carry_more"] = "You are full.",
  ["nacho_veh"] = "This is not your vehicle.",
  ["invalid_amount"] = "Invalid number",
  ["insufficient_space"] = "Insufficient space",
  ["glovebox_info"] = "<h3>Vehicle glove box </h3><br><strong>License plate:</strong> %s<br><strong>Storage area:</strong> %s / %s",
  ["player_inv_no_space"] = "There is not enough space in your inventory for that item!"
}
