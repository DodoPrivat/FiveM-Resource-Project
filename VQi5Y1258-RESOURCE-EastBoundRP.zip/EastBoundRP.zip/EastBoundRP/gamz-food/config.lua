Config = {}

Config.Zones = {

    ["Chihuahua Hotdogs"] = {

        ["coords"] = vector3(43.775257110596, -997.98028564453, 29.336441040039),

        ["drink"] = {
            ["Coca Cola"] = {
                ["price"] = 20,
                ["prop"] = "prop_ecola_can"
            },

            ["Sparkling Water"] = {
                ["price"] = 15,
                ["prop"] = "prop_ld_flow_bottle"
            } 
        },
        
        ["eatable"] = {
            ["Burger"] = {
                ["price"] = 79,
                ["prop"] = "prop_cs_burger_01"
            },

            ["Hotdog"] = {
                ["price"] = 79,
                ["prop"] = "prop_cs_hotdog_01"
            }

        }
    },
    
    ["Carlos' Vending Machine"] = {

        ["coords"] = vector3(310.51, -586.18, 43.28),

        ["drink"] = {
            ["Coca Cola"] = {
                ["price"] = 20,
                ["prop"] = "prop_ecola_can"
            },

            ["Sparkling Water"] = {
                ["price"] = 15,
                ["prop"] = "prop_ld_flow_bottle"
            } 
        },
        
        ["eatable"] = {
            ["Burger"] = {
                ["price"] = 79,
                ["prop"] = "prop_cs_burger_01"
            },

            ["Hotdog ni Tiyo"] = {
                ["price"] = 79,
                ["prop"] = "prop_cs_hotdog_01"
            }

        }
    },

    ["Estarossas' Vending Machine"] = {

        ["coords"] = vector3(-28.77, -1247.52, 29.34),

        ["drink"] = {
            ["Coca Cola"] = {
                ["price"] = 20,
                ["prop"] = "prop_ecola_can"
            },

            ["Sparkling Water"] = {
                ["price"] = 15,
                ["prop"] = "prop_ld_flow_bottle"
            } 
        },
        
        ["eatable"] = {
            ["Burger ni Pukay"] = {
                ["price"] = 79,
                ["prop"] = "prop_cs_burger_01"
            },

            ["Hotdog ni Fanchaw"] = {
                ["price"] = 79,
                ["prop"] = "prop_cs_hotdog_01"
            }

        }
    },
    
    ["Lufferts' Vending Machine"] = {

        ["coords"] = vector3(-1087.63, -809.13, 19.04),

        ["drink"] = {
            ["Coca Cola"] = {
                ["price"] = 20,
                ["prop"] = "prop_ecola_can"
            },

            ["Sparkling Water"] = {
                ["price"] = 15,
                ["prop"] = "prop_ld_flow_bottle"
            } 
        },
        
        ["eatable"] = {
            ["Burger ni Matt"] = {
                ["price"] = 80,
                ["prop"] = "prop_cs_burger_01"
            },

            ["Tabordog"] = {
                ["price"] = 80,
                ["prop"] = "prop_cs_hotdog_01"
            }

        }
    },

    ["Dax' Vending Machine"] = {

        ["coords"] = vector3(-204.53, -1330.65, 30.89),

        ["drink"] = {
            ["Coca Cola"] = {
                ["price"] = 20,
                ["prop"] = "prop_ecola_can"
            },

            ["Sparkling Water"] = {
                ["price"] = 15,
                ["prop"] = "prop_ld_flow_bottle"
            } 
        },
        
        ["eatable"] = {
            ["Burger ni Choy"] = {
                ["price"] = 80,
                ["prop"] = "prop_cs_burger_01"
            },

            ["Kaneks Siopao"] = {
                ["price"] = 80,
                ["prop"] = "prop_cs_burger_01"
            }

        }
    },

    ["Jeno's Vending Machine"] = {

        ["coords"] = vector3(-598.24, -914.63, 23.87),

        ["drink"] = {
            ["Coca Cola"] = {
                ["price"] = 20,
                ["prop"] = "prop_ecola_can"
            },

            ["Sparkling Water"] = {
                ["price"] = 15,
                ["prop"] = "prop_ld_flow_bottle"
            } 
        },
        
        ["eatable"] = {
            ["Supremo's Burger"] = {
                ["price"] = 80,
                ["prop"] = "prop_cs_burger_01"
            },

            ["Vacco's PotatoChips"] = {
                ["price"] = 80,
                ["prop"] = "prop_cs_burger_01"
            }

        }
    },

    ["Tiyo Vending Machine"] = {

        ["coords"] = vector3(-1100.55, -823.32, 19),

        ["drink"] = {
            ["Coca Cola"] = {
                ["price"] = 20,
                ["prop"] = "prop_ecola_can"
            },

            ["Sparkling Water"] = {
                ["price"] = 15,
                ["prop"] = "prop_ld_flow_bottle"
            } 
        },
        
        ["eatable"] = {
            ["Burger"] = {
                ["price"] = 79,
                ["prop"] = "prop_cs_burger_01"
            },

            ["Hotdog ni Carlow"] = {
                ["price"] = 79,
                ["prop"] = "prop_cs_hotdog_01"
            }

        }
    },

    ["Tiyo Vending Machine"] = {

        ["coords"] = vector3(-1100.72, -849.2, 26.83),

        ["drink"] = {
            ["Coca Cola"] = {
                ["price"] = 20,
                ["prop"] = "prop_ecola_can"
            },

            ["Sparkling Water"] = {
                ["price"] = 15,
                ["prop"] = "prop_ld_flow_bottle"
            } 
        },
        
        ["eatable"] = {
            ["Burger"] = {
                ["price"] = 79,
                ["prop"] = "prop_cs_burger_01"
            },

            ["Hotdog ni Carlow"] = {
                ["price"] = 79,
                ["prop"] = "prop_cs_hotdog_01"
            }

        }
    },
    
    
    
    -- You can add more spots by just copying this one and changing the values

    ["Gyro Day"] = {
        ["coords"] = vector3(461.50152587891, -699.02325439453, 27.402139663696)
    }

}

Config.Anims = { -- if you want to change the animation
    ["eatable"] = {
        ["animation"] = "mp_player_int_eat_burger_fp",
        ["dict"] = "mp_player_inteat@burger",
    },

    ["drink"] = {
        ["animation"] = "loop_bottle",
        ["dict"] = "mp_player_intdrink",
    },
}

Config.eatable = { -- if you have not choosed any food for a certain zone it will automatically get this
    ["Hotdog"] = {
        ["price"] = 79,
        ["prop"] = "prop_cs_hotdog_01"
    }
}

Config.drink = { -- if you have not choosed any drinks for a certain zone it will automatically get this
    ["Sparkling Water"] = {
        ["price"] = 15,
        ["prop"] = "prop_ld_flow_bottle"
    }
}