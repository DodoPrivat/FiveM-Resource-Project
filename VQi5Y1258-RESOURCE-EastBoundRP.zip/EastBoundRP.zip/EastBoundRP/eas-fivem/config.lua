Config = {}
Config.EAS = {}
Config.EAS.Volume = 0.2 --(0.2 = 20% Volume)
