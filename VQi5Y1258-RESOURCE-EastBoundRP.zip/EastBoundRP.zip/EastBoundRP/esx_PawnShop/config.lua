--------------------------------
------- Created by Hamza -------
-------------------------------- 

Config = {}

-- Pawn Shop Positions:
Config.PawnZones = {
	PawnShops = {
		Pos = {
			{x = 412.42,  y = 314.41, z = 103.02},
			{x = 182.76821899414,  y = -1319.3857421875, z = 29.317152023315},
			{x = -1459.3402099609,  y = -413.79244995117, z = 35.739379882813}
		}
	}
}

-- Pawn Shop Blip Settings:
Config.EnablePawnShopBlip = true
Config.BlipSprite = 59
Config.BlipDisplay = 4
Config.BlipScale = 1.0
Config.BlipColour = 5
Config.BlipName = "Pawn Shop"

-- Pawn Shop Marker Settings:
Config.KeyToOpenShop = 38														-- default 38 is E
Config.ShopMarker = 27 															-- marker type
Config.ShopMarkerColor = { r = 255, g = 255, b = 0, a = 100 } 					-- rgba color of the marker
Config.ShopMarkerScale = { x = 1.0, y = 1.0, z = 1.0 }  						-- the scale for the marker on the x, y and z axis
Config.ShopDraw3DText = "Press ~g~[E]~s~ for ~y~Pawn Shop~s~"					-- set your desired text here

-- Pawn Shop Item List:
Config.ItemsInPawnShop = {
	{ itemName = 'goldwatch', label = 'Gold Watch', BuyInPawnShop = false, BuyPrice = 1000, SellInPawnShop = true, SellPrice = 500 },
	{ itemName = 'goldbar', label = 'Gold Bar', BuyInPawnShop = false, BuyPrice = 2000, SellInPawnShop = true, SellPrice = 25000 },
	{ itemName = 'cokeburn', label = 'White USB', BuyInPawnShop = false, BuyPrice = 5000, SellInPawnShop = false, SellPrice = 2500 },
	{ itemName = 'gold', label = 'Gold', BuyInPawnShop = false, BuyPrice = 5000, SellInPawnShop = true, SellPrice = 1100 },
	{ itemName = 'silver', label = 'Silver', BuyInPawnShop = false, BuyPrice = 5000, SellInPawnShop = true, SellPrice = 1100 },
	{ itemName = 'copper', label = 'Copper', BuyInPawnShop = false, BuyPrice = 5000, SellInPawnShop = true, SellPrice = 1100 },
	{ itemName = 'iron_ore', label = 'Iron Ore', BuyInPawnShop = false, BuyPrice = 5000, SellInPawnShop = true, SellPrice = 1100 },
	{ itemName = 'uncut_diamond', label = 'Uncut Diamond', BuyInPawnShop = false, BuyPrice = 5000, SellInPawnShop = true, SellPrice = 1500 },
	{ itemName = 'uncut_rubbies', label = 'Uncut Rubbies', BuyInPawnShop = false, BuyPrice = 5000, SellInPawnShop = true, SellPrice = 1500 },
	{ itemName = 'washpan', label = 'Wash Pan', BuyInPawnShop = true, BuyPrice = 5000, SellInPawnShop = false, SellPrice = 250 },
	{ itemName = 'pickaxe', label = 'Pickaxe', BuyInPawnShop = true, BuyPrice = 5000, SellInPawnShop = false, SellPrice = 2500 },
}

