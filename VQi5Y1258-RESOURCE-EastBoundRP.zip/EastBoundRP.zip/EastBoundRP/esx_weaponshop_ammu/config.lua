Config               = {}

Config.DrawDistance  = 100
Config.Size          = { x = 1.5, y = 1.5, z = 0.5 }
Config.Color         = { r = 0, g = 128, b = 255 }
Config.Type          = 1
Config.Locale        = 'en'

Config.LicenseEnable = true-- only turn this on if you are using esx_license
Config.LicensePrice  = 100000

Config.Zones = {

	GunShop = {
		Legal = true,
		Items = {
			{ weapon = 'WEAPON_PISTOL', price = 70000, ammoPrice = 12500, AmmoToGive = 300 },
			{ weapon = 'WEAPON_NIGHTSTICK', price = 3000},
			{ weapon = 'WEAPON_BAT', price = 3000},
			{ weapon = 'WEAPON_KNIFE', price = 10000},
			{ weapon = 'WEAPON_PUMPSHOTGUN', price = 120000, ammoPrice = 15000, AmmoToGive = 300 },
			{ weapon = 'WEAPON_CARBINERIFLE', price = 250000, ammoPrice = 20000, AmmoToGive = 500 },
			{ weapon = 'WEAPON_MICROSMG', price = 200000, ammoPrice = 20000, AmmoToGive = 500 },
		},
		
		
			
	
		Locations = {
			vector3(-662.1, -935.3, 20.8),
			vector3(810.2, -2157.3, 28.6),
			vector3(1693.4, 3759.5, 33.7),
			vector3(-330.2, 6083.8, 30.4),
			vector3(252.3, -50.0, 68.9),
			vector3(22.0, -1107.2, 28.8),
			vector3(2567.6, 294.3, 107.7),
			vector3(-1117.5, 2698.6, 17.5),
			vector3(842.4, -1033.4, 27.1)
		}
	},

	BlackWeashop = {
		Legal = false,
		Items = {
			{ weapon = 'WEAPON_PISTOL', components = { 0, 0, 1000, 4000, nil }, price = 75000, ammoPrice = 15000, AmmoToGive = 300 },
			{ weapon = 'WEAPON_BZGAS', price = 80000, ammoPrice = 25000, AmmoToGive = 1 },

			{ weapon = 'WEAPON_SMG', price = 125000,ammoPrice = 25000, AmmoToGive = 500 },
			{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 150000, 150000, 150000, 350000, nil }, price = 150000, ammoPrice = 25000, AmmoToGive = 500 },
			{ weapon = 'WEAPON_SPECIALCARBINE', components = { 0, 150000, nil, 150000, 150000,150000,250000, 500000,nil }, price = 155000, ammoPrice = 25000, AmmoToGive = 500 }
			--DEFAULT GRIP , EXTENTED GRIP 60 AMMU , DRUM AMMU 100 , FLASHLIGHT , SCOPE, SUPRESSOR, GRIP, LUX FINISH
		},
		Locations = {
			vector3(-1500.14, -216.61, 46.89)
		}
	}
}
