Locales ['br'] = {
  ['buy_license'] = 'buy weapon license?',
  ['yes'] = '%s',
  ['no'] = 'no',
  ['weapon_bought'] = 'purchased for %s EUR',
  ['not_enough_black'] = 'você não tem dinheiro sujo suficiente',
  ['not_enough'] = 'você não tem dinheiro suficiente',
  ['already_owned'] = 'you already own this weapon!',
  ['shop_menu_title'] = 'comprar',
  ['shop_menu_prompt'] = 'pressione ~INPUT_CONTEXT~ para comprar armas.',
  ['shop_menu_item'] = 'R$%s',
  ['map_blip'] = 'loja de Armas',
}
