Locales ['cs'] = {
  ['buy_license'] = 'zakoupit zbrojni prukaz?',
  ['yes'] = '%s',
  ['no'] = 'ne',
  ['weapon_bought'] = 'zakoupeno za $%s',
  ['not_enough_black'] = 'nemas dostatek spinavych penez',
  ['not_enough'] = 'nemas dostatek penez',
  ['already_owned'] = 'tuhle zbran jiz vlastnis!',
  ['shop_menu_title'] = 'ammu-Nation',
  ['shop_menu_prompt'] = 'stiskni ~INPUT_CONTEXT~ pro pristup do ~y~Ammu-Nationu~s~.',
  ['shop_menu_item'] = '$%s',
  ['map_blip'] = 'ammu-Nation',
}
