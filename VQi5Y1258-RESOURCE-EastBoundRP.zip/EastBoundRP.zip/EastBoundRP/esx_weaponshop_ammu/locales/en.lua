Locales ['en'] = {
  ['buy_license'] = 'buy weapon license?',
  ['yes'] = '%s',
  ['no'] = 'no',
  ['weapon_bought'] = 'purchased for $%s',
  ['not_enough_black'] = 'you do not have enough dirty money',
  ['not_enough'] = 'you do not have enough money',
  ['already_owned'] = 'you already own this weapon!',
  ['shop_menu_title'] = 'ammu-Nation',
  ['shop_menu_prompt'] = 'press ~INPUT_CONTEXT~ to access the ~y~Ammu-Nation~s~.',
  ['shop_menu_item'] = '$%s',
  ['map_blip'] = 'ammu-Nation',
  ['buy_ammo'] = 'buy ammo:',
  ['gunshop_owned'] = 'owned',
  ['gunshop_free'] = 'free',
  ['gunshop_money'] = 'You don\'t have enough money',
  ['gunshop_bought'] = 'you bought an ~y~%s~s~ for ~r~$%s~s~',
  ['gunshop_item'] = '$%s',
  ['gunshop_weapontitle'] = 'weapon shop',
  ['gunshop_componenttitle'] = 'weapon shop - Weapon attatchments',
  ['gunshop_hascomponent'] = 'you have that attatchment equiped!',
  ['ammo'] = 'ammo',
}