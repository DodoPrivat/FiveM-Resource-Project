Locales ['fr'] = {
  ['voice']   = '~y~Voix: ~s~%s',
  ['normal']  = 'normal',
  ['shout']   = 'crier',
  ['whisper'] = 'chuchoter',
}
