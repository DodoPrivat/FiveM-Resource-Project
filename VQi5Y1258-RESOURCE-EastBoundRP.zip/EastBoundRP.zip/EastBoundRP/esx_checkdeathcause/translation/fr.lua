Locales['fr'] = {
	-- Author : Feared
  	['press_e'] = 'Appuyer sur ~INPUT_CONTEXT~ pour savoir de quoi est ~r~morte~s~ la personne.',
	['hardmeele'] = 'Probablement un ~r~choc violent~s~ a la tête.',
	['bullet'] = 'Probablement touché par une ~r~balle~s~, il y a des impact dans le corps.',
	['knifes'] = 'Probablement touché par un ~r~objet coupant~s~.',
	['bitten'] = 'Probablement attaqué par un ~r~animal~s~.',
	['brokenlegs'] = 'Il est ~r~tombé de haut~s~, il a les jambes cassé.',
	['explosive'] = 'Il est presque completement défiguré par des ~r~explosifs~s~.',
	['gas'] = 'Un ~r~gaz mortel~s~ a surement tué cette personne.',
	['fireextinguisher'] = 'Surement a cause du ~r~gaz d"un exctincteur~s~.',
	['fire'] = 'Il est complètement ~r~brulé~s~.',
	['caraccident'] = 'Il est surement mort du au ~r~choc de l"accident~s~.',
	['drown'] = 'Il s"est ~r~noyé~s~.',
	['unknown'] = 'Impossible de ~r~savoir de quoi il est mort~s~.',
}
