Locales['sv'] = {
  -- vanliga
  	['press_e'] = 'Tryck ~INPUT_CONTEXT~ för att försöka få fram ~r~dödsorsaken',
	['hardmeele'] = 'Personen har utsatts för trubbigt föremål.',
	['bullet'] = 'Personen har skottskador på kroppen',
	['knifes'] = 'Personen har skador av något vasst',
	['bitten'] = 'Personen har blivit biten och riven',
	['brokenlegs'] = 'Personen har brutit båda benen',
	['explosive'] = 'Personen har explosiva skador på kroppen',
	['gas'] = 'Personen har skadade lungor förmodligen av någon slags gas',
	['fireextinguisher'] = 'Personen har kvävts av något med vitt skum',
	['fire'] = 'Personen har brännskador över hela kroppen',
	['caraccident'] = 'PPersonen har varit involverad i en bilolycka',
	['drown'] = 'Personen har vatten i lungorna',
	['unknown'] = 'Dödsorsak okänd',

}
