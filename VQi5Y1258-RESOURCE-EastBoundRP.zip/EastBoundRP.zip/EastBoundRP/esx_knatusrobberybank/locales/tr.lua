Locales['tr'] = {

	['robbery_cancelled'] = 'Soygun iptal edildi, hiçbir şey kazanmayacaksın!',
	['robbery_successful'] = 'Soygun başarılı. Gelsin paralar.. ~g~₺',
	['bank_robbery'] = 'Banka soygunu',
	['press_to_rob'] = 'Soygunu başlatmak için ~INPUT_CONTEXT~ tuşuna basın. ~b~',
	['press_to_cancel'] = 'Soygundan vazgeçmek için ~INPUT_CONTEXT~ tuşuna basın. ~b~',
	['press_to_hack'] = 'Sisteme sızmak için ~INPUT_CONTEXT~ tuşuna basın. ~b~',
	['press_to_bomb'] = 'Bombayı kapıya yerleştirmek için ~INPUT_CONTEXT~ tuşuna basın! ~b~',
	['robbery_of'] = 'Banka Soygunu: ~r~',
	['bomb_of'] = 'Bombayı yerleştir: ~r~',
	['hack_of'] = 'Banka sistemine sız: ~r~',
	['seconds_remaining'] = '~w~ saniye kaldı.',
	['robbery_cancelled_at'] = '~r~ Soygun iptal edildi: ~b~',
	['robbery_has_cancelled'] = '~r~ Soygun iptal edildi: ~b~',
	['already_robbed'] = 'Bu banka zaten soyuldu. Lütfen bekleyin: ',
	['seconds'] = 'saniye.',
	['rob_in_prog'] = '~r~ Soygun işlemi devam ediyor: ~b~',
	['started_to_rob'] = 'Bir soygun başlattınız. ',
	['started_to_hack'] = 'Sisteme sızmaya çalışıyorsun. ',
	['started_to_plantbomb'] = 'Bombayı yerleştiriyorsun. ',
	['do_not_move'] = ', Hiçbir yere kıpırdama.',
	['alarm_triggered'] = 'Alarmlar çalmaya başladı.',
	['hack_failed'] = 'Sisteme sızma işlemi başarısız oldu, kapı açılmadı.',
	['hold_pos'] = '5 dakika dayanırsan paralar senin olacak!',
	['hold_pos_hack'] = 'Sisteme sızıp kapıyı açabilirsen içeriye erişebilirsin.',
	['hold_pos_plantbomb'] = 'Siper alın, bomba neredeyse patlayacak! Birazdan içeri girebilirsiniz!',
	['leave'] = 'Çıkmak için ~INPUT_CONTEXT~ tuşuna basın.',
	['robbery_complete'] = '~r~ Soygun tamamlandı.~s~ ~h~ Koş! ',
	['hack_complete'] = '~r~ İçeri sızma başarılı. Kaç! ',
	['robbery_complete_at'] = '~r~ Soygun tamamlandı: ~b~',
	['min_two_police'] = 'Şehirde yeterli sayıda polis yok: ',
	['robbery_already'] = '~r~ Soygun zaten devam ediyor.',
	['bombplanted_run'] = 'Bombayı yerleştirdin, koş ve siper al! Bomba 20 saniye içinde patlayacak',
	['bombplanted_at'] = 'Bomba yerleştirildi: ~b~ !',
	['rasperry_needed'] = 'Sisteme sızmak için Raspberry gerekli.',
	['c4_needed'] = 'Kapıyı patlatmak için C4 e ihtiyacın var.',
	['blowtorch_needed'] = 'Kasaya erişmek için kaynak makinesine ihtiyacın var',

}
