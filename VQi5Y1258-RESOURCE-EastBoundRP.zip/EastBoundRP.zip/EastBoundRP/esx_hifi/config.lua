Config = {}
Config.Locale = 'fr'
Config.distance = 8