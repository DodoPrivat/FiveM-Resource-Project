Locales ['fr'] = {
	['put_hifi'] = 'Vous venez de deposer la BoomBox',
	['get_hifi'] = 'Ramasser la BoomBox',
	['play_music'] = 'Jouer une musique',
	['stop_music'] = 'Stopper la musique',
	['volume_music'] = 'Regler le son',
	['hifi_alreadyOne'] = 'Vous avez deja une BoomBox sur vous',
	['set_volume'] = 'Entrez le niveau du volume (entre 0 et 100)',
	['play_id'] = 'Entrez l\'id de la video Youtube',
	['sound_limit'] = 'Le volume doit etre entre 0 et 100',
	['hifi_help'] = 'appuyez sur ~INPUT_CONTEXT~ pour regler la musique'
}
