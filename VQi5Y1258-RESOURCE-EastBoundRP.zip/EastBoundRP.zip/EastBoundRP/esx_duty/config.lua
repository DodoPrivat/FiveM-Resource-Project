Config                            = {}
Config.DrawDistance               = 100.0
--language currently available EN and SV
Config.Locale                     = 'en'

Config.Zones = {

  PoliceDuty = {
    Pos   = { x = -1098.04, y = -819.29, z = 19.04 },
    Size  = { x = 1.0, y = 1.0, z = 1.0 },
    Color = { r = 0, g = 255, b = 0 },  
    Type  = 20,
  },

  AmbulanceDuty = {
    Pos = { x = 301.2, y = -596.48, z = 42.28 },
    Size = { x = 2.5, y = 2.5, z = 1.5 },
    Color = { r = 0, g = 255, b = 0 },
    Type = 1,
  },
  
  MechanicDuty = {
    Pos = { x = -206.35, y = -1331.58, z = 33.89 },
    Size = { x = 2.5, y = 2.5, z = 1.5 },
    Color = { r = 0, g = 255, b = 0 },
    Type = 27,
  },

}