Config = {}

Config.Locale = 'fr'