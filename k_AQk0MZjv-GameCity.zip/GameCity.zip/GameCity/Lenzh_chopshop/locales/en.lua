Locales['en'] = {
  ['press_to_chop'] = "Press ~INPUT_CONTEXT~ to Chop the vehicle",
  ['map_blip'] = "Chop Shop",
  ['map_blip_shop'] = "Stanley's Car Parts",
  ['no_vehicle'] = "Must be in a vehicle to chop.",
  ['open_shop'] = "Press ~INPUT_CONTEXT~ to access the ~y~store~s~.",
  ['sold'] = "you\'ve sold ~b~%sx~s~ ~y~%s~s~ for ~g~$%s~s~",
  ['not_enough'] = 'you don\'t have enough of that to sell!',
  ['shop_prompt'] = 'press ~INPUT_CONTEXT~ to talk with ~r~Stanley~s~.',
  ['item'] = '$%s',
  ['shop_title'] = 'Stanley\'s Car Parts',
  ['cooldown'] = '~s~You have to ~g~wait ~r~%s secondes ~s~before you can ~g~chop ~s~another vehicle.',
  ['call'] = 'Someone is Chopping a vehicle.',
  ['911'] = '911 Call',
  ['chop'] = 'Car Chopping',
  ['not_enough_cops'] = 'Not enough cops in service',
}
