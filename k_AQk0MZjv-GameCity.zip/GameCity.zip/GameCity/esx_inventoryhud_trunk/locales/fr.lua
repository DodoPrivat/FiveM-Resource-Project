Locales["fr"] = {
  ["trunk_closed"] = "Ce coffre est ~r~fermé~s~.",
  ["no_veh_nearby"] = "Il n'y a pas de véhicule près de vous.",
  ["trunk_in_use"] = "Ce coffre est ~g~en cours~s~ d'utilisation.",
  ["trunk_full"] = "Ce coffre est ~r~plein~s~.",
  ["invalid_quantity"] = "Quantité ~r~invalide~s~",
  ["cant_carry_more"] = "Vous ne pouvez plus en porter.",
  ["nacho_veh"] = "Ce n'est pas votre véhicule.",
  ["invalid_amount"] = "Montant ~r~invalide~s~",
  ["insufficient_space"] = "Espace ~r~insuffisant~s~",
  ["trunk_info"] = "~y~Coffre de véhicule~s~~n~~y~Plaque~s~: %s~n~~y~Capacity~s~: %s / %s"
}
