Citizen.CreateThread(function()
	while true do
		SetVehicleDensityMultiplierThisFrame(0.5)
		Citizen.Wait(2)
	end
end)