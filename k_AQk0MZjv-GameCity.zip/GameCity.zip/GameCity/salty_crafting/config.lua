Config = {}

-- Ammo given by default to crafted weapons
Config.WeaponAmmo = 42

Config.Recipes = {
	-- Can be a normal ESX item
		["rdx"] = { 
		{item = "r2_pooch", quantity = 51 }, 
		{item = "no_plus_pooch", quantity = 40 },
	},
	
		["c4_bank"] = { 
		{item = "rdx", quantity = 1 }, 
		{item = "plasticizer", quantity = 5 },
		{item = "syn_rub", quantity = 2 },
		{item = "min_oil", quantity = 2 },
	},

	-- Can be a weapon, must follow this format
	['WEAPON_STICKYBOMB'] = { 
		{item = "rdx", quantity = 2 }, 
		{item = "plasticizer", quantity = 5 },
		{item = "syn_rub", quantity = 2 },
		{item = "min_oil", quantity = 2 },
		{item = "battery", quantity = 1 },
	},
	-- Can be a weapon, must follow this format
	['bulletproofs'] = { 
		{item = "garment_pooch", quantity = 20 }, 
		{item = "plasticizer", quantity =10 },
		{item = "syn_rub", quantity = 10 },
		{item = "steel_pooch", quantity = 35 },
		{item = "airbag", quantity = 1 },
	},
	['blowtorch'] = { 
		{item = "clip", quantity =3 },
		{item = "syn_rub", quantity = 15 },
		{item = "steel_pooch", quantity = 150 },
	},
	['raspberry'] = { 
		{item = "battery", quantity = 1 },
		{item = "syn_rub", quantity = 15 },
		{item = "steel_pooch", quantity = 3 },
	}

}

-- Enable a shop to access the crafting menu
Config.Shop = {
	useShop = true,
	shopCoordinates = { x=580.64, y=-3111.3, z=6.07 },
	shopName = "Crafting Station",
	shopBlipID = 467,
	zoneSize = { x = 2.5, y = 2.5, z = 1.5 },
	zoneColor = { r = 255, g = 0, b = 0, a = 100 }
}

-- Enable crafting menu through a keyboard shortcut
Config.Keyboard = {
	useKeyboard = false,
	keyCode = 303
}
