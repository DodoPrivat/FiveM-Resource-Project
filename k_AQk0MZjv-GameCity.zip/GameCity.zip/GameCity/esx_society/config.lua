Config = {}

Config.Locale = 'en'
Config.EnableESXIdentity = false
Config.MaxSalary = 20000
