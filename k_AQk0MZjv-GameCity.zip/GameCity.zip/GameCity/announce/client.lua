RegisterCommand("announce", function(source, args)
    TriggerServerEvent('announce', table.concat(args, " "))
     -- we have to concatenate the table because the 'args' cb return a table (array)
     -- the 2nd parameter in 'table.concat' is just spacing each args out
end)


RegisterCommand("vcpd", function(source, args)
    TriggerServerEvent('vcpd', table.concat(args, " "))
     -- we have to concatenate the table because the 'args' cb return a table (array)
     -- the 2nd parameter in 'table.concat' is just spacing each args out
end)



RegisterCommand("new_med", function(source, args)
    TriggerServerEvent('new_med', table.concat(args, " "))
     -- we have to concatenate the table because the 'args' cb return a table (array)
     -- the 2nd parameter in 'table.concat' is just spacing each args out
end)

