Config              = {}
Config.Locale       = 'en'

-- How many cops need to be online
Config.LSPD = 10 
-- Minimum reward
Config.MinReward = 8000000
-- Maximum reward
Config.MaxReward = 9105000 