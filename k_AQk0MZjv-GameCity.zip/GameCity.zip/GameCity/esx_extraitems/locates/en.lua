Locales ['en'] = {
	['dive_suit_on']     = 'you put on the diving mask and the secure the oxygen tank. Oxygen level: ~g~100~w~',
	['oxygen_notify']    = 'remaining ~b~oxygen~y~ in the tank: %s%s~w~',
	['redgull_consumed'] = 'you feel hyped and can now run ~y~5~w~ minutes ~o~without becoming tired~w~!',
	['redgull_end']      = 'you feel your heart rate returning to a normal level',
}
