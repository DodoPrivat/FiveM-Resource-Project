Locales ['br'] = {
	['blip_name']          = 'prisão',
	['judge']              = 'JUIZ',
	['escape_attempt']     = 'você não tem permissão para escapar da prisão!',
	['remaining_msg']      = 'lá permanece ~b~%s~s~ segundos até que você seja libertado da prisão',
	['jailed_msg']         = '%s está agora preso por %s minutos',
	['unjailed']           = '%s foi libertado da prisão!'
}
