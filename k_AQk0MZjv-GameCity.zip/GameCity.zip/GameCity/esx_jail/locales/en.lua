Locales ['en'] = {
	['blip_name']          = 'prison',
	['judge']              = 'JUDGE',
	['escape_attempt']     = 'you are not allowed to escape the prison!',
	['remaining_msg']      = 'there remains ~b~%s~s~ seconds until you are released from jail',
	['jailed_msg']         = '%s is now in jail for %s minutes',
	['unjailed']           = '%s has been released from jail!'
}
