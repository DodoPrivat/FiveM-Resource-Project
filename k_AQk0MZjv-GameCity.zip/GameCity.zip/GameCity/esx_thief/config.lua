Config = {}

Config.Locale = 'en'

Config.EnableCash       = true
Config.EnableBlackMoney = true
Config.EnableInventory  = true
