Locales['en'] = {
	['invalid_amount']    = '~r~invalid amount',
	['wash_money']         = 'you have Washed ~g~$', 
	['press_e_wash'] 		='press ~INPUT_PICKUP~ to acces the ~r~MoneyWash.',  
}
