Locales['tr'] = {
    ['invalid_amount'] = 'Geçersiz miktar',
    ['atm_blip'] = 'ATM',
    ['bank_blip'] = 'Banka',
    ['atm_open'] = 'Hesabına giriş yapmak için ~INPUT_PICKUP~ tuşuna basın.',
    ['no_money'] = 'Yeterli miktarda paraya sahip değilsin.',
    ['recieved1'] = 'Aldığın para ',
    ['recieved2'] = 'Toplam aldığın para ',
    ['recieved3'] = ' Dolar',
    ['removed1'] = 'Ödeme Makbuzu ',
    ['removed2'] = 'Ödemen ',
    ['removed3'] = ' dolar gönderildi.',
}
