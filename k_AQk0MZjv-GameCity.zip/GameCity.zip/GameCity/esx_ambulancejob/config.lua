Config                            = {}

Config.DrawDistance               = 100.0

Config.Marker                     = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false }

Config.ReviveReward               = 7000  -- revive reward, set to 0 if you don't want it enabled
Config.AntiCombatLog              = true -- enable anti-combat logging?
Config.LoadIpl                    = false -- disable if you're using fivem-ipl or other IPL loaders

Config.Locale = 'en'

local second = 1000
local minute = 60 * second

Config.EarlyRespawnTimer          = 6 * minute  -- Time til respawn is available
Config.BleedoutTimer              = 10 * minute -- Time til the player bleeds out

Config.EnablePlayerManagement     = true

Config.RemoveWeaponsAfterRPDeath  = true
Config.RemoveCashAfterRPDeath     = true
Config.RemoveItemsAfterRPDeath    = true

-- Let the player pay for respawning early, only if he can afford it.
Config.EarlyRespawnFine           = true
Config.EarlyRespawnFineAmount     = 5000

Config.RespawnPoint = { coords = vector3(296.35, -588.14, 43.26), heading = 81.07 }

Config.Hospitals = {

	CentralLosSantos = {
--PILLBOX
		Blip = {
			
			coords = vector3(307.49, -595.14, 43.29),
			sprite = 61,
			scale  = 1.2,
			color  = 2
		},

		AmbulanceActions = {
			vector3(300.81, -597.48, 42.30)
			
		},

		Pharmacies = {
			vector3(306.57, -601.75, 42.30)
	
			
		},

		Vehicles = {
			{
				Spawner = vector3(299.99, -580.57, 43.26),
				InsideShop = vector3(446.7, -1355.6, 43.5),
				Marker = { type = 36, x = 1.0, y = 1.0, z = 1.0, r = 100, g = 50, b = 200, a = 100, rotate = true },
				SpawnPoints = {
				----	{ coords = vector3(368.06, -585.95, 28.8), heading = 305.6, radius = 4.0 }
					{ coords = vector3(294.48, -573.41, 42.26), heading =55.34, radius = 4.0 },
				---	{ coords = vector3(309.4, -1442.5, 29.8), heading = 227.6, radius = 6.0 }
				}
				
				
			
			}
			
			
		},
		
		Vehicles1 = {
			{
				Spawner = vector3(292.62, -600.61, 43.0),
				InsideShop = vector3(446.7, -1355.6, 43.5),
				Marker = { type = 36, x = 1.0, y = 1.0, z = 1.0, r = 100, g = 50, b = 200, a = 100, rotate = true },
				SpawnPoints = {
					{ coords = vector3(368.06, -585.95, 28.8), heading = 305.6, radius = 4.0 }
				----	{ coords = vector3(294.0, -1433.1, 29.8), heading = 227.6, radius = 4.0 },
				---	{ coords = vector3(309.4, -1442.5, 29.8), heading = 227.6, radius = 6.0 }
				}
				
				
			
			}
			
			
		},
		Helicopters = {
			{
				Spawner = vector3(340.39, -587.73, 74.17),
				InsideShop = vector3(3, -686.6, 250.41),
				Marker = { type = 34, x = 1.5, y = 1.5, z = 1.5, r = 100, g = 150, b = 150, a = 100, rotate = true },
				SpawnPoints = {
					{ coords = vector3(352.36, -587.78, 74.17), heading = 239.88, radius = 10.0 },
					{ coords = vector3(352.36, -587.78, 74.17), heading = 239.88, radius = 10.0 }
					
				
				}
			}
		},

		FastTravels = {
		
------LOWER PILLBOX ENTRANCE
			{
				From = vector3(339.26, -594.93, 27.51),
				To = { coords = vector3(330.72, -593.45, 43.2), heading = 83.83 },
				Marker = { type = 1, x = 1.5, y = 1.5, z = 1.0, r = 102, g = 0, b = 102, a = 100, rotate = false }
			},
			{
				From = vector3(332.37, -595.81, 42.29),
				To = { coords = vector3(338.02, -590.46, 28.79), heading = 0.0 },
				Marker = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false }
			},
---WEED ENTRANCE EXIT
			{
				From = vector3(102.34, 175.56, 103.50),

				To = { coords = vector3(1064.06, -3181.55, -39.00), heading = 167.61 },
				Marker = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false }
			},
---WEED ENTRANCE PAGAWAS
			{
				From = vector3(1066.30, -3183.43, -40.15),

				To = { coords = vector3(103.17, 173.80, 104.00), heading = 148.59 },
				Marker = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false }
			},
---COKE DEALER PAGAWAS EXIT
			{
				From = vector3(1138.07, -3198.98, -40.67),
				To = { coords = vector3(1954.18, 3840.24, 32.18), heading = 0.0 },
				Marker = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false }
			},




---METHLAB PROCESS PAGAWAS EXIT
			{
				From = vector3(996.96, -3157.98, -39.91),
				To = { coords = vector3(1954.18, 3840.24, 32.18), heading = 0.0 },
				Marker = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false }
			},


---METHLAB PROCESS ENTRANCE
			{
				From = vector3(1951.38, 3841.28, 31.18),
				To = { coords = vector3(998.51, -3160.36,-38.91), heading = 257.35},
				Marker = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false }
			},




---COCAINLAB PAGAWAS EXIT
			{
				From = vector3(1088.83, -3187.56, -37.29),
				To = { coords = vector3(-2795.07, 1433.81, 101.00), heading = 0.0 },
				Marker = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false }
			},
	---COCAINLAB PASULOD ENTRANCE
			{
				From = vector3(-2797.98, 1431.58, 99.93 ),
				To = { coords = vector3(1090.58, -3189.63, -38.99), heading = 180.61},
				Marker = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false }
			}	
		},

		FastTravelsPrompt = {
			{
				From = vector3(310.34, -602.93, 42.28),
				To = { coords = vector3(340.39, -587.73, 74.17), heading = 0.0 },
				Marker = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, a = 100, rotate = false },
				Prompt = ('press ~INPUT_CONTEXT~ to go at Roof Top.')
			},
		--{
		--	From = vector3(298.6, -599.52, 42.30),
		--		To = { coords = vector3(357.58, -590.88, 28.79), heading = 0.0 },
		--	--	Marker = { type = 1, x = 1.5, y = 1.5, z = 1.0, r = 102, g = 0, b = 102, a = 100, rotate = false },
			--	Prompt = _U('roof_top')
		--	}

		
		}

	}
}

Config.AuthorizedVehicles = {

	ambulance = {
		{ model = 'dodgeEMS', label = 'Ambulance Car', price = 5000},
		{ model = 'ambulance', label = 'Ambulance Van 1', price = 5000}
	},

	doctor = {
		{ model = 'dodgeEMS', label = 'Ambulance Car', price = 4500},
		{ model = 'ambulance', label = 'Ambulance Van 1', price = 5000}
	},

	chief_doctor = {
	
		{ model = 'dodgeEMS', label = 'Ambulance Car', price = 3000},
		
		{ model = 'ambulance', label = 'Ambulance Van 1', price = 5000}
	},

	boss = {
		{ model = 'dodgeEMS', label = 'Ambulance Car', price = 2000},
		
		{ model = 'ambulance', label = 'Ambulance Van 1', price = 5000}
	}

}

Config.AuthorizedHelicopters = {

	ambulance = {},

	doctor = {
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 150000 },
		{ model = 'polmav', label = 'Ambulance Mav', price = 150000 },
	{ model = 'seasparrow', label = 'Sea Sparrow', price = 100000 }
	},

	chief_doctor = {
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 150000 },
			{ model = 'polmav', label = 'Ambulance Mav', price = 150000 },
		{ model = 'seasparrow', label = 'Sea Sparrow', price = 100000 }
	},

	boss = {
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 10000 },
			{ model = 'polmav', label = 'Ambulance Mav', price = 150000 },
		{ model = 'seasparrow', label = 'Sea Sparrow', price = 100000 }
	}

}
