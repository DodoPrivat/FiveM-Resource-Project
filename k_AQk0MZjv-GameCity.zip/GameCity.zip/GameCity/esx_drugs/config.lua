Config              = {}
Config.MarkerType   = -1 -- Marker visible or not. -1 = hiden  Set to 1 for a visible marker. To have a list of avaible marker go to https://docs.fivem.net/game-references/markers/
Config.DrawDistance = 100.0 --Distance where the marker be visible from
Config.ZoneSize     = {x = 5.0, y = 5.0, z = 3.0} -- Size of the marker
Config.MarkerColor  = {r = 0, g = 255, b = 0} --Color of the marker

Config.RequiredCopsCoke  = 3 --Ammount of cop that need to be online to be able to harvest/process/sell coke
Config.RequiredCopsMeth  = 3 --Ammount of cop that need to be online to be able to harvest/process/sell meth
Config.RequiredCopsWeed  = 2 --Ammount of cop that need to be online to be able to harvest/process/sell weed
Config.RequiredCopsOpium = 3 --Ammount of cop that need to be online to be able to harvest/process/sell opium
Config.RequiredCopsSolvent = 1 --Ammount of cop that need to be online to be able to harvest/process/sell solvent
Config.RequiredCopsR2 = 2 --Ammount of cop that need to be online to be able to harvest/process/sell solvent
Config.RequiredCopsNO = 2 --Ammount of cop that need to be online to be able to harvest/process/sell solvent
Config.RequiredCopsSteel = 0 --Ammount of cop that need to be online to be able to harvest/process/sell steel
Config.RequiredCopsGarment = 0 --Ammount of cop that need to be online to be able to harvest/process/sell garment

Config.TimeToFarmWeed     = 2  * 1000 -- Ammount of time to harvest weed
Config.TimeToProcessWeed  = 3  * 1000 -- Ammount of time to process weed
Config.TimeToSellWeed     = 1  * 1000 -- Ammount of time to sell weed

Config.TimeToFarmOpium    = 4  * 1000 -- Ammount of time to harvest coke
Config.TimeToProcessOpium = 5  * 1000 -- Ammount of time to process coke
Config.TimeToSellOpium    = 1  * 1000 -- Ammount of time to sell coke

Config.TimeToFarmCoke     = 6  * 1000 -- Ammount of time to harvest coke
Config.TimeToProcessCoke  = 7  * 1000 -- Ammount of time to process coke
Config.TimeToSellCoke     = 1  * 1000 -- Ammount of time to sell coke

Config.TimeToFarmMeth     = 8  * 1000 -- Ammount of time to harvest meth
Config.TimeToProcessMeth  = 9 * 1000 -- Ammount of time to process meth
Config.TimeToSellMeth     = 1  * 1000 -- Ammount of time to sell meth

Config.TimeToFarmSolvent     = 3  * 1000 -- Ammount of time to harvest solvent
Config.TimeToProcessSolvent  = 4 * 1000 -- Ammount of time to process solvent
Config.TimeToSellSolvent     = 1  * 1000 -- Ammount of time to sell solvent

Config.TimeToFarmR2     = 10  * 1000 -- Ammount of time to harvest r2
Config.TimeToProcessR2  = 15 * 1000 -- Ammount of time to process r2
Config.TimeToSellR2     = 1  * 1000 -- Ammount of time to sell r2

Config.TimeToFarmNO     = 10  * 1000 -- Ammount of time to harvest no
Config.TimeToProcessNO  = 15 * 1000 -- Ammount of time to process no
Config.TimeToSellNO     = 1  * 1000 -- Ammount of time to sell no

Config.TimeToFarmSteel     = 10  * 1000 -- Ammount of time to harvest steel
Config.TimeToProcessSteel  = 15 * 1000 -- Ammount of time to process steel
Config.TimeToSellSteel     = 1  * 1000 -- Ammount of time to sell steel

Config.TimeToFarmGarment     = 10  * 1000 -- Ammount of time to harvest garment
Config.TimeToProcessGarment  = 15 * 1000 -- Ammount of time to process garment
Config.TimeToSellGarment     = 1  * 1000 -- Ammount of time to sell garment

Config.Locale = 'en'

Config.Zones = {
	CokeField =		{x=-77.23,   y=-1402.03,  z=29.36},
	CokeProcessing =		{x=-79.7,    y=-1393.02,  z=29.36},
	CokeDealer =		{x=977.14,   y=-104.16,   z=74.85},
	
    	MethField =		{x=-224.6,   y=-2655.4,   z=6.0},
	MethProcessing =		{x=-232.11,  y=-2654.97,  z=6.0},
	MethDealer =		{x=-60.29,   y=-1217.4,   z=28.7},
	
	WeedField =		{x=1057.54,  y=-3197.39,  z=-39.14},
	WeedProcessing =		{x=1039.24,  y=-3205.39,  z=-38.17},
	WeedDealer =		{x =-54.249694824219,   y= -1443.3666992188,  z= 31.068626403809},
	
	OpiumField =		{x=2433.804, y=4969.196,  z=42.348},
	OpiumProcessing =	{x=2434.43,  y=4964.18,   z=42.348},
	OpiumDealer =		{x=32.09,    y=-627.07,   z=10.77},
	
	SolventField =		{x=1268.49,  y=-1710.16,  z=54.77},
	SolventProcessing =	{x=1299.07,  y=-1707.46,  z=55.08},
	SolventDealer =		{x=169.08,   y=-1222.29,  z=29.51},
	
	R2Field =			{x=-1818.36, y=3011.37,   z=32.81},
	R2Processing =   		{x=-1776.92, y=2982.46,   z=33.39},
	R2Dealer =		{x=-1271.88, y=-239.44,   z=42.45},
	
	NOField =			{x=842.42, y=2119.11,   z=52.6},
	NOProcessing =   		{x=843.31, y=2113.98,    z=52.27},
	NODealer =		{x=-1278.45, y=-214.47,   z=42.45},
	
	SteelField =		{x=847.16, y=2379.02,   z=55.32},
	SteelProcessing =   		{x=2763.88, y=1550.34,    z=24.5},
	SteelDealer =		{x=-216.37, y=-1318.77,   z=30.89},
	
	GarmentField =		{x=711.98, y=-974.1,   z=30.4},
	GarmentProcessing =   	{x=718.68, y=-960.0,    z=30.4},
	GarmentDealer =		{x=125.7, y=-223.96,   z=54.56}
}

Config.DisableBlip = false -- Set to true to disable blips. False to enable them.
Config.Map = {

  --{name="Coke Farm Entrance",    color=4, scale=0.8,  id=501, x=-77.23,    y=-1402.03,   z=29.36},
  {name="Coke Farm",               color=4, scale=0.75, id=501, x=-77.23,    y=-1402.03,   z=29.36},
  --{name="Coke Processing",       color=4, scale=0.8,  id=501, x=1101.837,  y=-3193.732,  z=-38.993},
   {name="Coke Sales",              color=3, scale=0.75, id=501, x=977.14,    y=-104.16,    z=74.85},
 -- {name="Meth Farm Entrance",    color=6, scale=0.8,  id=499, x=1386.659,  y=3622.805,   z=35.012},
 {name="Meth Farm",               color=6, scale=0.75, id=499, x=-224.6,    y=-2655.4,    z=6.0},
  --{name="Meth Processing",       color=6, scale=0.8,  id=499, x=1014.878,  y=-3194.871,  z=-38.993},
  {name="Meth Sales",              color=3, scale=0.75, id=499, x=-60.29,    y=-1217.4,    z=28.7},
 -- {name="Opium Farm Entrance",   color=6, scale=0.8,  id=403, x=2433.804,  y=4969.196,   z=42.348},
 {name="Opium Farm",              color=6, scale=0.75, id=403, x=2433.804,  y=4969.196,   z=42.348},
--{name="Opium Processing",        color=6, scale=0.8,  id=403, x=2434.43,   y=4964.18,    z=42.348},
  {name="Opium Sales",             color=3, scale=0.75, id=403, x=32.09,     y=-627.07,    z=10.77},
 -- {name="Weed Farm Entrance",    color=2, scale=0.8,  id=140, x=2221.858,  y=5614.81,    z=54.902},
  {name="Weed Farm",               color=2, scale=0.75, id=140, x=2223.49,   y=5608.91,    z=54.69},
  --{name="Weed Processing",       color=2, scale=0.8,  id=140, x=1037.527,  y=-3205.368,  z=-38.17},
  {name="Weed Sales",              color=3, scale=0.75, id=140, x =-54.249694824219,   y= -1443.3666992188,  z= 31.068626403809},
 {name="Solvent Farm",            color=2, scale=0.75, id=421, x=1268.49,   y=-1710.16,   z=54.77},
 {name="Solvent Sales",           color=3, scale=0.35, id=421, x=169.08,    y=-1222.29,   z=29.51},
 {name="R2 Alkyl Production",     color=2, scale=0.35, id=653, x=-1818.36, y=3011.37,   z=32.815},
 {name="NO+ Nitroso Group Production",  color=2, scale=0.35, id=654, x=842.42, y=2119.11,   z=52.6},
 {name="R2 Alkyl Group Transforming",      color=28, scale=0.35, id=651, x=-1776.92, y=2982.46,   z=33.39},
 --{name="NO+ Nitroso Group Transforming",   color=28, scale=0.75, id=651, x=843.31, y=2113.98,    z=52.27},

 {name="Scrap Production",     color=5, scale=0.35, id=677, x=847.16, y=2379.02,   z=55.32},
 {name="Yarn Production",  color=5, scale=0.35, id=618, x=711.98, y=-974.1,   z=30.4},
 {name="Steel Transforming",      color=81, scale=0.35, id=677, x=2763.88, y=1550.34,    z=24.5},
 {name="Garment Transforming",   color=81, scale=0.35, id=618, x=718.68, y=-960.0,    z=30.4},
 {name="Steel Selling",      color=28, scale=0.35, id=677, x=-216.37, y=-1318.77,   z=30.89},
 {name="Garment Selling",   color=28, scale=0.35, id=618, x=125.7, y=-223.96,   z=54.56},

}
