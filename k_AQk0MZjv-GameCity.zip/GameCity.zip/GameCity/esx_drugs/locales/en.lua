Locales['en'] = {
	['press_collect_coke'] = 'Collect Cocaine',
	['press_process_coke'] = 'Pack Cocaine',
	['press_sell_coke'] = 'Sell Cocaine',
	['press_collect_Steel'] = 'Collect Scrap Metal',
	['press_process_Steel'] = 'Steel Production',
	['press_sell_Steel'] = 'Sell Steel',
	['press_collect_Garment'] = 'Collect Yarn',
	['press_process_Garment'] = 'Garment Production',
	['press_sell_Garment'] = 'Sell Garment',
	['press_collect_meth'] = 'Mix Meth',
	['press_process_meth'] = 'Bag Meth',
	['press_sell_meth'] = 'Sell Meth',
	['press_collect_weed'] = 'Harvest Weed',
	['press_process_weed'] = 'Roll Weed',
	['press_sell_weed'] = 'Sell Weed',
	['press_collect_opium'] = 'Cook Opium',
	['press_process_opium'] = 'Pack Opium',
	['press_sell_opium'] = 'Sell Opium',
	['press_collect_solvent'] = 'Mix Solvent',
	['press_process_solvent'] = 'Plastic Solvent',
	['press_sell_solvent'] = 'Sell Solvent',
	['press_collect_R2'] = 'Make Alkyl Chemical',
	['press_process_R2'] = 'Transform R2 Alkyl Group',
	['press_sell_R2'] = 'Sell R2 Alkyl Group',
	['press_collect_NO'] = 'Mix Nitroso Chemical',
	['press_process_NO'] = 'Transform NO+ Nitroso Group',
	['press_sell_NO'] = 'Sell NO+ Nitroso Group',
	['act_imp_police'] = 'you cannot participate illegal activities unless there\'s enough cops online: ~o~%s~s~/~y~%s~s~ online',
	['inv_full_coke'] = 'you can no longer collect Cocaine, your inventory is ~r~full~s~',
	['inv_full_R2'] = 'you can no longer carry R2 Alkyl, your inventory is ~r~full~s~',
	['inv_full_Steel'] = 'you can no longer carry Scrap, your inventory is ~r~full~s~',
	['inv_full_Garment'] = 'you can no longer carry Yarn, your inventory is ~r~full~s~',
	['too_many_Steel'] = 'you have too many Steel',
	['too_many_Garment'] = 'you have too many Garment',
	['too_many_R2'] = 'you have too many R2 Alkyl Group',
	['not_enough_Steel'] = 'you do not have enough Steel to ~r~transform~s~',
	['not_enough_Garment'] = 'you do not have enough Garment to ~r~transform~s~',	
	['inv_full_NO'] = 'you can no longer carry NO+ Nitroso, your inventory is ~r~full~s~',	
	['not_enough_R2'] = 'you do not have enough R2 Alkyl to ~r~transform~s~',
	['not_enough_NO'] = 'you do not have enough NO+ Nitroso to ~r~transform~s~',
	['sold_one_R2'] = 'you\'ve sold ~y~x1~s~ ~y~R2 Alkyl Group~s~',	
	['sold_one_NO'] = 'you\'ve sold ~y~x1~s~ ~y~NO+ Nitroso Group~s~',
	['pickup_in_prog'] = '~y~IN PROGRESS~s~...',
	['too_many_pouches'] = 'you have too many bag',
	['not_enough_coke'] = 'you do not have enough coke to ~r~pack~s~',
	['packing_in_prog'] = '~y~Packaging in progress~s~...',
	['no_pouchs_sale'] = 'You have no more bag for ~r~sale~s~',
	['sold_one_coke'] = 'you\'ve sold ~y~x1~s~ ~y~Cocaine bag~s~',
	['sale_in_prog'] = '~g~Sale in progress~s~...',
	['inv_full_meth'] = 'you can no longer collect Meth, your inventory is ~r~full~s~',
	['not_enough_meth'] = 'you do not have enough Meth to ~r~pack~s~',
	['sold_one_meth'] = 'you\'ve sold ~g~x1 Meth bag(28G)~s~',
	['inv_full_weed'] = 'you can no longer collect Weed, your inventory is ~r~full~s~',
	['not_enough_weed'] = 'you do not have enough Weed to ~r~pack~s~',
	['sold_one_weed'] = 'you\'ve sold ~g~x1 Weed bag(28G)~s~',
	['sold_one_Steel'] = 'you\'ve sold ~g~x1 Finished Steel~s~',
	['sold_one_Garment'] = 'you\'ve sold ~g~x1 Garment~s~',
	['used_one_weed'] = 'you used 1G ~b~weed',
	['inv_full_opium'] = 'you can no longer collect opium, your inventory is ~r~full~s~',
	['not_enough_opium'] = 'you do not have enough opium to ~r~pack~s~',
	['sold_one_opium'] = 'you\'ve sold ~g~x1 opium bag(28G)~s~',
	['used_one_opium'] = 'you used 1 bag of ~b~opium',
	['inv_full_solvent'] = 'you can no longer collect opium, your inventory is ~r~full~s~',
	['not_enough_solvent'] = 'you do not have enough solvent to ~r~pack~s~',
	['sold_one_solvent'] = 'you\'ve sold ~g~x1 solvent plastic(28G)~s~',
	['used_one_solvent'] = 'you used 1 bag of ~b~solvent',
	['exit_marker'] = 'Press ~INPUT_LOOK_BEHIND~ to cancel the ~y~process~s~',
	['no_pouches_weed_sale'] = 'You do not have any bag of weed(28G) to sell',
	['no_pouches_coke_sale'] = 'You do not have any bag of coke(28G) to sell',
	['no_pouches_meth_sale'] = 'You do not have any bag of meth(28G) to sell',
	['no_pouches_opium_sale'] = 'You do not have any bag of meth(28G) to sell',
	['no_pouches_solvent_sale'] = 'You do not have any plastic of solvent(28G) to sell',
	['no_pouches_R2_sale'] = 'You do not have any Chemical to sell',
	['no_pouches_NO_sale'] = 'You do not have any Chemical to sell',
	['no_pouches_Steel_sale'] = 'You do not have any Steel to sell',
	['no_pouches_Garment_sale'] = 'You do not have any Garment to sell',
	['controls_cooldown'] = 'You must wait 5 minutes before you can do this again.',
	
}
