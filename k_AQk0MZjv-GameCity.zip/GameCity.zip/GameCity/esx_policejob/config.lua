Config                            = {}

Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 0.5 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }

Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- enable if you're using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableLicenses             = true -- enable if you're using esx_license

Config.EnableHandcuffTimer        = true -- enable handcuff timer? will unrestrain player after the time ends
Config.HandcuffTimer              = 10 * 60000 -- 10 mins

Config.EnableJobBlip              = true -- enable blips for colleagues, requires esx_society

Config.MaxInService               = -1
Config.Locale = 'en'

Config.PoliceStations = {

	LSPD = {

		Blip = {
			Coords  = vector3(425.1, -979.5, 30.7),
			Sprite  = 60,
			Display = 4,
			Scale   = 1.2,
			Colour  = 29
		},

		Cloakrooms = {
			vector3(452.6, -992.8, 30.6)
		},

		Armories = {
			vector3(451.7, -980.1, 30.6)
		},

		Vehicles = {
			{
				Spawner = vector3(454.6, -1017.4, 28.4),
				InsideShop = vector3(200.94, -1000.44, -99.02),
				SpawnPoints = {
					{ coords = vector3(438.4, -1018.3, 27.7), heading = 90.0, radius = 6.0 },
					{ coords = vector3(441.0, -1024.2, 28.3), heading = 90.0, radius = 6.0 },
					{ coords = vector3(453.5, -1022.2, 28.0), heading = 90.0, radius = 6.0 },
					{ coords = vector3(450.9, -1016.5, 28.1), heading = 90.0, radius = 6.0 }
				}
			},

			{
				Spawner = vector3(473.3, -1018.8, 28.0),
				InsideShop = vector3(228.5, -993.5, -99.0),
				SpawnPoints = {
					{ coords = vector3(475.9, -1021.6, 28.0), heading = 276.1, radius = 6.0 },
					{ coords = vector3(484.1, -1023.1, 27.5), heading = 302.5, radius = 6.0 }
				}
			}
		},

		Helicopters = {
			{
				Spawner = vector3(461.1, -981.5, 43.6),
				InsideShop = vector3(477.0, -1106.4, 43.0),
				SpawnPoints = {
					{ coords = vector3(449.5, -981.2, 43.6), heading = 92.6, radius = 10.0 }
				}
			}
		},

		BossActions = {
			vector3(448.4, -973.2, 30.6)
		}

	}

}

Config.AuthorizedWeapons = {
	recruit = {
		{ weapon = 'WEAPON_HEAVYPISTOL', components = { 0, 10000, 10000, 10000, nil }, price = 2000 },
		{ weapon = 'WEAPON_CARBINERIFLE', components = { 0, 50000, 50000, 50000,  nil }, price = 5000 },
		{ weapon = 'WEAPON_SMOKEGRENADE', price = 5000 },
		{ weapon = 'WEAPON_STUNGUN', price = 5000 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 80 }
	},
	

	

	officers = {
		{ weapon = 'WEAPON_HEAVYPISTOL', components = { 0, 10000, 10000, 10000, nil }, price = 2000 },
		{ weapon = 'WEAPON_CARBINERIFLE', components = { 0, 50000, 50000, 50000, 50000, nil }, price = 5000 },
		{ weapon = 'WEAPON_STUNGUN', price = 5000 },
		{ weapon = 'WEAPON_SMOKEGRENADE', price = 5000 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 80 }
		--{ weapon = 'WEAPON_SPECIALCARBINE', components = { 0, 1, nil  }, price = 5000 }
	
	},

	corporal = {
		{ weapon = 'WEAPON_HEAVYPISTOL', components = { 0, 0, 1, 1, nil }, price = 2000 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 5000, 25000, 50000, 50000, nil  }, price = 5000,  ammoPrice = 5000, AmmoToGive = 1000 },
		{ weapon = 'WEAPON_STUNGUN', price = 5000 },
		{ weapon = 'WEAPON_SMOKEGRENADE', price = 5000 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 5000 },
		{ weapon = 'WEAPON_SPECIALCARBINE', components = { 0, 5000, 25000, 30000, 50000, nil  }, price = 5000 ,  ammoPrice = 5000, AmmoToGive = 1000 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 80 }
	},
	
	sergeant = {
		{ weapon = 'WEAPON_HEAVYPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 10000 },
		{ weapon = 'WEAPON_SMG', components = { 0, nil }, price = 3000 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 80 },
		{ weapon = 'WEAPON_SMOKEGRENADE', price = 5000 },
		{ weapon = 'WEAPON_SPECIALCARBINE', components = { 0, 1, 1, 1, 1, nil }, price = 5000, ammoPrice = 5000, AmmoToGive = 1000 },
		{ weapon = 'WEAPON_STUNGUN', price = 5000 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, nil }, price = 5000,  ammoPrice = 5000, AmmoToGive = 1000 },
		},

	lieutenant  = {
		{ weapon = 'WEAPON_HEAVYPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1000 },
		{ weapon = 'WEAPON_SMG', components = { 0, nil }, price = 30000 ,  ammoPrice = 5000, AmmoToGive = 1000 },
		{ weapon = 'WEAPON_SPECIALCARBINE', components = { 0, 1, 1, 1, 1, nil }, price = 5000 ,  ammoPrice = 5000, AmmoToGive = 1000 },
		{ weapon = 'WEAPON_STUNGUN', price = 5000 },
		{ weapon = 'WEAPON_SMOKEGRENADE', price = 5000 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 5000 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 80 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 1, 1, 1, 1, nil }, price = 5000,  ammoPrice = 5000, AmmoToGive = 1000 },
		},

	captain = {
		{ weapon = 'WEAPON_HEAVYPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1000 },
		{ weapon = 'WEAPON_SMG', components = { 0, nil }, price = 3000 },
		{ weapon = 'WEAPON_STUNGUN', price = 5000 },
		{ weapon = 'WEAPON_SMOKEGRENADE', price = 5000 },
		{ weapon = 'WEAPON_HEAVYSNIPER',price = 5000 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 80 },
		{ weapon = 'WEAPON_SPECIALCARBINE', components = { 0, 1, 1, 1, 1, nil }, price = 5000 , ammoPrice = 5000, AmmoToGive = 1000 },

		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 1, 1, 1, 1, nil }, price = 5000 , ammoPrice = 5000, AmmoToGive = 1000 }
		},

	major = {
		{ weapon = 'WEAPON_HEAVYPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1000 },
		{ weapon = 'WEAPON_SMG', components = { 0, nil }, price = 3000 },
		{ weapon = 'WEAPON_STUNGUN', price = 5000 },
		{ weapon = 'WEAPON_SMOKEGRENADE', price = 5000 },
		{ weapon = 'WEAPON_HEAVYSNIPER',price = 5000 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 80 },
		{ weapon = 'WEAPON_SPECIALCARBINE', components = { 0, 1, 1, 1, 1, nil }, price = 5000 , ammoPrice = 5000, AmmoToGive = 1000 },

		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 1, 1, 1, 1, nil }, price = 5000 , ammoPrice = 5000, AmmoToGive = 1000 }
		},

	dcop = {
		{ weapon = 'WEAPON_HEAVYPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1000 },
		{ weapon = 'WEAPON_SMG', components = { 0, nil }, price = 3000 },
		{ weapon = 'WEAPON_STUNGUN', price = 5000 },
		{ weapon = 'WEAPON_SMOKEGRENADE', price = 5000 },
		{ weapon = 'WEAPON_HEAVYSNIPER',price = 5000 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 80 },
		{ weapon = 'WEAPON_SPECIALCARBINE', components = { 0, 1, 1, 1, 1, nil }, price = 5000 , ammoPrice = 5000, AmmoToGive = 1000 },

		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 1, 1, 1, 1, nil }, price = 5000 , ammoPrice = 5000, AmmoToGive = 1000 }
		},


	boss = {
		{ weapon = 'WEAPON_HEAVYPISTOL', components = { 0, 0, 1, 1, nil }, price = 2000 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 1, 1, 1, 1, nil }, price = 5000 , ammoPrice = 5000, AmmoToGive = 1000 },

		{ weapon = 'WEAPON_STUNGUN', price = 5000 },
		{ weapon = 'WEAPON_SMOKEGRENADE', price = 5000 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 5000 },
		{ weapon = 'WEAPON_SMG', components = { 0, nil }, price = 5000 },
		{ weapon = 'WEAPON_SPECIALCARBINE', components = { 0, 1, 1, 1, 1, nil }, price = 5000 , ammoPrice = 5000, AmmoToGive = 1000 },

		{ weapon = 'WEAPON_PUMPSHOTGUN', components = { 1, 1, nil }, price = 5000 , ammoPrice = 5000, AmmoToGive = 1000 },

		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 }
	}
}

Config.AuthorizedVehicles = {
	Shared = {
		--{ model = 'policeb', label = 'Police Bike', price = 300003 },
		--{ model = 'police', label = 'Police Cruiser', price = 20000 }
	
	

	},

	recruit = {
		{ model = 'polchiron', label = 'Police Car', price = 50000 }

	},

	officers = {
		{ model = 'polchiron', label = 'Police Car', price = 50000 }
	},

	corporal = {
		{ model = 'polchiron', label = 'Police Car', price = 50000 }
	},

	sergeant = {
		{ model = 'riot', label = 'Police Riot', price = 20000 },
		{ model = 'polchiron', label = 'Police Car', price = 50000 }

	},


	lieutenant = {
		{ model = 'riot', label = 'Police Riot', price = 20000 },
		{ model = 'polchiron', label = 'Police Car', price = 50000 }

	},

	captain = {
		{ model = 'riot', label = 'Police Riot', price = 20000 },
		{ model = 'polchiron', label = 'Police Car', price = 50000 }

	},


	major = {
		{ model = 'riot', label = 'Police Riot', price = 20000 },
		{ model = 'polchiron', label = 'Police Car', price = 50000 }

	},

	dcop = {
		{ model = 'riot', label = 'Police Riot', price = 20000 },
		{ model = 'polchiron', label = 'Police Car', price = 50000 },
		{ model = 'policeb', label = 'Police Bike', price = 32500 }
	},

	boss = {
		{ model = 'riot', label = 'Police Riot', price = 20000 },
		{ model = 'polchiron', label = 'Police Car', price = 50000 },
		{ model = 'policeb', label = 'Police Bike', price = 32500 }
	}
}

Config.AuthorizedHelicopters = {
	recruit = {},

	officer = {},

	sergeant = {},

	intendent = {},

	lieutenant = {
		{ model = 'polmav', label = 'Police Maverick', livery = 0, price = 5000000 }
	},

	chef = {
		{ model = 'polmav', label = 'Police Maverick', livery = 0, price = 5000000 }
	},

	boss = {
		{ model = 'polmav', label = 'Police Maverick', livery = 0, price = 100000 }
	}
}

-- CHECK SKINCHANGER CLIENT MAIN.LUA for matching elements

Config.Uniforms = {
	recruit_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 1,
			['torso_1'] = 55,   ['torso_2'] = 3,
			['decals_1'] = 8,   ['decals_2'] = 3,
			['arms'] = 26,
			['pants_1'] = 97,   ['pants_2'] = 13,
			['shoes_1'] = 26,   ['shoes_2'] = 0,
			['helmet_1'] = 107,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 20,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 160,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 3,
			['decals_1'] = 8,   ['decals_2'] = 3,
			['arms'] = 26,
			['pants_1'] = 24,   ['pants_2'] = 33,
			['shoes_1'] = 26,   ['shoes_2'] = 0,
			['helmet_1'] = 107,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 20,
			['ears_1'] = 0,     ['ears_2'] = 0
		}
	},
	officer_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 139,   ['torso_2'] = 3,
			['decals_1'] = 7,   ['decals_2'] = 1,
			['arms'] = 33,
			['pants_1'] = 78,   ['pants_2'] = 2,
			['glasses_1'] = 5,   ['glasses_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 106,  ['helmet_2'] = 10,
			['chain_1'] = 95,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 136,   ['torso_2'] = 3,
			['decals_1'] = 7,   ['decals_2'] = 1,
			['arms'] = 33,
			['pants_1'] = 97,   ['pants_2'] = 13,
			['glasses_1'] = 5,   ['glasses_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 106,  ['helmet_2'] = 10,
			['chain_1'] = 95,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		}
	},
	sergeant_wear = {
		male = {
	['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 220,   ['torso_2'] = 11,
			['decals_1'] = 7,   ['decals_2'] = 1,
			['arms'] = 29,
			['pants_1'] = 97,   ['pants_2'] = 13,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 106,  ['helmet_2'] = 11,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
	['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 220,   ['torso_2'] = 11,
			['decals_1'] = 7,   ['decals_2'] = 1,
			['arms'] = 29,
			['pants_1'] = 61,   ['pants_2'] = 9,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 106,  ['helmet_2'] = 11,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		}
	},
	intendent_wear = {
		male = {
	['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 232,   ['torso_2'] = 10,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 26,
			['pants_1'] = 97,   ['pants_2'] = 13,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['glasses_1'] = 5,   ['glasses_2'] = 0,
			['helmet_1'] = 105,  ['helmet_2'] = 11,
			['chain_1'] = 95,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
	['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 232,   ['torso_2'] = 10,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 23,
			['pants_1'] = 97,   ['pants_2'] = 13,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['glasses_1'] = 5,   ['glasses_2'] = 0,
			['helmet_1'] = 106,  ['helmet_2'] = 11,
			['chain_1'] = 95,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		}
	},
	lieutenant_wear = { -- currently the same as intendent_wear
		male = {
			['tshirt_1'] = 160,  ['tshirt_2'] = 0,
			['torso_1'] = 222,   ['torso_2'] = 10,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 26,
			['pants_1'] = 97,   ['pants_2'] = 8,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['glasses_1'] = 5,   ['glasses_2'] = 0,
			['helmet_1'] = 106,  ['helmet_2'] = 10,
			['chain_1'] = 95,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 160,  ['tshirt_2'] = 0,
			['torso_1'] = 222,   ['torso_2'] = 10,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 26,
			['pants_1'] = 97,   ['pants_2'] = 8,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['glasses_1'] = 5,   ['glasses_2'] = 0,
			['helmet_1'] = 106,  ['helmet_2'] = 10,
			['chain_1'] = 95,    ['chain_2'] = 0,
			['ears_1'] = 0,     ['ears_2'] = 0
		}
	},
	chef_wear = {
		male = {
			['tshirt_1'] = 58,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 8,   ['decals_2'] = 3,
			['arms'] = 26,
			['pants_1'] = 25,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 26,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	boss_wear = { -- currently the same as chef_wear
		male = {
			['tshirt_1'] = 58,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 8,   ['decals_2'] = 3,
			['arms'] = 26,
			['pants_1'] = 25,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 26,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	bullet_wear = {
		male = {
			['bproof_1'] = 16,  ['bproof_2'] = 0
		},
		female = {
			['bproof_1'] = 13,  ['bproof_2'] = 1
		}
	},
	gilet_wear = {
		male = {
			['tshirt_1'] = 59,  ['tshirt_2'] = 1
		},
		female = {
			['tshirt_1'] = 36,  ['tshirt_2'] = 1
		}
	}

}