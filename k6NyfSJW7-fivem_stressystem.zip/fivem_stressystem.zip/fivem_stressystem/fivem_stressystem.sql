CREATE TABLE `character_stressystem` (
	`charid` varchar(30) NOT NULL,
	`stresslevel` int(10) NOT NULL DEFAULT '0',
	PRIMARY KEY (`charid`)
);


INSERT INTO `items` (`name`, `label`, `limit`) VALUES
	('cigpack', 'Ciggpaket', 5),
	('cigarette', 'Cigarett', 100),
	('snuffbox', 'Snusdosa', 5),
	('snuff', 'Prilla', 100)
;