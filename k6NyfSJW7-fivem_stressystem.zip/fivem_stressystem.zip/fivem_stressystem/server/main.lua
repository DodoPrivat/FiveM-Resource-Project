ESX                = nil
local cachedStressLevels = {}

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterServerEvent('fivem_stressystem:uploadStressToServer')
AddEventHandler('fivem_stressystem:uploadStressToServer', function(stresslevel)
    local src = source
    cachedStressLevels[src] = stresslevel
    print(cachedStressLevels[src])
    TriggerClientEvent('fivem_stressystem:clientCanUploadLevel', src)
    
end)

AddEventHandler('playerDropped', function(player)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    print(cachedStressLevels[src])
    MySQL.Async.execute('UPDATE character_stressystem SET stresslevel = @stresslevel WHERE charid = @charid',{
        ['@stresslevel'] = cachedStressLevels[src],
        ['@charid'] = xPlayer.identifier
    })
end)

ESX.RegisterServerCallback('fivem_stressystem:fetchStressLevel', function(source, cb)
    local src = source
	local xPlayer = ESX.GetPlayerFromId(source)
	MySQL.Async.fetchAll('SELECT stresslevel FROM character_stressystem WHERE charid = @charid', {
		['@charid'] = xPlayer.identifier
    }, function(result)
		if result[1] ~= nil then
			cb(result[1]['stresslevel'])
		else
			MySQL.Async.execute('INSERT INTO character_stressystem (charid, stresslevel) VALUES (@charid, @stresslevel)',
			{
				['@charid']   = xPlayer.identifier,
				['@stresslevel'] = 0.0
            }, function()
                cb(0.0)
            end)
		end
	end)
end)

RegisterServerEvent('fivem_stressystem:usingStressReliever')
AddEventHandler('fivem_stressystem:usingStressReliever', function(item)
    local xPlayer = ESX.GetPlayerFromId(source)
    xPlayer.removeInventoryItem(item, 1)
end)

ESX.RegisterUsableItem('cigpack', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)
	xPlayer.removeInventoryItem('cigpack', 1)
    xPlayer.addInventoryItem('cigarette', 20)
end)

ESX.RegisterUsableItem('snuffbox', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
	xPlayer.removeInventoryItem('snuffbox', 1)
    xPlayer.addInventoryItem('snuff', 15)
end)

ESX.RegisterUsableItem('cigarette', function(source)
	TriggerClientEvent('fivem_stressystem:useCigarette', source)
end)

ESX.RegisterUsableItem('snuff', function(source)
	TriggerClientEvent('fivem_stressystem:useSnuff', source)
end)