ESX = nil
local stresslevel = 0.0
local walking = false
local usingStressReliever = false
local recentlyUpdatedCache = false
local showStressLevel = true
Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.TriggerServerCallback('fivem_stressystem:fetchStressLevel', function(info)
		stresslevel = info
	end)
end)

RegisterNetEvent('fivem_stressystem:clientCanUploadLevel')
AddEventHandler('fivem_stressystem:clientCanUploadLevel', function()
	recentlyUpdatedCache = false
end)

RegisterNetEvent('fivem_stressystem:updateStressLevel')
AddEventHandler('fivem_stressystem:updateStressLevel', function(value, setting)
	UpdateStressLevel(value, setting)
end)

RegisterNetEvent('fivem_stressystem:useCigarette')
AddEventHandler('fivem_stressystem:useCigarette', function()
	if not usingStressReliever then
		usingStressReliever = true
		TriggerServerEvent('fivem_stressystem:usingStressReliever', 'cigarette')
		local playerPed = PlayerPedId()
		local x,y,z = table.unpack(GetEntityCoords(playerPed))
		local prop = CreateObject(GetHashKey('ng_proc_cigarette01a'), x, y, z + 0.2, true, true, true)
		local boneIndex = GetPedBoneIndex(playerPed, 18905)
		AttachEntityToEntity(prop, playerPed, boneIndex, 0.12, 0.028, 0.001, 10.0, 175.0, 0.0, true, true, false, true, 1, true)
		ESX.Streaming.RequestAnimDict('amb@world_human_aa_smoke@male@idle_a', function()
			TaskStartScenarioInPlace(playerPed, 'WORLD_HUMAN_SMOKING', 0, false)
			Citizen.Wait(5000)
			UpdateStressLevel(math.random(30, 60), 'remove')
			Citizen.Wait(5000)
			ClearPedTasksImmediately(playerPed)
			ESX.SetTimeout(60000, function()
				usingStressReliever = false
			end)
		end)
	else
		ESX.ShowNotification('Du kan ska inte stressröka')--cig-- 
	end
end)

RegisterNetEvent('fivem_stressystem:useSnuff')
AddEventHandler('fivem_stressystem:useSnuff', function()
	if not usingStressReliever then
		usingStressReliever = true
		TriggerServerEvent('fivem_stressystem:usingStressReliever', 'snuff')
		local playerPed = PlayerPedId()
		RequestAnimDict('anim@mp_player_intcelebrationmale@nose_pick')
		while not HasAnimDictLoaded('anim@mp_player_intcelebrationmale@nose_pick') do
			Citizen.Wait(10)
		end
		TaskPlayAnim(playerPed, 'anim@mp_player_intcelebrationmale@nose_pick', 'nose_pick', 8.0, -8.0, 1111, 0.1, 0, false, false, false)
		Citizen.Wait(750)
		UpdateStressLevel(math.random(25, 55), 'remove')
		Citizen.Wait(750)
		ClearPedTasksImmediately(playerPed)
		ESX.SetTimeout(60000, function()
			usingStressReliever = false
		end)
	else
		ESX.ShowNotification('Du har redan en fräsh prilla i munnen') --snuff
	end
end)

RegisterCommand('reloadstress', function(src, args)
	ESX.TriggerServerCallback('fivem_stressystem:fetchStressLevel', function(info)
		stresslevel = info
	end)
end)

RegisterCommand('maxstress', function(src, args)
	stresslevel = 0.0
	if args[1] ~= nil then
		UpdateStressLevel(args[1], 'add')
	end
end)

UpdateStressLevel = function(val, setting)
	if setting == nil or setting == 'add' then
		stresslevel = (stresslevel + val)
	else
		stresslevel = (stresslevel - val)
		if stresslevel < 0.0 then 
			stresslevel = 0.0
		end
	end
	if recentlyUpdatedCache == false then
		TriggerServerEvent('fivem_stressystem:uploadStressToServer', stresslevel)
	end
	recentlyUpdatedCache = true
end

Citizen.CreateThread(function()
	while true do
		local sleep = 500
		if tonumber(stresslevel) > 0.0 then
			ShakeGameplayCam("SMALL_EXPLOSION_SHAKE", stresslevel / 20000)
		elseif stresslevel ~= 0.0 then
			stresslevel = 0.0
		end
		Citizen.Wait(sleep)
	end
end)

DrawAdvancedText = function(x,y ,w,h,sc, text, r,g,b,a,font,jus)
    SetTextFont(font)
    SetTextProportional(0)
    SetTextScale(sc, sc)
	N_0x4e096588b13ffeca(jus)
    SetTextColour(r, g, b, a)
    SetTextDropShadow(0, 0, 0, 0,255)
    SetTextEdge(1, 0, 0, 0, 255)
    SetTextDropShadow()
    SetTextOutline()
    SetTextEntry("STRING")
    AddTextComponentString(text)
	DrawText(x - 0.1+w, y - 0.02+h)
end

Citizen.CreateThread(function()
	x = 0.01135
	y = 0.002
	while true do
		if showStressLevel then
			if stresslevel ~= nil then
				DrawAdvancedText(0.130 - x, 0.77 - y, 0.005, 0.0028, 0.4,'Stresslevel: '..stresslevel, 255, 255, 255, 255, 6, 1)
			else
				DrawAdvancedText(0.130 - x, 0.77 - y, 0.005, 0.0028, 0.4,'Stresslevel: 0', 255, 255, 255, 255, 6, 1)
			end
		end
		Citizen.Wait(10)
	end
end)

Citizen.CreateThread(function()
	local startpos = nil
	local currentpos = nil
	local count = 0
	while true do
		local playerPed = PlayerPedId()
		local sleepThread = 1000
		local vehicle = GetVehiclePedIsIn(playerPed, false)
		if vehicle ~= 0 then 
			walking = false
			sleep = 250
			local vehspeed = GetEntitySpeed(vehicle)
			local kmh = math.floor(vehspeed * 3.6 + 0.5)
			if kmh >= 190 then 
				UpdateStressLevel(math.random(1,7), 'add')
				sleep = 1000
			end
		elseif IsPlayerFreeAiming(PlayerId()) then
			sleep = 500
			UpdateStressLevel(math.random(7,10), 'add')
			if IsPedShooting(playerPed) then
				UpdateStressLevel(math.random(30,45), 'add')
			end
		elseif IsPedOnFoot(playerPed) and not walking then
			sleep = 5000
			count = 0
			startpos = nil
			if GetEntitySpeed(playerPed) < 3 then
				walking = true
				startpos = GetEntityCoords(playerPed)
			end
		elseif IsPedOnFoot(playerPed) and walking then
			sleep = 5000
			if GetEntitySpeed(playerPed) < 3 then
				currentpos = GetEntityCoords(playerPed)
				if GetDistanceBetweenCoords(currentpos, startpos['x'], startpos['y'], startpos['z'], true) > 4.0 then
					count = count + 1
					startpos = currentpos
					if count >= 10 then 
						UpdateStressLevel(math.random(20, 50), 'remove')
						walking = false
					end
				else
					walking = false
				end
			else
				walking = false
			end
		end
		Citizen.Wait(sleep)
	end
end)