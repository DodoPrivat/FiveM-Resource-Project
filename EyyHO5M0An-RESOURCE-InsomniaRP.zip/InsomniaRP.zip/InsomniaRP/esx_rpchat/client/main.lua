--[[

  ESX RP Chat

--]]



RegisterNetEvent('sendProximityMessage')
AddEventHandler('sendProximityMessage', function(id, name, message, adm)
  local myId = PlayerId()
  local pid = GetPlayerFromServerId(id)
  if pid == myId then
    TriggerEvent('chatMessage', "[Local " .. id .. "] " .. name .. "", {0, 255, 0}, "^7 " .. message)
  elseif GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(myId)), GetEntityCoords(GetPlayerPed(pid)), true) < 19.999 then
    if adm then
      TriggerEvent('chatMessage', "[Local " .. id .. "] " .. name .. "", {0, 255, 0}, "^7 " .. message)
    else
      TriggerEvent('chatMessage', "[Local " .. "] " .. name .. "", {0, 255, 0}, "^7 " .. message)
    end
  end
end)

RegisterNetEvent('sendProximityMessageMe')
AddEventHandler('sendProximityMessageMe', function(id, name, message, adm)
  local myId = PlayerId()
  local pid = GetPlayerFromServerId(id)
  if pid == myId then
    TriggerEvent('chatMessage', "", {255, 0, 0}, " ^6* " .. name .." ".."^6 " .. message)
  elseif GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(myId)), GetEntityCoords(GetPlayerPed(pid)), true) < 19.999 then
    TriggerEvent('chatMessage', "", {255, 0, 0}, " ^6* " .. name .." ".."^6 " .. message)
  end
end)