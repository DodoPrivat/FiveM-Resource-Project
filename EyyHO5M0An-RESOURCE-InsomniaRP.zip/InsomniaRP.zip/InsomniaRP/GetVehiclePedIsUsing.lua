function Global.GetVehiclePedIsUsing(ped)
	return _in(0x6094AD011A2EA87D, ped, _r, _ri)
end
