function Global.GetPlayerServerId(player)
	return _in(0x4d97bcc7, player, _r, _ri)
end
