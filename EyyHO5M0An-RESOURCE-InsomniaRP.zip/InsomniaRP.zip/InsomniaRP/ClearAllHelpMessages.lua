function Global.ClearAllHelpMessages()
	return _in(0x6178F68A87A4D3A0)
end
