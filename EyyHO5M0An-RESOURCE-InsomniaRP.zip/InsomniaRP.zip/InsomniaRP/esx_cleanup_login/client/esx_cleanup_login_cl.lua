
ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)


RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	print("****************************************UPDATING LOGIN*********************************************")
	TriggerServerEvent('esx_cleanup_login:updateLogin')
	print("****************************************UPDATING LOGIN*********************************************")
end)
