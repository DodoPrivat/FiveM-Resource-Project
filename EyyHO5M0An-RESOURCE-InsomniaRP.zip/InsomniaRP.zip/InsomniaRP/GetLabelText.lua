--- Gets a string literal from a label name.
function Global.GetLabelText(labelName)
	return _in(0x7B5280EBA9840C72, _ts(labelName), _r, _s)
end
