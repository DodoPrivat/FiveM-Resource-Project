function Global.GetNamedRendertargetRenderId(p0)
	return _in(0x1A6478B61C6BDC3B, _ts(p0), _r, _ri)
end
