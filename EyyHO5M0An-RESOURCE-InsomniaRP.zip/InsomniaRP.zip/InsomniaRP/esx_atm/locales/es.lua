Locales['es'] = {
	['invalid_amount']    = '~r~cantidad no válida',
	['deposit_money']          = 'has depositado ~g~€',
	['withdraw_money']         = 'has retirado ~g~€',
	['press_e_atm'] = 'Presiona ~INPUT_PICKUP~ para depositar o retirar ~g~cash~s~.',  
	['transf_money_ok'] = 'Transferencia correctamente ~g~€',
	['transf_money_error'] = '~r~ Error en la transferencia'
}
