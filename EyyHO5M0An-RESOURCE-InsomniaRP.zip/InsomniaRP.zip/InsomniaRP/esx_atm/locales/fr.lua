Locales['fr'] = {
	['invalid_amount']    = '~r~montant invalide',
	['deposit_money']          = 'vous avez déposé ~g~$',
	['withdraw_money']         = 'vous avez retiré ~g~$',
	['press_e_atm'] = 'appuyez sur ~INPUT_PICKUP~ pour déposer ou retirer du ~g~cash~s~.',  
}