Locales['en'] = {
	['invalid_amount']    = '~r~invalid amount',
	['deposit_money']          = 'you have deposited ~g~$',
	['withdraw_money']         = 'you have withdrawn ~g~$', 
	['press_e_atm'] = 'press ~INPUT_PICKUP~ for deposit or withdrawal from ~g~ATM~s~.',  
}
