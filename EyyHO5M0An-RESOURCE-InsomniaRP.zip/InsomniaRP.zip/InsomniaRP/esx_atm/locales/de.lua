Locales['de'] = {
	['invalid_amount']    = '~r~ungültiger Betrag',
	['deposit_money']          = 'eingezahlt ~g~$',
	['withdraw_money']         = 'abgehoben ~g~$', 
	['press_e_atm'] = 'Drücke ~INPUT_PICKUP~ um auf den ~g~ATM~s~ zuzugreifen.',  
}
