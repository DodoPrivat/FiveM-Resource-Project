--- Gets the current coordinates for a specified entity.
-- @param entity The entity to get the coordinates from.
-- @param alive Unused by the game, potentially used by debug builds of GTA in order to assert whether or not an entity was alive.
-- @return The current entity coordinates.
function Global.GetEntityCoords(entity, alive)
	return _in(0x3FEF770D40960D5A, entity, alive, _r, _rv)
end
