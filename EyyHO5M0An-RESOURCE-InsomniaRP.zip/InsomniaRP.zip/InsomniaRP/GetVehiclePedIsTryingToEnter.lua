function Global.GetVehiclePedIsTryingToEnter(ped)
	return _in(0x814FA8BE5449445D, ped, _r, _ri)
end
