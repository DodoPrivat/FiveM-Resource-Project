Locales['de'] = {

	['shop'] = 'Geschäft',
	['shops'] = 'Geschäfte',
	['press_menu'] = 'Drücke ~INPUT_CONTEXT~ um auf das Geschäft zuzugreifen.',
	['bought'] = 'du kaufst ~b~1x ',
	['not_enough'] = 'du ~r~hast nicht~s~ genug Geld.'

}
