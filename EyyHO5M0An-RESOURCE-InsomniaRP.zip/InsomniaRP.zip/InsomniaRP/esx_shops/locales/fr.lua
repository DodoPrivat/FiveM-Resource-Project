Locales['fr'] = {

	['shop'] = 'magasin',
	['shops'] = 'magasins',
	['press_menu'] = 'appuyez sur ~INPUT_CONTEXT~ pour accéder au magasin.',
	['bought'] = 'vous avez acheté ~b~1x ',
	['not_enough'] = 'vous n\'avez ~r~pas assez~s~ d\'argent.',

}
