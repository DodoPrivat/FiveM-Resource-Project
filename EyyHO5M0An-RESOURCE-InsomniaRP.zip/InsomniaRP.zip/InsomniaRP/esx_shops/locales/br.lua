Locales['br'] = {

	['shop'] = 'Loja',
	['shops'] = 'Lojas',
	['press_menu'] = 'Pressione ~INPUT_CONTEXT~ para acessar a loja.',
	['bought'] = 'você comprou ~b~1x ',
	['not_enough'] = 'você não tem ~r~dinheiro suficiente~s~.',
	['player_cannot_hold'] = 'Você ~r~não~s~ tem ~y~espaço livre~s~ suficiente no seu inventário!',

}
