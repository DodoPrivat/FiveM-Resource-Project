Locales['en'] = {

	['shop'] = 'shop',
	['shops'] = 'shops',
	['press_menu'] = 'press ~INPUT_CONTEXT~ to access the shop.',
	['bought'] = 'you bought ~b~1x ',
	['not_enough'] = 'you do not ~r~have enough~s~ money.'

}
