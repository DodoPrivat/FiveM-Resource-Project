function Global.GetEntityHealth(entity)
	return _in(0xEEF059FAD016D209, entity, _r, _ri)
end
