--- Displays the current ROLL axis of the entity [-180.0000/180.0000+]
-- (Sideways Roll) such as a vehicle tipped on its side
function Global.GetEntityRoll(entity)
	return _in(0x831E0242595560DF, entity, _r, _rf)
end
