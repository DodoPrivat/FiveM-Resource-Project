Config              = {}
Config.DrawDistance = 20.0
Config.ZoneSize     = {x = 3.0, y = 3.0, z = 2.0}
Config.MarkerColor  = {r = 100, g = 100, b = 204}
Config.MarkerType   = 1
Config.Locale = 'en'

Config.Zones = {
	{x = -268.240, y = -957.270, z = 30.223},
	{x = 1930.622, y = 3732.115, z = 32.0}
}
