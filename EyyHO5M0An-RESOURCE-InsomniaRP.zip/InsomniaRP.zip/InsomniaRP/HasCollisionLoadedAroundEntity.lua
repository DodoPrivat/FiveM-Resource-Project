function Global.HasCollisionLoadedAroundEntity(entity)
	return _in(0xE9676F61BC0B3321, entity, _r)
end
