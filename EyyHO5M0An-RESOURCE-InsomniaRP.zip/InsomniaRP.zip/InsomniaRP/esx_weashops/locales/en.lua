Locales ['en'] = {

  ['buy_license'] = 'Buy a license?',
  ['yes'] = 'Yes',
  ['no'] = 'No',
  ['buy'] = 'Purchased ',
  ['not_enough_black'] = 'Not enough Dirty Money',
  ['not_enough'] = 'Not enough Clean Money',
  ['shop'] = 'Weapon Shop',
  ['shop_menu'] = 'Press ~INPUT_CONTEXT~ to access the store.',
  ['map_blip'] = 'Weapon Shop',

}
