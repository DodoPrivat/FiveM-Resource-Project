Locales['fr'] = {
	['cash'] = 'Éspèces',
	['black_money'] = 'Argent sale',
	['player_nearby'] = 'Le joueur sélectionné n\'est plus près de vous.',
	['players_nearby'] = 'Il n\'y a personne près de vous.',
}
