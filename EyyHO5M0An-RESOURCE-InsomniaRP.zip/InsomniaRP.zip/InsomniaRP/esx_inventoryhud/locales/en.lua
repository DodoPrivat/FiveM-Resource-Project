Locales['en'] = {
	['cash'] = 'Cash',
	['black_money'] = 'Black Money',
	['player_nearby'] = 'This player is not near you anymore!',
	['players_nearby'] = 'There are no players nearby!'
}