Locales['cs'] = {
	['cash'] = 'Hotovost',
	['black_money'] = 'Špinavé peníze',
	['player_nearby'] = 'Zvolený hráč již není u tebe!',
	['players_nearby'] = 'Poblíž tebe není žádný hrác!'
}