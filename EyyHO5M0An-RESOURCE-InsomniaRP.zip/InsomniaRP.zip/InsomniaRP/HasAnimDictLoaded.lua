function Global.HasAnimDictLoaded(animDict)
	return _in(0xD031A9162D01088C, _ts(animDict), _r)
end
