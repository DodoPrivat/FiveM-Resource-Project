--- More info: http://gtaforums.com/topic/836367-adding-props-to-interiors/
function Global.EnableInteriorProp(interiorID, propName)
	return _in(0x55E86AF2712B36A1, interiorID, _ts(propName))
end
