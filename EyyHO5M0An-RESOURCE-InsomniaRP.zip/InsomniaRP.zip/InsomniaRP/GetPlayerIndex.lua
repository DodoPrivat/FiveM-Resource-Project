function Global.GetPlayerIndex()
	return _in(0xA5EDC40EF369B48D, _r, _ri)
end
