Locales['pl'] = {
  ['skin_menu'] = 'menu wyglądu',
  ['use_rotate_view'] = 'użyj ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ i ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ aby obrócić ekran.',
  ['skin'] = 'zmień wygląd',
  ['saveskin'] = 'zapisz wygląd do pliku',
}
