function Global.IsDisabledControlPressed(index, control)
	return _in(0xE2587F8CBBD87B1D, index, control, _r)
end
