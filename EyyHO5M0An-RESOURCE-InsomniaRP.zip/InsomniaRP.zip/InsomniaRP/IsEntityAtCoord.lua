function Global.IsEntityAtCoord(entity, x, y, z, xSize, ySize, zSize, p7, p8, p9)
	return _in(0x20B60995556D004F, entity, x, y, z, xSize, ySize, zSize, p7, p8, p9, _r)
end
