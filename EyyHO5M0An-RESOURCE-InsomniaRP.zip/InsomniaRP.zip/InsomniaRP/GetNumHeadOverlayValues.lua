--- Used with freemode (online) characters.
function Global.GetNumHeadOverlayValues(overlayID)
	return _in(0xCF1CE768BB43480E, overlayID, _r, _ri)
end
