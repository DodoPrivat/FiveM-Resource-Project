function Global.GetDisplayNameFromVehicleModel(modelHash)
	return _in(0xB215AAC32D25D019, _ch(modelHash), _r, _s)
end
