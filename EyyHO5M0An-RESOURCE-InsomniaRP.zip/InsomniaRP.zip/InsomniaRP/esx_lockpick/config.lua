Config						= {}
Config.InfiniteLocks		= false  -- Should one lockpick last forever?
Config.LockTime			    = 25     -- In seconds, how long should lockpicking take?
Config.IgnoreAbort			= true   -- Remove lockpick from inventory even if user aborts lockpicking?
Config.AllowMecano			= false  -- Allow mechanics to use this lockpick?

Config.Locale				= 'en'
