Locales ['en'] = {
	['used_kit']					= 'You used x1 lockpick',
	['must_be_outside']				= 'You must be outside of the vehicle!',
	['no_vehicle_nearby']			= 'There is no vehicle nearby',
	['vehicle_unlocked']			= 'You lockpicked the vehicle!',
	['abort_hint']					= 'Press ~INPUT_VEH_DUCK~ to cancel',
	['aborted_lockpicking']		    = 'You aborted the lockpicking',
}
