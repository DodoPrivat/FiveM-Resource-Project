function Global.GetEntitySpeed(entity)
	return _in(0xD5037BA82E12416F, entity, _r, _rf)
end
