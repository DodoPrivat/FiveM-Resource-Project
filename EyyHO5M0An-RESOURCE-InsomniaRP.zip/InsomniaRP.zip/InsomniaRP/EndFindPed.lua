function Global.EndFindPed(findHandle)
	return _in(0x9615c2ad, findHandle)
end
