--- Gets the trailer of a vehicle and puts it into the trailer parameter.
function Global.GetVehicleTrailerVehicle(vehicle, trailer)
	return _in(0x1CDD6BADC297830D, vehicle, _ii(trailer) --[[ may be optional ]], _r)
end
