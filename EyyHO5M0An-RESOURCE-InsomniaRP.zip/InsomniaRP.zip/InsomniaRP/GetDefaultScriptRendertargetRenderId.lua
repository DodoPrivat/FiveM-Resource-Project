--- This function is hard-coded to always return 1.
function Global.GetDefaultScriptRendertargetRenderId()
	return _in(0x52F0982D7FD156B6, _r, _ri)
end
