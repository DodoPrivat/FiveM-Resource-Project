Config = {}

Config = {
	DrawDistance = 100,
	BlipInfos = {
		Sprite = 477,
		Color = 54
	}
}

-- Determines if the ability to impound vehicles is based upon esx jobs
Config.RestrictImpoundToJobs = true

-- The jobs that are able to impound vehicles
Config.JobsThatCanImpound = {'police', 'mecano'}

-- Determines if the ability to retrieve vehicles is based upon esx jobs
Config.RestrictRetrievalToJobs = false

-- The jobs that are able to retrieve vehicles
Config.RetrievalJobs = {'unemployed'}

-- Is the user required to wait a period of time before they can get their vehicle back
Config.UserMustWaitElapsedTime = true

-- Is the user required to pay a fine before they get their vehicle back
Config.UserMustPayFine = true

-- The amount of the fine the user must pay
Config.ImpoundFineAmount = 15000


-- The time in minutes before a user is able to retrieve a vehicle from the
-- impound lot.
Config.ElapsedTimeBeforeRelease = 360


Config.ImpoundLots = {
	city = {
		Pos = {x=402.731, y= -1630.266, z= 29.0},
		Size  = {x = 3.0, y = 3.0, z = 1.0},
		Color = {r = 204, g = 204, b = 0},
		Marker = -1,
		DropoffPoint = {
			Pos = {x=402.731, y= -1630.266, z= 29.0},
			Color = {r=58,g=100,b=122},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = 27
		},
		RetrievePoint = {
			Pos = {x=407.656, y= -1647.14, z= 29.392},
			Color = {r=0,g=0,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = -1

		},
	},
	Sandy = {
		Pos = {x=177.379, y= 2751.539, z= 43.426},
		Size  = {x = 3.0, y = 3.0, z = 1.0},
		Color = {r = 204, g = 204, b = 0},
		Marker = -1,
		DropoffPoint = {
			Pos = {x= 192.966, y= 2747.771, z= 43.426},
			Color = {r=58,g=100,b=122},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = 27
		},
		RetrievePoint = {
			Pos = {x= 210.177, y= 2752.165, z= 43.426},
			Color = {r=0,g=0,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = -1
		},
	}
}
