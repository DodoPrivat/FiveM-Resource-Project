Config = {}
Config.Locale = 'en'

Stores = {
	["bank_pacific"] = {
		position = { ['x'] = 259.080, ['y'] = 225.620, ['z'] = 101.00 },
		reward = math.random(950000,1200000),
		nameofstore = "Pacific Standard Bank",
		lastrobbed = 0
	},
	["fleca_highway"] = {
		position = { ['x'] = -2957.570, ['y'] = 480.440, ['z'] = 15.00 },
		reward = math.random(875000,1000000),
		nameofstore = "Fleca Highway Bank",
		lastrobbed = 0
	},
	["bank_paleto"] = {
		position = { ['x'] =-106.580, ['y'] = 6474.140, ['z'] = 31.000 },
		reward = math.random(900000,1250000),
		nameofstore = "Blaine County Savings",
		lastrobbed = 0
	},
	["life_invader"] = {
		position = { ['x'] =-1057.650, ['y'] = -244.370, ['z'] = 43.500 },
		reward = math.random(900000,1000000),
		nameofstore = "Life Invader",
		lastrobbed = 0
	}
}
