ESX                           = nil

Citizen.CreateThread(function()
  while ESX == nil do
    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
    Citizen.Wait(0)
  end
end)


RegisterNetEvent('esx_commands:armor')
AddEventHandler('esx_commands:armor', function()
    local playerPed = GetPlayerPed(-1)
    SetPedArmour(playerPed, 100)
    ClearPedBloodDamage(playerPed)
    ResetPedVisibleDamage(playerPed)
    ClearPedLastWeaponDamage(playerPed)
end)
