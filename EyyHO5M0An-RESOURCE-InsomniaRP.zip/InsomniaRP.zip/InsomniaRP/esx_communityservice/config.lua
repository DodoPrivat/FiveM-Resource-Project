Config = {}

-- # Locale to be used. You can create your own by simple copying the 'en' and translating the values.
Config.Locale       				= 'en'

-- # By how many services a player's community service gets extended if he tries to escape
Config.ServiceExtensionOnEscape		= 20

-- # Don't change this unless you know what you are doing.
Config.ServiceLocation 				= {x =  -915.354, y = -752.97, z = 19.866}

-- # Don't change this unless you know what you are doing.
Config.ReleaseLocation				= {x = 427.33, y = -979.51, z = 30.2}


-- # Don't change this unless you know what you are doing.
Config.ServiceLocations = {
	{ type = "cleaning", coords = vector3(-933.399, -741.507, 19.927) },
	{ type = "cleaning", coords = vector3(-948.008, -741.075, 19.928) },
	{ type = "cleaning", coords = vector3(-955.606, -750.872, 19.535) },
	{ type = "cleaning", coords = vector3(-953.93, -767.536, 17.277) },
	{ type = "cleaning", coords = vector3(-934.091, -779.98, 15.921) },
	{ type = "cleaning", coords = vector3(-899.586, -779.635, 15.823) },
	{ type = "cleaning", coords = vector3(-893.719, -796.273, 15.905) },
	{ type = "cleaning", coords = vector3(-908.437, -803.29, 15.921) },
	{ type = "gardening", coords = vector3(-927.415, -751.023, 19.832) },
	{ type = "gardening", coords = vector3(-914.38, -757.23, 19.89) },
	{ type = "gardening", coords = vector3(-907.089, -750.284, 19.731) },
	{ type = "gardening", coords = vector3(-947.482, -747.875, 19.768) }
	
}



Config.Uniforms = {
	prison_wear = {
		male = {
			['tshirt_1'] = 15,  ['tshirt_2'] = 0,
			['torso_1']  = 146, ['torso_2']  = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms']     = 119, ['pants_1']  = 3,
			['pants_2']  = 7,   ['shoes_1']  = 12,
			['shoes_2']  = 12,  ['chain_1']  = 0,
			['chain_2']  = 0
		},
		female = {
			['tshirt_1'] = 3,   ['tshirt_2'] = 0,
			['torso_1']  = 38,  ['torso_2']  = 3,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms']     = 120,  ['pants_1'] = 3,
			['pants_2']  = 15,  ['shoes_1']  = 66,
			['shoes_2']  = 5,   ['chain_1']  = 0,
			['chain_2']  = 0
		}
	}
}
