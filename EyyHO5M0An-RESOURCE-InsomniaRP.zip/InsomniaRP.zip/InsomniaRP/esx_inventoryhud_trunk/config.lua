local Keys = {
    ["ESC"] = 322,
    ["F1"] = 288,
    ["F2"] = 289,
    ["F3"] = 170,
    ["F5"] = 166,
    ["F6"] = 167,
    ["F7"] = 168,
    ["F8"] = 169,
    ["F9"] = 56,
    ["F10"] = 57,
    ["~"] = 243,
    ["1"] = 157,
    ["2"] = 158,
    ["3"] = 160,
    ["4"] = 164,
    ["5"] = 165,
    ["6"] = 159,
    ["7"] = 161,
    ["8"] = 162,
    ["9"] = 163,
    ["-"] = 84,
    ["="] = 83,
    ["BACKSPACE"] = 177,
    ["TAB"] = 37,
    ["Q"] = 44,
    ["W"] = 32,
    ["E"] = 38,
    ["R"] = 45,
    ["T"] = 245,
    ["Y"] = 246,
    ["U"] = 303,
    ["P"] = 199,
    ["["] = 39,
    ["]"] = 40,
    ["ENTER"] = 18,
    ["CAPS"] = 137,
    ["A"] = 34,
    ["S"] = 8,
    ["D"] = 9,
    ["F"] = 23,
    ["G"] = 47,
    ["H"] = 74,
    ["K"] = 311,
    ["L"] = 182,
    ["LEFTSHIFT"] = 21,
    ["Z"] = 20,
    ["X"] = 73,
    ["C"] = 26,
    ["V"] = 0,
    ["B"] = 29,
    ["N"] = 249,
    ["M"] = 244,
    [","] = 82,
    ["."] = 81,
    ["-"] = 84,
    ["LEFTCTRL"] = 36,
    ["LEFTALT"] = 19,
    ["SPACE"] = 22,
    ["RIGHTCTRL"] = 70,
    ["HOME"] = 213,
    ["PAGEUP"] = 10,
    ["PAGEDOWN"] = 11,
    ["DELETE"] = 178,
    ["LEFT"] = 174,
    ["RIGHT"] = 175,
    ["TOP"] = 27,
    ["DOWN"] = 173,
    ["NENTER"] = 201,
    ["N4"] = 108,
    ["N5"] = 60,
    ["N6"] = 107,
    ["N+"] = 96,
    ["N-"] = 97,
    ["N7"] = 117,
    ["N8"] = 61,
    ["N9"] = 118
}

Config = {}

Config.CheckOwnership = true -- If true, Only owner of vehicle can store items in trunk.
Config.AllowPolice = true -- If true, police will be able to search players' trunks.

Config.Locale = "en"

Config.OpenKey = Keys["Y"]

-- Limit, unit can be whatever you want. Originally grams (as average people can hold 25kg)
Config.Limit = 25000

-- Default weight for an item:
-- weight == 0 : The item do not affect character inventory weight
-- weight > 0 : The item cost place on inventory
-- weight < 0 : The item add place on inventory. Smart people will love it.
Config.DefaultWeight = 10

Config.localWeight = {
    bread = 125,
    water = 330,
    coke_pooch = 150,
    weed_pooch = 9999999,
    weed = 1500,
    meth_pooch = 150,
    opium_pooch = 150,
    WEAPON_PUMPSHOTGUN = 7000,
    WEAPON_SAWNOFFSHOTGUN = 3000,
    WEAPON_GUSENBERG = 8000,
    WEAPON_MICROSMG = 5000,
    WEAPON_ASSAULTRIFLE = 7000,
    WEAPON_COMPACTRIFLE = 8000,
    WEAPON_MG = 20000,
    WEAPON_ADVANCEDRIFLE = 8000,
    WEAPON_COMBATPDW = 6000,
    alive_chicken = 99999999,
    slaughtered_chicken = 99999999,
    packaged_chicken = 9999999999,
    stone = 999999999,
    washed_stone = 999999999,
    fish = 9999999999,
    copper = 999999999,
    iron = 9999999999,
    gold = 99999999999,
    diamond = 999999999,
    wood = 999999999,
    cutted_wood = 9999999999,
    packaged_plank = 9999999999,
    essence = 999999999,
    whool = 9999999999,
    fabric = 999999999,
    clothe = 9999999999,
    contrat = 9999999999,
    fixkit = 999999999,
    clip = 300,
    jewels = 99999999999



}

Config.VehicleLimit = {
    [0] = 20000, --Compact
    [1] = 40000, --Sedan
    [2] = 120000, --SUV
    [3] = 25000, --Coupes
    [4] = 25000, --Muscle
    [5] = 10000, --Sports Classics
    [6] = 5000, --Sports
    [7] = 5000, --Super
    [8] = 100, --Motorcycles
    [9] = 150000, --Off-road
    [10] = 300000, --Industrial
    [11] = 70000, --Utility
    [12] = 180000, --Vans
    [13] = 0, --Cycles
    [14] = 5000, --Boats
    [15] = 20000, --Helicopters
    [16] = 0, --Planes
    [17] = 40000, --Service
    [18] = 40000, --Emergency
    [19] = 0, --Military
    [20] = 300000, --Commercial
    [21] = 0 --Trains
}

Config.VehiclePlate = {
    taxi = "TAXI",
    cop = "LSPD",
    ambulance = "EMS0",
    mecano = "MECA"
}
