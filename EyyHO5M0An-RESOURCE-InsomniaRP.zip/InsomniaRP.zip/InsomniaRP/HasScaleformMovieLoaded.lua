function Global.HasScaleformMovieLoaded(scaleformHandle)
	return _in(0x85F01B8D5B90570E, scaleformHandle, _r)
end
