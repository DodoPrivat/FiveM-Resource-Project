--- List of component/props ID
-- gtaxscripting.blogspot.com/2016/04/gta-v-peds-component-and-props.html
function Global.GetPedPropIndex(ped, componentId)
	return _in(0x898CC20EA75BACD8, ped, componentId, _r, _ri)
end
