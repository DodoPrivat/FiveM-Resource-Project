function Global.GetGameTimer()
	return _in(0x9CD27B0045628463, _r, _ri)
end
