function Global.DisableInteriorProp(interiorID, propName)
	return _in(0x420BD37289EEE162, interiorID, _ts(propName))
end
