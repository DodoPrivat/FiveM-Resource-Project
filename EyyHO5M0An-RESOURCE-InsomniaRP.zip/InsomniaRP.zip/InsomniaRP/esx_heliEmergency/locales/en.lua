Locales['en'] = {
  -- Vehicles
  ['vehicle_menu'] = 'vehicle',
  ['vehicle_out'] = 'there is already a vehicle out',
  ['vehicle_spawner'] = 'press ~INPUT_CONTEXT~ to take out a vehicle',

  ['map_blip'] = 'Emergency Helicopter',
}