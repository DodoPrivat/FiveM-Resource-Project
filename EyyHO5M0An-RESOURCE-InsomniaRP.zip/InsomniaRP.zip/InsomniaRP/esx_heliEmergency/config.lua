Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = {x = 1.8, y = 1.8, z = 1.0}
Config.MarkerColor                = {r = 100, g = 160, b = 255}
Config.EnableSocietyOwnedVehicles = false
Config.MaxInService               = -1
Config.Locale = 'en'

Config.Spawners = {

  HOSPTIAL = {

    Blip = {
      Pos     = {x = 313.32, y = -1465.13, z = 45.55},
      Sprite  = 43,
      Display = 4,
      Scale   = 0.8,
      Color  = 1,
    },

    Vehicles = {
      {
        Spawner    = {x = 316.77, y = -1454.3, z = 45.51},
        SpawnPoint = {x = 313.32, y = -1465.13, z = 45.55},
        Heading    = 324.94
      }
    },

  },

  LSPD = {

    Blip = {
      Pos     = {x = 449.22, y = -981.52, z = 42.75},
      Sprite  = 43,
      Display = 4,
      Scale   = 0.8,
      Color  = 3,
    },

    Vehicles = {
      {
        Spawner    = {x = 459.16, y = -988.71, z = 42.69},
        SpawnPoint = {x = 449.22, y = -981.52, z = 42.75},
        Heading    = 358.03
      }
    },

  },

  BCSO = {

    Blip = {
      Pos     = {x = 1728.53, y = 3990.52, z = 41.50},
      Sprite  = 43,
      Display = 4,
      Scale   = 0.8,
      Color  = 3,
    },

    Vehicles = {
      {
        Spawner    = {x = 1780.68, y = 3242.66, z = 41.32},
        SpawnPoint = {x = 1770.27, y = 3239.90, z = 41.50},
        Heading    = 103.71
      }
    },

  },

  PALETO = {

    Blip = {
      Pos     = {x = -475.2, y = 5988.45, z = 30.34},
      Sprite  = 43,
      Display = 4,
      Scale   = 0.8,
      Color  = 3,
    },

    Vehicles = {
      {
        Spawner    = {x = -466.54, y = 5998.58, z = 30.26},
        SpawnPoint = {x = -475.2, y = 5988.45, z = 30.34},
        Heading    = 313.63
      }
    },

  }

}
