--- Finalizes a text command started with [`BEGIN_TEXT_COMMAND_SET_BLIP_NAME`](#_0xF9113A30DE5C6670), setting the name
-- of the specified blip.
-- @param blip The blip to change the name for.
function Global.EndTextCommandSetBlipName(blip)
	return _in(0xBC38B49BCB83BC9B, blip)
end
