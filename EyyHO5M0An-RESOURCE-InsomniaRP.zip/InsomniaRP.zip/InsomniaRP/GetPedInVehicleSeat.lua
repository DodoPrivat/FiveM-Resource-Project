function Global.GetPedInVehicleSeat(vehicle, index)
	return _in(0xBB40DD2270B65366, vehicle, index, _r, _ri)
end
