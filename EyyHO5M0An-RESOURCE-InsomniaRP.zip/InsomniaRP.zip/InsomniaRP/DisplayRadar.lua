function Global.DisplayRadar(Toggle)
	return _in(0xA0EBB943C300E693, Toggle, _r, _ri)
end
