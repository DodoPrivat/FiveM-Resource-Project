Config = {}

Config.Animations = {
	
	{
		name  = 'Festives',
		label = 'Festives',
		items = {
	    {label = "Smoke a cigarette", type = "scenario", data = {anim = "WORLD_HUMAN_SMOKING"}},
	    {label = "Play music", type = "scenario", data = {anim = "WORLD_HUMAN_MUSICIAN"}},
	    {label = "Dj", type = "anim", data = {lib = "anim@mp_player_intcelebrationmale@dj", anim = "dj"}},
	    {label = "Drink a beer", type = "scenario", data = {anim = "WORLD_HUMAN_DRINKING"}},
	    {label = "Party", type = "scenario", data = {anim = "WORLD_HUMAN_PARTYING"}},
	    {label = "Air Guitar", type = "anim", data = {lib = "anim@mp_player_intcelebrationmale@air_guitar", anim = "air_guitar"}},
	    {label = "Air Shagging", type = "anim", data = {lib = "anim@mp_player_intcelebrationfemale@air_shagging", anim = "air_shagging"}},
	    {label = "Rock'n'roll", type = "anim", data = {lib = "mp_player_int_upperrock", anim = "mp_player_int_rock"}},
	    {label = "Smoke pot", type = "scenario", data = {anim = "WORLD_HUMAN_SMOKING_POT"}},
	    {label = "Snort Coke", type = "anim", data = {lib = "missfbi3_party", anim = "snort_coke_b_male3"}},
	    {label = "Drunk", type = "anim", data = {lib = "amb@world_human_bum_standing@drunk@idle_a", anim = "idle_a"}},
	    {label = "Vomit", type = "anim", data = {lib = "oddjobs@taxi@tie", anim = "vomit_outside"}},
		}
	},

	{
		name  = 'greetings',
		label = 'greetings',
		items = {
	    {label = "Hello", type = "anim", data = {lib = "gestures@m@standing@casual", anim = "gesture_hello"}},
	    {label = "Hello 2", type = "anim", data = {lib = "mp_common", anim = "givetake1_a"}},
	    {label = "Handshake", type = "anim", data = {lib = "mp_ped_interaction", anim = "handshake_guy_a"}},
	    {label = "Thug hug", type = "anim", data = {lib = "mp_ped_interaction", anim = "hugs_guy_a"}},
	    {label = "Sup", type = "anim", data = {lib = "missfbi3_sniping", anim = "dance_m_default"}},
	    {label = "Salute", type = "anim", data = {lib = "mp_player_int_uppersalute", anim = "mp_player_int_salute"}},
		}
	},

	{
		name  = 'work',
		label = 'work',
		items = {
	    {label = "Suspect : Busted", type = "anim", data = {lib = "random@arrests@busted", anim = "idle_c"}},
	    {label = "Fishing", type = "scenario", data = {anim = "world_human_stand_fishing"}},
	    {label = "Police : Standing", type = "scenario", data = {anim = "WORLD_HUMAN_COP_IDLES"}},
	    {label = "Police : Investigate", type = "anim", data = {lib = "amb@code_human_police_investigate@idle_b", anim = "idle_f"}},
	    {label = "Police : Talk on radio", type = "anim", data = {lib = "random@arrests", anim = "generic_radio_chatter"}},
	    {label = "Police : Traffic", type = "scenario", data = {anim = "WORLD_HUMAN_CAR_PARK_ATTENDANT"}},
	    {label = "Police : Binoculars", type = "scenario", data = {anim = "WORLD_HUMAN_BINOCULARS"}},
	    {label = "Gardener : Plant", type = "scenario", data = {anim = "world_human_gardener_plant"}},
	    {label = "Mechanic : Repair engine", type = "anim", data = {lib = "mini@repair", anim = "fixing_a_ped"}},
	    {label = "Medic : Kneel", type = "scenario", data = {anim = "CODE_HUMAN_MEDIC_KNEEL"}},
	    --{label = "Taxi : parler au client", type = "anim", data = {lib = "oddjobs@taxi@driver", anim = "leanover_idle"}},
	    --{label = "Taxi : donner la facture", type = "anim", data = {lib = "oddjobs@taxi@cyi", anim = "std_hand_off_ps_passenger"}},
	    --{label = "Epicier : donner les courses", type = "anim", data = {lib = "mp_am_hold_up", anim = "purchase_beerbox_shopkeeper"}},
	    {label = "Barman : serve shot", type = "anim", data = {lib = "mini@drinking", anim = "shots_barman_b"}},
		{label = "Paparazzi", type = "scenario", data = {anim = "WORLD_HUMAN_PAPARAZZI"}},
	    {label = "Clipboard", type = "scenario", data = {anim = "WORLD_HUMAN_CLIPBOARD"}},
	    {label = "Notepad", type = "scenario", data = {anim = "CODE_HUMAN_MEDIC_TIME_OF_DEATH"}},
	    {label = "Hammering", type = "scenario", data = {anim = "WORLD_HUMAN_HAMMERING"}},
	    {label = "Highway bum sign", type = "scenario", data = {anim = "WORLD_HUMAN_BUM_FREEWAY"}},
	    {label = "Human statute", type = "scenario", data = {anim = "WORLD_HUMAN_HUMAN_STATUE"}},
		}
	},

	{
		name  = 'humors',
		label = 'humors',
		items = {
	    {label = "Cheer", type = "scenario", data = {anim = "WORLD_HUMAN_CHEERING"}},
	    {label = "Super", type = "anim", data = {lib = "mp_action", anim = "thanks_male_06"}},
	    {label = "Point", type = "anim", data = {lib = "gestures@m@standing@casual", anim = "gesture_point"}},
	    {label = "Come here", type = "anim", data = {lib = "gestures@m@standing@casual", anim = "gesture_come_here_soft"}}, 
	    {label = "Bring it!", type = "anim", data = {lib = "gestures@m@standing@casual", anim = "gesture_bring_it_on"}},
	    {label = "Me?", type = "anim", data = {lib = "gestures@m@standing@casual", anim = "gesture_me"}},
	    {label = "Shoplift high", type = "anim", data = {lib = "anim@am_hold_up@male", anim = "shoplift_high"}},
	    {label = "Standing jog", type = "scenario", data = {lib = "amb@world_human_jog_standing@male@idle_b", anim = "idle_d"}},
	    {label = "Bum idle", type = "scenario", data = {lib = "amb@world_human_bum_standing@depressed@idle_a", anim = "idle_a"}},
	    {label = "Facepalm", type = "anim", data = {lib = "anim@mp_player_intcelebrationmale@face_palm", anim = "face_palm"}},
	    {label = "Calm down ", type = "anim", data = {lib = "gestures@m@standing@casual", anim = "gesture_easy_now"}},
	    {label = "Assassinate", type = "anim", data = {lib = "oddjobs@assassinate@multi@", anim = "react_big_variations_a"}},
	    {label = "Cower", type = "anim", data = {lib = "amb@code_human_cower_stand@male@react_cowering", anim = "base_right"}},
	    {label = "Fight ?", type = "anim", data = {lib = "anim@deathmatch_intros@unarmed", anim = "intro_male_unarmed_e"}},
	    {label = "Daamn!", type = "anim", data = {lib = "gestures@m@standing@casual", anim = "gesture_damn"}},
	    {label = "Kiss guy", type = "anim", data = {lib = "mp_ped_interaction", anim = "kisses_guy_a"}},
	    {label = "F U", type = "anim", data = {lib = "mp_player_int_upperfinger", anim = "mp_player_int_finger_01_enter"}},
	    {label = "Wank", type = "anim", data = {lib = "mp_player_int_upperwank", anim = "mp_player_int_wank_01"}},
	    {label = "Suicide by gun", type = "anim", data = {lib = "mp_suicide", anim = "pistol"}},
		}
	},

	{
		name  = 'sports',
		label = 'Sports',
		items = {
	    {label = "Flex", type = "anim", data = {lib = "amb@world_human_muscle_flex@arms_at_side@base", anim = "base"}},
	    {label = "Free weight", type = "anim", data = {lib = "amb@world_human_muscle_free_weights@male@barbell@base", anim = "base"}},
	    {label = "Push ups", type = "anim", data = {lib = "amb@world_human_push_ups@male@base", anim = "base"}},
	    {label = "Sit ups", type = "anim", data = {lib = "amb@world_human_sit_ups@male@base", anim = "base"}},
	    {label = "Yoga", type = "anim", data = {lib = "amb@world_human_yoga@male@base", anim = "base_a"}},
		}
	},

	{
		name  = 'misc',
		label = 'misc',
		items = {
	    {label = "Drink coffe", type = "scenario", data = {anim = "WORLD_HUMAN_AA_COFFEE"}},
	    --{label = "S'asseoir", type = "anim", data = {lib = "anim@heists@prison_heistunfinished_biztarget_idle", anim = "target_idle"}},
	    {label = "Lean", type = "scenario", data = {anim = "world_human_leaning"}},
	    {label = "Sunbathe", type = "scenario", data = {anim = "WORLD_HUMAN_SUNBATHE_BACK"}},
	    {label = "Lie on stomach", type = "scenario", data = {anim = "WORLD_HUMAN_SUNBATHE"}},
	    {label = "Clean", type = "scenario", data = {anim = "world_human_maid_clean"}},
	    {label = "BBQ", type = "scenario", data = {anim = "PROP_HUMAN_BBQ"}},
	    --{label = "Position de Fouille", type = "anim", data = {lib = "mini@prostitutes@sexlow_veh", anim = "low_car_bj_to_prop_female"}},
	    {label = "Selfie", type = "scenario", data = {anim = "world_human_tourist_mobile"}},
	    {label = "Crack safe", type = "anim", data = {lib = "mini@safe_cracking", anim = "idle_base"}}, 
		{label = "Sit with phone", type = "anim", data = {lib = "anim@heists@prison_heistunfinished_biztarget_idle", anim = "target_idle"}},
	    {label = "Sit on ground", type = "scenario", data = {anim = "WORLD_HUMAN_PICNIC"}},
	    {label = "Lay Down", type = "anim", data = {lib = "mp_bank_heist_1", anim = "prone_l_loop"}},
		}
	},

	{
		name  = 'Attitudes',
		label = 'Attitudes',
		items = {
	    {label = "Normal M", type = "attitude", data = {lib = "move_m@confident", anim = "move_m@confident"}},
	    {label = "Normal F", type = "attitude", data = {lib = "move_f@heels@c", anim = "move_f@heels@c"}},
	    {label = "Depressed M", type = "attitude", data = {lib = "move_m@depressed@a", anim = "move_m@depressed@a"}},
	    {label = "Depressed F", type = "attitude", data = {lib = "move_f@depressed@a", anim = "move_f@depressed@a"}},
	    {label = "Business", type = "attitude", data = {lib = "move_m@business@a", anim = "move_m@business@a"}},
	    {label = "Brave", type = "attitude", data = {lib = "move_m@brave@a", anim = "move_m@brave@a"}},
	    {label = "Casual", type = "attitude", data = {lib = "move_m@casual@a", anim = "move_m@casual@a"}},
	    {label = "Fat", type = "attitude", data = {lib = "move_m@fat@a", anim = "move_m@fat@a"}},
	    {label = "Hipster", type = "attitude", data = {lib = "move_m@hipster@a", anim = "move_m@hipster@a"}},
	    {label = "Injured", type = "attitude", data = {lib = "move_m@injured", anim = "move_m@injured"}},
	    {label = "Hurry", type = "attitude", data = {lib = "move_m@hurry@a", anim = "move_m@hurry@a"}},
	    {label = "Hobo", type = "attitude", data = {lib = "move_m@hobo@a", anim = "move_m@hobo@a"}},
	    {label = "Sad", type = "attitude", data = {lib = "move_m@sad@a", anim = "move_m@sad@a"}},
	    {label = "Muscle", type = "attitude", data = {lib = "move_m@muscle@a", anim = "move_m@muscle@a"}},
	    {label = "Shocked", type = "attitude", data = {lib = "move_m@shocked@a", anim = "move_m@shocked@a"}},
	    {label = "Shady", type = "attitude", data = {lib = "move_m@shadyped@a", anim = "move_m@shadyped@a"}},
	    {label = "Buzzed", type = "attitude", data = {lib = "move_m@buzzed", anim = "move_m@buzzed"}},
	    {label = "Butch", type = "attitude", data = {lib = "move_m@hurry_butch@a", anim = "move_m@hurry_butch@a"}},
	    {label = "Rich", type = "attitude", data = {lib = "move_m@money", anim = "move_m@money"}},
	    {label = "Quick", type = "attitude", data = {lib = "move_m@quick", anim = "move_m@quick"}},
	    {label = "Maneater", type = "attitude", data = {lib = "move_f@maneater", anim = "move_f@maneater"}},
	    {label = "Sassy", type = "attitude", data = {lib = "move_f@sassy", anim = "move_f@sassy"}},	
	    {label = "Arrogant", type = "attitude", data = {lib = "move_f@arrogant@a", anim = "move_f@arrogant@a"}},
		}
	},

	{
		name  = 'Dances',
		label = 'Dance',
		items = {
	    {label = "Dance", type = "anim", data = {lib = "misschinese2_crystalmazemcs1_cs", anim = "dance_loop_tao"}},
	    {label = "Shake That 2", type = "anim", data = {lib = "rcmnigel1bnmt_1b", anim = "dance_loop_tyler"}},
	    {label = "Get in there", type = "anim", data = {lib = "rcmnigel1bnmt_1b", anim = "dance_intro_tyler"}},
	    {label = "Jiggy 1", type = "anim", data = {lib = "special_ped@mountain_dancer@monologue_1@monologue_1a", anim = "mtn_dnc_if_you_want_to_get_to_heaven"}},
	    {label = "Jiggy 2", type = "anim", data = {lib = "special_ped@mountain_dancer@monologue_2@monologue_2a", anim = "mnt_dnc_angel"}},
	    {label = "Jiggy 3", type = "anim", data = {lib = "special_ped@mountain_dancer@monologue_3@monologue_3a", anim = "mnt_dnc_buttwag"}},
	    {label = "Jiggy 4", type = "anim", data = {lib = "special_ped@mountain_dancer@monologue_4@monologue_4a", anim = "mnt_dnc_verse"}},
	    {label = "Rasta Dance", type = "anim", data = {lib = "move_clown@p_m_two_idles@", anim = "fidget_short_dance"}},
	    {label = "Taniec 1", type = "anim", data = {lib = "anim@amb@nightclub@dancers@club_ambientpeds@med-hi_intensity", anim = "mi-hi_amb_club_10_v1_male^6"}},
        {label = "Taniec 2", type = "anim", data = {lib = "amb@code_human_in_car_mp_actions@dance@bodhi@ds@base", anim = "idle_a_fp"}},
        {label = "Taniec 3", type = "anim", data = {lib = "amb@code_human_in_car_mp_actions@dance@bodhi@rds@base", anim = "idle_b"}},
        {label = "Taniec 4", type = "anim", data = {lib = "amb@code_human_in_car_mp_actions@dance@std@ds@base", anim = "idle_a"}},
        {label = "Taniec 5", type = "anim", data = {lib = "anim@amb@nightclub@dancers@crowddance_facedj@hi_intensity", anim = "hi_dance_facedj_09_v2_male^6"}},
        {label = "Taniec 6", type = "anim", data = {lib = "anim@amb@nightclub@dancers@crowddance_facedj@low_intesnsity", anim = "li_dance_facedj_09_v1_male^6"}},
        {label = "Taniec 7", type = "anim", data = {lib = "anim@amb@nightclub@dancers@crowddance_facedj_transitions@from_hi_intensity", anim = "trans_dance_facedj_hi_to_li_09_v1_male^6"}},
        {label = "Taniec 8", type = "anim", data = {lib = "anim@amb@nightclub@dancers@crowddance_facedj_transitions@from_low_intensity", anim = "trans_dance_facedj_li_to_hi_07_v1_male^6"}},
        {label = "Taniec 9", type = "anim", data = {lib = "anim@amb@nightclub@dancers@crowddance_groups@hi_intensity", anim = "hi_dance_crowd_13_v2_male^6"}},
        {label = "Taniec 10", type = "anim", data = {lib = "anim@amb@nightclub@dancers@crowddance_groups_transitions@from_hi_intensity", anim = "trans_dance_crowd_hi_to_li__07_v1_male^6"}},
        {label = "Taniec 11", type = "anim", data = {lib = "anim@amb@nightclub@dancers@crowddance_single_props@hi_intensity", anim = "hi_dance_prop_13_v1_male^6"}},
        {label = "Taniec 12", type = "anim", data = {lib = "anim@amb@nightclub@dancers@crowddance_single_props_transitions@from_med_intensity", anim = "trans_crowd_prop_mi_to_li_11_v1_male^6"}},
        {label = "Taniec 13", type = "anim", data = {lib = "anim@amb@nightclub@mini@dance@dance_solo@male@var_a@", anim = "med_center_up"}},
        {label = "Taniec 14", type = "anim", data = {lib = "anim@amb@nightclub@mini@dance@dance_solo@male@var_a@", anim = "med_right_up"}},
        {label = "Taniec 15", type = "anim", data = {lib = "anim@amb@nightclub@dancers@crowddance_groups@low_intensity", anim = "li_dance_crowd_17_v1_male^6"}},
        {label = "Taniec 16", type = "anim", data = {lib = "anim@amb@nightclub@dancers@crowddance_facedj_transitions@from_med_intensity", anim = "trans_dance_facedj_mi_to_li_09_v1_male^6"}},
        {label = "Taniec Rak xD", type = "anim", data = {lib = "special_ped@zombie@monologue_4@monologue_4l", anim = "iamtheundead_11"}},
        {label = "Taniec 17", type = "anim", data = {lib = "timetable@tracy@ig_5@idle_b", anim = "idle_e"}},
        {label = "Taniec 18", type = "anim", data = {lib = "mini@strip_club@idles@dj@idle_04", anim = "idle_04"}},
        {label = "Taniec 19", type = "anim", data = {lib = "special_ped@mountain_dancer@monologue_1@monologue_1a", anim = "mtn_dnc_if_you_want_to_get_to_heaven"}},
        {label = "Taniec 20", type = "anim", data = {lib = "special_ped@mountain_dancer@monologue_4@monologue_4a", anim = "mnt_dnc_verse"}},
        {label = "Taniec 21", type = "anim", data = {lib = "special_ped@mountain_dancer@monologue_3@monologue_3a", anim = "mnt_dnc_buttwag"}},
        {label = "Taniec 22", type = "anim", data = {lib = "anim@amb@nightclub@dancers@black_madonna_entourage@", anim = "hi_dance_facedj_09_v2_male^5"}},
        {label = "Taniec 23", type = "anim", data = {lib = "anim@amb@nightclub@dancers@crowddance_single_props@", anim = "hi_dance_prop_09_v1_male^6"}},
        {label = "Taniec 24", type = "anim", data = {lib = "anim@amb@nightclub@dancers@dixon_entourage@", anim = "mi_dance_facedj_15_v1_male^4"}},
        {label = "Taniec 25", type = "anim", data = {lib = "anim@amb@nightclub@dancers@podium_dancers@", anim = "hi_dance_facedj_17_v2_male^5"}},
        {label = "Taniec 26", type = "anim", data = {lib = "anim@amb@nightclub@dancers@tale_of_us_entourage@", anim = "mi_dance_prop_13_v2_male^4"}},
        {label = "Taniec 27", type = "anim", data = {lib = "misschinese2_crystalmazemcs1_cs", anim = "dance_loop_tao"}},
        {label = "Taniec 28", type = "anim", data = {lib = "misschinese2_crystalmazemcs1_ig", anim = "dance_loop_tao"}},
        {label = "Taniec 29", type = "anim", data = {lib = "anim@mp_player_intcelebrationfemale@uncle_disco", anim = "uncle_disco"}},
        {label = "Taniec 30", type = "anim", data = {lib = "anim@mp_player_intcelebrationfemale@raise_the_roof", anim = "raise_the_roof"}},
        {label = "Taniec 31", type = "anim", data = {lib = "anim@mp_player_intcelebrationmale@cats_cradle", anim = "cats_cradle"}},
        {label = "Taniec 32", type = "anim", data = {lib = "anim@mp_player_intupperbanging_tunes", anim = "idle_a"}},
        {label = "Taniec 33", type = "anim", data = {lib = "anim@amb@nightclub@mini@dance@dance_solo@female@var_a@", anim = "high_center"}},
        {label = "Taniec 34", type = "anim", data = {lib = "anim@amb@nightclub@mini@dance@dance_solo@female@var_b@", anim = "high_center"}},
        {label = "Taniec 35", type = "anim", data = {lib = "anim@amb@nightclub@mini@dance@dance_solo@male@var_b@", anim = "high_center"}},
        {label = "Taniec 36", type = "anim", data = {lib = "anim@amb@nightclub@dancers@crowddance_facedj_transitions@", anim = "trans_dance_facedj_hi_to_mi_11_v1_female^6"}},
        {label = "Taniec 37", type = "anim", data = {lib = "anim@amb@nightclub@dancers@crowddance_facedj_transitions@from_hi_intensity", anim = "trans_dance_facedj_hi_to_li_07_v1_female^6"}},
        {label = "Taniec 38", type = "anim", data = {lib = "anim@amb@nightclub@dancers@crowddance_facedj@", anim = "hi_dance_facedj_09_v1_female^6"}},
        {label = "Taniec 39", type = "anim", data = {lib = "anim@amb@nightclub@dancers@crowddance_groups@hi_intensity", anim = "hi_dance_crowd_09_v1_female^6"}},
        {label = "Taniec 40", type = "anim", data = {lib = "anim@amb@nightclub@lazlow@hi_podium@", anim = "danceidle_hi_06_base_laz"}},
		}
	},

	--[[

	{
		name  = 'TEST',
		label = 'Test',
		items = {
		{label = "Tablet 1", type = "anim", data = {lib = "martin_1_int-1", anim = "prop_cs_tablet_02-1"}},
		{label = "Tablet 2", type = "anim", data = {lib = "martin_1_int-2", anim = "prop_cs_tablet_02-2"}},
		{label = "Tablet 3", type = "anim", data = {lib = "martin_1_int-3", anim = "prop_cs_tablet_02-3"}},
		{label = "Tablet 4", type = "anim", data = {lib = "martin_1_int-4", anim = "prop_cs_tablet_02-4"}},
		{label = "Tablet 5", type = "anim", data = {lib = "martin_1_int-5", anim = "prop_cs_tablet_02-5"}},
		{label = "Tablet 6", type = "anim", data = {lib = "martin_1_int-6", anim = "prop_cs_tablet_02-6"}},
		{label = "Tablet 7", type = "anim", data = {lib = "martin_1_int-7", anim = "prop_cs_tablet_02-7"}},
		{label = "Tablet 8", type = "anim", data = {lib = "martin_1_int-8", anim = "prop_cs_tablet_02-8"}},
		{label = "Tablet 9", type = "anim", data = {lib = "martin_1_int-9", anim = "prop_cs_tablet_02-9"}},
		{label = "Tablet 10", type = "anim", data = {lib = "martin_1_int-10", anim = "prop_cs_tablet_02-10"}},
		{label = "Tablet 11", type = "anim", data = {lib = "martin_1_int-11", anim = "prop_cs_tablet_02-11"}},
		{label = "Tablet 12", type = "anim", data = {lib = "martin_1_int-12", anim = "prop_cs_tablet_02-12"}},
		{label = "Tablet 13", type = "anim", data = {lib = "martin_1_int-13", anim = "prop_cs_tablet_02-13"}},
		{label = "Tablet 14", type = "anim", data = {lib = "martin_1_int-14", anim = "prop_cs_tablet_02-14"}},
		{label = "Tablet 15", type = "anim", data = {lib = "martin_1_int-15", anim = "prop_cs_tablet_02-15"}},
		{label = "Tablet 16", type = "anim", data = {lib = "martin_1_int-16", anim = "prop_cs_tablet_02-16"}},
			}
	},

	--]]

	{
		name  = 'dog',
		label = 'Dog',
		items = {
	    {label = "Bark", type = "anim", data = {lib = "creatures@rottweiler@amb@world_dog_barking@idle_a", anim = "idle_a"}},
	    {label = "Itch", type = "anim", data = {lib = "creatures@rottweiler@amb@world_dog_sitting@idle_a", anim = "idle_a"}},
	    {label = "Draw Attention", type = "anim", data = {lib = "creatures@rottweiler@indication@", anim = "indicate_high"}},
	    {label = "Attack", type = "anim", data = {lib = "creatures@rottweiler@melee@", anim = "dog_takedown_from_back"}},
	    {label = "Taunt", type = "anim", data = {lib = "creatures@rottweiler@melee@streamed_taunts@", anim = "taunt_02"}},
	    {label = "Swim", type = "anim", data = {lib = "creatures@rottweiler@swim@", anim = "swim"}},
			}
	},



	{
		name  = 'PEGI 21',
		label = 'PEGI 21',
		items = {
	    {label = "Bj in car driver", type = "anim", data = {lib = "oddjobs@towing", anim = "m_blow_job_loop"}},
	    {label = "Bj in car passenger", type = "anim", data = {lib = "oddjobs@towing", anim = "f_blow_job_loop"}},
	    {label = "Sex in car driver", type = "anim", data = {lib = "mini@prostitutes@sexlow_veh", anim = "low_car_sex_loop_player"}},
	    {label = "Sex in car passenger", type = "anim", data = {lib = "mini@prostitutes@sexlow_veh", anim = "low_car_sex_loop_female"}},
	    {label = "Grab crotch", type = "anim", data = {lib = "mp_player_int_uppergrab_crotch", anim = "mp_player_int_grab_crotch"}},
	    {label = "Stripper", type = "anim", data = {lib = "mini@strip_club@idles@stripper", anim = "stripper_idle_02"}},
	    {label = "Prostitute", type = "scenario", data = {anim = "WORLD_HUMAN_PROSTITUTE_HIGH_CLASS"}},
	    {label = "Stripper 2", type = "anim", data = {lib = "mini@strip_club@backroom@", anim = "stripper_b_backroom_idle_b"}},
	    {label = "Strip Tease 1", type = "anim", data = {lib = "mini@strip_club@lap_dance@ld_girl_a_song_a_p1", anim = "ld_girl_a_song_a_p1_f"}},
	    {label = "Strip Tease 2", type = "anim", data = {lib = "mini@strip_club@private_dance@part2", anim = "priv_dance_p2"}},
	    {label = "Stip Tease private", type = "anim", data = {lib = "mini@strip_club@private_dance@part3", anim = "priv_dance_p3"}},
	    {label = "Booty 1", type = "anim", data = {lib = "switch@trevor@mocks_lapdance", anim = "001443_01_trvs_28_exit_stripper"}},
        {label = "Booty 2", type = "anim", data = {lib = "switch@trevor@mocks_lapdance", anim = "001443_01_trvs_28_idle_stripper"}},
			}
	},

}