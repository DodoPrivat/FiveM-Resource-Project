--- p2 should be FALSE, otherwise it seems to always return FALSE
-- Bool does not check if the weapon is current equipped, unfortunately.
function Global.HasPedGotWeapon(ped, weaponHash, p2)
	return _in(0x8DECB02F88F428BC, ped, _ch(weaponHash), p2, _r)
end
