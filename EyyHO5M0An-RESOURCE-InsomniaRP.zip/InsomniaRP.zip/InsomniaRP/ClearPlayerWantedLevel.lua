function Global.ClearPlayerWantedLevel(player)
	return _in(0xB302540597885499, player)
end
