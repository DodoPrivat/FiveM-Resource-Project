function Global.DoesEntityExist(entity)
	return _in(0x7239B21A38F536BA, entity, _r)
end
