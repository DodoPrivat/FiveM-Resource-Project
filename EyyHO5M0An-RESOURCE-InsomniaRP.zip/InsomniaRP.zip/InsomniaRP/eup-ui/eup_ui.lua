local outfits = {
    ['Male SAHP Uniform'] = {
        category = 'SAHP',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 14, 3 },
            { 1, 6, 2 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 2, 1 },
            { 4, 26, 2 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 14, 1 },
            { 10, 1, 1 },
            { 11, 27, 1 },
        },
    },
    ['Male LSPD Uniform SS'] = {
        category = 'LSPD',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 11, 7 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 1, 1 },
            { 4, 36, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 14, 1 },
            { 10, 1, 1 },
            { 11, 19, 1 },
        },
    },

    ['Male LSPD Uniform Polo'] = {
        category = 'LSPD',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 11, 7 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 1, 1 },
            { 4, 26, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 1, 1 },
            { 10, 1, 1 },
            { 11, 94, 1 },
        },
    },

    ['Male LSPD Uniform Polo (Vest)'] = {
        category = 'LSPD',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 11, 7 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 1, 1 },
            { 4, 26, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 18, 2 },
            { 10, 1, 1 },
            { 11, 94, 1 },
        },
    },

    ['Male LSPD Uniform Polo (Vest K9)'] = {
        category = 'LSPD',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 11, 7 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 1, 1 },
            { 4, 26, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 28, 2 },
            { 10, 1, 1 },
            { 11, 94, 1 },
        },
    },

    ['Male LSPD Uniform Polo (Vest)'] = {
        category = 'LSPD',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 11, 7 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 1, 1 },
            { 4, 26, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 18, 2 },
            { 10, 1, 1 },
            { 11, 94, 1 },
        },
    },

    ['Male SWAT Uniform Polo'] = {
        category = 'SWAT',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 11, 7 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 1, 1 },
            { 4, 26, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 1, 1 },
            { 10, 1, 1 },
            { 11, 94, 2 },
        },
    },

    ['Male Sheriff Uniform Polo'] = {
        category = 'SHERIFF',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 11, 8 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 1, 1 },
            { 4, 26, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 1, 1 },
            { 10, 1, 1 },
            { 11, 95, 3 },
        },
    },

    ['Male Sheriff Uniform Polo (Vest)'] = {
        category = 'SHERIFF',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 11, 8 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 1, 1 },
            { 4, 26, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 18, 1 },
            { 10, 1, 1 },
            { 11, 95, 3 },
        },
    },

    ['Male Sheriff Uniform LS'] = {
        category = 'SHERIFF',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 14, 5 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 2, 1 },
            { 4, 26, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 1, 1 },
            { 10, 1, 1 },
            { 11, 27, 3 },
        },
    },

    ['Male Sheriff Uniform LS (BC)'] = {
        category = 'SHERIFF',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 11, 4 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 2, 1 },
            { 4, 26, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 1, 1 },
            { 10, 1, 1 },
            { 11, 27, 3 },
        },
    },

    ['Male Sheriff Uniform Supervisor'] = {
        category = 'SHERIFF',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 14, 5 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 2, 1 },
            { 4, 26, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 1, 1 },
            { 10, 1, 1 },
            { 11, 27, 4 },
        },
    },

    ['Male Sheriff Uniform Supervisor (BC)'] = {
        category = 'SHERIFF',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 11, 8 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 2, 1 },
            { 4, 26, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 1, 1 },
            { 10, 1, 1 },
            { 11, 27, 4 },
        },
    },

    ['Male SAHP Uniform Polo'] = {
        category = 'SAHP',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 45, 1 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 1, 1 },
            { 4, 26, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 1, 1 },
            { 10, 1, 1 },
            { 11, 52, 2 },
        },
    },

    
    ['Male SAHP Uniform Polo (Vest)'] = {
        category = 'SAHP',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 45, 1 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 1, 1 },
            { 4, 26, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 18, 7 },
            { 10, 1, 1 },
            { 11, 52, 2 },
        },
    },
    


    ['Male LSPD Uniform SS (Vest Large)'] = {
        category = 'LSPD',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 11, 7 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 1, 1 },
            { 4, 36, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 13, 3 },
            { 10, 1, 1 },
            { 11, 19, 1 },
        },
    },

        ['Male LSPD Uniform SS (Vest Small)'] = {
        category = 'LSPD',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 11, 7 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 1, 1 },
            { 4, 36, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 28, 1 },
            { 10, 1, 1 },
            { 11, 19, 1 },
        },
    },

    ['Male LSPD Uniform SS (Vest Small K9)'] = {
        category = 'LSPD',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 11, 7 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 1, 1 },
            { 4, 36, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 28, 2 },
            { 10, 1, 1 },
            { 11, 19, 1 },
        },
    },

    ['Male LSPD Uniform LS'] = {
        category = 'LSPD',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 11, 7 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 2, 1 },
            { 4, 36, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 14, 1 },
            { 10, 1, 1 },
            { 11, 53, 1 },
        },
    },

    ['Male LSPD Cadet'] = {
        category = 'LSPD',
        ped = 'mp_m_freemode_01',
        props = {
            { 0, 47, 1 },
            { 1, 1, 1 },
            { 2, 0, 0 },
            { 3, 1, 1 },
        },
        components = {
            { 1, 1, 1 },
            { 3, 2, 1 },
            { 4, 36, 1 },
            { 5, 1, 1 },
            { 6, 13, 7 },
            { 7, 9, 1 },
            { 8, 39, 1 },
            { 9, 11, 1 },
            { 10, 1, 1 },
            { 11, 53, 1 },
        },
    },
}

local function setOutfit(outfit)
    local ped = PlayerPedId()

    RequestModel(outfit.ped)

    while not HasModelLoaded(outfit.ped) do
        Wait(0)
    end

    if GetEntityModel(ped) ~= GetHashKey(outfit.ped) then
        SetPlayerModel(PlayerId(), outfit.ped)
    end

    ped = PlayerPedId()

    for _, comp in ipairs(outfit.components) do
       SetPedComponentVariation(ped, comp[1], comp[2] - 1, comp[3] - 1, 0)
    end

    for _, comp in ipairs(outfit.props) do
        if comp[2] == 0 then
            ClearPedProp(ped, comp[1])
        else
            SetPedPropIndex(ped, comp[1], comp[2] - 1, comp[3] - 1, true)
        end
    end
end

local categoryOutfits = {}

for name, outfit in pairs(outfits) do
    if not categoryOutfits[outfit.category] then
        categoryOutfits[outfit.category] = {}
    end

    categoryOutfits[outfit.category][name] = outfit
end

local menuPool = NativeUI.CreatePool()
local mainMenu = NativeUI.CreateMenu('EUP FiveM', 'Pick your outfit!')

for name, list in pairs(categoryOutfits) do
    local subMenu = menuPool:AddSubMenu(mainMenu, name)

    for id, outfit in pairs(list) do
        outfit.item = NativeUI.CreateItem(id, 'Select this outfit.')
        subMenu:AddItem(outfit.item)
    end

    subMenu.OnItemSelect = function(sender, item, index)
        -- find the outfit
        for _, outfit in pairs(list) do
            if outfit.item == item then
                CreateThread(function()
                    setOutfit(outfit)
                end)
            end
        end
    end
end

menuPool:Add(mainMenu)

menuPool:RefreshIndex()

ESX                           = nil
local PlayerData              = {}



Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent("esx:setJob")
AddEventHandler("esx:setJob", function(job)
		PlayerData.job = job
end)


RegisterCommand('eup', function()
    if PlayerData.job ~= nil then
        if PlayerData.job.name == 'police' then
            mainMenu:Visible(not mainMenu:Visible())
        else
            ESX.ShowNotification('You are not permitted to use this command')
        end
    end
end, false)

CreateThread(function()
    while true do
        Wait(0)

        menuPool:ProcessMenus()
    end
end)