--- Check if model is in cdimage(rpf)
function Global.IsModelInCdimage(model)
	return _in(0x35B9E0803292B641, _ch(model), _r)
end
