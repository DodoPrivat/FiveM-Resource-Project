function Global.GetHashKey(value)
	return _in(0xD24D37CC275948CC, _ts(value), _r, _ri)
end
