function Global.AddTextComponentString(text)
	return _in(0x6C188BE134E074AA, _ts(text))
end
