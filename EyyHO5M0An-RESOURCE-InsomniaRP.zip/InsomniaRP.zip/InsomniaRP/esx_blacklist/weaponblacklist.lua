-- Blacklisted weapons
weaponblacklist = {
	"WEAPON_SNIPERRIFLE", --polmav sniper
	"WEAPON_BZGAS",       --bz gas    
	"WEAPON_SMG",   --SMG
	"WEAPON_SPECIALCARBINE", -- SPECIAL CARBINE
	"WEAPON_KNIFE",
	"WEAPON_HAMMER",
	"WEAPON_GOLFCLUB",
	"WEAPON_APPISTOL",
	"WEAPON_ADVANCEDRIFLE",
	"WEAPON_MG",
	"WEAPON_ASSAULTSHOTGUN",
	"WEAPON_BULLPUPSHOTGUN",
	"WEAPON_HEAVYSNIPER",
	"WEAPON_REMOTESNIPER",
	"WEAPON_GRENADELAUNCHER",
	"WEAPON_GRENADE",
	"GADGET_PARACHUTE",
	"WEAPON_CARBINERIFLE_MK2",
}

weaponblacklistCop = {
	"WEAPON_COMBATPISTOL",
}

-- Don't allow any weapons at all (overrides the blacklist)
disableallweapons = false
local PlayerData = {}

ESX = nil



Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
  PlayerData.job = job
end)




	-- CODE --

Citizen.CreateThread(function()
	while true do
		Wait(1)
		playerPed = GetPlayerPed(-1)
		if playerPed then
			nothing, weapon = GetCurrentPedWeapon(playerPed, true)
				if isWeaponBlacklisted(weapon) then
					RemoveWeaponFromPed(playerPed, weapon)
					sendForbiddenMessage("Firearm is Blacklisted")
				end
				if isWeaponBlacklistedCop(weapon) and PlayerData.job.name ~= 'police' then
					RemoveWeaponFromPed(playerPed, weapon)
					sendForbiddenMessage("Firearm is Blacklisted (Police Only)")
				elseif isWeaponBlacklistedEmer(weapon) and not(PlayerData.job.name == 'ambulance' or PlayerData.job.name == 'security' or PlayerData.job.name == 'police') then
					RemoveWeaponFromPed(playerPed, weapon)
					sendForbiddenMessage("Firearm is Blacklisted (Emergency Personel Only)")
				end

		end
	end
end)

-- Disable weapons dropping off peds

Citizen.CreateThread(function()
  while true do
    Citizen.Wait(1)
    -- List of pickup hashes (https://pastebin.com/8EuSv2r1)
    RemoveAllPickupsOfType(0xDF711959) -- carbine rifle
    RemoveAllPickupsOfType(0xF9AFB48F) -- pistol
    RemoveAllPickupsOfType(0xA9355DCD) -- pumpshotgun
  end
end)

function isWeaponBlacklisted(model)
--              SNIPERRIFLE
	if model == 2726580491 then
		return true
	end
	return false
end

function isWeaponBlacklistedCop(model)
	--          COMBATPISTOL          CARBINERIFLE             Sniper                 BZ Gas              ASSAULTSMG 				smoke					FLAREGUN			 nightstick				shotgun					pump Mk2           Carbine MK2
	if model == 1593441988 or model == 2210333304 or model == 100416529 or model == 2694266206 or model == 4024951519 or model == 736523883 or model  == 1233104067 or model == 1737195953 or model == 3800352039 or model == 1432025498 or model == 4208062921 then
		return true
	end
    return false
end

function isWeaponBlacklistedEmer(model)
	--           STUNGUN                FLAREGUN
	if model == 911657153 or model == 1198879012 or model == 3800352039 then
		return true
	end
	return false
end

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  DisablePlayerVehicleRewards(GetPlayerPed(-1))
end)
