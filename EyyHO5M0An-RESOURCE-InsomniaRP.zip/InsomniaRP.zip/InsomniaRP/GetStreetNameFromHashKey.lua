function Global.GetStreetNameFromHashKey(hash)
	return _in(0xD0EF8A959B8A4CB9, _ch(hash), _r, _s)
end
