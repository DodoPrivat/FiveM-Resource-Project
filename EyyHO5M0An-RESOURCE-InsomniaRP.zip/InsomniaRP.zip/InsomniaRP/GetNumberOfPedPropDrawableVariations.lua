--- List of component/props ID
-- gtaxscripting.blogspot.com/2016/04/gta-v-peds-component-and-props.html
function Global.GetNumberOfPedPropDrawableVariations(ped, propId)
	return _in(0x5FAF9754E789FB47, ped, propId, _r, _ri)
end
