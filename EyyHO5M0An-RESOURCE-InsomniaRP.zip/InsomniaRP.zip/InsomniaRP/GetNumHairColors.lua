--- Used for freemode (online) characters.
function Global.GetNumHairColors()
	return _in(0xE5C0CF872C2AD150, _r, _ri)
end
