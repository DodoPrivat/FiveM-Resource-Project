Config = {}

Config.EnableBlips		= true
Config.VehicleFailure	= 5 -- At what fuel-percentage should the engine stop functioning properly? (Defualt: 10)
