function Global.GetBlipFromEntity(p0)
	return _in(0xBC8DBDCA2436F7E8, p0, _r, _ri)
end
