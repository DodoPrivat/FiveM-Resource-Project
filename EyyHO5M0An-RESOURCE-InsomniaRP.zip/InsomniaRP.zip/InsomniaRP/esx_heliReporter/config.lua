Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = {x = 1.8, y = 1.8, z = 1.0}
Config.MarkerColor                = {r = 100, g = 160, b = 255}
Config.EnableSocietyOwnedVehicles = false
Config.MaxInService               = -1
Config.Locale = 'en'

Config.Spawners = {

  
  NEWS = {

    Blip = {
      Pos     = {x = 1837.4, y = 3695.15, z = 33.27},
      Sprite  = 43,
      Display = 4,
      Scale   = 0.8,
      Color  = 1,
    },

    Vehicles = {
      {
        Spawner    = {x = -563.06, y = -887.1, z = 24.2},
        SpawnPoint = {x = -558.63, y = -899.06, z = 24.47},
        Heading    = 255.28
      }
    },

  },
}
