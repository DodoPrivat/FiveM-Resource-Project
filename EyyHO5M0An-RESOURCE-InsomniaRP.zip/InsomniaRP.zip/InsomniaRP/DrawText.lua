function Global.DrawText(x, y)
	return _in(0xCD015E5BB0D96A57, x, y)
end
