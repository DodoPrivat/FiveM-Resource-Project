function Global.GetVehiclePedIsIn(ped, getLastVehicle)
	return _in(0x9A9112A0FE9A4713, ped, getLastVehicle, _r, _ri)
end
