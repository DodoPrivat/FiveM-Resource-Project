function Global.GetPlayerWantedLevel(player)
	return _in(0xE28E54788CE8F12D, player, _r, _ri)
end
