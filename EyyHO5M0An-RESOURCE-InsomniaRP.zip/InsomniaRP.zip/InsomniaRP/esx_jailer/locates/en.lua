Locales ['en'] = {
	['blip_name']          = 'prison',
	['judge']              = 'Breaking News!!',
	['escape_attempt']     = 'you are not allowed to escape the prison!',
	['remaining_msg']      = 'there remains %s minutes until you are released from jail',
	['jailed_msg']         = '%s is now in jail for %s minutes',
	['unjailed']           = '%s has been released from jail!'
}
