function Global.DestroyMobilePhone()
	return _in(0x3BC861DF703E5097)
end
