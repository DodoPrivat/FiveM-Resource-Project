--- Has 8 params in the latest patches.
-- isMission - if true doesn't return mission objects
function Global.GetClosestObjectOfType(x, y, z, radius, modelHash, isMission, p6, p7)
	return _in(0xE143FA2249364369, x, y, z, radius, _ch(modelHash), isMission, p6, p7, _r, _ri)
end
