
ESX                           = nil

Citizen.CreateThread(function ()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	ESX.TriggerServerCallback('esx_vehicleshop:getVehicles', function (vehicles)
		Vehicles = vehicles
	end)
end)

function OpenPersonnalVehicleMenu ()

	ESX.UI.Menu.CloseAll()
  
	ESX.TriggerServerCallback('esx_pv:getPersonnalVehicles', function (vehicles)
	  local elements = {}
  
	  for i=1, #vehicles, 1 do
		for j=1, #Vehicles, 1 do
		  if vehicles[i].model == GetHashKey(Vehicles[j].model) then
			vehicles[i].name = Vehicles[j].name
		  end
		end
	  end
  
	  for i=1, #vehicles, 1 do
		table.insert(elements, {label = vehicles[i].name .. ' [' .. vehicles[i].plate .. ']', value = vehicles[i]})
	  end
  
	  ESX.UI.Menu.Open(
		'default', GetCurrentResourceName(), 'personnal_vehicle',
		{
		  title    =  'Personal Vehicles',
		  align    = 'left',
		  elements = elements,
		},
		function (data, menu)
		  local playerPed   = GetPlayerPed(-1)
		  local coords      = GetEntityCoords(playerPed)
		  local heading     = GetEntityHeading(playerPed)
		  local vehicleData = data.current.value
  
		  menu.close()
  
		  ESX.Game.SpawnVehicle(vehicleData.model, {
			x = coords.x,
			y = coords.y,
			z = coords.z
		  }, heading, function (vehicle)
			ESX.Game.SetVehicleProperties(vehicle, vehicleData)
			TaskWarpPedIntoVehicle(playerPed, vehicle, -1)
		  end)
		end,
		function (data, menu)
		  menu.close()
		end
	  )
	end)
  end

RegisterNetEvent('esx_pv:openPersonnalVehicleMenu')
AddEventHandler('esx_pv:openPersonnalVehicleMenu', function ()
  OpenPersonnalVehicleMenu()
end)


RegisterNetEvent('esx_pv:setVehPlate')
AddEventHandler('esx_pv:setVehPlate', function(plate)
	local vehicle = GetVehiclePedIsIn(GetPlayerPed(-1), false)
	SetVehicleNumberPlateText(vehicle, plate)
end)
