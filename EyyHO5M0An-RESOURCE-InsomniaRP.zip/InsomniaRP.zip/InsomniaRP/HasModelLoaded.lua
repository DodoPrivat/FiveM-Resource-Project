--- Checks if the specified model has loaded into memory.
function Global.HasModelLoaded(model)
	return _in(0x98A4EB5D89A0C952, _ch(model), _r)
end
