function Global.IsControlJustReleased(index, control)
	return _in(0x50F940259D3841E6, index, control, _r)
end
