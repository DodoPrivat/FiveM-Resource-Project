Config = {
	DrawDistance = 100,
	Price = 5000,
	BlipInfos = {
		Sprite = 290,
		Color = 5 
	}
}

Config.Garages = {
	Centre = {	
		Pos = {x=-303.201, y=-742.733, z=32.965},
		Size  = {x = 3.0, y = 3.0, z = 1.0},
		Color = {r = 204, g = 204, b = 0},
		Marker = 27,
		SpawnPoint = {
			Pos = {x=-307.384, y= -756.554, z= 31.969, h=71.243309020},
			Color = {r=0,g=255,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = -1
		},
		DeletePoint = {
			Pos = {x=-289.95, y=-748.108, z=32.965},
			Color = {r=255,g=0,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = 27
		}, 	
	},
	Paleto = {	
		Pos = {x=105.359, y=6613.586, z=31.50},
		Size  = {x = 1.0, y = 1.0, z = 1.0},
		Color = {r = 0, g = 255, b = 0},
		Marker = 27,
		SpawnPoint = {
			Pos = {x=128.7822, y= 6622.9965, z= 30.7828, h=71.243309020},
			Color = {r=0,g=255,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = -1
		},
		DeletePoint = {
			Pos = {x=126.3572, y=6608.4150, z=30.90},
			Color = {r=255,g=0,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = 27
		}, 	
	},

	CarAuction = {	
		Pos = {x=711.412, y=592.87, z=128.3},
		Size  = {x = 1.0, y = 1.0, z = 1.0},
		Color = {r = 0, g = 255, b = 0},
		Marker = 27,
		SpawnPoint = {
			Pos = {x=699.547, y=604.029, z= 46.2, h=71.243309020},
			Color = {r=0,g=255,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = -1
		},
		DeletePoint = {
			Pos = {x=676.433, y=611.125, z=128.5},
			Color = {r=255,g=0,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = 27
		}, 	
	},

	sandy = {	
		Pos = {x=1737.450, y=3710.230, z=33.18},
		Size  = {x = 3.0, y = 3.0, z = 1.0},
		Color = {r = 204, g = 204, b = 0},
		Marker = 27,
		SpawnPoint = {
			Pos = {x=1721.860, y=3715.880, z=33.18, h=71.243309020},
			Color = {r=0,g=255,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = -1
		},
		DeletePoint = {
			Pos = {x=1739.920, y=3720.500, z=33.05},
			Color = {r=255,g=0,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = 27
		}, 	
	},

	northerncity = {	
		Pos = {x=-341.46, y=269.95, z=84.56},
		Size  = {x = 3.0, y = 3.0, z = 1.0},
		Color = {r = 204, g = 204, b = 0},
		Marker = 1,
		SpawnPoint = {
			Pos = {x= -332.600, y=281.42, z=85.01, h=71.243309020},
			Color = {r=0,g=255,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = -1
		},
		DeletePoint = {
			Pos = {x=-348.87, y=275.89, z=84.04},
			Color = {r=255,g=0,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = 1
		}, 	
	},

	midcity = {	
		Pos = {x=-897.365, y=-345.819, z=33.534},
		Size  = {x = 3.0, y = 3.0, z = 1.0},
		Color = {r = 204, g = 204, b = 0},
		Marker = 27,
		SpawnPoint = {
			Pos =  {x=-887.31, y=-343.726, z=32.534},
			Color = {r=0,g=255,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = -1
		},
		DeletePoint = {
			Pos = {x=-889.1, y=-336.84, z=33.534},
			Color = {r=255,g=0,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = 27
		}, 	
	},

	midcity2 = {	
		Pos = {x=-1362.314, y=-472.211, z=30.696},
		Size  = {x = 3.0, y = 3.0, z = 1.0},
		Color = {r = 204, g = 204, b = 0},
		Marker = 27,
		SpawnPoint = {
			Pos =  {x=-1381.078, y=-474.915, z=30.6},
			Color = {r=0,g=255,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = -1
		},
		DeletePoint = {
			Pos = {x=-1372.996, y=-480.648, z=30.7},
			Color = {r=255,g=0,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = 27
		}, 	
	},

	grovestreet = {	
		Pos = {x=-71.250, y=-1821.960, z=25.940},
		Size  = {x = 3.0, y = 3.0, z = 1.0},
		Color = {r = 204, g = 204, b = 0},
		Marker = 1,
		SpawnPoint = {
			Pos = {x= -61.990, y=-1833.12, z=25.800, h=71.243309020},
			Color = {r=0,g=255,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = -1
		},
		DeletePoint = {
			Pos = {x=-59.950, y=-1842.53, z=25.58},
			Color = {r=255,g=0,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = 1
		}, 	
	},


    LSIA = {	
		Pos = {x=-1129.7268066406, y=-2003.4063720703, z=12.171084403992},
		Size  = {x = 3.0, y = 3.0, z = 1.0},
		Color = {r = 204, g = 204, b = 0},
		Marker = 1,
		SpawnPoint = {
			Pos = {x=-1115.2082519531, y=-2004.4404296875, z=12.171123504639, h=180.243309020},
			Color = {r=0,g=255,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = -1
		},
		DeletePoint = {
			Pos = {x=-1133.1614990234, y=-1999.8729248047, z=12.172080039978},
			Color = {r=255,g=0,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = 1
		}, 	
	},


	Harmony = {	
		Pos = {x=1224.434, y=2727.473, z=37.005},
		Size  = {x = 3.0, y = 3.0, z = 1.0},
		Color = {r = 204, g = 204, b = 0},
		Marker = 1,
		SpawnPoint = {
			Pos = {x=1210.398, y=2720.753, z=37.004, h=172.644},
			Color = {r=0,g=255,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = -1
		},
		DeletePoint = {
			Pos = {x=1234.843, y=2720.943, z=37.005},
			Color = {r=255,g=0,b=0},
			Size  = {x = 3.0, y = 3.0, z = 1.0},
			Marker = 1
		}, 	
	},


}