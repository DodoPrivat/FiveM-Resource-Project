Config                = {}
Config.DrawDistance   = 100
Config.Size           = { x = 1.0, y = 1.0, z = 1.0 }
Config.Color          = { r = 255, g = 0, b = 0 }
Config.Type           = -1
Config.Locale = 'en'

Config.Zones = {

    PubLaunderer = {
        legal = 0,
        Items = {},
        Pos   = {
            --{ x = 944.914,   y = -944.765,   z = 43.38 }, -- Casino
            { x = 152.260,     y = -1478.460,   z = 28.760 },  -- Back Alley

        }
    },

    PrivLaunderer = {
        legal = 1,
        Items = {},
        Pos   = {
            { x = -535.75,   y = 4652.899,  z = 89.794},  -- private seller
        }
    },

}
