function Global.DoScreenFadeIn(duration)
	return _in(0xD4E8E24955024033, duration)
end
