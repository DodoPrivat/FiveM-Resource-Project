function Global.IsDisabledControlJustPressed(index, control)
	return _in(0x91AEF906BCA88877, index, control, _r)
end
