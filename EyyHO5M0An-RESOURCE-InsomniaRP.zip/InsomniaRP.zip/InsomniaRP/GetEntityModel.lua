function Global.GetEntityModel(entity)
	return _in(0x9F47B058362C84B5, entity, _r, _ri)
end
