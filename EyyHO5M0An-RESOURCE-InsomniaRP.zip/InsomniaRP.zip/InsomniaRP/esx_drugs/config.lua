Config              = {}
Config.MarkerType   = -1
Config.DrawDistance = 20.0
Config.ZoneSize     = {x = 5.0, y = 5.0, z = 5.0}
Config.MarkerColor  = {r = 100, g = 204, b = 100}

Config.RequiredCopsCoke  = 0
Config.RequiredCopsMeth  = 0
Config.RequiredCopsWeed  = 0
Config.RequiredCopsOpium = 0

Config.TimeToFarm    = 4 * 1000
Config.TimeToProcess = 16 * 1000
Config.TimeToSell    = 5  * 1000

Config.Locale = 'en'

Config.Zones = {
	--CokeField =			{x = -27.923,	y = -2717.721,	z = 2.888},
	--CokeProcessing =	{x = -929.128, y = -1323.007, z = 9.895},
	--CokeDealer =		{x = -882.918,	y = -1286.327,		z = 13.196},	
	--MethField =			{x = 893.472,	y = -1965.99,	z = 43.269},	
	--MethProcessing =	{x = 983.546, y = -92.169, z = 74.85},
	--MethDealer =		{x = -63.59,	y = -1224.07,	z = 27.76},
	WeedField =			{x = 2224.77, y = 5576.44, z = 53.80},
	WeedProcessing =	{x = 1036.1,		y = -3204.637,	z = -38.174},
	--WeedDealer =		{x = -54.24,	y = -1443.36,	z = 31.06},
	--OpiumField =		{x = -1363.235,	y = 88.753,	z = 60.629},
	--OpiumProcessing =	{x = -1915.578, y = 1388.459, z = 220.015},
	--OpiumDealer =		{x = 2331.08,	y = 2570.22,	z = 46.68},
}

