function GetPlayers()
    print("Checking Instanced Players")
    local players = {}

    totalPlayers = 0

    for i = 0, 31 do
        if NetworkIsPlayerActive(i) then
            table.insert(players, i)
            totalPlayers = totalPlayers + 1
        end
    end

    print("TOTAL PLAYERS")
    print(totalPlayers)

    if totalPlayers > 1 then
        return false
    else
        return true
    end

end

RegisterNetEvent('esx_instanced:checkInstanced')
AddEventHandler('esx_instanced:checkInstanced', function()
    print("TESTING")
    if GetPlayers() then
         TriggerServerEvent('es_admin:KickMe')
    end
end)
