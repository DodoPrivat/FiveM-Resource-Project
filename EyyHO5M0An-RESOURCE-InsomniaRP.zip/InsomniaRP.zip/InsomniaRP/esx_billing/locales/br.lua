Locales['br'] = {

	['invoices'] = 'Faturas',
	['received_invoice'] = 'Você ~r~recebeu~s~ uma fatura',
	['paid_invoice'] = 'Você ~g~pagou~s~ uma fatura de ~r~$',
	['received_payment'] = 'Você ~g~recebeu~s~ um pagamento de ~r~$',
	['player_not_logged'] = 'O jogador não está logado',

}
