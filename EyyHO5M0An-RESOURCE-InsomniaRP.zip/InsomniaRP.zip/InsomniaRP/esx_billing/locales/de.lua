Locales['de'] = {

	['invoices'] = 'Rechnungen',
	['received_invoice'] = 'you hast eine Rechnung ~r~erhlaten~s~',
	['paid_invoice'] = 'du ~g~bezahlst~s~ eine Rechnung von ~r~$',
	['received_payment'] = 'du ~g~erhältst~s~ eine Zahlung von ~r~$',
	['player_not_logged'] = 'der Spieler ist nicht online',

}
