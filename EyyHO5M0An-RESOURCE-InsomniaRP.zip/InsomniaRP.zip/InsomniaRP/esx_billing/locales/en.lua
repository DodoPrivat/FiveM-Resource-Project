Locales['en'] = {

	['invoices'] = 'invoices',
	['received_invoice'] = 'you ~r~received~s~ an invoice',
	['paid_invoice'] = 'you ~g~paid~s~ an invoice of ~r~$',
	['received_payment'] = 'you ~g~received~s~ a payment of ~r~$',
	['player_not_logged'] = 'the player is not logged in',

}
