Locales['es'] = {

	['invoices'] = 'Facturas',
	['received_invoice'] = 'Has ~r~recibido~s~ una multa',
	['paid_invoice'] = 'Has ~g~pagado~s~ una multa de ~r~€',
	['received_payment'] = 'Has ~g~recibido~s~ un pago de ~g~€',
	['player_not_logged'] = 'El jugador no está conectado',
}
