Locales['fr'] = {

	['invoices'] = 'factures',
	['received_invoice'] = 'vous avez ~r~reçu~s~ une facture',
	['paid_invoice'] = 'vous avez ~g~payé~s~ une facture de ~r~$',
	['received_payment'] = 'vous avez ~g~reçu~s~ un paiement de ~g~$',
	['player_not_logged'] = 'le joueur n\'est pas connecté',

}
