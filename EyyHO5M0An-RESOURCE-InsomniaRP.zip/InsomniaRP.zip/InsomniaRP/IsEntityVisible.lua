function Global.IsEntityVisible(entity)
	return _in(0x47D6F43D77935C75, entity, _r)
end
