function Global.FreezeEntityPosition(entity, toggle)
	return _in(0x428CA6DBD1094446, entity, toggle)
end
