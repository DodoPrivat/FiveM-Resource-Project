function Global.DisablePlayerVehicleRewards(player)
	return _in(0xC142BE3BB9CE125F, player)
end
