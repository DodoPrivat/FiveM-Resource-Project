Config = {}
Config.Locale = 'en'

Config.PoliceNumberRequired = 4
Config.TimerBeforeNewRob = 2500 -- seconds


-- Change secondsRemaining if you want another timer
Stores = {
    --[["paleto_twentyfourseven"] = {
        position = { ['x'] = 1736.32092285156, ['y'] = 6419.4970703125, ['z'] = 35.037223815918 },
        reward = math.random(2500,75000),
        nameofstore = "24/7. (Paleto Bay)",
        secondsRemaining = 400, -- seconds
        lastrobbed = 0
    },]]
    ["sandyshores_twentyfoursever"] = {
        position = { ['x'] = 1961.24682617188, ['y'] = 3749.46069335938, ['z'] = 32.3437461853027 },
        reward = math.random(2500,7500),
        nameofstore = "24/7. (Sandy Shores)",
        secondsRemaining = 60, -- seconds
        lastrobbed = 0
    },
    ["bar_one"] = {
        position = { ['x'] = 1990.579, ['y'] = 3044.957, ['z'] = 47.215171813965 },
        reward = math.random(2500,7500),
        nameofstore = "Yellow Jack. (Sandy Shores)",
        secondsRemaining = 80, -- seconds
        lastrobbed = 0
    },
    ["paleto_twentyfourseven"] = {
        position = { ['x'] = 1736.32092285156, ['y'] = 6419.4970703125, ['z'] = 35.037223815918 },
        reward = math.random(2500,7500),
        nameofstore = "24/7. (Paleto Bay)",
        secondsRemaining = 60, -- seconds
        lastrobbed = 0
    },
    ["ocean_liquor"] = {
        position = { ['x'] = -2959.33715820313, ['y'] = 388.214172363281, ['z'] = 14.0432071685791 },
        reward = math.random(2500,7500),
        nameofstore = "Robs Liquor. (Great Ocean Higway)",
        secondsRemaining = 60, -- seconds
        lastrobbed = 0
    },
    ["sanandreas_liquor"] = {
        position = { ['x'] = -1219.85607910156, ['y'] = -916.276550292969, ['z'] = 11.3262157440186 },
        reward = math.random(2500,7500),
        nameofstore = "Robs Liquor. (San andreas Avenue)",
        secondsRemaining = 60, -- seconds
        lastrobbed = 0
    },
    ["grove_ltd"] = {
        position = { ['x'] = -43.4035377502441, ['y'] = -1749.20922851563, ['z'] = 29.421012878418 },
        reward = math.random(2500,7500),
        nameofstore = "LTD Gasoline. (Grove Street)",
        secondsRemaining = 60, -- seconds
        lastrobbed = 0
    },
    ["mirror_ltd"] = {
        position = { ['x'] = 1160.67578125, ['y'] = -314.400451660156, ['z'] = 69.2050552368164 },
        reward = math.random(2500,7500),
        nameofstore = "LTD Gasoline. (Mirror Park Boulevard)",
        secondsRemaining = 60, -- seconds
        lastrobbed = 0
    },
    ["littleseoul_twentyfourseven"] = {
        position = { ['x'] = -709.17022705078, ['y'] = -904.21722412109, ['z'] = 19.215591430664 },
        reward = math.random(2500,7500),
        nameofstore = "24/7. (Little Seoul)",
        secondsRemaining = 60, -- seconds
        lastrobbed = 0
    },
	--["bank_pacific"] = {
	--	position = { ['x'] = 259.080, ['y'] = 225.620, ['z'] = 101.00 },
	--	reward = math.random(870000,1300000),
	--	nameofstore = "Pacific Standard Bank",
	--	secondsRemaining = 700, -- seconds
	--	lastrobbed = 0
	--},
	--["fleca_highway"] = {
		--position = { ['x'] = -2957.570, ['y'] = 480.440, ['z'] = 15.00 },
		--reward = math.random(575000,825000),
		--nameofstore = "Fleca Highway Bank",
		--secondsRemaining = 700, -- seconds
		--lastrobbed = 0
	--},
	--["bank_paleto"] = {
		--position = { ['x'] =-106.580, ['y'] = 6474.140, ['z'] = 31.000 },
		--reward = math.random(600000,1250000),
		--nameofstore = "Blaine County Savings",
		--secondsRemaining = 700, -- seconds
		--lastrobbed = 0
	--},
	--["fleca_sandy"] = {
		--position = { ['x'] =1177.380, ['y'] = 2711.850, ['z'] = 37.50 },
		--reward = math.random(600000,1250000),
		--nameofstore = "Sandy Shores Fleeca Bank",
		--secondsRemaining = 700, -- seconds
		--lastrobbed = 0
	--},
	--["fleca_lossantos"] = {
		--position = { ['x'] =-354.59, ['y'] = -53.910, ['z'] = 48.500 },
		--reward = math.random(600000,1200000),
		--nameofstore = "Hawick Avenue Fleeca Bank",
		--secondsRemaining = 700, -- seconds
		--lastrobbed = 0
	--},
	--["life_invader"] = {
	--	position = { ['x'] =-1057.650, ['y'] = -244.370, ['z'] = 43.500 },
	--	reward = math.random(600000,1000000),
	--	nameofstore = "Life Invader",
	--	secondsRemaining = 700, -- seconds
	--	lastrobbed = 0
	--},
    ["24/7_Grapeseed"] = {
        position = { ['x'] =1706.675, ['y'] = 4919.988, ['z'] = 42.063 },
        reward = math.random(2500,7500),
        nameofstore = "24/7 Grapeseed",
        secondsRemaining = 60, -- seconds
        lastrobbed = 0
    },
    ["24/7_route68"] = {
        position = { ['x'] =546.691, ['y'] = 2664.466, ['z'] = 42.063 },
        reward = math.random(2500,7500),
        nameofstore = "24/7 Route 68",
        secondsRemaining = 60, -- seconds
        lastrobbed = 0
    },
    ["ace_liqour"] = {
        position = { ['x'] =1393.250, ['y'] = 3608.934, ['z'] = 34.980 },
        reward = math.random(2500,7500),
        nameofstore = "Ace Liquor Sandy Shores",
        secondsRemaining = 60, -- seconds
        lastrobbed = 0
    },
    ["24/7_nrockford"] = {
        position = { ['x'] =-1827.73, ['y'] = 799.028, ['z'] = 138.164 },
        reward = math.random(2500,7500),
        nameofstore = "24/7 North Rockford Dr",
        secondsRemaining = 60, -- seconds
        lastrobbed = 0
    }
}
