function Global.DecorGetInt(entity, propertyName)
	return _in(0xA06C969B02A97298, entity, _ts(propertyName), _r, _ri)
end
