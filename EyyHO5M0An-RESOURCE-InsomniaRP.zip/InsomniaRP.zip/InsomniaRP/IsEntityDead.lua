function Global.IsEntityDead(entity)
	return _in(0x5F9532F3B5CC2551, entity, _r)
end
