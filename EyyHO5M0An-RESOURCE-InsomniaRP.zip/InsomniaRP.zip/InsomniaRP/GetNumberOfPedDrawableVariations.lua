--- List of component/props ID
-- gtaxscripting.blogspot.com/2016/04/gta-v-peds-component-and-props.html
function Global.GetNumberOfPedDrawableVariations(ped, componentId)
	return _in(0x27561561732A7842, ped, componentId, _r, _ri)
end
