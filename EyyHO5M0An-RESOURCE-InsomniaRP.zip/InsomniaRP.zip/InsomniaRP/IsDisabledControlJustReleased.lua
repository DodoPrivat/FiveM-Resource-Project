function Global.IsDisabledControlJustReleased(index, control)
	return _in(0x305C8DCD79DA8B0F, index, control, _r)
end
