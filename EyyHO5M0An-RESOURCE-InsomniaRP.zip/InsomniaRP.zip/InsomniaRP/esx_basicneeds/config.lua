Config = {}
Config.Locale = 'en'

Config.TickTime         = 100
Config.UpdateClientTime = 5000
