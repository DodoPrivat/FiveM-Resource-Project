Locales['en'] = {

	['used_bread'] = 'you have used 1x bread',
	['used_water'] = 'you have used 1x water',
	['used_chocolate'] = 'you have used 1x chocolate',
	['used_sandwich'] = 'you have used 1x sandwich',
	['used_hamburger'] = 'you have used 1x hamburger',
	['used_cupcake'] = 'you have used 1x cupcake',
	['used_cocacola'] = 'you have used 1x coca-cola',
	['used_icetea'] = 'you have used 1x ice-tea',
	['used_redbull'] = 'you have used 1x coffee',
	['used_beer'] = 'you have used 1x ~y~beer~s~',
	['used_wine'] = 'you have used 1x ~y~wine~s~',
	['used_vodka'] = 'you have used 1x ~y~Vodka~s~',
	['used_tequila'] = 'you have used 1x ~y~Tequila~s~',
	['used_whisky'] = 'you have used 1x ~y~Whisky~s~',
	['used_milk'] = 'you have used 1x milk',
	['used_taco'] = 'you have used 1x taco',
	['used_milkbone'] = 'Wolf Wolf',

}

