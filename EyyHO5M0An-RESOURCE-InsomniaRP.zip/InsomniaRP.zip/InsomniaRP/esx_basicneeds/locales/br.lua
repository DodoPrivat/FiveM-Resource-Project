Locales['br'] = {

	['used_bread'] = 'Você comeu 1x pão',
	['used_water'] = 'Você bebeu 1x água',
	['used_wine'] = 'Você bebeu 1x vinho',
	['used_beer'] = 'Você bebeu 1x cerveja',
	['used_vodka'] = 'Você bebeu 1x vodka',
	['used_chocolate'] = 'Você comeu 1x chocolate',
	['used_sandwich'] = 'Você comeu 1x sandwich',
	['used_hamburger'] = 'Você comeu 1x hamburger',
	['used_tequila'] = 'Você bebeu 1x tequila',
	['used_whisky'] = 'Você bebeu 1x whisky',
	['used_cupcake'] = 'Você comeu 1x bolinho',
	['used_cocacola'] = 'Você bebeu 1x coca-cola',
	['used_icetea'] = 'Você bebeu 1x ice-tea',
	['used_redbull'] = 'Você bebeu 1x café',
	['used_beer'] = 'Você bebeu 1x ~y~Cerveja~s~',
	['used_wine'] = 'Você bebeu 1x ~y~Vinho~s~',
	['used_vodka'] = 'Você bebeu 1x ~y~Vodka~s~',
	['used_tequila'] = 'Você bebeu 1x ~y~Tequila~s~',
	['used_whisky'] = 'Você bebeu 1x ~y~Whisky~s~',
	['used_milk'] = 'Você bebe 1x leite',

}
