local GUI          			  = {}
local hasAlreadyEnteredMarker = false
local menuIsShowed   		  = false

ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

-- Create blips
Citizen.CreateThread(function()

  for k,v in pairs(Config.Blips) do

    local blip = AddBlipForCoord(v.Blip.Pos.x, v.Blip.Pos.y, v.Blip.Pos.z)

    SetBlipSprite (blip, v.Blip.Sprite)
    SetBlipDisplay(blip, v.Blip.Display)
    SetBlipScale  (blip, v.Blip.Scale)
    SetBlipColour (blip, v.Blip.Color)
    SetBlipAsShortRange(blip, true)

    local blipString = v.Label
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(blipString)
    EndTextCommandSetBlipName(blip)

  end

end)