Config              = {}
Config.ZDiff        = 2.0
Config.Locale = 'en'

Config.Blips = {

  Villa = {

    Blip = {
      Pos     = { x = 1407.71, y = 1145.1, z = 114.33 },
      Sprite  = 304,
      Display = 4,
      Scale   = 1.0,
      Color  = 27,
    },

    Label = "Villa dei Luna",

  },

  Unicorn = {

    Blip = {
      Pos     = { x = 109.15, y = -1314.26, z = 29.21 },
      Sprite  = 279,
      Display = 4,
      Scale   = 1.0,
      Color  = 1,
    },

    Label = "Vanilla Unicorn",

  },



  Casino = {

    Blip = {
      Pos     = { x = 991.38, y = 33.32, z = 80.99 },
      Sprite  = 121,
      Display = 4,
      Scale   = 1.0,
      Color  = 81,
    },

    Label = "FC Casino",

  },

 Laywer = {

    Blip = {
      Pos     = { x = -1529.222, y = 858.046, z = 181.595 },
      Sprite  = 77,
      Display = 4,
      Scale   = 1.0,
      Color  = 1,
    },

    Label = "Law Firm",

  },

   
}
