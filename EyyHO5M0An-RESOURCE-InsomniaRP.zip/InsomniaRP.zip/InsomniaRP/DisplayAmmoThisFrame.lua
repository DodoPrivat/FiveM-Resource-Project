function Global.DisplayAmmoThisFrame(display)
	return _in(0xA5E78BA2B1331C55, display)
end
