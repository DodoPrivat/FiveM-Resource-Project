Config                = {}
Config.DrawDistance   = 100
Config.Size           = { x = 1.5, y = 1.5, z = 1.5 }
Config.Color          = { r = 255, g = 0, b = 0 }
Config.Type           = 27
Config.Locale         = 'en'

Config.Zones = {

    PubLaunderer = {
        legal = 0,
        Items = {},
        Pos   = {

        }
    },

    PrivLaunderer = {
        legal = 1,
        Items = {},
        Pos   = {
            { x = -1127.903,   y = 2707.799,  z = 17.6},  -- attachment seller
        }
    },

}
