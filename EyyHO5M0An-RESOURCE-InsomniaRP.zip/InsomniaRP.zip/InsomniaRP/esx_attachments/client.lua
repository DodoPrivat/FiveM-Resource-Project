ESX                           = nil
local HasAlreadyEnteredMarker = false
local LastZone                = nil
local CurrentAction           = nil
local CurrentActionMsg        = ''
local CurrentActionData       = {}

Citizen.CreateThread(function()
  while ESX == nil do
    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
    Citizen.Wait(0)
  end
end)

function DisplayHelpText(str)
  SetTextComponentFormat("STRING")
  AddTextComponentString(str)
  DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end

AddEventHandler('esx_attachments:hasEnteredMarker', function(zone)
  CurrentAction     = 'get_attachments'
  CurrentActionMsg  = 'Press E to knock on door and get Illegal attachments'
  CurrentActionData = {zone = zone}

end)

RegisterNetEvent('esx_attachments:giveAttachments')
AddEventHandler('esx_attachments:giveAttachments', function()
    local ped = GetPlayerPed(-1)
    GiveWeaponComponentToPed(ped, 0xD205520E, 0xC304849A) --Heavy Pistol Suppressor
    GiveWeaponComponentToPed(ped, 0xD205520E, 0x359B7AAE) --Heavy Pistol Flashlight
    GiveWeaponComponentToPed(ped, 0x1B06D571, 0x65EA7EBB) -- Pistol Suppressor
    GiveWeaponComponentToPed(ped, 0x13532244, 0xA73D4664) --SMG Suppressor Flashlight
    GiveWeaponComponentToPed(ped, 0xBFEFFF6D, 0xA73D4664) --Assault Suppressor 
    GiveWeaponComponentToPed(ped, 0xBFEFFF6D, 0x7BC4CDDC) --Assault Flaslight
    GiveWeaponComponentToPed(ped, 0xBFEFFF6D, 0x9D2FBF29) --Assault Scope 
    GiveWeaponComponentToPed(ped, 0x0A3D4D34, 0xAA2C45B4) --pdw Scope
    GiveWeaponComponentToPed(ped, 0x9D07F764, 0x82158B47) --mg mag
    GiveWeaponComponentToPed(ped, 0xAF113F99, 0x837445AA) --ADVANCED RIFLE SUPPRESSOR
    GiveWeaponComponentToPed(ped, 0xAF113F99, 0xAA2C45B4) --ADVANCED RIFLE SCOPE
    GiveWeaponComponentToPed(ped, 0x624FE830, 0x59FF9BF8) --COMPACT RIFLE extended
    GiveWeaponComponentToPed(ped, 0xBFEFFF6D, 0x4EAD7533) -- AK finish
    GiveWeaponComponentToPed(ped, 0x1B06D571, 0xD7391086) -- Pistol Suppressor
    GiveWeaponComponentToPed(ped, 0x13532244, 0x487AAE09) --SMG Suppressor Flashlight
    GiveWeaponComponentToPed(ped, 0x61012683, 0x4EAD7533) -- Gusenberg finish

    GiveWeaponComponentToPed(ped, 0xBFE256D4, 0x43FD595B) --Pistol MK2 flash
    GiveWeaponComponentToPed(ped, 0xBFE256D4, 0x8ED4BB70) --Pistol MK2 rail
    GiveWeaponComponentToPed(ped, 0xBFE256D4, 0x65EA7EBB) --Pistol MK2 supp
    --GiveWeaponComponentToPed(ped, 0xBFE256D4, 0x21E34793) --Pistol MK2 comp
    GiveWeaponComponentToPed(ped, 0xBFE256D4, 0x4D901310) --Pistol MK2 Camo
    SetPedWeaponTintIndex(ped,0xBFE256D4, 13) -- Assault Rifle MK2 Tint 

    GiveWeaponComponentToPed(ped, 0x78A97CD0, 0x4C24806E) --SMG MK2 Clip
    --GiveWeaponComponentToPed(ped, 0x78A97CD0, 0x7BC4CDDC) --SMG MK2 Flash
    GiveWeaponComponentToPed(ped, 0x78A97CD0, 0x9FDB5652) --SMG MK2 Sights
    GiveWeaponComponentToPed(ped, 0x78A97CD0, 0x4DB62ABE) --SMG MK2 Muzzel
    GiveWeaponComponentToPed(ped, 0x78A97CD0, 0x45C5C3C5) --SMG MK2 Camo
    SetPedWeaponTintIndex(ped,0x78A97CD0, 26) -- SMG MK2 Tint

    GiveWeaponComponentToPed(ped, 0x555AF99A, 0xF6446FE1) --Pump Shotgun MK2 Clip
    GiveWeaponComponentToPed(ped, 0x555AF99A, 0x420FD713) --Pump Shotgun MK2 Sight
    GiveWeaponComponentToPed(ped, 0x555AF99A, 0x7BC4CDDC) --Pump Shotgun MK2 Flash
    --GiveWeaponComponentToPed(ped, 0x555AF99A, 0x5F7DCE4D) --Pump Shotgun MK2 Muzzel
    GiveWeaponComponentToPed(ped, 0x555AF99A, 0x0085627D) --Pump Shotgun MK2 Camo
    SetPedWeaponTintIndex(ped,0x555AF99A, 23) -- Pump Shotgun MK2 Tint

    GiveWeaponComponentToPed(ped, 0x394F415C, 0x8610343F) --Assault Rifle MK2 Clip
    GiveWeaponComponentToPed(ped, 0x394F415C, 0x420FD713) --Assault Rifle MK2 Holo
    GiveWeaponComponentToPed(ped, 0x394F415C, 0x9D65907A) --Assault Rifle MK2 Grip
    GiveWeaponComponentToPed(ped, 0x394F415C, 0x7BC4CDDC) --Assault Rifle MK2 Flash
    GiveWeaponComponentToPed(ped, 0x394F415C, 0x2E7957A) --Assault Rifle MK2 Muzzel
    GiveWeaponComponentToPed(ped, 0x394F415C, 0xC5495F2D) --Assault Rifle MK2 Camo
    SetPedWeaponTintIndex(ped,0x394F415C, 23) -- Assault Rifle MK2 Tint
    --GiveWeaponComponentToPed(ped, 0x394F415C, 0x5646C26A) --Assault Rifle MK2 Heavy Barrel 0x833637FF

    --GiveWeaponComponentToPed(ped, 0xFAD1F1C9, 0x833637FF) -- Carbine Rifle MK2 Regular Barrel
    --GiveWeaponComponentToPed(ped, 0xFAD1F1C9, 0x8B3C480B) -- Carbine Rifle MK2 Heavy Barrel
    GiveWeaponComponentToPed(ped, 0x969C3D67, 0x16C69281) --Special Carbine Rifle MK2 Extended Clip
    GiveWeaponComponentToPed(ped, 0x969C3D67, 0x7BC4CDDC) --Special Carbine Rifle MK2 flash
    GiveWeaponComponentToPed(ped, 0x969C3D67, 0x420FD713) --Special Carbine Rifle MK2 Scope
    GiveWeaponComponentToPed(ped, 0x969C3D67, 0x347EF8AC) --Special Carbine Rifle MK2 Muzzel
    --GiveWeaponComponentToPed(ped, 0x969C3D67, 0xA73D4664) --Special Carbine Rifle MK2 Suppressor
    GiveWeaponComponentToPed(ped, 0x969C3D67, 0x9D65907A) --Special Carbine Rifle MK2 Grip
    GiveWeaponComponentToPed(ped, 0x969C3D67, 0x899CAF75) --Special Carbine Rifle MK2 Cammo
    SetPedWeaponTintIndex(ped,0x969C3D67, 26)

    --GiveWeaponComponentToPed(ped, 0xFAD1F1C9, 0x5DD5DBD5) -- Carbine Rifle MK2 Extended Clip
    GiveWeaponComponentToPed(ped, 0xFAD1F1C9, 0x9D65907A) --Carbine Rifle MK2 Grip
    GiveWeaponComponentToPed(ped, 0xFAD1F1C9, 0x7BC4CDDC) --Carbine Rifle MK2 Light
    GiveWeaponComponentToPed(ped, 0xFAD1F1C9, 0x420FD713) --Carbine Rifle MK2 Sights
    GiveWeaponComponentToPed(ped, 0xFAD1F1C9, 0x837445AA) --Carbine Rifle MK2 Suprresor
    GiveWeaponComponentToPed(ped, 0xFAD1F1C9, 0xD37D1F2F) --Carbine Rifle MK2 Cammo
    SetPedWeaponTintIndex(ped,0xFAD1F1C9, 23)
    --GiveWeaponComponentToPed(ped, 0xFAD1F1C9, 0xDA55CD3F) --Carbine Rifle MK2 Cammo MURICA

    GiveWeaponComponentToPed(ped, 0xDBBD7280, 0x9D65907A) --CombatMG MK2 Grip
    GiveWeaponComponentToPed(ped, 0xDBBD7280, 0x492B257C) --CombatMG MK2 Clip
    GiveWeaponComponentToPed(ped, 0xDBBD7280, 0x420FD713) --CombatMG MK2 Sight
    GiveWeaponComponentToPed(ped, 0xDBBD7280, 0xDE11CBCF) --CombatMG MK2 Muzzel 03, 05, 06
    GiveWeaponComponentToPed(ped, 0xDBBD7280, 0xD703C94D) --CombatMG MK2 Cammo
end)

RegisterNetEvent('esx_attachments:giveCopAttachments')
AddEventHandler('esx_attachments:giveCopAttachments', function()
  local ped = GetPlayerPed(-1)
	GiveWeaponComponentToPed(ped, 0x83BF0278, 0x7BC4CDDC) --Carbine Rifle Flashlight
	GiveWeaponComponentToPed(ped, 0x83BF0278, 0xC164F53) --Carbine Rifle Grip
	GiveWeaponComponentToPed(ped, 0x83BF0278, 0xA0D89C42) --Carbine Rifle Scope
	--GiveWeaponComponentToPed(ped, 0x83BF0278, 0x837445AA)  --Carbine Suppressor
	GiveWeaponComponentToPed(ped, 0x5EF9FEC4, 0x359B7AAE) --Combat Pistol Flashlight
	GiveWeaponComponentToPed(ped, 0xC0A3098D, 0xA73D4664) --SCarbine Rifle Suppressor
	GiveWeaponComponentToPed(ped, 0x5EF9FEC4, 0x359B7AAE) --Combat Pistol Flashlight
	GiveWeaponComponentToPed(ped, 0x1D073A89, 0x7BC4CDDC) --Pump Shotgun Flashlight
	GiveWeaponComponentToPed(ped, 0x2BE6766B, 0x7BC4CDDC) --SMG Flashlight 
	GiveWeaponComponentToPed(ped, 0x2BE6766B, 0xC304849A) --SMG Suppressor
	GiveWeaponComponentToPed(ped, 0x2BE6766B, 0x350966FB) --SMG Extended Mag  
	GiveWeaponComponentToPed(ped, 0x2BE6766B, 0x3CC6BA57) --SMG Scope  
	GiveWeaponComponentToPed(ped, 0x05FC3C11, 0xA73D4664) --Sniper Suppressor
	GiveWeaponComponentToPed(ped, 0x05FC3C11, 0xBC54da77) --Sniper Advance Scope

  GiveWeaponComponentToPed(ped, 0x555AF99A, 0x420FD713) --Pump Shotgun MK2 Sight
  GiveWeaponComponentToPed(ped, 0x555AF99A, 0x7BC4CDDC) --Pump Shotgun MK2 Flash

  GiveWeaponComponentToPed(ped, 0xFAD1F1C9, 0x9D65907A) --Carbine Rifle MK2 Grip
  GiveWeaponComponentToPed(ped, 0xFAD1F1C9, 0x7BC4CDDC) --Carbine Rifle MK2 Light
  GiveWeaponComponentToPed(ped, 0xFAD1F1C9, 0x420FD713) --Carbine Rifle MK2 Sights



end)

AddEventHandler('esx_moneylaundering:hasExitedMarker', function(zone)

  CurrentAction = nil

end)

-- Create Blips
Citizen.CreateThread(function()
  for k,v in pairs(Config.Zones) do
  if v.legal==0 then
    for i = 1, #v.Pos, 1 do
    local blip = AddBlipForCoord(v.Pos[i].x, v.Pos[i].y, v.Pos[i].z)
    SetBlipSprite (blip, 108)
    SetBlipDisplay(blip, 4)
    SetBlipScale  (blip, 1.0)
    SetBlipColour (blip, 1)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString('Money Laundering')
    EndTextCommandSetBlipName(blip)
    end
    end
  end
end)

-- Display Markers
Citizen.CreateThread(function()
  while true do
    Wait(0)
    local coords = GetEntityCoords(GetPlayerPed(-1))
    for k,v in pairs(Config.Zones) do
      for i = 1, #v.Pos, 1 do
        if(Config.Type ~= -1 and GetDistanceBetweenCoords(coords, v.Pos[i].x, v.Pos[i].y, v.Pos[i].z, true) < Config.DrawDistance) then
          DrawMarker(Config.Type, v.Pos[i].x, v.Pos[i].y, v.Pos[i].z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, Config.Size.x, Config.Size.y, Config.Size.z, Config.Color.r, Config.Color.g, Config.Color.b, 100, false, true, 2, false, false, false, false)
        end
      end
    end
  end
end)

-- Enter / Exit marker events
Citizen.CreateThread(function()
  while true do
    Wait(0)
    local coords      = GetEntityCoords(GetPlayerPed(-1))
    local isInMarker  = false
    local currentZone = nil

    for k,v in pairs(Config.Zones) do
      for i = 1, #v.Pos, 1 do
        if(GetDistanceBetweenCoords(coords, v.Pos[i].x, v.Pos[i].y, v.Pos[i].z, true) < Config.Size.x) then
          isInMarker  = true
          --ShopItems   = v.Items
          currentZone = k
          LastZone    = k
        end
      end
    end
    if isInMarker and not HasAlreadyEnteredMarker then
      HasAlreadyEnteredMarker = true
      TriggerEvent('esx_attachments:hasEnteredMarker', currentZone)
    end
    if not isInMarker and HasAlreadyEnteredMarker then
      HasAlreadyEnteredMarker = false
      TriggerEvent('esx_attachments:hasExitedMarker', LastZone)
    end
  end
end)


-- Key Controls
Citizen.CreateThread(function()
  while true do
    Citizen.Wait(0)
    if CurrentAction ~=nil then 
      SetTextComponentFormat('STRING')
      AddTextComponentString(CurrentActionMsg)
      DisplayHelpTextFromStringLabel(0, 0, 1, -1)
      if IsControlJustReleased(0, 38) then
        if CurrentAction == 'get_attachments' and Config.Zones[CurrentActionData.zone] then
          local ped = GetPlayerPed(-1)
     GiveWeaponComponentToPed(ped, 0xD205520E, 0xC304849A) --Heavy Pistol Suppressor
     GiveWeaponComponentToPed(ped, 0x1B06D571, 0x65EA7EBB) -- Pistol Suppressor
    GiveWeaponComponentToPed(ped, 0xD205520E, 0x359B7AAE) --Heavy Pistol Flashlight
    GiveWeaponComponentToPed(ped, 0x13532244, 0xA73D4664) --SMG Suppressor Flashlight
    GiveWeaponComponentToPed(ped, 0xBFEFFF6D, 0xA73D4664) --Assault Suppressor 
    GiveWeaponComponentToPed(ped, 0xBFEFFF6D, 0x7BC4CDDC) --Assault Flaslight
    GiveWeaponComponentToPed(ped, 0xBFEFFF6D, 0x9D2FBF29) --Assault Scope 
    GiveWeaponComponentToPed(ped, 0x0A3D4D34, 0xAA2C45B4) --pdw Scope
    GiveWeaponComponentToPed(ped, 0x9D07F764, 0x82158B47) --mg mag
    GiveWeaponComponentToPed(ped, 0xAF113F99, 0x837445AA) --ADVANCED RIFLE SUPPRESSOR
    GiveWeaponComponentToPed(ped, 0xAF113F99, 0xAA2C45B4) --ADVANCED RIFLE SCOPE
    GiveWeaponComponentToPed(ped, 0x624FE830, 0x59FF9BF8) --COMPACT RIFLE extended
        end
      CurrentAction = nil
      end
    end
  end
end)