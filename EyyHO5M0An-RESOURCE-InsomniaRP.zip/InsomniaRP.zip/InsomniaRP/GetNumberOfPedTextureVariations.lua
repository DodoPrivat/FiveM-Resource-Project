--- List of component/props ID
-- gtaxscripting.blogspot.com/2016/04/gta-v-peds-component-and-props.html
function Global.GetNumberOfPedTextureVariations(ped, componentId, drawableId)
	return _in(0x8F7156A3142A6BAD, ped, componentId, drawableId, _r, _ri)
end
