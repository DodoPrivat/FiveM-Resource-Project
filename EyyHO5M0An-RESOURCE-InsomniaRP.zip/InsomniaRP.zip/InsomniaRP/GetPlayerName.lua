function Global.GetPlayerName(player)
	return _in(0x6D0DE6A7B5DA71F8, player, _r, _s)
end
