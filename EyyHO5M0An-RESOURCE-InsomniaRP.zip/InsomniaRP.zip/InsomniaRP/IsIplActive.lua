--- List of all IPLs: pastebin.com/iNGLY32D
function Global.IsIplActive(iplName)
	return _in(0x88A741E44A2B3495, _ts(iplName), _r)
end
