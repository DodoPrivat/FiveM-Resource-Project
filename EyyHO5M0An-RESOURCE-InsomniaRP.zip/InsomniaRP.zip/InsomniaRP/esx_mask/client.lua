RegisterNetEvent('mask')
AddEventHandler('mask', function()
--[[
  Sets variables for if sunglasses are on and which sunglasses they are
]]--
  local player = GetPlayerPed(-1)
  local currentmasks = GetPedDrawableVariation(player, 1)
  if currentmasks == -1 and masksSet == false then
    nomasks = true
    masksSet = false
  elseif currentmasks ~= -1 and masksSet == false then
    mymasks = GetPedDrawableVariation(player, 1)
    masksTexture = GetPedTextureVariation(player, 1)
    nomasks = false
    masksSet = true
    masksOn = true
  elseif currentmasks == -1 and masksSet == true then
    masksOn = false
  elseif masksSet == true and currentMasks ~= -1 and myMasks ~= currentMasks then
    mymasks = GetPedDrawableVariation(player, 1)
    masksTexture = GetPedTextureVariation(player, 1)
    masksSet = true
    nomasks = false
    masksOn = true
  end
 
--Takes masks off / Puts them On
if not nomasks then
  masksOn = not masksOn
  if masksOn then
    SetPedComponentVariation(player, 1, mymasks, masksTexture, 2)
    ShowNotification('Masks are on')
  else
    SetPedComponentVariation(player, 1)
    ShowNotification('Masks are off')
  end
else
  ShowNotification('You are not wearing a mask')
end
 
end, false)
 
RegisterCommand('hat', function()
  TriggerEvent('hats')
end)
 
RegisterCommand('sg', function()
  TriggerEvent('sung')
end)
 
RegisterCommand('mask', function()
  TriggerEvent('mask')
end)
--Function to show the notification
 
function ShowNotification( text )
    SetNotificationTextEntry( "STRING" )
    AddTextComponentString( text )
    DrawNotification( false, false )
  end