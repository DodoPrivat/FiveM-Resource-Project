--- Returns whether the specified model exists in the game.
function Global.IsModelValid(model)
	return _in(0xC0296A2EDF545E92, _ch(model), _r)
end
