function Global.IsControlJustPressed(index, control)
	return _in(0x580417101DDB492F, index, control, _r)
end
