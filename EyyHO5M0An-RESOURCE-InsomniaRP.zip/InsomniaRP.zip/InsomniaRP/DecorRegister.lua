function Global.DecorRegister(propertyName, type)
	return _in(0x9FD90732F56403CE, _ts(propertyName), type)
end
