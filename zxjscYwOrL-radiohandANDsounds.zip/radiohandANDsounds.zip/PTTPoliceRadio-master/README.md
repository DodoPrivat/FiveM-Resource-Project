# PTTPoliceRadio
<br><br>
### NOTICE: This script is no longer supported, no further updates will be released.
<br><br>
This script toggles the police radio animation when the PTT key for your voice application is pushed.
<br>
A very special thank you to [IllusiveTea](https://github.com/IllusiveTea) for helping write this script.
## Controls
###### _Restricted to LEO's only or other peds specified._
#### **Talk on radio animation:**
###### Your voice application must have a PTT button mapped to this control.
`INPUT_CHARACTER_WHEEL (Left ALT by default)`
<br><br>
When aiming a weapon, player must release aim when activiating Left ALT and vice versa. Otherwise the animation will not play properly.
#### **Hold weapon holster animation:**
`INPUT_MULTIPLAYER_INFO (Z by default)`
#### **Holster/Unholster Pistol:**
When the Pistol is selected it will be removed from the weapon holster and vice versa.
## Optional Extras
Install the InteractSound folder into your resources along side PTTPoliceRadio and have mic clicks in-game! All credit for that resource goes to plunkettscott. https://github.com/plunkettscott/FiveM-Scripts
# NOTICE
This script is licensed under ["No License"](https://choosealicense.com/no-license/).
### You are allowed to:
Download, Use and Edit the Script.
<br>
### You are not allowed to:
Copy, re-release, re-distribute it without my written permission.
