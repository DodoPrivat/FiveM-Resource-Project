ESX                  = nil
local EndPoint       = 'http://127.0.0.1:30121'
local ClientEndPoint = 'http://51.15.206.83:30121'

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

function encodeURI(str)
  if (str) then
    str = string.gsub (str, "\n", "\r\n")
    str = string.gsub (str, "([^%w ])",
      function (c) return string.format ("%%%02X", string.byte(c)) end)
    str = string.gsub (str, " ", "+")
  end
  return str
end

function decodeURI(s)
  if(s) then
    s = string.gsub(s, '%%(%x%x)', function(hex)
      return string.char(tonumber(hex,16)) end )
  end
  return s
end

function GetFiles(identifier, cb)

	PerformHttpRequest(EndPoint .. '/getfiles/?identifier=' .. identifier, function(err, rText, headers)
		
    local files = json.decode(rText)
    local data  = {}
    local id    = string.gsub(identifier, ':', '_')

    for i=1, #files, 1 do
      table.insert(data, {name = files[i], url = ClientEndPoint .. '/ogg/' .. id .. '/' .. files[i]})
    end

    cb(data)

	end, "GET", "", {})

end

function Download(url, identifier, cb)

  PerformHttpRequest(EndPoint .. '/download/?identifier=' .. identifier .. '&url=' .. url, function(err, rText, headers)
    cb(json.decode(rText))
  end, "GET", "", {})

end

ESX.RegisterServerCallback('esx_bluetoothspeaker:getFiles', function(source, cb)
  local xPlayer = ESX.GetPlayerFromId(source)
  GetFiles(xPlayer.identifier, cb)
end)

ESX.RegisterServerCallback('esx_bluetoothspeaker:download', function(source, cb, url)
  local xPlayer = ESX.GetPlayerFromId(source)
  Download(url, xPlayer.identifier, cb)
end)