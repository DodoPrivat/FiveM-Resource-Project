'use strict';

let fs          = require('fs');
let express     = require('express');
let ytdl        = require('ytdl-core');
let ytvalidator = require('youtube-validator');
let ffmpeg      = require('fluent-ffmpeg');
let sanitize    = require('sanitize-filename');
let Url         = require('url');
let querystring = require('querystring');

function DownloadToOgg(url, folder, callback){

	url = url.replace('https://', 'http://');

	ytvalidator.validateUrl(url, function(res, err) {

		if(err){

			callback(err);
			return;

		} else {

			let query  = Url.parse(url).query;
			let parsed = querystring.parse(query);
			let id     = parsed.v;

			ytdl.getInfo(id, (err, info) => {
			  
			  if (err){
			  	callback(err);
			  	return
			  }

			  let title = sanitize(info.title);

			  console.error('Downloading ' + title);

				ytdl(url, {filter: 'audioonly'})
					.pipe(fs.createWriteStream(__dirname + '/tmp/' + title + '.mp4'))
					.on('finish', () => {

						ffmpeg(__dirname + '/tmp/' + title + '.mp4')
						 .audioCodec('libvorbis')
						 .audioBitrate(256)
						 .format('ogg')
						 .on('error', (err) => {
						 		callback(err)
						 	})
						 .on('end', () => {
						 	callback(null, title)
						 })
						 .pipe(fs.createWriteStream(folder + '/' + title + '.ogg'), {
						   end: true
						});

			  	}
			  );

			});

		}

	});

}

let app = express();

app.use('/ogg', express.static(__dirname + '/ogg'));

app.get('/getfiles', function(req, res){

	res.setHeader('Content-Type', 'application/json');

	let identifier = req.query.identifier.replace(':', '_');

	fs.readdir(__dirname + '/ogg/' + identifier, function(err, files){
		
		if(err){
			res.end('[]');
			return;
		}

		res.end(JSON.stringify(files));

	})

})

app.get('/download', function(req, res) {

	res.setHeader('Content-Type', 'application/json');

	let identifier = req.query.identifier.replace(':', '_');
	let url        = req.query.url

	function download(){

		DownloadToOgg(url, __dirname + '/ogg/' + identifier, (err, title) => {
			if(err){
				
				console.error(err);
				
				res.end(JSON.stringify({
					error: err
				}));

			} else {

				console.error('Finished');

				res.end(JSON.stringify({
					error: null,
					title: title
				}));

			}
		})

	}

	fs.access(__dirname + '/ogg/' + identifier, fs.constants.R_OK | fs.constants.W_OK, (err) => {
	 
		if(err){
			fs.mkdir(__dirname + '/ogg/' + identifier, () => {
				download()
			});
		} else {
			download()
		}

	});


});

app.listen(30121);