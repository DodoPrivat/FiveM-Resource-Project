Description "Enhanced clothes script for rp servers."

client_scripts {
    "ClothesOnOff.lua",
}