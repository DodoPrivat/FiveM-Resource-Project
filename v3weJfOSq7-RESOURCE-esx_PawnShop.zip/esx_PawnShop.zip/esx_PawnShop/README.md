# PAWN SHOP

### Installation
1) Drag & drop the folder into your `resources` server folder.
2) Configure the config file to your liking.
3) Add `start esx_PawnShop` to your server config.

### Showcase
- https://streamable.com/fza55