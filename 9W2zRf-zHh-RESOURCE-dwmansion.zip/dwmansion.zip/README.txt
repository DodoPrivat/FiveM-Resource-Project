Installation:
1. Drag the dwmansion folder into the resource folder of your FX Server folder.
2. Edit your server.cfg and add "start dwmansion" to the resource list.

All credit for the making of the map is to JP-Schindler.