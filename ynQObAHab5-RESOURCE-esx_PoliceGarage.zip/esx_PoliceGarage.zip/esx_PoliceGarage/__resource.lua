--------------------------------
------- Created by Hamza -------
-------------------------------- 

resource_manifest_version "44febabe-d386-4d18-afbe-5e627f4af937"

description 'ESX Police Garage'

client_scripts {
	"@es_extended/locale.lua",
	"locales/en.lua", 
    "config.lua",
    "client.lua"
}
