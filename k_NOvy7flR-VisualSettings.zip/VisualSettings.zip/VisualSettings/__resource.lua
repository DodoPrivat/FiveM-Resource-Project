files {
	'visualsettings.dat'
}

client_script 'client.lua'