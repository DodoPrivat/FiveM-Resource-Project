RegisterNetEvent('LootCrates:Sync')
AddEventHandler('LootCrates:Sync', function(crate)
  TriggerClientEvent('LootCrates:Synced',-1,crate)
end)

RegisterNetEvent('LootCrates:SyncFalling')
AddEventHandler('LootCrates:SyncFalling', function(crate)
  TriggerClientEvent('LootCrates:SyncedFalling',-1,crate)
end)

RegisterNetEvent('LootCrates:Delete')
AddEventHandler('LootCrates:Delete', function(crate)
  TriggerClientEvent('LootCrates:Delete',-1,crate)
end)

RegisterCommand('newCrate', function(source,args)
  local target = (args and args[1] or source)
  TriggerClientEvent('LootCrates:NewOnPlayer',target)
end,true)

RegisterCommand('randCrate', function(source,args)
  local target = (args and args[1] or source)
  TriggerClientEvent('LootCrates:NewRandom',target)
end,true)