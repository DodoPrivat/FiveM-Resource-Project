-- Found on: https://modit.store
-- ModFreakz Discord: https://discord.gg/4S7FcFs

-- Example of how to use, with commands:
/newcrate targetServerId (or none for self) - drops a loot crate at target player location.
/randcrate targetServerId (or none for self) - drops a loot crate one of the random locations listed in the client.lua