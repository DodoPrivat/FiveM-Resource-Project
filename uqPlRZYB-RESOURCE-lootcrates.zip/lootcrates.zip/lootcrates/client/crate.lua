local minItems = 2
local maxItems = 8

local minAmmo = 20
local maxAmmo = 250

local baseTime = 5000
local timeStep = 1000

local chuteModel = 'p_cargo_chute_s'
local boxModels  = {
  [1] = 'hei_prop_carrier_cargo_03a',
  [2] = 'hei_prop_carrier_cargo_04a',
  [3] = 'hei_prop_carrier_cargo_05a',
}

local weaponTiers = {
  [1] = {"weapon_pistol"},
  [2] = {"weapon_pistol50"},
  [3] = {"weapon_smg"},
  [4] = {"weapon_assaultrifle"},
}

local dropPositions = {
  [1] = vector3(111.11,111.11,111.11),
  [2] = vector3(111.11,111.11,111.11),
  [3] = vector3(111.11,111.11,111.11),
  [4] = vector3(111.11,111.11,111.11),
}

local vowels = {
  ['a'] = true,
  ['e'] = true,
  ['i'] = true,
  ['o'] = true,
  ['u'] = true,
}
for k,v in pairs(vowels) do vowels[k:upper()] = true; end

local chuteHash = GetHashKey(chuteModel)
local modelHash = {}

local crates = {}

for k=2,#weaponTiers,1 do
  local tierBelow = weaponTiers[k-1]
  local v = weaponTiers[k]
  for _,weapon in pairs(tierBelow) do
    table.insert(v,weapon)
  end
end 

modelHash[chuteModel] = GetHashKey(chuteModel)
for k,v in pairs(boxModels) do
  modelHash[v] = GetHashKey(v)
end

GetWeaponLabel = function(weaponName)
  weaponName = string.upper(weaponName)
  local weapons = Config.Weapons

  for i=1, #weapons, 1 do
    if weapons[i].name == weaponName then
      return weapons[i].label
    end
  end
end

NewItem = function(tier)
  local weapons = weaponTiers[tier]
  return weapons[math.random(#weapons)]
end

NewLoot = function(tier)
  local goodieCount = math.random(minItems,maxItems)
  local loot = {}
  for i=1,goodieCount,1 do
    local item = NewItem(tier)
    if not loot[item] then
      loot[item] = math.random(minAmmo,maxAmmo)
    end
  end
  return loot
end

NewCrate = function(pos,tier)
  local crateTier = (tier or math.random(#weaponTiers))
  if crateTier <= 0 then crateTier = 1 elseif crateTier > #weaponTiers then crateTier = #weaponTiers; end
  local model = boxModels[math.random(#boxModels)]
  local loot  = NewLoot(crateTier)
  local dimMin,dimMax = GetModelDimensions(model)
  return {
    pos     = pos,
    model   = model,
    dimsMin = dimMin,
    dimsMax = dimMax,
    loot    = loot,
    tier    = crateTier,
    ground  = false,
  }
end

RandomCrate = function()
  local dropPosition = dropPositions[math.random(#dropPositions)]
  local tier = math.random(#weaponTiers)
  return NewCrate(dropPosition,tier)
end

LoadModels = function(models)
  for k,v in pairs(models) do
    RequestModel(v)
    while not HasModelLoaded(v) do RequestModel(v); Wait(0); end
  end
end

UnloadModels = function(models)
  for k,v in pairs(models) do
    SetModelAsNoLongerNeeded(v)
  end
end

NetworkObjects = function(objects)
  for k,v in pairs(objects) do
    while not NetworkGetEntityIsNetworked(v) do
      NetworkRegisterEntityAsNetworked(v)
      Wait(0)
    end
  end
end

MissionEntities = function(entities)
  for k,v in pairs(entities) do
    SetEntityAsMissionEntity(v,true,true)
  end
end

NetworkId = function(entity)
  return NetworkGetNetworkIdFromEntity(entity)
end

SpawnCrate = function(crate)
  LoadModels({modelHash[crate.model],modelHash[chuteModel]})

  local pos = crate.pos
  local chuteObj = CreateObject(modelHash[chuteModel], pos.x,pos.y,pos.z + 55.0, true,true,true)
  local crateObj = CreateObject(modelHash[crate.model],pos.x,pos.y,pos.z + 55.0, true,true,true)

  local min,max = GetModelDimensions(modelHash[crate.model])
  AttachEntityToEntity(chuteObj,crateObj, 0, 0.0,0.0,max.z, 0.0,0.0,0.0, false,true,true,false,0,false)

  MissionEntities({chuteObj,crateObj})
  NetworkObjects({chuteObj,crateObj})
  UnloadModels({modelHash[crate.model],modelHash[chuteModel]})

  crate.crateObj = NetworkId(crateObj)
  crate.chuteObj = NetworkId(chuteObj)

  TriggerServerEvent('LootCrates:SyncFalling',crate)

  CrateFalling(crate)
end

MakeBlip = function(pos)
  print("Making blip")
  local blip = AddBlipForCoord(pos.x,pos.y,pos.z)
  SetBlipSprite(blip,568)
  SetBlipDisplay(blip,2)
  SetBlipScale(blip,1.0)
  SetBlipColour(blip,5)
  SetBlipDisplay(blip,4)
  SetBlipAsShortRange(blip,true)
  SetBlipHighDetail(blip,true)
  BeginTextCommandSetBlipName("STRING")
  AddTextComponentString('Loot Crate')
  EndTextCommandSetBlipName(blip)

  return blip
end

CrateFalling = function(crate)
  Citizen.CreateThread(function() 
    local grounded = false
    while not grounded do
      local crateObj = NetworkGetEntityFromNetworkId(crate.crateObj)
      local pos = GetEntityCoords(NetworkGetEntityFromNetworkId(crate.crateObj))

      SetEntityCoords(crateObj, pos.x,pos.y,pos.z-0.02)

      grounded = (pos.z <= crate.pos.z)
      Wait(0)
    end
    local crateObj = NetworkGetEntityFromNetworkId(crate.crateObj)
    local chuteObj = NetworkGetEntityFromNetworkId(crate.chuteObj)
    PlaceObjectOnGroundProperly(crateObj)
    DeleteObject(chuteObj)
    crate.ground = true
    TriggerServerEvent('LootCrates:Sync',crate)
  end)
end

GetClosestCrate = function()
  local closest,closestDist
  local plyPos = GetEntityCoords(GetPlayerPed(-1))
  for k,v in pairs(crates) do
    if v.ground then
      local dist = Vdist(plyPos,v.pos)
      if not closestDist or dist < closestDist then
        closest = k
        closestDist = dist
      end
    end
  end
  return (closest or false),(closestDist or 9999)
end

IsVowel = function(str)
  return vowels[str:sub(1,1)]
end

Update = function()
  local keyPressed = false
  while true do
    local closest,dist = GetClosestCrate()
    local plyPed = GetPlayerPed(-1)

    if closest then
      local maxDist = crates[closest].dimsMax.x
      if crates[closest].dimsMax.y > maxDist then maxDist = crates[closest].dimsMax.y; end
      if crates[closest].dimsMax.z > maxDist then maxDist = crates[closest].dimsMax.z; end

      if dist < maxDist + 1.0 then
        if IsControlJustPressed(0, 38) then
          keyPressed = GetGameTimer()
          exports["progbars"]:StartProg(baseTime+(crates[closest].tier*timeStep)-300,"Opening Crate")
          TaskStartScenarioInPlace(plyPed, "PROP_HUMAN_BUM_BIN", 0, true)
        elseif IsControlPressed(0, 38) then
          if keyPressed then
            ShowHelp("Keep holding ~INPUT_PICKUP~ to open the crate.")
            if (GetGameTimer() - keyPressed) > (baseTime+(crates[closest].tier*timeStep) - 100) then
              exports["progbars"]:CloseProg()
              TaskStartScenarioInPlace(plyPed, "PROP_HUMAN_BUM_BIN", 0, false)
              Wait(math.random(1000,2000))
              ClearPedTasksImmediately(plyPed)

              if closest and crates and crates[closest] and crates[closest].crateObj and NetworkDoesEntityExistWithNetworkId(crates[closest].crateObj) and DoesEntityExist(NetworkGetEntityFromNetworkId(crates[closest].crateObj)) then
                TriggerServerEvent('LootCrates:Delete',crates[closest])
                DeleteObject(NetworkGetEntityFromNetworkId(crates[closest].crateObj))
                ShowNotification("You broke open the loot crate (Tier: "..crates[closest].tier..")")  
                for k,v in pairs(crates[closest].loot) do
                  local label = GetWeaponLabel(k)
                  ShowNotification("You received "..(IsVowel(label) and "an " or "a ")..label.." with "..v.." ammo.")                  
                  GiveWeaponToPed(plyPed, GetHashKey(k), v, true, false)
                end               
                RemoveBlip(crates[closest].blip)
                crates[closest] = nil           
              end

              keyPressed = false
            end
          end
        elseif IsControlJustReleased(0, 38) then
          if keyPressed then
            keyPressed = false
            exports["progbars"]:CloseProg()
            TaskStartScenarioInPlace(plyPed, "PROP_HUMAN_BUM_BIN", 0, false)
            Wait(1500)
            ClearPedTasksImmediately(plyPed)
          end  
        else
          ShowHelp("Hold ~INPUT_PICKUP~ to open the crate.")    
        end
      else
        if keyPressed then
          keyPressed = false
          exports["progbars"]:CloseProg()
          TaskStartScenarioInPlace(plyPed, "PROP_HUMAN_BUM_BIN", 0, false)
          Wait(1500)
          ClearPedTasksImmediately(plyPed)
        end
      end
    else
      if keyPressed then
        keyPressed = false
        exports["progbars"]:CloseProg()
        TaskStartScenarioInPlace(plyPed, "PROP_HUMAN_BUM_BIN", 0, false)
        Wait(1500)
        ClearPedTasksImmediately(plyPed)
      end      
    end
    Wait(0)
  end
end

ShowHelp = function(msg)
  AddTextEntry('LootCrates:ShowHelp', msg)
  BeginTextCommandDisplayHelp('LootCrates:ShowHelp')
  EndTextCommandDisplayHelp(0, false, true, -1)
end

ShowNotification = function(msg)
  AddTextEntry('LootCrates:ShowNotification', msg)
  SetNotificationTextEntry('LootCrates:ShowNotification')
  DrawNotification(false, true)
end

Vdist = function(v1,v2)
  if not v1 or not v2 or not v1.x or not v2.x then return 0; end
  return math.sqrt(  ( (v1.x or 0) - (v2.x or 0) )*(  (v1.x or 0) - (v2.x or 0) )+( (v1.y or 0) - (v2.y or 0) )*( (v1.y or 0) - (v2.y or 0) )+( (v1.z or 0) - (v2.z or 0) )*( (v1.z or 0) - (v2.z or 0) )  )
end

Event = function(e,h,n)
  if n then RegisterNetEvent(e); end
  AddEventHandler(e,h)
end

Synced = function(crate)
  for k,v in pairs(crates) do
    if v.crateObj == crate.crateObj then
      local blip = v.blip
      crates[k] = crate
      crates[k].blip = blip
      return
    end
  end
  table.insert(crates,crate)
end

SyncedFalling = function(crate)
  crate.blip = MakeBlip(crate.pos)
  table.insert(crates,crate)
end

Delete = function(crate)
  for k,v in pairs(crates) do
    if v.crateObj == crate.crateObj then
      if NetworkDoesEntityExistWithNetworkId(crate.crateObj) and DoesEntityExist(NetworkGetEntityFromNetworkId(crate.crateObj)) then
        local ent = NetworkGetEntityFromNetworkId(crate.crateObj)
        NetworkRequestControlOfEntity(ent)
        while not NetworkHasControlOfEntity(ent) do NetworkRequestControlOfEntity(ent); Wait(0); end
        SetEntityAsMissionEntity(ent,true,true)
        DeleteEntity(ent)
      end              
      RemoveBlip(crates[k].blip)
      for key,val in pairs(crates[k]) do crates[k][key] = nil; end
      crates[k] = nil
    end
  end
end

NewOnPlayer = function() 
  local crate = NewCrate(GetEntityCoords(GetPlayerPed(-1)) - vector3(0.0,0.0,1.0))
  SpawnCrate(crate)
end

NewRandom = function() 
  local crate = RandomCrate()
  SpawnCrate(crate)
end

Event('LootCrates:Synced',Synced,1)
Event('LootCrates:SyncedFalling',SyncedFalling,1)
Event('LootCrates:Delete',Delete,1)

Event('LootCrates:NewOnPlayer',NewOnPlayer,1)
Event('LootCrates:NewRandom',NewRandom,1)

Citizen.CreateThread(Update)