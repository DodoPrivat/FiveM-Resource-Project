# T1GER DRUGS

### Requirements
- start progressBars                          
- start mhacking
- start t1ger_drugs

- https://github.com/Hamza8700/fivem_scripts
- You can also get InventoryHUD pictures for all the items on my gitHub

### Installation
1) Drag & drop the folder into your `resources` server folder.
2) Configure the config file to your liking.
3) Import items.sql into your database
4) Add `start t1ger_drugs` to your server config.

### Showcase
- https://streamable.com/sx9li