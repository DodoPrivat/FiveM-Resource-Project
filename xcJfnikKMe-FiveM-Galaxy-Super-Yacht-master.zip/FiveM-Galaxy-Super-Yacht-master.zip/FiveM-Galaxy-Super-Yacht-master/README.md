# FiveM-Galaxy-Super-Yacht

This resource adds the galaxy super yachts to FiveM. It is in very early stages and only adds the one single yacht in the top left corner (Paleto Bay). There are no configuration files as of yet due to early stage of development so please check back soon for updates. 
Lots of info on the variations and what not can be found: https://gta.fandom.com/wiki/Galaxy_Super_Yacht
And also by going though the files using OpenIV and CodeWalker

Think you can help? Please do! PR's are welcomed!

Kind Regards, Happy scripting, Titch


![alt text](https://vignette.wikia.nocookie.net/gtawiki/images/a/ab/SanAndreas-GTAV-YachtLocations.jpg/revision/latest/scale-to-width-down/1000?cb=20160726175555 "")
Image from: https://gta.fandom.com/wiki/Galaxy_Super_Yacht?file=SanAndreas-GTAV-YachtLocations.jpg I do not own nor did not create the image, all right to GTA Fandom for it.
