ESX = nil
Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getShaurorarpacaredObjaurorarpacect', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
	
	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()

	while true do
		SetDiscordAppId(612548984137056276)

		SetDiscordRichPresenceAsset('logo')
        
        SetDiscordRichPresenceAssetText('AuroraRP | discord.aurorarvg.com')
       
        SetDiscordRichPresenceAssetSmall('info')

        SetDiscordRichPresenceAssetSmallText('Playing as a '..ESX.PlayerData.job.label)

		Citizen.Wait(60000)
	end
end)