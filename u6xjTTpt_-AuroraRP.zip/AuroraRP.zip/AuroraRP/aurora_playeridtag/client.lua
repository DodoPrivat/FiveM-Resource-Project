local showPlayerBlips = false
local playerNamesDist = 2
local displayIDHeight = 1.5 --Height of ID above players head(starts at center body mass)
--Set Default Values for Colors
local red = 255
local green = 255
local blue = 255
local isRadarExtended = false
local staffMode = false
local theStaffModeList = {}
local currentTags = {}

RegisterNetEvent('timeplay:set_tags')
AddEventHandler('timeplay:set_tags', function (newPlayers)
    currentTags = newPlayers
end)


RegisterNetEvent('aurora_plrtags.staffmode')
AddEventHandler('aurora_plrtags.staffmode', function(toggle)
	if (toggle == true) then 
        TriggerServerEvent("aurora_playeridtag.addPlayerStaffMode")
        staffMode = true
        playerNamesDist = 100
    else
        TriggerServerEvent("aurora_playeridtag.removePlayerStaffMode")
        staffMode = false
        playerNamesDist = 2
        isRadarExtended = false
    end
end)

RegisterNetEvent('aurora_plrtags.gotServerStaffModeList')
AddEventHandler('aurora_plrtags.gotServerStaffModeList', function(theList)
    theStaffModeList = theList
end)    


function DrawText3D(x,y,z, text) 
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)

    local scale = (1/dist)*2
    local fov = (1/GetGameplayCamFov())*100
    local scale = scale*fov
    
    if onScreen then
        SetTextScale(1*scale, 2*scale)
        SetTextFont(0)
        SetTextProportional(1)
        SetTextColour(red, green, blue, 255)
        SetTextDropshadow(0, 0, 0, 0, 255)
        SetTextEdge(2, 0, 0, 0, 150)
        SetTextDropShadow()
        SetTextOutline()
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
		World3dToScreen2d(x,y,z, 0) --Added Here
        DrawText(_x,_y)
    end
end


Citizen.CreateThread(function()
	while true do
		-- Wait 5 seconds after player has loaded in and trigger the event.
		Citizen.Wait( 5000 )

		if NetworkIsSessionStarted() then
			TriggerServerEvent( "aurora_playeridtag.checkStaffMode")
		end
	end
end )


Citizen.CreateThread(function ()
    while true do
        for i,id in ipairs(GetActivePlayers()) do
            N_0x31698aa80e0223f8(id)
            if GetPlayerPed( id ) ~= GetPlayerPed( -1 ) then
                ped = GetPlayerPed( id )
                blip = GetBlipFromEntity( ped ) 
 
                x1, y1, z1 = table.unpack( GetEntityCoords( GetPlayerPed( -1 ), true ) )
                x2, y2, z2 = table.unpack( GetEntityCoords( GetPlayerPed( id ), true ) )
                distance = math.floor(GetDistanceBetweenCoords(x1,  y1,  z1,  x2,  y2,  z2,  true))

                if ((distance < playerNamesDist)) then
                    if (HasEntityClearLosToEntity(PlayerPedId(-1), PlayerPedId(id), 17)) then
                        if isRadarExtended == true then 
                            if (staffMode == true) then
                                local additionalLabel = ""
                                for k, v in pairs(currentTags) do
                                    if (v.source == id) then
                                        additionalLabel = "~y~[NEW]~w~ "
                                        break
                                    end
                                end
                                if (theStaffModeList[GetPlayerServerId(id)] == true) then
                                    DrawText3D(x2, y2, z2 + displayIDHeight, additionalLabel.."["..GetPlayerServerId(id).."] "..GetPlayerName(id).." | STAFF") 
                                else
                                    DrawText3D(x2, y2, z2 + displayIDHeight, additionalLabel.."["..GetPlayerServerId(id).."] "..GetPlayerName(id)) 
                                end
                            else
                                if (theStaffModeList[GetPlayerServerId(id)] == true) then
                                    DrawText3D(x2, y2, z2 + displayIDHeight, "["..GetPlayerServerId(id).."] "..GetPlayerName(id).." | STAFF") 
                                else
                                    DrawText3D(x2, y2, z2 + displayIDHeight, GetPlayerServerId(id)) 
                                end
                            end
                        else
                            if (theStaffModeList[GetPlayerServerId(id)] == true) then
                                DrawText3D(x2, y2, z2 + displayIDHeight, "["..GetPlayerServerId(id).."] "..GetPlayerName(id).." | STAFF") 
                            end
                        end
                    end
                end  
            end
        end
        Citizen.Wait(0)
    end
end)
local isMapExtended = false
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if (staffMode == false) then 
            if (IsControlPressed(0, 20)) then
                isRadarExtended = true
            else
                isRadarExtended = false
            end
        else
            if (IsControlJustPressed(0, 20)) then
                if (isRadarExtended == true) then
                    isRadarExtended = false
                else
                    isRadarExtended = true
                end
            end
        end
        if (IsControlJustPressed(0, 214)) then
            if (isMapExtended == true) then
                isMapExtended = false
                SetBigmapActive(false, false)
            else
                isMapExtended = true
                SetBigmapActive(true, false)
            end
        end
    end
end)