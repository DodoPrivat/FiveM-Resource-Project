Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableJobBlip              = true --enable blips for colleagues, requiers esx_identity
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.MafiaStations = {

  Yakuza = {

    Blip = {
      Pos     = { x = 425.130, y = -979.558, z = 30.711 },
      Sprite  = 60,
      Display = 4,
      Scale   = 1.2,
      Colour  = 29,
    },

    AuthorizedWeapons = {
      { name = 'weapon_machete',     price = 2000 },
      { name = 'weapon_revolver',       price = 10000 },
      { name = 'weapon_pumpshotgun',      price = 20000 },
      { name = 'weapon_assaultrifle',      price = 30000 },
      { name = 'weapon_microsmg',      price = 20000 },
      { name = 'weapon_molotov',      price = 5000 },
      { name = 'weapon_heavysniper',      price = 70000 },
	  { name = 'weapon_stickybomb',      price = 50000 },
	  { name = 'weapon_rpg',      price = 100000 },
	 
      
    },

	  AuthorizedVehicles = {
		  { name = 'barrage',  label = 'Barrage' },
		  { name = 'technical',  label = 'Technical' },
		  { name = 'technical2',  label = 'Technical2' },
		  { name = 'sanchez',  label = 'Sanchez' },
		  { name = 'rumpo3',  label = 'Rumpo3' },
	  },

    Cloakrooms = {
      --{ x = 9.283, y = 528.914, z = 169.635 },
    },

    Armories = {
      { x = -1133.06, y = 4948.34, z = 221.27 },
    },

    Vehicles = {
      {
        Spawner    = { x = -1094.81, y = 4905.77, z = 214.07 },
        SpawnPoint = { x = -1091.55, y = 4914.97, z = 215.12 },
        Heading    = 240.93,
      }
    },
	
	Helicopters = {
      {
        Spawner    = { x = -1154.55, y = 4897.4, z = 223.69 },
        SpawnPoint = { x = -1150.86, y = 4923.88, z = 220.42 },
        Heading    = 68.43,
      }
    },

    VehicleDeleters = {
      { x = -1079.4, y = 4920.84, z = 212.89 },
    },

    BossActions = {
      { x = -1132.51, y = 4953.82, z = 221.27 },
    },

  },

}
