ESX = nil
group = "user"

RegisterNetEvent('es_admin:setGroup')
AddEventHandler('es_admin:setGroup', function(g)
    group = g
end)

RegisterCommand('getobj', function (source, args, rawCommand)
    print (GetEntityModel(args[1]))
end, false)

local display = false
local displayed = false

local loaded = false

RegisterNetEvent('aurora_admin:setskin')
AddEventHandler('aurora_admin:setskin', function(skin)
    Citizen.CreateThread(function()
        local model = GetHashKey(skin)
        RequestModel(model)
        while not HasModelLoaded(model) do
            RequestModel(model)
            Citizen.Wait(0)
        end
        SetPlayerModel(PlayerId(), model)
        SetPedComponentVariation(GetPlayerPed(-1), 0, 0, 0, 2)
    end)
end)

RegisterNetEvent('aurora_admin:on')
AddEventHandler('aurora_admin:on', function(steamIDz)
    local _source = source
    local steamID = string.gsub(steamIDz, "steam:", "")
    if (loaded == true) then
        SendNUIMessage({
            type = "ui",
            display = true,
            loadedz = true
        })
    else
        SendNUIMessage({
            type = "ui",
            display = true,
            steamid = steamID,
            loadedz = false
        })
        loaded = true
    end
    displayed = true
    SetNuiFocus(true, true)
end)

RegisterNetEvent('aurora_admin:off')
AddEventHandler('aurora_admin:off', function()
    SendNUIMessage({
        type = "ui",
        display = false
    })
    displayed = false
    SetNuiFocus(false, false)
end)

RegisterNUICallback('close', function(data, cb)
	SendNUIMessage({
        type = "ui",
        display = false
    })
    displayed = false
    SetNuiFocus(false, false)
    cb('ok')
end)


--[[Citizen.CreateThread( function()
	SetNuiFocus( false )

	while true do 
	    if ( displayed == true ) then
            local ped = GetPlayerPed( -1 )	

            DisableControlAction( 0, 1, true )
            DisableControlAction( 0, 2, true )
            DisableControlAction( 0, 24, true )
            DisablePlayerFiring( ped, true )
            DisableControlAction( 0, 142, true )
            DisableControlAction( 0, 106, true ) 
        end

        if group ~= "user" then
            if IsControlJustPressed(1, 97) and GetLastInputMethod( 0 ) then
                if (displayed == true) then 
                    TriggerEvent("aurora_admin:off", true)
                else
                    TriggerServerEvent('aurora_staff:getIdentAndOpen')
                end
            end
        end
		Citizen.Wait( 0 )
	end 
end )]]--

ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getShaurorarpacaredObjaurorarpacect', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end

    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end

    PlayerData = ESX.GetPlayerData() 
end)


local blipsCops = {}

function createBlip(id)
    local ped = GetPlayerPed(id)
    local blip = GetBlipFromEntity(ped)

    if not DoesBlipExist(blip) then -- Add blip and create head display on player
        blip = AddBlipForEntity(ped)
        SetBlipSprite(blip, 1)
        ShowHeadingIndicatorOnBlip(blip, true) -- Player Blip indicator
        SetBlipRotation(blip, math.ceil(GetEntityHeading(ped))) -- update rotation
        SetBlipNameToPlayerName(blip, id) -- update blip name
        SetBlipScale(blip, 0.85) -- set scale
        SetBlipAsShortRange(blip, true)

        table.insert(blipsCops, blip) -- add blip to array so we can remove it later
    end
end


function toggleBlips (toggle)
    if (toggle == true) then
        for k, existingBlip in pairs(blipsCops) do
            RemoveBlip(existingBlip)
        end

        blipsCops = {}
        for z,id in ipairs(GetActivePlayers()) do
            if NetworkIsPlayerActive(id) and GetPlayerPed(id) ~= PlayerPedId() then
                createBlip(id)
            end
        end
    else
        for k, existingBlip in pairs(blipsCops) do
            RemoveBlip(existingBlip)
        end

        blipsCops = {}
    end
end
local isGodModeEnabled = false

RegisterNetEvent('esx_policejob:updateBlip')
AddEventHandler('esx_policejob:updateBlip', function()
    if (isGodModeEnabled == true) then 
        for k, existingBlip in pairs(blipsCops) do
            RemoveBlip(existingBlip)
        end
        blipsCops = {}

        
        for z,id in ipairs(GetActivePlayers()) do
            if NetworkIsPlayerActive(id) and GetPlayerPed(id) ~= PlayerPedId() then
                createBlip(id)
            end
        end
    end
end)

local isInviEnabled = false
RegisterNetEvent('aurora_admin:toggleInvi')
AddEventHandler('aurora_admin:toggleInvi', function()
    if (isInviEnabled == false) then 
        SetEntityVisible(GetPlayerPed(-1), false)
        SetEntityVisible(GetPlayerPed(-1), true)
        TriggerEvent("pNotify:SendNotification", {
            text = "Invisible Mode On",
            type = "success",
            timeout = 5000,
            layout = "topCenter"
        })
        isInviEnabled = true
    else
        SetEntityVisible(GetPlayerPed(-1), true)
        TriggerEvent("pNotify:SendNotification", {
            text = "Invisible Mode Off",
            type = "success",
            timeout = 5000,
            layout = "topCenter"
        })
        isInviEnabled = false
    end
end)


RegisterNetEvent('aurora_admin:toggleMode')
AddEventHandler('aurora_admin:toggleMode', function()
    if (isGodModeEnabled == false) then 
        SetEntityInvincible(GetPlayerPed(-1), true)
        SetPlayerInvincible(PlayerId(), true)
        SetPedCanRagdoll(GetPlayerPed(-1), false)
        ClearPedBloodDamage(GetPlayerPed(-1))
        ResetPedVisibleDamage(GetPlayerPed(-1))
        ClearPedLastWeaponDamage(GetPlayerPed(-1))
        SetEntityProofs(GetPlayerPed(-1), true, true, true, true, true, true, true, true)
        SetEntityOnlyDamagedByPlayer(GetPlayerPed(-1), false)
        SetEntityCanBeDamaged(GetPlayerPed(-1), false)
        TriggerEvent("pNotify:SendNotification", {
            text = "Staff Mode On",
            type = "success",
            timeout = 5000,
            layout = "topCenter"
        })
        TriggerEvent("aurora_plrtags.staffmode", true)
        toggleBlips (true)
        isGodModeEnabled = true
    else
        SetEntityInvincible(GetPlayerPed(-1), false)
        SetPlayerInvincible(PlayerId(), false)
        SetPedCanRagdoll(GetPlayerPed(-1), true)
        ClearPedLastWeaponDamage(GetPlayerPed(-1))
        SetEntityProofs(GetPlayerPed(-1), false, false, false, false, false, false, false, false)
        SetEntityOnlyDamagedByPlayer(GetPlayerPed(-1), true)
        SetEntityCanBeDamaged(GetPlayerPed(-1), true)
        TriggerEvent("pNotify:SendNotification", {
            text = "Staff Mode Off",
            type = "success",
            timeout = 5000,
            layout = "topCenter"
        })
        TriggerEvent("aurora_plrtags.staffmode", false)
        toggleBlips (false)
        isGodModeEnabled = false
    end
end)

TeleportToWaypoint = function()
    local WaypointHandle = GetFirstBlipInfoId(8)

    if DoesBlipExist(WaypointHandle) then
        local waypointCoords = GetBlipInfoIdCoord(WaypointHandle)

        for height = 1, 1000 do
            SetPedCoordsKeepVehicle(PlayerPedId(), waypointCoords["x"], waypointCoords["y"], height + 0.0)

            local foundGround, zPos = GetGroundZFor_3dCoord(waypointCoords["x"], waypointCoords["y"], height + 0.0)

            if foundGround then
                SetPedCoordsKeepVehicle(PlayerPedId(), waypointCoords["x"], waypointCoords["y"], height + 0.0)

                break
            end

            Citizen.Wait(5)
        end

        ESX.ShowNotification("Teleported.")
    else
        ESX.ShowNotification("Please place your waypoint.")
    end
end


RegisterNetEvent('aurora_admin:tpWaypoint')
AddEventHandler('aurora_admin:tpWaypoint', function()
    TeleportToWaypoint()
end)
