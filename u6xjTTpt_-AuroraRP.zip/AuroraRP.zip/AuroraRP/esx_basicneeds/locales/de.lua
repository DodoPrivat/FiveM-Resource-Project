Locales['de'] = {

	['used_bread'] = 'Du hast 1x Brot gegessen',
	['used_water'] = 'Du hast 1x Wasser getrunken',

}
