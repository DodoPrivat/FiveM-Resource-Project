Config                            = {}

Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 0.5 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }

Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- enable if you're using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableLicenses             = true -- enable if you're using esx_license

Config.EnableHandcuffTimer        = true -- enable handcuff timer? will unrestrain player after the time ends
Config.HandcuffTimer              = 10 * 60000 -- 10 mins

Config.EnableJobBlip              = true -- enable blips for colleagues, requires esx_society

Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.PoliceStations = {

	MilitaryBase = {

		Blip = {
			Coords  = vector3(-2357.63, 2354.73, 32.81),
			Sprite  = 60,
			Display = 4,
			Scale   = 1.2,
			Colour  = 29
		},

		Cloakrooms = {
			vector3(-2350.08, 3262.48, 32.81 )
		},

		Armories = {
			vector3(-2358.26, 3255.19, 32.81 )
		},

		Vehicles = {
			{
				Spawner = vector3(-2305.32, 3185.68, 32.81),
				InsideShop = vector3(-2189.28, 3275.81, 32.81),
				SpawnPoints = {
					{ coords = vector3(-2317.12, 3184.67, 32.82), heading = 59.12, radius = 6.0 },
					{ coords = vector3(-2193.93, 3305.72, 32.81), heading = 186.56, radius = 6.0 },
					{ coords = vector3(-2187.41, 3306.13, 32.81), heading = 186.56, radius = 6.0 },
				}
			},

			{
				Spawner = vector3(-2030.04, 3233.15, 32.81),
				InsideShop = vector3(-2041.08, 3226.65, 32.81),
				SpawnPoints = {
					{ coords = vector3(-2038.56, 3232.53, 32.81), heading = 61.71, radius = 6.0 },
				}
			}
		},

		Helicopters = {
			{
				Spawner = vector3(-2353.95, 3202.44, 32.83),
				InsideShop = vector3(-2188.0, 3170.59, 32.81),
				SpawnPoints = {
					{ coords = vector3(-2361.19, 3185.76, 32.83), heading = 147.89, radius = 10.0 }
				}
			}
		},

		BossActions = {
			vector3(-2360.44, 3244.05, 92.9)
		}

	}

}

Config.AuthorizedWeapons = {
	trainee = {
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
	},
	
	private = {
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
	},

	privatefirstclass = {
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
	},
	
	corporal = {
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
	},

	sergeant = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
	},
	
	staffsergeant = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
	},
	
	techsergeant = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
	},
	
	mastersergeant = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 1 },
		{ weapon = 'WEAPON_COMBATMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
	},
	
	seniormastersergeant = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 1 },
		{ weapon = 'WEAPON_COMBATMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
	},
	
	chiefmastersergeant = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 1 },
		{ weapon = 'WEAPON_COMBATMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
	},
	
	llieutenant = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 1 },
		{ weapon = 'WEAPON_COMBATMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
	},

	lieutenant = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'WEAPON_GUSENBERG', price = 1 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 1 },
		{ weapon = 'WEAPON_COMBATMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
		{ weapon = 'WEAPON_RPG', price = 1 },
		{ weapon = 'WEAPON_BZGAS', price = 1 },
		{ weapon = 'WEAPON_GRENADE', price = 1 },
	},

	captain = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'WEAPON_GUSENBERG', price = 1 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 1 },
		{ weapon = 'WEAPON_COMBATMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
		{ weapon = 'WEAPON_RPG', price = 1 },
		{ weapon = 'WEAPON_BZGAS', price = 1 },
		{ weapon = 'WEAPON_GRENADE', price = 1 },
	},
	
	major = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'WEAPON_GUSENBERG', price = 1 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 1 },
		{ weapon = 'WEAPON_COMBATMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
		{ weapon = 'WEAPON_RPG', price = 1 },
		{ weapon = 'WEAPON_BZGAS', price = 1 },
		{ weapon = 'WEAPON_GRENADE', price = 1 },
	},
	
	lcolonel = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'WEAPON_GUSENBERG', price = 1 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 1 },
		{ weapon = 'WEAPON_COMBATMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
		{ weapon = 'WEAPON_RPG', price = 1 },
		{ weapon = 'WEAPON_BZGAS', price = 1 },
		{ weapon = 'WEAPON_GRENADE', price = 1 },
	},
	
	colonel = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'WEAPON_GUSENBERG', price = 1 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 1 },
		{ weapon = 'WEAPON_COMBATMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
		{ weapon = 'WEAPON_RPG', price = 1 },
		{ weapon = 'WEAPON_BZGAS', price = 1 },
		{ weapon = 'WEAPON_GRENADE', price = 1 },
	},
	
	bgeneral = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'WEAPON_GUSENBERG', price = 1 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 1 },
		{ weapon = 'WEAPON_COMBATMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
		{ weapon = 'WEAPON_RPG', price = 1 },
		{ weapon = 'WEAPON_BZGAS', price = 1 },
		{ weapon = 'WEAPON_GRENADE', price = 1 },
	},
	
	mgeneral = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'WEAPON_GUSENBERG', price = 1 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 1 },
		{ weapon = 'WEAPON_COMBATMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
		{ weapon = 'WEAPON_RPG', price = 1 },
		{ weapon = 'WEAPON_BZGAS', price = 1 },
		{ weapon = 'WEAPON_GRENADE', price = 1 },
	},
	
	lgeneral = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'WEAPON_GUSENBERG', price = 1 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 1 },
		{ weapon = 'WEAPON_COMBATMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
		{ weapon = 'WEAPON_RPG', price = 1 },
		{ weapon = 'WEAPON_BZGAS', price = 1 },
		{ weapon = 'WEAPON_GRENADE', price = 1 },
	},

	general = {
		{ weapon = 'WEAPON_FLASHLIGHT', price = 1 },
		{ weapon = 'WEAPON_KNIFE', price = 1 },
		{ weapon = 'WEAPON_FLAREGUN', price = 1 },
		{ weapon = 'WEAPON_COMBATPISTOL', price = 1 },
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 1 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 6000, 1000, 4000, 8000, nil }, price = 1 },
		{ weapon = 'WEAPON_SMG', price = 1 },
		{ weapon = 'WEAPON_GUSENBERG', price = 1 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 1 },
		{ weapon = 'WEAPON_COMBATMG', price = 1 },
		{ weapon = 'GADGET_PARACHUTE', price = 1 },
		{ weapon = 'WEAPON_HEAVYSHOTGUN', price = 1 },
		{ weapon = 'WEAPON_RPG', price = 1 },
		{ weapon = 'WEAPON_BZGAS', price = 1 },
		{ weapon = 'WEAPON_GRENADE', price = 1 },
	},
}

Config.AuthorizedVehicles = {
	trainee = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	private = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	privatefirstclass = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	corporal = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	sergeant = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	staffsergeant = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	techsergeant = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	mastersergeant = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	seniormastersergeant = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	chiefmastersergeant = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	llieutenant = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	lieutenant = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	captain = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	major = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	lcolonel = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	colonel = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	bgeneral = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	mgeneral = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	lgeneral = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	
	general = {
		{ model = 'UPARMORHMVDES', label = 'Humvee', price = 1 },
		{ model = 'apc', label = 'APC', price = 1 },
		{ model = 'barracks', label = 'Barracks', price = 1 },
		{ model = 'barracks2', label = 'Barracks 2', price = 1 },
		{ model = 'barracks3', label = 'Barracks 3', price = 1 },
		{ model = 'barrage', label = 'Barrage', price = 1 },
		{ model = 'crusader', label = 'Crusader', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
	},
	Shared = {

	},

}

Config.AuthorizedHelicopters = {
	trainee = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	private = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	privatefirstclass = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	corporal = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	sergeant = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	staffsergeant = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	techsergeant = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	mastersergeant = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	seniormastersergeant = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	chiefmastersergeant = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	llieutenant = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'avenger', label = '[Plane] Avenger', price = 1 },
		{ model = 'besra', label = '[Plane] Besra', price = 1 },
		{ model = 'bombushka', label = '[Plane] Bombushka', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	lieutenant = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'avenger', label = '[Plane] Avenger', price = 1 },
		{ model = 'besra', label = '[Plane] Besra', price = 1 },
		{ model = 'bombushka', label = '[Plane] Bombushka', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	captain = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'avenger', label = '[Plane] Avenger', price = 1 },
		{ model = 'besra', label = '[Plane] Besra', price = 1 },
		{ model = 'bombushka', label = '[Plane] Bombushka', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	major = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'avenger', label = '[Plane] Avenger', price = 1 },
		{ model = 'besra', label = '[Plane] Besra', price = 1 },
		{ model = 'bombushka', label = '[Plane] Bombushka', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	lcolonel = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'avenger', label = '[Plane] Avenger', price = 1 },
		{ model = 'besra', label = '[Plane] Besra', price = 1 },
		{ model = 'bombushka', label = '[Plane] Bombushka', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	colonel = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'avenger', label = '[Plane] Avenger', price = 1 },
		{ model = 'besra', label = '[Plane] Besra', price = 1 },
		{ model = 'bombushka', label = '[Plane] Bombushka', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	bgeneral = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'avenger', label = '[Plane] Avenger', price = 1 },
		{ model = 'besra', label = '[Plane] Besra', price = 1 },
		{ model = 'bombushka', label = '[Plane] Bombushka', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	mgeneral = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'avenger', label = '[Plane] Avenger', price = 1 },
		{ model = 'besra', label = '[Plane] Besra', price = 1 },
		{ model = 'bombushka', label = '[Plane] Bombushka', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	lgeneral = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'avenger', label = '[Plane] Avenger', price = 1 },
		{ model = 'besra', label = '[Plane] Besra', price = 1 },
		{ model = 'bombushka', label = '[Plane] Bombushka', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
	general = {
		{ model = 'valkyrie2', label = '[Heli] Valkyrie2', price = 1 },
		{ model = 'valkyrie', label = '[Heli] Valkyrie', price = 1 },
		{ model = 'cargobob', label = '[Heli] Cargobob', price = 1 },
		{ model = 'cargobob3', label = '[Heli] Cargobob 3', price = 1 },
		{ model = 'cargobob4', label = '[Heli] Cargobob 4', price = 1 },
		{ model = 'crusader', label = '[Heli] Crusader', price = 1 },
		{ model = 'molotok', label = '[Plane] Molotok', price = 1 },
		{ model = 'titan', label = '[Plane] Titan', price = 1 },
		{ model = 'tula', label = '[Plane] Tula', price = 1 },
		{ model = 'avenger', label = '[Plane] Avenger', price = 1 },
		{ model = 'besra', label = '[Plane] Besra', price = 1 },
		{ model = 'bombushka', label = '[Plane] Bombushka', price = 1 },
		{ model = 'howard', label = '[Plane] Howard', price = 1 },
		{ model = 'miljet', label = '[Plane] Miljet', price = 1 },
		{ model = 'lazer', label = '[Plane] Lazer', price = 1 },
	},
}

-- CHECK SKINCHANGER CLIENT MAIN.LUA for matching elements

Config.Uniforms = {
	private_wear = {
		male = {
			['tshirt_2']=0,['hair_color_1']=0,
            ['glasses_2']=0,['shoes_1']=60,
            ['shoes_2']=3,['torso_2']=8,
            ['hair_color_2']=0,['pants_1']=87,
            ['glasses_1']=0,['hair_1']=0,
            ['sex']=0,['decals_2']=0,
            ['tshirt_1']=125,['helmet_1']=117,
            ['helmet_2']=0,['arms']=53,
            ['face']=0,['decals_1']=0,
            ['torso_1']=221,['hair_2']=0,
            ['skin']=0,['pants_2']=8,
            ['chain_1']=0
		},
		female = {
			['tshirt_2']=0,['hair_color_1']=0,
            ['glasses_2']=0,['shoes_1']=25,
            ['shoes_2']=0,['torso_2']=8,
            ['hair_color_2']=0,['pants_1']=90,
            ['glasses_1']=0,['hair_1']=0,
            ['sex']=0,['decals_2']=0,
            ['tshirt_1']=155,['helmet_1']=116,
            ['helmet_2']=0,['arms']=63,
            ['face']=0,['decals_1']=0,
            ['torso_1']=232,['hair_2']=0,
            ['skin']=0,['pants_2']=8,
            ['chain_1']=0
		}
	},
	patrol_wear = {
		male = {
			['tshirt_2']=0,['hair_color_1']=0,
            ['glasses_2']=0,['shoes_1']=60,
            ['shoes_2']=3,['torso_2']=8,
            ['hair_color_2']=0,['pants_1']=87,
            ['glasses_1']=0,['hair_1']=0,
            ['sex']=0,['decals_2']=0,
            ['tshirt_1']=125,['helmet_1']=117,
            ['helmet_2']=0,['arms']=53,
            ['face']=0,['decals_1']=0,
            ['torso_1']=221,['hair_2']=0,
            ['skin']=0,['pants_2']=8,
            ['chain_1']=0
		},
		female = {
			['tshirt_2']=0,['hair_color_1']=0,
            ['glasses_2']=0,['shoes_1']=25,
            ['shoes_2']=0,['torso_2']=8,
            ['hair_color_2']=0,['pants_1']=90,
            ['glasses_1']=0,['hair_1']=0,
            ['sex']=0,['decals_2']=0,
            ['tshirt_1']=155,['helmet_1']=116,
            ['helmet_2']=0,['arms']=63,
            ['face']=0,['decals_1']=0,
            ['torso_1']=232,['hair_2']=0,
            ['skin']=0,['pants_2']=8,
            ['chain_1']=0
		}
	},
	outpost_wear = {
		male = {
			['tshirt_2']=0,['hair_color_1']=0,
            ['glasses_2']=0,['shoes_1']=60,
            ['shoes_2']=3,['torso_2']=8,
            ['hair_color_2']=0,['pants_1']=87,
            ['glasses_1']=0,['hair_1']=0,
            ['sex']=0,['decals_2']=0,
            ['tshirt_1']=125,['helmet_1']=117,
            ['helmet_2']=0,['arms']=53,
            ['face']=0,['decals_1']=0,
            ['torso_1']=221,['hair_2']=0,
            ['skin']=0,['pants_2']=8,
            ['chain_1']=0
		},
		female = {
			['tshirt_2']=0,['hair_color_1']=0,
            ['glasses_2']=0,['shoes_1']=25,
            ['shoes_2']=0,['torso_2']=8,
            ['hair_color_2']=0,['pants_1']=90,
            ['glasses_1']=0,['hair_1']=0,
            ['sex']=0,['decals_2']=0,
            ['tshirt_1']=155,['helmet_1']=116,
            ['helmet_2']=0,['arms']=63,
            ['face']=0,['decals_1']=0,
            ['torso_1']=232,['hair_2']=0,
            ['skin']=0,['pants_2']=8,
            ['chain_1']=0

		}
	},
	sergeant_wear = {
		male = {
			['tshirt_2']=0,['hair_color_1']=0,
            ['glasses_2']=0,['shoes_1']=60,
            ['shoes_2']=3,['torso_2']=8,
            ['hair_color_2']=0,['pants_1']=87,
            ['glasses_1']=0,['hair_1']=0,
            ['sex']=0,['decals_2']=0,
            ['tshirt_1']=125,['helmet_1']=117,
            ['helmet_2']=0,['arms']=53,
            ['face']=0,['decals_1']=0,
            ['torso_1']=221,['hair_2']=0,
            ['skin']=0,['pants_2']=8,
            ['chain_1']=0
		},
		female = {
			['tshirt_2']=0,['hair_color_1']=0,
            ['glasses_2']=0,['shoes_1']=25,
            ['shoes_2']=0,['torso_2']=8,
            ['hair_color_2']=0,['pants_1']=90,
            ['glasses_1']=0,['hair_1']=0,
            ['sex']=0,['decals_2']=0,
            ['tshirt_1']=155,['helmet_1']=116,
            ['helmet_2']=0,['arms']=63,
            ['face']=0,['decals_1']=0,
            ['torso_1']=232,['hair_2']=0,
            ['skin']=0,['pants_2']=8,
            ['chain_1']=0
		}
	},
	lieutenant_wear = { -- currently the same as intendent_wear
		male = {
			['tshirt_2']=0,['hair_color_1']=0,
            ['glasses_2']=0,['shoes_1']=60,
            ['shoes_2']=3,['torso_2']=8,
            ['hair_color_2']=0,['pants_1']=87,
            ['glasses_1']=0,['hair_1']=0,
            ['sex']=0,['decals_2']=0,
            ['tshirt_1']=125,['helmet_1']=117,
            ['helmet_2']=0,['arms']=53,
            ['face']=0,['decals_1']=0,
            ['torso_1']=221,['hair_2']=0,
            ['skin']=0,['pants_2']=8,
            ['chain_1']=0
		},
		female = {
			['tshirt_2']=0,['hair_color_1']=0,
            ['glasses_2']=0,['shoes_1']=25,
            ['shoes_2']=0,['torso_2']=8,
            ['hair_color_2']=0,['pants_1']=90,
            ['glasses_1']=0,['hair_1']=0,
            ['sex']=0,['decals_2']=0,
            ['tshirt_1']=155,['helmet_1']=116,
            ['helmet_2']=0,['arms']=63,
            ['face']=0,['decals_1']=0,
            ['torso_1']=232,['hair_2']=0,
            ['skin']=0,['pants_2']=8,
            ['chain_1']=0
		}
	},
	captain_wear = {
		male = {
			['tshirt_2']=0,['hair_color_1']=0,
            ['glasses_2']=0,['shoes_1']=60,
            ['shoes_2']=3,['torso_2']=8,
            ['hair_color_2']=0,['pants_1']=87,
            ['glasses_1']=0,['hair_1']=0,
            ['sex']=0,['decals_2']=0,
            ['tshirt_1']=125,['helmet_1']=117,
            ['helmet_2']=0,['arms']=53,
            ['face']=0,['decals_1']=0,
            ['torso_1']=221,['hair_2']=0,
            ['skin']=0,['pants_2']=8,
            ['chain_1']=0
		},
		female = {
			['tshirt_2']=0,['hair_color_1']=0,
            ['glasses_2']=0,['shoes_1']=25,
            ['shoes_2']=0,['torso_2']=8,
            ['hair_color_2']=0,['pants_1']=90,
            ['glasses_1']=0,['hair_1']=0,
            ['sex']=0,['decals_2']=0,
            ['tshirt_1']=155,['helmet_1']=116,
            ['helmet_2']=0,['arms']=63,
            ['face']=0,['decals_1']=0,
            ['torso_1']=232,['hair_2']=0,
            ['skin']=0,['pants_2']=8,
            ['chain_1']=0
		}
	},
	pilot_wear = { -- currently the same as chef_wear
		male = {
			['tshirt_2']=0,['hair_color_1']=0,
            ['glasses_2']=0,['shoes_1']=60,
            ['shoes_2']=3,['torso_2']=8,
            ['hair_color_2']=0,['pants_1']=87,
            ['glasses_1']=0,['hair_1']=0,
            ['sex']=0,['decals_2']=0,
            ['tshirt_1']=125,['helmet_1']=117,
            ['helmet_2']=0,['arms']=53,
            ['face']=0,['decals_1']=0,
            ['torso_1']=221,['hair_2']=0,
            ['skin']=0,['pants_2']=8,
            ['chain_1']=0
		},
		female = {
			['tshirt_2']=0,['hair_color_1']=0,
            ['glasses_2']=0,['shoes_1']=25,
            ['shoes_2']=0,['torso_2']=8,
            ['hair_color_2']=0,['pants_1']=90,
            ['glasses_1']=0,['hair_1']=0,
            ['sex']=0,['decals_2']=0,
            ['tshirt_1']=155,['helmet_1']=116,
            ['helmet_2']=0,['arms']=63,
            ['face']=0,['decals_1']=0,
            ['torso_1']=232,['hair_2']=0,
            ['skin']=0,['pants_2']=8,
            ['chain_1']=0
		}
	},
	bullet_wear = {
		male = {
			['bproof_1'] = 11,  ['bproof_2'] = 1
		},
		female = {
			['bproof_1'] = 13,  ['bproof_2'] = 1
		}
	},
	gilet_wear = {
		male = {
			['tshirt_1'] = 59,  ['tshirt_2'] = 1
		},
		female = {
			['tshirt_1'] = 36,  ['tshirt_2'] = 1
		}
	}

}