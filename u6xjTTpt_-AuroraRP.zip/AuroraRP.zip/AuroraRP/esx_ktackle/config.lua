Config                            	= {}
Config.TackleDistance				= 3.0