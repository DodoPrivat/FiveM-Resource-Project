local isAllowed = false
RegisterNetEvent('aurora_weapons:checkpermsreturn')
AddEventHandler('aurora_weapons:checkpermsreturn', function(hasPerms)
	isAllowed = hasPerms
end)
TriggerServerEvent("aurora_weapons:checkperms")
-- CONFIG --

-- Blacklisted weapons
weaponblacklist = {
	"WEAPON_HOMINGLAUNCHER",
	"WEAPON_COMPACTLAUNCHER",
	"WEAPON_RAYCARBINE",
	"WEAPON_COMPACTRIFLE",
	"WEAPON_MG",
	"WEAPON_PROXMINE",
	"WEAPON_MARKSMANRIFLE",
	"WEAPON_MARKSMANRIFLE_MK2",
	"WEAPON_MARKSMANPISTOL",
	"WEAPON_SAWNOFFSHOTGUN",
	"WEAPON_MUSKET",
	"WEAPON_MINIGUN",
	"WEAPON_RAYPISTOL",
	"WEAPON_RAILGUN",
	"WEAPON_HEAVYSNIPER_MK2"
}

disableallweapons = false

Citizen.CreateThread(function()
	while true do
		Wait(1)

		playerPed = GetPlayerPed(-1)
		if playerPed and isAllowed == false then
			nothing, weapon = GetCurrentPedWeapon(playerPed, true)

			if disableallweapons then
				RemoveAllPedWeapons(playerPed, true)
			else
				if isWeaponBlacklisted(weapon) then
					SetCurrentPedWeapon(playerPed, GetHashKey("WEAPON_UNARMED"), true)
					RemoveWeaponFromPed(playerPed, weapon)
					DisplayNotification("This weapon is blacklisted!")
				end
			end
		end
	end
end)

function isWeaponBlacklisted(model)
	for _, blacklistedWeapon in pairs(weaponblacklist) do
		if model == GetHashKey(blacklistedWeapon) then
			return true
		end
	end

	return false
end

function DisplayNotification( text )
    SetNotificationTextEntry( "STRING" )
    AddTextComponentString( text )
    DrawNotification( false, false )
end