Citizen.CreateThread(function()
AddTextEntry("0x00AB9693", "Daytona Classic Gold")
AddTextEntry("0x019E8851", "AR767 Gloss Black 01")
AddTextEntry("0x01CE5F34", "JDM August Feroce Chrome")
AddTextEntry("0x0216B3C1", "Compqtive Racing")
AddTextEntry("0x0220780F", "Muscle 2 Black")
AddTextEntry("0x02356B12", "American Racing AR767 Tire 2 Black")
AddTextEntry("0x02CB905B", "AR62 Outlaw II Chrome 02")
AddTextEntry("0x02FB77A9", "SSR F5 V3")
AddTextEntry("0x040FDB2A", "Bmw BBS CHRII Chrome")
AddTextEntry("0x04A930D5", "Work Equip 05 Black")
AddTextEntry("0x081864AE", "MK1 V1")
AddTextEntry("0x09C2069B", "Adv1 15 TSpecs Chrome")
AddTextEntry("0x0A561802", "Rotiform DSC Invo Tires")
AddTextEntry("0x0B04933A", "Black Offroad Wheels Chrome")
AddTextEntry("0x0B082A4D", "Tenzo Racing RS-5")
AddTextEntry("0x0CD38B5D", "SSR Star Shark V3")
AddTextEntry("0x0CEB00BA", "Cragar Series 352 Black")
AddTextEntry("0x0E423D1F", "Benz Amg SLR 05 Color")
AddTextEntry("0x0FCE8C68", "Wire Spoke Cadillac Chrome")
AddTextEntry("0x0FF9FB8B", "JDM August Feroce Black")
AddTextEntry("0x1B1A5129", "Hre S104 V1")
AddTextEntry("0x1D852CC0", "SSR F5 V1")
AddTextEntry("0x1DB1BEB9", "Rotiform DSC Idlers Tire")
AddTextEntry("0x1E0E28E7", "Wire Spoke Cadillac Gold")
AddTextEntry("0x1E99A417", "Cragar Series 352 Chrome")
AddTextEntry("0x1EFCDA12", "Hre S101")
AddTextEntry("0x1F93D8D3", "BBS CH")
AddTextEntry("0x2A7626DC", "Hre FF01 Black")
AddTextEntry("0x2AB2F600", "Benz C63 10 Color")
AddTextEntry("0x2C64CBE0", "Adv1 Track Spec V05 Chrome")
AddTextEntry("0x2CE774C3", "Hre S104 V2")
AddTextEntry("0x2E61104E", "Oz Avantgarde MSW 24")
AddTextEntry("0x2ECE72D8", "Daytona Detalhada Color")
AddTextEntry("0x2FCC1272", "Asanti Concave CX-506 Chrome")
AddTextEntry("0x3A648B12", "Momo Corse V1")
AddTextEntry("0x3B8101C5", "AR767 Chrome 02")
AddTextEntry("0x3B273406", "GramLights Wheel")
AddTextEntry("0x3C8B28F2", "Benz Wheel 03")
AddTextEntry("0x3C23DA73", "Benz A45 C Red 2")
AddTextEntry("0x3CF0A419", "Black Offroad Wheels Black")
AddTextEntry("0x3D53FA95", "ADV05C CS Series V1")
AddTextEntry("0x3ED95223", "MK1 V2")
AddTextEntry("0x4BD74776", "Benz Wheel 04")
AddTextEntry("0x4DFAA6B8", "AR62 Outlaw II Color 01")
AddTextEntry("0x4E3ECC59", "Benz Wheel 02")
AddTextEntry("0x4F129E12", "Adv1 M.V1 V7 Chrome")
AddTextEntry("0x5A7B8C13", "Minilite Mk1 Color")
AddTextEntry("0x5A37B430", "GT MKIV Chrome")
AddTextEntry("0x5CC5ACA5", "Adv1 Track Spec V05 Black")
AddTextEntry("0x6D874EDB", "Muscle 2 Black")
AddTextEntry("0x6DBBAB64", "Brabus Wheel 02")
AddTextEntry("0x6E6DBF06", "Benz E63 10 Color")
AddTextEntry("0x6FA81120", "American Racing Outlaw II Black")
AddTextEntry("0x6FD5B655", "Oettinger Wheel 01")
AddTextEntry("0x7C3AB1A5", "Vossen VPS 305")
AddTextEntry("0x7D76D197", "Oettinger Wheel 02")
AddTextEntry("0x7E72270E", "Avant Garde F142 Chrome")
AddTextEntry("0x7ED7F0C9", "Adv1 M.V1 V005 Chrome")
AddTextEntry("0x7F4FE009", "Racing R Black")
AddTextEntry("0x7F12991C", "Hre 940RL V2")
AddTextEntry("0x7FD4ED0A", "Cragar Chrome Smoothie 313 V1")
AddTextEntry("0x7FFA4FE1", "Brabus Wheel 01")
AddTextEntry("0x8A1207F4", "Muscle 4 Black")
AddTextEntry("0x9B5D2A8A", "Muscle 4 Chrome")
AddTextEntry("0x9BD33C94", "Weld Racing AlumaStar Color")
AddTextEntry("0x9DAFC071", "AR767 Chrome 01")
AddTextEntry("0x9ECF52D0", "Daytona Cla Gold")
AddTextEntry("0x9F075A29", "Hre C103")
AddTextEntry("0x16A95D7C", "Volk Racing TE37")
AddTextEntry("0x22A4FE77", "Vossen VFS-2")
AddTextEntry("0x22F5234A", "Avant Garde F142 Idlers Tire")
AddTextEntry("0x25FA4BB6", "GT MKIV Black")
AddTextEntry("0x31F9BB0C", "Minilite Mk1 Chrome")
AddTextEntry("0x39BBE68E", "Adv1 15 TSpecs Black")
AddTextEntry("0x39C5C57B", "Hre FF01 Chrome")
AddTextEntry("0x39FCA3C1", "Benz Wheel 05")
AddTextEntry("0x49F0F60D", "Benz A45 C Red 1")
AddTextEntry("0x52FB990D", "Adv1 M.V1 V005 Black")
AddTextEntry("0x53E6CF4F", "Work Rezax 5 Chrome")
AddTextEntry("0x61D1E43D", "Benz E63 10 Chrome")
AddTextEntry("0x61E1C3B0", "Adv1 M.V1 V7 Black")
AddTextEntry("0x62C1B249", "Daytona 2 Gold")
AddTextEntry("0x64F4DF24", "Daytona Detalhada Chrome")
AddTextEntry("0x65D7E6A7", "Hre C100")
AddTextEntry("0x69AAC0B6", "Cragar Chrome Smoothie 313 V2")
AddTextEntry("0x80DB7583", "Muscle 3 Chrome")
AddTextEntry("0x89A0BD7F", "Avant Garde F142 Chrome 20")
AddTextEntry("0x94E93F04", "Daytona Classic Color")
AddTextEntry("0x97A5DF6D", "Hamann Logo Audi")
AddTextEntry("0x134BD6BB", "Hamann Special")
AddTextEntry("0x196A536F", "Benz C63 10 Chrome")
AddTextEntry("0x477CFC17", "Cragar 08/61 S/S Super Sport")
AddTextEntry("0x491F6554", "Bmw BBS CHRII Grey")
AddTextEntry("0x551F7EAF", "Cobra Gt500 Shelby V1")
AddTextEntry("0x561D4856", "Hre V107 V2")
AddTextEntry("0x621F6BC0", "Work Seeker FX Black")
AddTextEntry("0x648CFAE6", "American Racing Outlaw II Chrome")
AddTextEntry("0x685FECDB", "Hre S107 V1")
AddTextEntry("0x704C0AC2", "Avant Garde F142 Black")
AddTextEntry("0x738F670B", "Adv1 M.V2 V5 Chrome")
AddTextEntry("0x790D7CDD", "AR62 Outlaw II Color 02")
AddTextEntry("0x822A7B68", "ZR Wheels")
AddTextEntry("0x831F8F6B", "Work Equip 01 Black")
AddTextEntry("0x832C9B8B", "Daytona Classic Chrome")
AddTextEntry("0x859DB2BC", "Work Equip 05 Chrome")
AddTextEntry("0x860A33C9", "Work Rezax 5 Color")
AddTextEntry("0x914D3D91", "Hre P940 RL Black")
AddTextEntry("0x925B2DE2", "Work Equip 01 Tire 2 Chrome")
AddTextEntry("0x942A2840", "ADV1 Chrome")
AddTextEntry("0x971A0F9D", "Racing R Chrome")
AddTextEntry("0x971AD982", "Vorsteiner Wheel Special")
AddTextEntry("0x1323BB83", "Daytona Detalhada Gold")
AddTextEntry("0x2108F746", "Borbet Wheel")
AddTextEntry("0x2242C7DB", "Rotiform LSR Cast 1 Black")
AddTextEntry("0x3037E583", "AR767 Chrome")
AddTextEntry("0x3809D242", "Ccw Wheels Black")
AddTextEntry("0x6205F3E7", "Benz Wheel 01")
AddTextEntry("0x6776D9B0", "AR62 Outlaw II Chrome 01")
AddTextEntry("0x7602F118", "AR767 Gloss Black")
AddTextEntry("0x38158B23", "Hre S101")
AddTextEntry("0x41996FFD", "Wire Spoke Cadillac Color")
AddTextEntry("0x45533E32", "Oz Avantgarde MSW 11")
AddTextEntry("0x85527DBA", "ADV05C CS Series V2")
AddTextEntry("0x175881C7", "Bmw Wheel 02")
AddTextEntry("0x295282CE", "Volk Racing TE37 Saga Expert")
AddTextEntry("0x541599E0", "SSR Star Shark V2")
AddTextEntry("0x742201EA", "BBS Super RS Wide Michelin")
AddTextEntry("0x827904DE", "Adv1 M.V2 V5 Black")
AddTextEntry("0x29264402", "SSR Star Shark V1")
AddTextEntry("0x31176584", "Rotiform LSR Cast 1 Chrome")
AddTextEntry("0x53904218", "Hre C100")
AddTextEntry("0x98993122", "ADV1 05C Chrome")
AddTextEntry("0xA69CCD25", "ADV1 Black")
AddTextEntry("0xA79B4306", "Muscle 1 Black")
AddTextEntry("0xA727B4F0", "American Racing AR767 Tire 2 Chrome")
AddTextEntry("0xA55403D7", "Vossen VFS-5 Chrome")
AddTextEntry("0xA96702EF", "Audi Sport Wheels")
AddTextEntry("0xAA9F0575", "Volk CE28N 8 Spoke")
AddTextEntry("0xAAE3D5B7", "ADV1 05C Black")
AddTextEntry("0xACF9F4EA", "Hre 940RL V1")
AddTextEntry("0xAEAEBF86", "Ccw Wheels Chrome")
AddTextEntry("0xB074F61B", "Daytona Cla Chrome")
AddTextEntry("0xB0FE670E", "AR767 Gloss Black 02")
AddTextEntry("0xB3A57076", "Work Equip 01 Tire 2 Black")
AddTextEntry("0xB3B4BBDC", "Mustang Chrome")
AddTextEntry("0xB3EF087A", "Benz Amg GT 2016 Chrome")
AddTextEntry("0xB4B5E6B3", "Fikse Wheel")
AddTextEntry("0xB4E95073", "American Racing AR62 Outlaw II Black")
AddTextEntry("0xB8F82B1F", "Vossen CV3-R")
AddTextEntry("0xB28F97FB", "Asanti Concave CX-506 Color")
AddTextEntry("0xB29E52A0", "Cragar 08/61 S/S Super Sport")
AddTextEntry("0xB79A0EF0", "Benz Amg GTR 17 V2")
AddTextEntry("0xB94A8D8B", "Hre RS300 M V2 Chrome")
AddTextEntry("0xB248940B", "Halibrand Sprint II Color")
AddTextEntry("0xB5210458", "Hochtech Nekkar 5 Chrome")
AddTextEntry("0xBA02E7D5", "Muscle 1 Chrome")
AddTextEntry("0xBA6609FD", "Daytona Cla Color")
AddTextEntry("0xBB8DDDC0", "American Racing AR62 Outlaw II Tire 2 Black")
AddTextEntry("0xBBA61366", "Hre S107 V1")
AddTextEntry("0xBBF12819", "Volk Racing TE37 Wide")
AddTextEntry("0xBCDB935C", "BBS LM")
AddTextEntry("0xC8FC7F5C", "Cragar 08/61 S/S Super Sport")
AddTextEntry("0xC35F4655", "Ford Old Rims V1")
AddTextEntry("0xC58EED47", "Benz A45 C Black")
AddTextEntry("0xC95C795D", "American Racing AR62 Outlaw II Tire 2 Chrome")
AddTextEntry("0xC418A8C5", "Benz Amg GTR 17 V1")
AddTextEntry("0xC1662368", "Benz Amg GT 2016 Color")
AddTextEntry("0xCB1CCF68", "Vossen CV4")
AddTextEntry("0xCB777D8F", "American Racing AR62 Outlaw II Chrome")
AddTextEntry("0xCC2CE780", "Kosei Wheel")
AddTextEntry("0xCCE043E9", "Avant Garde F142 Black 20")
AddTextEntry("0xCD20C9BB", "Halibrand Sprint II Chrome")
AddTextEntry("0xCDC1B79D", "Hre C103")
AddTextEntry("0xD052C141", "Benz 190E 90 Chrome")
AddTextEntry("0xD5ABFD45", "Hre RS300 M V2 Black")
AddTextEntry("0xD7A8CD7C", "Vorsteiner vs 350 Black")
AddTextEntry("0xD39DC231", "Hre P940 RL Chrome")
AddTextEntry("0xD198E2C8", "Ford Old Rims V2")
AddTextEntry("0xD4682DBD", "Weld Racing AlumaStar Chrome")
AddTextEntry("0xD4749CB8", "Muscle 2 Chrome")
AddTextEntry("0xD4891EAA", "Team Dynamics Wheels")
AddTextEntry("0xD68919DE", "Daytona 2 Color")
AddTextEntry("0xDC8A0D86", "Cobra Gt500 Shelby V2")
AddTextEntry("0xDE389041", "Momo Corse V2")
AddTextEntry("0xE2B165FE", "Benz 190E 90 Color")
AddTextEntry("0xE4C23650", "Daytona 2 Chrome")
AddTextEntry("0xE5CB69C1", "Vorsteiner vs 350 Chrome")
AddTextEntry("0xE8F36BFC", "Hochtech Nekkar 5 Black")
AddTextEntry("0xE97BEC9C", "BBS Super RS Wide Invo")
AddTextEntry("0xE4802FA8", "American Racing AR767 Gloss Black")
AddTextEntry("0xE8636CE0", "Hre S107 V2")
AddTextEntry("0xE4783653", "Cragar Bonneville 391 V1")
AddTextEntry("0xEAAA5A41", "Weld Racing AlumaStar Chrome")
AddTextEntry("0xEB78CA73", "Racing W")
AddTextEntry("0xECA9ADD1", "Mustang Color")
AddTextEntry("0xEDB1648D", "Work Equip 01 Chrome")
AddTextEntry("0xEF16B138", "Bmw Wheel 01")
AddTextEntry("0xF030D214", "SSR F5 V2")
AddTextEntry("0xF6C58737", "BBS CH Wide")
AddTextEntry("0xF23ACB1D", "American Racing AR767 Gloss Chrome")
AddTextEntry("0xF853CE00", "Avant Garde F142 Invo Tires")
AddTextEntry("0xF98977FF", "Weld Racing AlumaStar Color")
AddTextEntry("0xF320966B", "Volk Racing TE37 Saga Chromo")
AddTextEntry("0xF7019586", "Work Seeker FX Chrome")
AddTextEntry("0xFD0C9AB4", "Benz Amg SLR 05 Chrome")
AddTextEntry("0xFDED3508", "Vossen VFS-5 Black")
AddTextEntry("0xFE2F69C1", "Cragar Bonneville 391 V2")
end)