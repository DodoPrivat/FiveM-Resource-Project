DiscordWebhookSystemInfos = 'https://canary.discordapp.com/api/webhooks/662895887286009866/eU42jxK1i2HMPHmCzAkQ0hXMtbOAic2Hqm7tUcoBO9g6IHADovAo_0nAd9to-n-q4lMD'
DiscordWebhookKillinglogs = 'https://canary.discordapp.com/api/webhooks/662895812346511391/p-zbNoGAOF3nyqv7_Td9XbcnBd7a-dHCyufT51h08rbEHOp3nug0Ogi1EBHQQ7wjNk60'
DiscordWebhookChat = 'https://canary.discordapp.com/api/webhooks/662895672587976707/5kn9L74Wcj_BcR4spMAwt_foMFwtJwrCPW_puYnTt1d14GmvJKf_0xtOUxAGfvEIGsFa'

SystemAvatar = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2hut8svehJlhvi_ljKF9YHngm8kkOFQDMvB9l3O744ENdxRcU-w'

UserAvatar = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2hut8svehJlhvi_ljKF9YHngm8kkOFQDMvB9l3O744ENdxRcU-w'

SystemName = 'SYSTEM'


--[[ Special Commands formatting
		 *YOUR_TEXT*			--> Make Text Italics in Discord
		**YOUR_TEXT**			--> Make Text Bold in Discord
	   ***YOUR_TEXT***			--> Make Text Italics & Bold in Discord
		__YOUR_TEXT__			--> Underline Text in Discord
	   __*YOUR_TEXT*__			--> Underline Text and make it Italics in Discord
	  __**YOUR_TEXT**__			--> Underline Text and make it Bold in Discord
	 __***YOUR_TEXT***__		--> Underline Text and make it Italics & Bold in Discord
		~~YOUR_TEXT~~			--> Strikethrough Text in Discord
]]
-- Use 'USERNAME_NEEDED_HERE' without the quotes if you need a Users Name in a special command
-- Use 'USERID_NEEDED_HERE' without the quotes if you need a Users ID in a special command


-- These special commands will be printed differently in discord, depending on what you set it to
SpecialCommands = {
				   {'/ooc', '**[OOC]:**'},
				   {'/911', '**[911]: (CALLER ID: [ USERNAME_NEEDED_HERE | USERID_NEEDED_HERE ])**'},
				  }

						
-- These blacklisted commands will not be printed in discord
BlacklistedCommands = {
					   '/AnyCommand',
					   '/AnyCommand2',
					  }

-- These Commands will use their own webhook
OwnWebhookCommands = {
					  {'/AnotherCommand', 'WEBHOOK_LINK_HERE'},
					  {'/AnotherCommand2', 'WEBHOOK_LINK_HERE'},
					 }

-- These Commands will be sent as TTS messages
TTSCommands = {
			   '/Whatever',
			   '/Whatever2',
			  }

