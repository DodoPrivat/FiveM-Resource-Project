local theVehicles = {
	{"filthynsx", "NSX Custom (2016)"},
	{"acuransx", "NSX Standard (2016)"},
	{"arsx", "RSX Custom (2006)"},
	{"alfa67", "MUSEO (1967)"},
	{"giulia", "GIULIA  (2016)"},
	{"4c", "Spider C4 (2015)"},
	{"stelvio", "Stelvio (2017)"},
	{"tz3", "TZ3 (2011)"},
	{"ardv", "Volante (2013)"},
	{"db9v", "DB9 (2006)"},
	{"amdb64", "DB5 (1964)"},
	{"db11", "DB11 (2017)"},
	{"vgt12", "Vantage GT12 (2015)"},
	{"rapide10", "Rapide (2010)"},
	{"ast", "Vanquish (2013)"},
	{"vulcan ", "Vulcan (2016)"},
	{"audia4", "A4 (2000)"},
	{"audi7", "A7 (2015)"},
	{"audiq3", "Q3 (2010)"},
	{"audi2q7", "Q7 (2015)"},
	{"r8v10", "R8 (2015)"},
	{"rs5r", "RS5 (2019)"},
	{"rs6avant", "RS6 AVANT (2015)"},
	{"c5rs6", "RS6 (2003)"},
	{"s4avant", "S4 AVANT (2013)"},
	{"s8w12", "S8 (2016)"},
	{"tts07", "TT (2007)"},
	{"bbentayga", "Bentayga (2020)"},
	{"bentaygam", "Bentayga (2019)"},
	{"bfs14", "FLY SPUR (2014)"},
	{"bmm", "Mulsanne (2013)"},
	{"m3f80 ", "M3 (2015)"},
	{"mteche39 ", "530D (2002)"},
	{"bmwe38", "750i (1999)"},
	{"750im", "750i (2016)"},
	{"850csi", "850i (1995)"},
	{"acs8", "i8 (2019)"},
	{"m3e46", "M3  (2005)"},
	{"e60", "M5 (2008)"},
	{"e34touring", "M5 touring (1995)"},
	{"oldm6", "M6 (1984)"},
	{"lummax6", "X6 (2015)"},
	{"z3m", "M3 (2002)"},
	{"z4", "z4 (2010)"},
	{"eb110", "B110 (1995)"},
	{"ctsv16", "CTSV (2016)"},
	{"ctssw10", "CTS touring (2010)"},
	{"escade", "Escalede (2016)"},
	{"xlrv", "XLRV (2008)"},
	{"limoxts", "XTS (2016)"},
	{"cblazer", "BLAZER (2001)"},
	{"C7", "CORVETTE (2019)"},
	{"caprice89 ", "CAPRICE (1989)"},
	{"caprice13", "CAPRICE (2014)"},
	{"impala", "IMPALA (1996)"},
	{"80silverado", "SILVERADO (1986)"},
	{"silverado ", "SILVERADO (2017)"},
	{"suburban2008", "SUBURBAN (2008)"},
	{"tahoe ", "TAHOE (2016)"},
	{"chry300", "SRT8 300c (2008)"},
	{"300srt8", "SRT8 300c (2012)"},
	{"caravan", "CARAVAN (2008)"},
	{"rampage10", "CHALLENGER SRT8 (2010)"},
	{"16charger", "CHARGER SRT8 (2016)"},
	{"hellcat", "CHARGER HELLCAT (2016)"},
	{"charger", "CHARGER R/T (1960)"},
	{"durango", "DURANGO SRT8 (2018)"},
	{"ram99", "RAM (1999)"},
	{"10ram", "RAM 4x4  (2010)"},
	{"19ramoffroad ", "RAM (2019)"},
	{"dodgesrt2 ", "RAM SRT10 (2006)"},
	{"acr", "VIPER ACR (2019)"},
	{"99viper", "VIPER GTS (1999)"},
	{"gto2", "GTO (1962)"},
	{"f288gto", "GTO (1984)"},
	{"fer458 ", "458 Italia (2015)"},
	{"488speedster", "488 Speedster (2016)"},
	{"fer612", "612 S (2004)"},
	{"bb512", "512 BB (1981)"},
	{"fc15", "CALIFORNIA (2015)"},
	{"enzo", "ENZO (2005)"},
	{"355f1berlinetta", "355 Berlinetta (1999)"},
	{"f430s", "430 Spider  (2005)"},
	{"f40", "F40 (1987)"},
	{"575m", "Maranello (2002)"},
	{"pista", "PISTA (2019)"},
	{"trossa", "TESTAROSSA (1984)"},
	{"f500", "500 ABARTH (2019)"},
	{"yfiat595ssa-yfiat595ssb", "595 ABARTH  (1972)"},
	{"fiat175", "175 coupe (1999)"},
	{"17jamb", "RV (2018)"},
	{"bronco", "BRONCO (1980)"},
	{"towtruck2", "TOWTRUCK (2007)"},
	{"expedition ", "EXPEDITION (2018)"},
	{"18f350", "F350  (2018)"},
	{"superduty", "SUPERDUTY (2008)"},
	{"20f250", "F250 (2019)"},
	{"focus2003", "FOCUS (2003)"},
	{"fgt ", "GT (2005)"},
	{"eleanor", "MUSTANG (1967)"},
	{"93mustang ", "MUSTANG (1993)"},
	{"95stang", "MUSTANG (1995)"},
	{"mst", "MUSTANG (2013)"},
	{"fmgt", "MUSTANG (2019)"},
	{"gmcs", "SIERRA (2017)"},
	{"denalihd", "SIERRA  (2019)"},
	{"gmcSuburban", "SUBURBAN (1989)"},
	{"c4500", "TOPKICK (2006)"},
	{"gmcyd", "YUKON (2015)"},
	{"cv8", "CV8R (2005)"},
	{"hsvmaloo", "HSV (2017)"},
	{"dc2", "INTEGRA TYPE R (1998)"},
	{"accord11", "ACCORD (2011)"},
	{"crv ", "HR-V (2011)"},
	{"crx2", "CRX (1990)"},
	{"hfit", "FIT (2010)"},
	{"nsx4", "NSX (2005)"},
	{"ody18", "ODYSSEY (2018)"},
	{"ap2", "S2000 (2009)"},
	{"h1", "H1 (2006)"},
	{"h6", "H6 (2005)"},
	{"uparmorhmvdes", "M11114 (Unknow)"},
	{"accent", "ACCENT (1997)"},
	{"santafe", "SANTAFE (2013)"},
	{"sont18", "SONATA (2018)"},
	{"fx50s", "FX50S (2010)"},
	{"qx56", "QX56 (2012)"},
	{"qx80", "QX80 (2019)"},
	{"cx75", "CX75 (2019)"},
	{"p7", "P7 (2016)"},
	{"fpace2017", "FPACE (2017)"},
	{"fpacehm", "FPACE (2018)"},
	{"jaguarxf ", "XFR (2012)"},
	{"jxj", "XJ (2014)"},
	{"xjr", "XJR (2016)"},
	{"xj220", "XJ220 (1997)"},
	{"xkgt", "XKGT (2015)"},
	{"srt8", "SRT8 (2015)"},
	{"jp12", "WRANGLER (2012)"},
	{"cherokee96", "CHEROKE (1996)"},
	{"m939", "M939 (Unknow)"},
	{"kamaz6396", "6396- (Unknow)"},
	{"koup", "KOUP (2010)"},
	{"optima", "OPTIMA (2014)"},
	{"kiasoul2", "SOUL (2018)"},
	{"kiagt", "STINGER (2017)"},
	{"one1", "ONE1 (2016)"},
	{"ccx", "CCX (2006)"},
	{"regera", "REGERA (2016)"},
	{"ktmx", "KTM X BOW (2007)"},
	{"lp670", "LP670 (2009)"},
	{"asterion", "ASTERION (2019)"},
	{"countach", "COUNTACH (1986)"},
	{"500gtrlam", "DIABLO GTR (2000)"},
	{"torofeo", "TOROFEO (2015)"},
	{"lp610", "LP610 (2014)"},
	{"jalpa", "JALPA (1985)"},
	{"lambose", "SESTO (2010)"},
	{"lm002", "LM002 (1986)"},
	{"lp6504", "MURCIELAGO roadster (2008)"},
	{"lp640", "MURCIELAGO (2007)"},
	{"aventadors", "AVENDATOR S (2018)"},
	{"lp700", "AVENDATOR (2012)"},
	{"sc18", "ALSTON (2020)"},
	{"def90", "DEFENDER (2011)"},
	{"discovery4", "DISCOVERY (2016)"},
	{"evoq", "EVOQUE (2018)"},
	{"rr12", "RANGE ROVER (2012)"},
	{"rrvelar", "VELAR (2019)"},
	{"svr14", "RANGE SPORT SVR (2017)"},
	{"evoque", "EVOQUE (2018)"},
	{"rr14", "RANGE ROVER (2017)"},
	{"rstech", "RANGE SPORT (2017)"},
	{"lct200h", "CT200h (2011)"},
	{"gs350", "GS350 (2015)"},
	{"is350", "IS350 (2014)"},
	{"lex09isf", "IS-F (2009)"},
	{"lc500", "LC500 (2018)"},
	{"ls600", "LS600h (2016)"},
	{"lx2018", "LX (2018)"},
	{"lx570", "LX (2016)"},
	{"wald2018", "LX (2018)"},
	{"rcf", "RC-F (2015)"},
	{"rx450h", "RX450h (2016)"},
	{"lc01", "CONTINENTAL (2017)"},
	{"ln16", "NAVIGATOR (2016)"},
	{"evora", "EVORA (2011)"},
	{"exigev6", "EXIGE (2017)"},
	{"es1", "ES1 (1999)"},
	{"mc12", "MC12 (2005)"},
	{"ceo", "QATROPORTE (2013)"},
	{"rx3", "RX3 (1973)"},
	{"mz3", "SPEED3 (2009)"},
	{"04mpv", "MPV (2004)"},
	{"na6", "MX miata (1994)"},
	{"rx811", "RX8 (2011)"},
	{"f1", "F1 (1993)"},
	{"p1gtr", "P1 GTR (2017)"},
	{"senna", "SENNA (2019)"},
	{"500w124", "E500 (1991)"},
	{"a45", "A45 (2017)"},
	{"amggt", "AMG GT (2016)"},
	{"brabus700", "G 6X6  (2017)"},
	{"c63s", "C63S (2016)"},
	{"cl65", "CL65 (2010)"},
	{"cla45sb2", "CLA45S (2016)"},
	{"cls500w219", "CLS500 (2008)"},
	{"classb", "CLS63 (2015)"},
	{"w210", "E420 (1997)"},
	{"g770", "G63 (2018)"},
	{"g63", "G63 (2019)"},
	{"gclass", "G65 (2017)"},
	{"gl63", "GL63 (2015)"},
	{"amggtsmansory", "AMG GT )"},
	{"mbh", "Maybach 62s (2005)"},
	{"pro1", "PROJECT ONE (2020)"},
	{"mb18", "S63 (2018)"},
	{"s63w222", "S63 (2017)"},
	{"s65", "S65 (2009)"},
	{"w140s600", "S600 (1998)"},
	{"sl6509", "SL65 (2009)"},
	{"slsamg", "SLS AMG (2015)"},
	{"mercxclass", "XCLASS (2019)"},
	{"moss", "MOSS (2009)"},
	{"cooperworks", "COOPER WORKS (2019)"},
	{"eclipse", "ECLIPSE GSX (1999)"},
	{"cp9a", "EVO V (1998)"},
	{"fq360", "EVO IX (2005)"},
	{"evo10", "EVO X (2016)"},
	{"pajieluo", "PAJERO (2015)"},
	{"nisaltima", "ALTIMA (2008)"},
	{"tule", "ARMADA (2018)"},
	{"leaf", "LEAF (2015)"},
	{"tulenis", "PATROL NISMO (2019)"},
	{"patroly60", "PATROL SAFARI (1997)"},
	{"patrolsafari4", "PATROL VTC (2016)"},
	{"patrolsafari-patrolgl-patrolturbo", "PATROL VTC (2016)"},
	{"qashqai16", "QASHQAI (2016)"},
	{"nr390", "R390R (1998)"},
	{"nisy", "GTR33 (1996)"},
	{"silvia3", "SILVIA14 (1996)"},
	{"silvia15", "SILVIA15 (1999)"},
	{"dk350z", "Z350 (2006)"},
	{"370z", "Z370 NISMO (2017)"},
	{"jgtc34", "GTR34 JGTC (2002)"},
	{"huayrar", "HUAYRA roadster (2018)"},
	{"paganiragno", "ZONDA LMR (2016)"},
	{"ktkzr", "ZONDA R (2010)"},
	{"gt1", "991 GT1 (1998)"},
	{"por9", "P959 (1986)"},
	{"718b", "BOXSTER (2017)"},
	{"pcs18", "CAYENNE (2018)"},
	{"718caymans", "CAYMAN S (2019)"},
	{"911gt2", "911 GT (1990)"},
	{"por911gt3", "911 GT3 (2005)"},
	{"macanpd600m", "MACAN (2018)"},
	{"pturismo", "PANAMERA TURBO (2019)"},
	{"pgto", "GTO (1966)"},
	{"17cliofl", "CLIO 4 (2017)"},
	{"pacev", "ESPACE (2015)"},
	{"rculi", "CULLINAN (2019)"},
	{"dawn", "DAWN (2016)"},
	{"rrphantom", "PHANTOM  VIII (2018)"},
	{"silver67", "SILVER SHADOW (1967)"},
	{"sweptail", "SWEPTAIL (2017)"},
	{"wraith", "WRATH (2019)"},
	{"spyker", "C8 (2010)"},
	{"saleens7", "S7 (2002)"},
	{"smt", "SMART (2013)"},
	{"subwrx", "WRX (2004)"},
	{"sti11", "STI (2011)"},
	{"slega", "LAGECY (1990)"},
	{"vivio", "VIVIO (1993)"},
	{"suzukigv", "GRAND VITARA (2010)"},
	{"suzuswift", "SWIFT (2008)"},
	{"teslapd", "MODEL S (2019)"},
	{"teslax", "MODEL X (2018)"},
	{"cmr06", "CAMRY (2006)"},
	{"cam08", "CAMRY (2008)"},
	{"camry18", "CAMRY (2018)"},
	{"celica", "CELICA GT  (1992)"},
	{"celicaa", "CELICA GT  (1974)"},
	{"fj40", "FJ (1978)"},
	{"fjc", "FJ TRD (2018)"},
	{"landv6", "LAND CRUISER LX  (2017)"},
	{"lc100", "LAND CRUISER XV (2007)"},
	{"autana97", "LAND CRUISER GX (1997)"},
	{"prius", "PRIUS (2015)"},
	{"rav4", "RAV 4 (2010)"},
	{"siennas", "SIENNA (2011)"},
	{"sienna", "SIENNA (2017)"},
	{"tsup3", "SUPRA (1992)"},
	{"toyft1", "FT-1 (2017)"},
	{"grsupra", "SUPRA  (2020)"},
	{"supraa90", "SUPRA (2019)"},
	{"vwtouareg", "TOUAREG (2017)"},
	{"xc60", "XC60 (2019)"},
	{"aprt", "Tuono"},
	{"bmws", "S1000 RR"},
	{"bmws1", "S1000 RR"},
	{"bmwsr", "1100 R"},
	{"bmwsrn", "1100 R"},
	{"p51", "P51 COMBAT"},
	{"d99", "1199 Panigale"},
	{"ddrr", "Desmosedici RR"},
	{"diavel", "Diavel"},
	{"dgp15", "GP15"},
	{"dgp215", "GP15"},
	{"hdfb", "FAT BOY Lo Vintage"},
	{"hdss", "FXSTS Springer Softail"},
	{"hcb1000", "CB 1000 R"},
	{"hcb18", "CB 1800 "},
	{"honcbr", "CBR 1000 RR"},
	{"honcbf", "CB 650 F"},
	{"hf150", "FAN 150"},
	{"hor600", "HORNET 600F"},
	{"hlcr", "LCR"},
	{"hmarc", "VDS"},
	{"hrc213", "RC213V"},
	{"hrcp213", "RC213V"},
	{"hxre", "XRE 300"},
	{"goldwing", "GOLDWING"},
	{"hfc250", "FC 250"},
	{"hsmxe", "SM - MX 450"},
	{"hsmr", "SMR 610"},
	{"nh2r", "NINJA H2"},
	{"ke400", "Eliminator 400SE"},
	{"kgpz", "GPZ 1100"},
	{"kx450f", "KX450F"},
	{"knh22", "NINJA H2R"},
	{"zx10", "NINJA ZX-10R"},
	{"kza1000", "Z1000 A1"},
	{"kz750", "Z750"},
	{"sxf450", "450 SX-F"},
	{"ktmtrr", "EXC 530 TRR"},
	{"ktmpit", "PitBike"},
	{"ktmrc", "RC 390"},
	{"ktmrc8", "RC8 1190 R"},
	{"mvaf", "F4RR"},
	{"mvab", "Brutale 800"},
	{"sban", "Bandit 1250N"},
	{"gsxr", "GSX 1000R"},
	{"sgsx13", "HAYABUSA"},
	{"srmz2", "RMZ 250"},
	{"ss750", "SRAD 750"},
	{"hayabusa", "HAYABUSA"},
	{"tmrs", "SUPERMOTARD"},
	{"yfz68", "FZ6"},
	{"yrd1", "R1"},
	{"yr1", "R1"},
	{"yss", "STAR STRYKER"},
	{"yxj6", "XJ6"},
	{"xj6", "XJ6-F"},
	{"yxt", "XT 660"},
	{"yzf", "YZ250F"},
	{"r3", "YFZ R3"},
	{"r6", "YFZ R6"},
	{"spcj", "SCORPIO 225"},
	{"ae86", "Toyota AE86 Sprinter Trueno GT"},
	{"350zrb", "Nissan 350z Rocket Bunny"},
	{"na1", "Honda NSX-R (NA1)"},
	{"gtr17", "Nissan GTR (R35)"},
	{"16ss", "Chevrolet Camaro SS (2016)"},
	{"apollo", "Apollo Intensa Emozione"},
	{"epit", "Laraki Epitome"},
	{"jes", "Koenigsegg Jesko"},
	{"gr1", "SRT Tomahawk Vision"},
	{"rx7tunable", "Mazda RX7 FD3S"},
	{"exor", "Camaro Exorcist ZL1"},
	{"str20", "2020 Porsche 911 Speedster"},
	{"rmodsupra", "Toyota Supra MKIV "},
	{"rmodamgc63", "Mercedes-AMG C63 S Coupe"},
	{"fulux63", "1963 Volkswagen Beetle"},
	{"rmodpolice", "Police GTR"},
	{"lp610", "Huracan Spyder"},
	{"610lb", "Huracan [LibertyWalk]"},
	{"rmodveneno", "Lamborghini ni Osus"},
	{"993rwb", "Porsche 911 GT-2 RWB"},
	{"fxxk16", "2015 Flavio Manzoni Ferrari FXX K"},
	{"bmci", "2018 BMW M5 F90"},
	{"fxxk", "Ferrari FXX K"},
	{"350z", "Nissan 370Z Nismo Z34"},
	{"delsoleg", "Honda Civic EG VTI 94"},
	{"devilz", "Nissan S30Z"},
	{"rcf", "2015 Lexus RCF"},
	{"brz", "Rocket Bunny V3 BRZ"},
	{"na6", "Miata"},
	{"180sx", "Nissan 180SX"},
	{"mk2100", "Toyota JZX100"},
	{"zn20", "Zenvo TSR-S"},
	{"rwdp30", "RWD P30-6"},
	{"50thpolstang", "Unmarked Mustang"},
	{"audiq8", "EMS Audi Q8"},
	{"720s", "McLaren 720s"},
	{"19gt500", "Mustang Shelby GT500"},
	{"c7", "Chevrolet Corvette C7"},
	{"dyc3db11", "Aston Martin DB11"},
	{"raptor150", "Ford Raptor"},
	{"f248", "Ferrari F248"},
	{"audir8lms2", "Audi R8 LMS Ultra Racecar"},
	{"rmodlp770", "Lamborghini Centenario LP770-4"},
	{"rmodskyline", "Nissan Skyline GT-R ni PapaBear"},
	{"skyline", "Nissan Skyline GT-R"},
	{"rmodmustang", "Ekalam Mustang"},
	{"avj", "Aventador J Speedster"},
	{"laferrari17", "LaFerrari Aperta 2017"},
	{"hondacivictr", "Honda Civic Type R"},
	{"pandema90", "2020 Toyota Supra A90"},
	{"c8", "2020 Chevrolet Corvette C8"},
	{"fd2", "2008 Honda Civic Type-R"},
	{"demonhawk", "Jeep DEMONHAWK"},
	{"dc5", "Honda Integra Type-R (DC5)"},
	{"evo9", "Evolution IX"},
	{"civic", "Honda Civic SI"},
	{"rmodmi8", "BMW I8 Roadster AC Schnitzer"},
	{"rmodbmwi8", "2015 BMW i8"},
	{"lp770r", "Centenario Roadster"},
	{"f82", "2015 BMW F82 M4"},
	{"bmwx7", "BMW X7 Concept"},
	{"z4alchemist", "BMW Z4 Alch"},
	{"centuria", "Chiron Mansory Centuria"},
	{"plegend", "Peugeot Concept"},
	{"gallardosuperlb", "Superlaggera LB"},
	{"biome", "Mercedes Concept"},
	{"shifter_kart", "Go Kar"},
	{"bdivo", "Bugatti Divo"},
	{"2f2fgtr34", "FNF GTR r34(ERROR)"},
	{"2f2fgts", "FNF eclipse"},
	{"2f2fmk4", "FNF Supra mk4"},
	{"2f2fmle7", "FNF Evo VII"},
	{"ff4wrx", "FNF WRX STI"},
	{"fnf4r34", "FNF R34 (blue)"},
	{"fnflan", "FNF Evo 9 (ERROR)"},
	{"ffmk4", "FNF Supra"},
	{"fnfrx7", "FNF RX7"},
	{"r18", "2016 Audi R18 "},
	{"rx7", "Mazda RX-F7 BLS"},
	{"amggtsprior", "AMG GT-S Prior"},
	{"rt70", "Dom's Dodge Charger"},
	{"develsix", "Devel Sixteen"},
	{"gtrlms", "FORD GTR LMS"},
	{"lfa", "Lexus LFA"},
	{"hilux1", "Toyota Hilux"},
	{"contss18", "Continental GT"},
	{"vagner2", "Dewbauchee Vagner"},
	{"lambokart", "Lambo Kart"},
	{"s15mak", "Nissan Silvia S15"},
	{"m3gtr", "NFS M3"},
	{"zr", "Pagani Zonda R"},
	{"g63mg", "Mansory AMG G63"},
	{"dzsb", "2014 rolls Royce Phantom"},
	{"lw458s", "458 Liberty Walk"},
	{"bugatticentodieci", "Bugatti Centodieci"},
	{"chargerf8", "Dodge Charger"},
	{"rx7twerk", "Mazda Rx7 Fc3"},
	{"cp9a", "Mitsubishi Lancer Evo VI"},
	{"kcg10", "1971 Skyline"},

}

Citizen.CreateThread(function()
  for _, v in pairs(theVehicles) do 
	AddTextEntryByHash(GetHashKey(v[1]), v[2])
  end
end)