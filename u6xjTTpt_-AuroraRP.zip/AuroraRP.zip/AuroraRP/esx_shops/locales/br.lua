Locales['br'] = {
	['shop'] = 'comprar',
	['shops'] = 'lojas',
	['press_menu'] = 'pressione ~INPUT_CONTEXT~ para acessar a loja.',
	['bought'] = 'you just bought ~y~%sx~s~ ~b~%s~s~ for ~r~$%s~s~',
	['not_enough'] = 'você não tem ~r~dinheiro suficiente~s~: %s',
	['player_cannot_hold'] = 'você ~r~não~s~ tem bastante ~y~espaço livre~s~ no seu inventário!',
	['shop_confirm'] = 'buy %sx %s for $%s?',
	['no'] = 'no',
	['yes'] = 'yes',
}
