Locales['en'] = {
  -- regulars
  	['duty'] = 'Press ~INPUT_CONTEXT~ to ~g~on~s~/~r~off~s~ duty',
	['onduty'] = 'You went on duty.',
	['offduty'] = 'You went off duty.',
	['notpol'] = 'You are not a policemen.',
	['notamb'] = 'You are not a doctor.',
}
