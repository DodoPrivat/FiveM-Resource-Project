Config                            = {}
Config.DrawDistance               = 100.0
--language currently available EN and SV
Config.Locale                     = 'en'

Config.Zones = {

  PoliceDuty = {
    Pos   = { x = 439.825, y = -975.693, z = 29.691 },
    Size  = { x = 2.5, y = 2.5, z = 1.5 },
    Color = { r = 0, g = 255, b = 0 },  
    Type  = 27,
  },

  AmbulanceDuty = {
    Pos = { x = 309.31, y = -602.88, z = 42.3 },
    Size = { x = 2.5, y = 2.5, z = 1.5 },
    Color = { r = 0, g = 255, b = 0 },
    Type = 27,
  },
  MechanicDuty = {
    Pos = { x = -206.6, y = -1341.86, z = 33.89 },
    Size = { x = 2.5, y = 2.5, z = 1.5 },
    Color = { r = 255, g = 255, b = 153 },
    Type = 27,
  },
  MilitaryDuty = {
    Pos = { x = -2349.84, y = 3266.75, z = 31.81 },
    Size = { x = 2.5, y = 2.5, z = 1.5 },
    Color = { r = 255, g = 255, b = 153 },
    Type = 27,
  },
  CarDealerDuty = {
    Pos = { x = -367.4, y = -110.75, z = 46.78 },
    Size = { x = 2.5, y = 2.5, z = 1.5 },
    Color = { r = 255, g = 255, b = 153 },
    Type = 27,
  },
  --[[CityHallDuty = {
    Pos = { x = 211.83, y = -901.51, z = 35.79 },
    Size = { x = 2.5, y = 2.5, z = 1.5 },
    Color = { r = 255, g = 255, b = 153 },
    Type = 27,
  },]]--
}