Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale = 'en'

Config.EnableJobBlip              = true

Config.MafiaStations = {

  news = {

    Blip = {
      Pos     = { x = 425.130, y = -979.558, z = 30.711 },
      Sprite  = 60,
      Display = 4,
      Scale   = 1.2,
      Colour  = 29,
    },

    AuthorizedWeapons = {
      --[[{ name = 'WEAPON_COMBATPISTOL',     price = 4000 },
      { name = 'WEAPON_ASSAULTSMG',       price = 15000 },
      { name = 'WEAPON_ASSAULTRIFLE',     price = 25000 },
      { name = 'WEAPON_PUMPSHOTGUN',      price = 9000 },
      { name = 'WEAPON_STUNGUN',          price = 250 },
      { name = 'WEAPON_FLASHLIGHT',       price = 50 },
      { name = 'WEAPON_FIREEXTINGUISHER', price = 50 },
      { name = 'WEAPON_FLAREGUN',         price = 3000 },
      { name = 'GADGET_PARACHUTE',        price = 2000 },
      { name = 'WEAPON_SNIPERRIFLE',      price = 50000 },
      { name = 'WEAPON_FIREWORK',         price = 5000 },
      { name = 'WEAPON_BZGAS',            price = 8000 },
      { name = 'WEAPON_SMOKEGRENADE',     price = 8000 },
      { name = 'WEAPON_APPISTOL',         price = 12000 },
      { name = 'WEAPON_CARBINERIFLE',     price = 25000 },
      { name = 'WEAPON_HEAVYSNIPER',      price = 100000 },
      { name = 'WEAPON_FLARE',            price = 8000 },
      { name = 'WEAPON_SWITCHBLADE',      price = 500 },
	  { name = 'WEAPON_REVOLVER',         price = 6000 },
	  { name = 'WEAPON_POOLCUE',          price = 100 },
	  { name = 'WEAPON_GUSENBERG',        price = 17500 },
	  ]]--
    },

	  AuthorizedVehicles = {
		  { name = 'rumpo',  label = 'Project X News Van' },
		  
	  },

    Cloakrooms = {
      --{ x = -132.69, y = -632.59, z = 168.82 },
    },

    Armories = {
      { x = -797.75, y = 187.05, z = 71.61 },
    },

    Vehicles = {
      {
        Spawner    = { x = -1096.16, y = -255.18, z = 36.68 },
        SpawnPoint = { x = -1101.38, y = -261.45, z = 36.7 },
        Heading    = 205.01,
      }
    },
	
	Helicopters = {
      {
        Spawner    = { x = -1087.52, y = -248.79, z = 57.97 },
        SpawnPoint = { x = -1081.0, y = -250.78, z = 59.17 },
        Heading    = 116.96,
      }
    },

    VehicleDeleters = {
      { x = -1100.18, y = -255.53, z = 37.72 }
      --{ x = 21.35, y = 543.3, z = 175.027 },
    },

    BossActions = {
      { x = -1054.51, y = -231.86, z = 43.02 }
    },

  },

}