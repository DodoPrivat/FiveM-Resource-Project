Locales['de'] = {
  ['have_withdrawn']      = 'abgehoben ~g~$',
  ['invalid_amount']      = 'ungültiger Betrag',
  ['have_deposited']      = 'eingezahlt ~r~$',
  ['you_have']            = 'du hast ~g~$',
  ['you_have_laundered']  = 'du hast dein Geld ~r~gewaschen~s~: ~g~$',
}
