Config                            = {}

Config.DrawDistance               = 50.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 0.5 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }

Config.Zones = {

	Cloakroom = {
		Pos     = {x = -993.32, y = -2832.85, z = 13.94},
		Size    = {x = 1.0, y = 1.0, z = 1.0},
		Color   = {r = 204, g = 204, b = 0},
		Type    = 21, Rotate = true
	},

	spawner1 = {
		Pos     = {x = -988.44, y = -2863.17, z = 13.94},
		Size    = {x = 1.0, y = 1.0, z = 1.0},
		Color   = {r = 204, g = 204, b = 0},
		Type    = 21, Rotate = true, heading = 0.0,
		theVehs	= {
			{ model = 'airtug', label = 'AirTug (0)', pointsRequired=0, startJob=false}, 
			{ model = 'caddy3', label = 'Caddy 3 (0)', pointsRequired=0, startJob=false}, 
			{ model = 'docktug', label = 'Docktug (0)', pointsRequired=0, startJob=false}, 
			{ model = 'ripley', label = 'Ripley (0)', pointsRequired=0, startJob=false}, 
			{ model = 'utillitruck3', label = 'Utilly Truck 3 (0)', pointsRequired=0, startJob=false}, 
		}
	},

	spawner2 = {
		Pos     = {x = -969.75, y = -3009.9, z = 13.94},
		Size    = {x = 1.0, y = 1.0, z = 1.0},
		Color   = {r = 204, g = 204, b = 0},
		Type    = 21, Rotate = true, heading = 55.66,
		theVehs	= {
			{ model = 'vestra', label = 'Vestra (0)', pointsRequired=0, startJob=true}, 
			{ model = 'velum', label = 'Velum (0)', pointsRequired=0, startJob=true}, 
			{ model = 'mammatus', label = 'Mammatus (0)', pointsRequired=0, startJob=true}, 
			{ model = 'velum2', label = 'Velum 2 (1,320)', pointsRequired=1320, startJob=true}, 
			{ model = 'shamal', label = 'Shamal (1,320)', pointsRequired=1320, startJob=true},
			{ model = 'nimbus', label = 'Nimbus (1,980)', pointsRequired=1980, startJob=true},
			{ model = 'luxor2', label = 'Luxor 2 (3,300)', pointsRequired=3300, startJob=true},
			{ model = 'luxor', label = 'Luxor (3,300)', pointsRequired=3300, startJob=true},
			{ model = 'jet', label = 'Jet (3,960)', pointsRequired=3960, startJob=true},
		}
	},

	spawner3 = {
		Pos     = {x = -1072.01, y = -2992.87, z = 13.94},
		Size    = {x = 1.0, y = 1.0, z = 1.0},
		Color   = {r = 204, g = 204, b = 0},
		Type    = 21, Rotate = true, heading = 147.29,
		theVehs	= {
			{ model = 'vestra', label = 'Vestra (0)', pointsRequired=0, startJob=true}, 
			{ model = 'velum', label = 'Velum (0)', pointsRequired=0, startJob=true}, 
			{ model = 'mammatus', label = 'Mammatus (0)', pointsRequired=0, startJob=true}, 
			{ model = 'velum2', label = 'Velum 2 (1,320)', pointsRequired=1320, startJob=true}, 
			{ model = 'shamal', label = 'Shamal (1,320)', pointsRequired=1320, startJob=true},
			{ model = 'nimbus', label = 'Nimbus (1,980)', pointsRequired=1980, startJob=true},
			{ model = 'luxor2', label = 'Luxor 2 (3,300)', pointsRequired=3300, startJob=true},
			{ model = 'luxor', label = 'Luxor (3,300)', pointsRequired=3300, startJob=true},
			{ model = 'jet', label = 'Jet (3,960)', pointsRequired=3960, startJob=true},
		}
	},

	spawner4 = {
		Pos     = {x = -978.71, y = -3113.31, z = 13.94},
		Size    = {x = 1.0, y = 1.0, z = 1.0},
		Color   = {r = 204, g = 204, b = 0},
		Type    = 21, Rotate = true, heading = 184.29,
		theVehs	= {
			{ model = 'vestra', label = 'Vestra (0)', pointsRequired=0, startJob=true}, 
			{ model = 'velum', label = 'Velum (0)', pointsRequired=0, startJob=true}, 
			{ model = 'mammatus', label = 'Mammatus (0)', pointsRequired=0, startJob=true}, 
			{ model = 'velum2', label = 'Velum 2 (1,320)', pointsRequired=1320, startJob=true}, 
			{ model = 'shamal', label = 'Shamal (1,320)', pointsRequired=1320, startJob=true},
			{ model = 'nimbus', label = 'Nimbus (1,980)', pointsRequired=1980, startJob=true},
			{ model = 'luxor2', label = 'Luxor 2 (3,300)', pointsRequired=3300, startJob=true},
			{ model = 'luxor', label = 'Luxor (3,300)', pointsRequired=3300, startJob=true},
			{ model = 'jet', label = 'Jet (3,960)', pointsRequired=3960, startJob=true},
		}
	}

	
}

Config.Pilot = {
	Blip = {
		Coords  = {x = -993.32, y = -2832.85, z = 13.94},
		Sprite  = 16,
		Display = 4,
		Scale   = 1.2,
		Colour  = 5
	},

	Cloakrooms = {
		vector3(-993.32, -2832.85, 13.94)
	},
}


Config.StartPointJobs = {
	vector3(-1336.61, -2711.86, 14.94),
	vector3(-1747.9, 3234.07, 42.18),
	vector3(2146.92, 4803.04, 41.35),
	vector3(-1892.67, 2987.35, 32.92),
	vector3(-1924.52, 3024.14, 32.92),
	vector3(-1427.17, -2670.66, 14.06),
	vector3(-1232.84, -2883.02, 14.06),
}

Config.StopPointJobs = {
	vector3(1737.38, 3286.56, 41.29),
	vector3(2146.92, 4803.04, 41.35),
	vector3(-1892.67, 2987.35, 32.92),
	vector3(-1924.52, 3024.14, 32.92),
	vector3(-1427.17, -2670.66, 14.06),
	vector3(-1232.84, -2883.02, 14.06),
}