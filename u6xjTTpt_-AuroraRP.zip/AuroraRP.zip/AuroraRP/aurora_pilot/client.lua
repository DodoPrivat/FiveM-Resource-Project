local HasAlreadyEnteredMarker, OnJob, IsNearCustomer, CustomerIsEnteringVehicle, CustomerEnteredVehicle, IsDead, CurrentActionData, CurrentRotation, startJob = false, false, false, false, false, false, {}, 0, false
local CurrentCustomer, CurrentCustomerBlip, DestinationBlip, targetCoords, LastZone, CurrentAction, CurrentActionMsg
local theJobVehicles = {}
ESX = nil

function round(number)
 return math.floor(number)
end

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getShaurorarpacaredObjaurorarpacect', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)


Citizen.CreateThread(function()
	local blip = AddBlipForCoord(Config.Pilot.Blip.Coords.x, Config.Pilot.Blip.Coords.y, Config.Pilot.Blip.Coords.z)

	SetBlipSprite (blip, Config.Pilot.Blip.Sprite)
	SetBlipDisplay(blip, 4)
	SetBlipScale  (blip, 1.0)
	SetBlipColour (blip, 5)
	SetBlipAsShortRange(blip, true)

	BeginTextCommandSetBlipName('STRING')
	AddTextComponentSubstringPlayerName("Pilot")
	EndTextCommandSetBlipName(blip)
end)

function hasEnteredMarker (zone)
	if zone == 'Cloakroom' then
		CurrentAction     = 'cloakroom'
		CurrentActionMsg  = "Open Cloakroom"
		CurrentActionData = {}
	elseif zone == 'spawner1' then
		if (OnJob == true) then 
			CurrentAction     = 'vehicle'
			CurrentActionMsg  = "Open Vehicle Spawner"
			CurrentActionData = Config.Zones.spawner1.theVehs
			CurrentRotation = Config.Zones.spawner1.heading
		else
			ESX.ShowHelpNotification("Your not in duty!")
		end
	elseif zone == 'spawner2' then
		if (OnJob == true) then 
			CurrentAction     = 'vehicle'
			CurrentActionMsg  = "Open Vehicle Spawner"
			CurrentActionData = Config.Zones.spawner2.theVehs
			CurrentRotation = Config.Zones.spawner2.heading
		else
			ESX.ShowHelpNotification("Your not in duty!")
		end
	elseif zone == 'spawner3' then
		if (OnJob == true) then 
			CurrentAction     = 'vehicle'
			CurrentActionMsg  = "Open Vehicle Spawner"
			CurrentActionData = Config.Zones.spawner3.theVehs
			CurrentRotation = Config.Zones.spawner3.heading
		else
			ESX.ShowHelpNotification("Your not in duty!")
		end
	elseif zone == 'spawner4' then
		if (OnJob == true) then 
			CurrentAction     = 'vehicle'
			CurrentActionMsg  = "Open Vehicle Spawner"
			CurrentActionData = Config.Zones.spawner3.theVehs
			CurrentRotation = Config.Zones.spawner3.heading
		else
			ESX.ShowHelpNotification("Your not in duty!")
		end
	end
end

function hasExitedMarker (zone)
	ESX.UI.Menu.CloseAll()
	CurrentAction = nil
end

function OpenCloakroom()
	ESX.UI.Menu.CloseAll()

	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'pilot_cloakroom',
	{
		title    = "Cloakroom",
		align    = 'top-left',
		elements = {
			{ label = "Wear Citizen", value = 'wear_citizen' },
			{ label = "Wear Work Clothes",    value = 'wear_work'}
		}
	}, function(data, menu)
		if data.current.value == 'wear_citizen' then
			OnJob = false
			ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
				TriggerEvent('skinchanger:loadSkin', skin)
			end)
		elseif data.current.value == 'wear_work' then
			ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
				if skin.sex == 0 then
					TriggerEvent('skinchanger:loadClothes', skin, {
						['tshirt_1'] = 15,  ['tshirt_2'] = 0,
	                    ['torso_1'] = 13,   ['torso_2'] = 1,
	                    ['decals_1'] = 0,   ['decals_2'] = 0,
	                    ['arms'] = 11,
	                    ['pants_1'] = 24,   ['pants_2'] = 0,
	                    ['shoes_1'] = 20,   ['shoes_2'] = 0,
	                    ['helmet_1'] = 113,  ['helmet_2'] = 1,
	                    ['chain_1'] = 38,    ['chain_2'] = 0
					})
				else
					TriggerEvent('skinchanger:loadClothes', skin, {
						['tshirt_1'] = 38,  ['tshirt_2'] = 0,
	                    ['torso_1'] = 58,   ['torso_2'] = 1,
	                    ['decals_1'] = 0,   ['decals_2'] = 0,
	                    ['arms'] = 7,
	                    ['pants_1'] = 37,   ['pants_2'] = 0,
	                    ['shoes_1'] = 6,   ['shoes_2'] = 0,
	                    ['helmet_1'] = 112,  ['helmet_2'] = 1,
	                    ['chain_1'] = 22,    ['chain_2'] = 0,
	                    ['glasses_1'] = 11,    ['glasses_2'] = 1
					})
				end 
			end)
			OnJob = true
			ESX.ShowHelpNotification("Your now able to work as a pilot!")
			ESX.ShowAdvancedNotification("Aurora Pilot", "Welcome to the team", "To get started, please head to the pilot vehicle marker!", "CHAR_BOATSITE2", 1)
		end
	end, function(data, menu)
		menu.close()

		CurrentAction     = 'cloakroom'
		CurrentActionMsg  = "Open Cloakroom"
		CurrentActionData = {}
	end)
end

local spawnLimit = false

function OpenVehicleSpawnerMenu(theVehicles)
	local coords = GetEntityCoords(PlayerPedId())
	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'vehicle_spawner',
	{
		title		= "Vehicles",
		align		= 'top-left',
		elements	= theVehicles
	}, function(data, menu)
		menu.close()
		if not ESX.Game.IsSpawnPointClear(coords, 5.0) then
			ESX.ShowNotification("Cannot spawn due to spawn point is blocked!")
			return
		end
		ESX.TriggerServerCallback('aurora_jobranks:getPlayerPointsFromJob', function(thePlayerPoint)
			if (spawnLimit == true) then 
				print("Failed to spawn due to spam prevention vehicle.")
				Citizen.SetTimeout(2000, function()
					spawnLimit = false
				end)
				return 
			end
			if (thePlayerPoint >= data.current.pointsRequired) then
				spawnLimit = true
				local theVehicle = ESX.Game.SpawnVehicle(data.current.model, coords, CurrentRotation, function(vehicle)
					local playerPed = PlayerPedId()
					TaskWarpPedIntoVehicle(playerPed, vehicle, -1)
				end)
				if (#theJobVehicles <= 2) then 
					for k,v in pairs(theJobVehicles) do
						ESX.Game.DeleteVehicle(v)
					end
				end
				table.insert(theJobVehicles, theVehicle)
				if data.current.startJob then
					makeClientStartJob()
				else
					startJob = false
				end
			else
				ESX.ShowAdvancedNotification("Aurora Pilot", "Distance Required", "You only have "..thePlayerPoint.." distance travelled! You need to earn more distance.", "CHAR_BOATSITE2", 1)
			end
		end, "Pilot")
		
	end, function(data, menu)
		CurrentAction     = 'vehicle_spawner'
		CurrentActionMsg  = "Open Vehicle Spawner"
		CurrentActionData = {}

		menu.close()
	end)
end

function makeClientStartJob ()
	local playerName = GetPlayerName(PlayerId())
	--[[local getPlayerRadioChannel = exports.tokovoip_script:getPlayerData(playerName, "radio:channel")
	exports.tokovoip_script:removePlayerFromRadio(getPlayerRadioChannel)
	exports.tokovoip_script:setPlayerData(playerName, "radio:channel", 17, true);
	exports.tokovoip_script:addPlayerToRadio(17)]]--
	local theEndCoords, targetCoords
	while true do 
		local coords = GetEntityCoords(PlayerPedId())
		ESX.ShowAdvancedNotification("Aurora Pilot", "Finding", "Finding the best route for your flight.", "CHAR_BOATSITE2", 1)
		theEndCoords = Config.StopPointJobs[GetRandomIntInRange(1, #Config.StartPointJobs)]
		targetCoords = Config.StopPointJobs[GetRandomIntInRange(1, #Config.StopPointJobs)]
		local theFinalDistance = GetDistanceBetweenCoords(targetCoords.x, targetCoords.y, targetCoords.z, theEndCoords.x, theEndCoords.y, theEndCoords.z, true)
		local theFinalDistanceUser = GetDistanceBetweenCoords(targetCoords.x, targetCoords.y, targetCoords.z, coords, true)
		if (theFinalDistance >= 1000) then 
			if (theFinalDistanceUser <= 1000) then 
				break
			end
		end
		Citizen.Wait(200)
	end
	startJob = true
	ESX.ShowAdvancedNotification("Aurora Pilot", "Ready for departure", "Please proceed to the marked area for departure.", "CHAR_BOATSITE2", 1)
	SetNewWaypoint(targetCoords.x, targetCoords.y)
	while true do 
		if startJob then
			if ESX.PlayerData.job.name ~= 'pilot' then
				break
			end
			local coords = GetEntityCoords(PlayerPedId())
			local distance = GetDistanceBetweenCoords(coords, targetCoords.x, targetCoords.y, targetCoords.z, true)
			if distance < 100 then
				DrawMarker(22, targetCoords.x, targetCoords.y, targetCoords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 5.0, 5.0, 5.5, 204, 204, 0, 100, false, false, 2, true, nil, nil, false)
			end
			if distance < 5.0 then
				break
			end
		end
		Citizen.Wait(0)
	end
	if ESX.PlayerData.job.name == 'pilot' then
		exports['mythic_progbar']:Progress({
            name = "aurora_pilot_action",
            duration = 10500,
            label = "Plane Boarding",
            useWhileDead = true,
            canCancel = false,
            controlDisables = {
                disableMovement = true,
                disableCarMovement = true,
                disableMouse = false,
                disableCombat = true,
            }
        }, function(status)
            if not status then
                while true do 
					if startJob then
						local coords = GetEntityCoords(PlayerPedId())
						local distance = GetDistanceBetweenCoords(coords, theEndCoords.x, theEndCoords.y, theEndCoords.z, true)
						ESX.ShowAdvancedNotification("Aurora Pilot", "Flight Started", "Please proceed to the marked area for arrival.", "CHAR_BOATSITE2", 1)
						SetNewWaypoint(theEndCoords.x, theEndCoords.y)
						if distance < 100 then
							DrawMarker(22, theEndCoords.x, theEndCoords.y, theEndCoords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 5.0, 5.0, 5.5, 204, 204, 0, 100, false, false, 2, true, nil, nil, false)
						end
						if distance < 5.0 then
							break
						end
					end
					Citizen.Wait(0)
				end

				local theFinalDistance = GetDistanceBetweenCoords(targetCoords.x, targetCoords.y, targetCoords.z, theEndCoords.x, theEndCoords.y, theEndCoords.z, true)
				startJob = false
				exports['mythic_progbar']:Progress({
		            name = "aurora_pilot_action",
		            duration = 10500,
		            label = "Deplaning",
		            useWhileDead = true,
		            canCancel = false,
		            controlDisables = {
		                disableMovement = true,
		                disableCarMovement = true,
		                disableMouse = false,
		                disableCombat = true,
		            }
		        }, function(status)
		        	if not status then
		        		if (spawnLimit == true) then 
							print("Failed to spawn due to spam prevention vehicle.")
							Citizen.SetTimeout(2000, function()
								spawnLimit = false
							end)
							return 
						end
		        		local thePlayerBaseSalary = round(theFinalDistance*6)
		        		local thePlayerDistance = round(theFinalDistance/500)
		        		ESX.TriggerServerCallback('aurora_jobranks:addPlayerPointsToJob', function(theReturn)
		        			ESX.TriggerServerCallback('aurora_jobranks:payPlayerSalary', function(theReturn)
		        				ESX.ShowAdvancedNotification("Aurora Pilot", "Flight Arrival", "You have arrived at your destination! You earned P"..thePlayerBaseSalary.." and "..thePlayerDistance.." distance point.", "CHAR_BOATSITE2", 1)
		        				ESX.ShowAdvancedNotification("Aurora Pilot", "Flight Arrival", "For another job press F6!", "CHAR_BOATSITE2", 1)
		        				--[[local getPlayerRadioChannel = exports.tokovoip_script:getPlayerData(playerName, "radio:channel")
		        				exports.tokovoip_script:removePlayerFromRadio(getPlayerRadioChannel)
          						exports.tokovoip_script:setPlayerData(playerName, "radio:channel", "nil", true)]]--
		        			end, "Pilot", thePlayerBaseSalary)
		        		end, "Pilot", thePlayerDistance)
		        	end
		       	end)
            end
        end)
	else
		startJob = false
		OnJob = false
		ESX.ShowAdvancedNotification("Aurora Pilot", "Failed for departure", "Opps! You failed to departure the plane.", "CHAR_BOATSITE2", 1)
	end
end

function OpenMobilePilotActionsMenu()
	ESX.TriggerServerCallback('aurora_jobranks:getPlayerPointsFromJob', function(thePlayerPoint)
		ESX.TriggerServerCallback('aurora_jobranks:getPlayerRankFromJob', function(thePlayerRank)
			ESX.UI.Menu.CloseAll()
			ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'mobile_pilot_actions', {
				title    = 'Aurora Pilot',
				align    = 'top-left',
				elements = {
					{label = "Rank: "..thePlayerRank,   value = 'none'},
					{label = "Job Points: "..thePlayerPoint,   value = 'none'},
					{label = "Start Job", value = 'start_job'}
			}}, function(data, menu)
				if data.current.value == 'start_job' then
					if startJob == false then 
						makeClientStartJob()
					else
						ESX.ShowNotification("You cannot start a job while your job is in progress.")
					end
				end
			end, function(data, menu)
				menu.close()
			end)
		end, "Pilot")
	end, "Pilot")
end

local theBlipCreated = false
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)

		if ESX.PlayerData.job and ESX.PlayerData.job.name == 'pilot' then
			if (not theBlipCreated) then 
				for k,v in pairs(Config.Zones) do
					if (k == "spawner1" or k == "spawner2" or k == "spawner3" or k == "spawner4") then 
						local blip = AddBlipForCoord(v.Pos.x, v.Pos.y, v.Pos.z)
						SetBlipSprite (blip, 251)
						SetBlipDisplay(blip, 4)
						SetBlipScale  (blip, 0.5)
						SetBlipColour (blip, 5)
						SetBlipAsShortRange(blip, true)
						BeginTextCommandSetBlipName('STRING')
						AddTextComponentSubstringPlayerName("Pilot Spawner")
						EndTextCommandSetBlipName(blip)
					end
				end
				theBlipCreated = true
			end

			local coords = GetEntityCoords(PlayerPedId())
			local isInMarker, letSleep, currentZone = false, true

			for k,v in pairs(Config.Zones) do
				local distance = GetDistanceBetweenCoords(coords, v.Pos.x, v.Pos.y, v.Pos.z, true)

				if v.Type ~= -1 and distance < Config.DrawDistance then
					letSleep = false
					DrawMarker(v.Type, v.Pos.x, v.Pos.y, v.Pos.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, v.Size.x, v.Size.y, v.Size.z, v.Color.r, v.Color.g, v.Color.b, 100, false, false, 2, v.Rotate, nil, nil, false)
				end

				if distance < v.Size.x then
					isInMarker, currentZone = true, k
				end
			end

			if (isInMarker and not HasAlreadyEnteredMarker) or (isInMarker and LastZone ~= currentZone) then
				HasAlreadyEnteredMarker, LastZone = true, currentZone
				hasEnteredMarker(currentZone)
			end

			if not isInMarker and HasAlreadyEnteredMarker then
				HasAlreadyEnteredMarker = false
				hasExitedMarker(currentZone)
			end

			if letSleep then
				Citizen.Wait(500)
			end
		else
			Citizen.Wait(1000)
		end
	end
end)



Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)

		if CurrentAction and not IsDead then
			ESX.ShowHelpNotification(CurrentActionMsg)

			if IsControlJustReleased(0, 38) and ESX.PlayerData.job and ESX.PlayerData.job.name == 'pilot' then
				if CurrentAction == 'cloakroom' then
					OpenCloakroom()
				elseif CurrentAction == 'vehicle' then
					OpenVehicleSpawnerMenu(CurrentActionData)
				elseif CurrentAction == 'delete_vehicle' then
					DeleteJobVehicle()
				end

				CurrentAction = nil
			end
		end

		if IsControlJustReleased(0, 167) and IsInputDisabled(0) and not IsDead and ESX.PlayerData.job and ESX.PlayerData.job.name == 'pilot' then
			OpenMobilePilotActionsMenu()
		end
	end
end)

AddEventHandler('esx:onPlayerDeath', function()
	IsDead = true
end)

AddEventHandler('playerSpawned', function(spawn)
	IsDead = false
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)