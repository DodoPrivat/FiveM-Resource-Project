Config              = {}

Config.DrawDistance = 30.0
Config.ZoneSize     = {x = 1.0, y = 1.0, z = 1.0}
Config.MarkerColor  = {r = 100, g = 100, b = 204}
Config.MarkerType   = 2

Config.Locale       = 'en'

Config.Zones = {
	vector3(-556.39, -194.65, 38.26)
}
