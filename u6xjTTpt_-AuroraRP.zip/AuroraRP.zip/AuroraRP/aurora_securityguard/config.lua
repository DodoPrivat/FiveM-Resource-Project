Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.MafiaStations = {

  aurorasecurity = {

    Blip = {
      Pos     = { x = 425.130, y = -979.558, z = 30.711 },
      Sprite  = 60,
      Display = 4,
      Scale   = 1.2,
      Colour  = 29,
    },

    AuthorizedWeapons = {
      --[[{ name = 'weapon_heavysniper',     price = 100000 },
      { name = 'weapon_specialcarbine',       price = 50000 },
      { name = 'weapon_assaultshotgun',     price = 50000 },
      { name = 'weapon_smokegrenade',      price = 9000 },
      { name = 'weapon_mg',          price = 80000 },]]--
    },

	  AuthorizedVehicles = {
		  --{ name = 'fxxk',  label = 'Ferrari' },
	  },

    Cloakrooms = {
      --{ x = -132.69, y = -632.59, z = 168.82 },
    },

    Armories = {
      { x = -797.75, y = 187.05, z = 71.61 },
    },

    Vehicles = {
      {
        Spawner    = { x = -142.23, y = -583.88, z = 31.42 },
        SpawnPoint = { x = -150.05, y = -595.96, z = 32.42 },
        Heading    = 156.24,
      }
    },
	
	Helicopters = {
      --[[{
        Spawner    = { x = -145.11, y = -593.44, z = 211.78 },
        SpawnPoint = { x = -145.11, y = -593.44, z = 211.78 },
        Heading    = 0.0,
      }]]--
    },

    VehicleDeleters = {
      { x = -142.95, y = -598.56, z = 31.42 }
      --{ x = 21.35, y = 543.3, z = 175.027 },
    },

    BossActions = {
      { x = -125.14, y = -640.3, z = 167.82 }
    },

  },

}