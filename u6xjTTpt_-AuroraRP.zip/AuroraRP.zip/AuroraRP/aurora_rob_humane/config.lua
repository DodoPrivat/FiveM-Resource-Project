Config = {}
Config.Locale = 'en'
Config.NumberOfCopsRequired = 9

Banks = {
	["humane_labs"] = {
		position = { ['x'] = 3536.17, ['y'] = 3660.11, ['z'] = 28.12 },
		reward = math.random(1000000,3000000),
		nameofbank = "Humane Labs",
		lastrobbed = 0
	},
}
