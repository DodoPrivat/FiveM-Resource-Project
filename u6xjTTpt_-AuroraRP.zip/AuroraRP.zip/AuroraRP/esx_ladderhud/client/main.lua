ESX	= nil

------------------------------------------------------------------
--                          Variables
------------------------------------------------------------------

local showHud = true                          -- Boolean to show / hide HUD
local hunger                                  -- Init hunger's variable. Set to 100 for development. 
local thirst                                  -- Init thirst's variable. Set to 100 for development. 


RegisterNetEvent('hideInGameHud')
AddEventHandler('hideInGameHud', function()
	SendNUIMessage({
		hideHud = true
	})
end)


RegisterNetEvent('showInGameHud')
AddEventHandler('showInGameHud', function()
	SendNUIMessage({
		showHud = true
	})
end)

------------------------------------------------------------------
--                          Functions
------------------------------------------------------------------

function updateHungerThirstHUD(hunger, thirst, inventory)
	SendNUIMessage({
		update = true,
		hunger = hunger,
		thirst = thirst,
		inventory = inventory
	})
end

function updateHungerCashHUD(cash, bank, job, bmoney, role)
	SendNUIMessage({
		update2 = true,
		cash = cash,
		bank = bank,
		job = job,
		bmoney = bmoney,
		role = role
	})
end

------------------------------------------------------------------
--                          Citizen
------------------------------------------------------------------
function dump(o)
	if type(o) == 'table' then
	   local s = '{ '
	   for k,v in pairs(o) do
		  if type(k) ~= 'number' then k = '"'..k..'"' end
		  s = s .. '['..k..'] = ' .. dump(v) .. ','
	   end
	   return s .. '} '
	else
	   return tostring(o)
	end
 end
-- Show HUD
Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getShaurorarpacaredObjaurorarpacect', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
	Citizen.Wait(5000)
end)

function firstToUpper(str)
    return (str:gsub("^%l", string.upper))
end

local theMode = 1

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(5000)
		if showHud then
			if (theMode == 1) then 
				theMode = 0
				TriggerEvent('esx_status:getStatus', 'hunger', function(hungerStatus)
					TriggerEvent('esx_status:getStatus', 'thirst', function(thirstStatus)
						updateHungerThirstHUD(hungerStatus.val / 10000, thirstStatus.val / 10000, 0)
					end)
				end)
				PlayerData = ESX.GetPlayerData()
				bmoney = "Loading.."
				bank = "Loading.."
				cash = "Loading.."
				if (type(PlayerData.accounts) == "table") then
					for k,v in ipairs(PlayerData.accounts) do
						if (v.name == "bank") then 
							bank = ESX.Math.GroupDigits(v.money)
						elseif (v.name == "black_money") then
							bmoney = ESX.Math.GroupDigits(v.money)
						end
					end
				end
				if (type(PlayerData.money) == "number") then 
					cash = PlayerData.money
				else 
					cash = 0
				end 
				if (type(PlayerData.job) == "table") then 
					joblabel = PlayerData.job.label
				else 
					joblabel = "Unknown"
				end 
				if (type(PlayerData.job) == "table") then 
					jobrole = PlayerData.job.grade_label
				else 
					jobrole = "Unknown"
				end 
				updateHungerCashHUD(cash, bank, joblabel, bmoney, jobrole)
			else
				theMode = 1
				TriggerEvent('esx_status:getStatus', 'hunger', function(hungerStatus)
					TriggerEvent('esx_status:getStatus', 'thirst', function(thirstStatus)
						updateHungerThirstHUD(hungerStatus.val / 10000, thirstStatus.val / 10000, 0)
					end)
				end)
				PlayerData = ESX.GetPlayerData()
				bmoney = "Loading.."
				bank = "Loading.."
				cash = "Loading.."
				if (type(PlayerData.accounts) == "table") then
					for k,v in ipairs(PlayerData.accounts) do
						if (v.name == "bank") then 
							bank = ESX.Math.GroupDigits(v.money)
						elseif (v.name == "black_money") then
							bmoney = ESX.Math.GroupDigits(v.money)
						end
					end
				end
				if (type(PlayerData.money) == "number") then 
					cash = PlayerData.money
				else 
					cash = 0
				end 

				ESX.TriggerServerCallback('sody_clubs:getPlayerClub', function(playerdata)
					joblabel = playerdata.club
					jobrole = playerdata.club_rank_name
					if joblabel ~= nil and jobrole ~= nil then
						updateHungerCashHUD(cash, bank, firstToUpper(joblabel), bmoney, firstToUpper(jobrole))
					else
						if (type(PlayerData.job) == "table") then 
							joblabel = PlayerData.job.label
						else 
							joblabel = "Unknown"
						end 
						if (type(PlayerData.job) == "table") then 
							jobrole = PlayerData.job.grade_label
						else 
							jobrole = "Unknown"
						end 
						updateHungerCashHUD(cash, bank, joblabel, bmoney, jobrole)
					end
				end)
			end
		end
    end
end)


-- Update hunger and thirst
Citizen.CreateThread(function()
    while true do
		Citizen.Wait(0)
		SetPlayerHealthRechargeMultiplier(PlayerId(), 0)
		--updateHungerThirst()
    end
end)