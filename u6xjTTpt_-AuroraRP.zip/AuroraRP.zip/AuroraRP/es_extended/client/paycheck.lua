local afkTimeout = 600 -- AFK kick time limit in seconds
local timer = 0

local currentPosition  = nil
local previousPosition = nil
local currentHeading   = nil
local previousHeading  = nil

local isPlayerAFKForJob = false

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1000)

		playerPed = PlayerPedId()
		if playerPed then
			currentPosition = GetEntityCoords(playerPed, true)
			currentHeading  = GetEntityHeading(playerPed)

			if currentPosition == previousPosition and currentHeading == previousHeading then
				if timer > 0 then
					timer = timer - 1
				else
					isPlayerAFKForJob = true
				end
			else
				isPlayerAFKForJob = false
				timer = afkTimeout
			end

			-- (always) update variables
			previousPosition = currentPosition
			previousHeading  = currentHeading
		end
	end
end)

RegisterNetEvent('aurora_es:doPayCheckAndCheckAFK')
AddEventHandler('aurora_es:doPayCheckAndCheckAFK', function()
    if (not isPlayerAFKForJob) then 
    	TriggerServerEvent('aurora_es:doPaycheckSalary')
    else
    	TriggerEvent('esx:showAdvancedNotification', _U('bank'), "Paycheck not received", "We didn't give you a paycheck since your not doing your job.", 'CHAR_BANK_MAZE', 9)
    end
end)