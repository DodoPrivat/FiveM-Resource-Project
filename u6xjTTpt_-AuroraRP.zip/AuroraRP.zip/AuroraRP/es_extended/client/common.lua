AddEventHandler('esx:getShaurorarpacaredObjaurorarpacect', function(cb)
	cb(ESX)
end)

function getSharedObject()
	return ESX
end
