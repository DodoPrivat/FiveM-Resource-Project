Locales['sv'] = {
	['press_wash'] = 'tryck ~b~ENTER~s~ för att tvätta fordonet',
	['press_wash_paid'] = 'tryck ~b~ENTER~s~ för att tvätta fordonet för ~g~$%s~s~',
	['wash_failed'] = 'du har inte råd med en biltvätt',
	['wash_successful'] = 'ditt fordon har tvättats',
	['wash_successful_paid'] = 'ditt fordon har tvättats för ~g~$%s~s~',
}
