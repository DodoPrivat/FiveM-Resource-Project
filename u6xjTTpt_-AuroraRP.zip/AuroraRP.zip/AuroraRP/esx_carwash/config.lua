Config = {}

Config.Locale = 'en'

Config.EnablePrice = true
Config.Price = 3000