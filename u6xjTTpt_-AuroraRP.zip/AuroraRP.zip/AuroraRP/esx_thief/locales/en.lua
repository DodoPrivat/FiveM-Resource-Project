Locales['en'] = {
	['no_hands_up']         = 'target has no hands up!',
    ['cash']                = 'cash',
    ['black_money']         = 'dirty cash',
    ['inventory']           = 'inventory',
    ['target_inventory']    = 'target inventory',
    ['steal']               = 'steal',
    ['return']              = 'return',
    ['action_choice']       = 'choose action',
    ['amount']              = 'amount',
    ['too_far']             = 'you`re too far away!',
    ['no_players_nearby']   = 'no players nearby',
    ['ex_inv_lim_source']   = 'lack of space in inventory',
    ['ex_inv_lim_target']   = 'lack of space in inventory',
    ['you_stole']           = 'you stole',
    ['from_your_target']    = 'from your target',
    ['someone_stole']       = 'someone stole',
    ['invalid_quantity']    = 'invalid amount',
	['cuff']				= 'cuff',
	['uncuff']				= 'uncuff',
	['search']				= 'search',
	['drag']				= 'drag',
    ['handcuffs']			= 'handcuffs',
    ['not_cuffed']          = 'player is not cuffed',
    ['cuffed']              = 'you\'ve been cuffed',
    ['uncuffed']            = 'you\'ve been uncuffed',
    ['no_handcuffs']        = 'you do not have handcuffs',
    ['no_rope']             = 'you do not have a rope',
    ['gun_label']           = 'weapons',
    ['not_armed']           = 'you are not armed',
}
    