ESX               = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getShaurorarpacaredObjaurorarpacect', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  PlayerData = xPlayer
end)

-----

RegisterNetEvent('esx_borrmaskin_humane:startpendrive')
AddEventHandler('esx_borrmaskin_humane:startpendrive', function(source)
	DrillAnimation()
end)

function DrillAnimation()
	local playerPed = GetPlayerPed(-1)
	
	Citizen.CreateThread(function()
        TaskStartScenarioInPlace(playerPed, "WORLD_XHUMAN_CONST_DRILL", 0, true)          
	end)
end