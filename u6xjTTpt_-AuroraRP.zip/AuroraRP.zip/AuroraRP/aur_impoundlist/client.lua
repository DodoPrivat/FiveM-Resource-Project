ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getShaurorarpacaredObjaurorarpacect', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
	
	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('aur_impoundlist:openImpound')
AddEventHandler('aur_impoundlist:openImpound', function(vehs)
	local elements = {}
	table.insert(elements, {label = "Impound List"})
	if #vehs == 0 then
			ESX.ShowNotification("No impound list.")
		else
	    for _,v in pairs(vehs) do
			table.insert(elements, {label = v})
	    end

	    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'spawnimpoundlist', {
			title    = "Impound List",
			align    = 'top-center',
			elements = elements
		}, function(data, menu)
			menu.close()
		end, function(data, menu)
			menu.close()
		end)
	end 
end)