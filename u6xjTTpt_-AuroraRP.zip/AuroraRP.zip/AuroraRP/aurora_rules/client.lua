local display = false
local displayed = false

RegisterNetEvent('aurorarulesnui:on')
AddEventHandler('aurorarulesnui:on', function()
    SendNUIMessage({
        type = "ui",
        display = true
    })
    displayed = true
    SetNuiFocus(true, true)
end)

RegisterNetEvent('aurorarulesnui:off')
AddEventHandler('aurorarulesnui:off', function()
    SendNUIMessage({
        type = "ui",
        display = false
    })
    displayed = false
    SetNuiFocus(false, false)
end)

RegisterNUICallback('close', function(data, cb)
	SendNUIMessage({
        type = "ui",
        display = false
    })
    displayed = false
    SetNuiFocus(false, false)
    cb('ok')
end)


Citizen.CreateThread( function()
	SetNuiFocus( false )

	while true do 
	    if ( displayed == true ) then
            local ped = GetPlayerPed( -1 )	

            DisableControlAction( 0, 1, true )
            DisableControlAction( 0, 2, true )
            DisableControlAction( 0, 24, true )
            DisablePlayerFiring( ped, true )
            DisableControlAction( 0, 142, true )
            DisableControlAction( 0, 106, true ) 
        end

        
        if IsControlJustPressed(1, 288) and GetLastInputMethod( 0 ) then
            if (displayed == true) then 
                TriggerEvent("aurorarulesnui:off", true)
            else
                TriggerEvent('aurorarulesnui:on', true)
            end
        end
        Citizen.Wait(0)
	end 
end )