--Benny's
local Interior = GetInteriorAtCoords(-210.08, -1318.142, 30.89)

LoadInterior(Interior)