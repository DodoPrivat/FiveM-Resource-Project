Locales['en'] = {

	['valid_this_purchase'] = 'validate this purchase?',
	['yes_valid_purchase'] = 'Yes',
	['yes'] = 'yes',
	['no'] = 'no',
	['name_outfit'] = 'name of the outfit?',
	['not_enough_money'] = 'you dont have enough money',
	['press_menu'] = 'press ~INPUT_CONTEXT~ to access the menu',
	['clothes'] = 'clothes',
	['you_paid'] = 'you paid P',
	['save_in_dressing'] = 'Name your outfit',
	['shop_clothes'] = 'clothing store',
	['player_clothes'] = 'change clothes',
	['shop_main_menu'] = 'Clothing Store',
	['saved_outfit'] = 'your outfit has been saved in your dressing-room. Thank you for your visit !',
	['loaded_outfit'] = 'you have recovered the outfit of your dressing-room. Thank you for your visit !',
	['suppr_cloth'] = 'delete outfit',
	['supprimed_cloth'] = 'this outfit has been deleted of your dressing-room'

}