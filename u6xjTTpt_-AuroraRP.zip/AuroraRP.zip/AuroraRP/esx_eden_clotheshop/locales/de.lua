Locales['de'] = {
	['valid_this_purchase'] = 'Einkauf bestätigen?',
  	['yes_valid_purchase'] = 'ja (<span style="color: green;">$%s</span>)',
	['yes'] = 'ja',
	['no'] = 'nein',
	['name_outfit'] = 'Name des Outfits?',
	['not_enough_money'] = 'du hast nicht genug Geld',
	['press_menu'] = 'Drücke ~INPUT_CONTEXT~ um das Menü zu öffnen',
	['clothes'] = 'Kleidung',
	['you_paid'] = 'du bezahlst $',
	['save_in_dressing'] = 'Do you want to give a name to your outfit ?',
	['shop_clothes'] = 'clothing store',
	['player_clothes'] = 'change clothes - dressing-room',
	['shop_main_menu'] = 'welcome ! what do you want to do ?',
	['saved_outfit'] = 'your outfit has been saved in your dressing-room. Thank you for your visit !',
	['loaded_outfit'] = 'you have recovered the outfit of your dressing-room. Thank you for your visit !',
	['suppr_cloth'] = 'delete outfit - dressing-room',
	['supprimed_cloth'] = 'this outfit has been deleted of your dressing-room'
}
