Locales['br'] = {
	['valid_this_purchase'] = 'validar esta compra?',
  	['yes_valid_purchase'] = 'sim (<span style="color: green;">$%s</span>)',
	['yes'] = 'sim',
	['no'] = 'não',
	['name_outfit'] = 'nome da roupa?',
	['not_enough_money'] = 'você não tem dinheiro suficiente',
	['press_menu'] = 'pressione ~INPUT_CONTEXT~ para acessar o menu',
	['clothes'] = 'roupas',
	['you_paid'] = 'você pagou $',
	['save_in_dressing'] = 'você quer salvar essa roupa?',
	['shop_clothes'] = 'clothing store',
	['player_clothes'] = 'change clothes - dressing-room',
	['shop_main_menu'] = 'welcome ! what do you want to do ?',
	['saved_outfit'] = 'roupa salva',
	['loaded_outfit'] = 'you have recovered the outfit of your dressing-room. Thank you for your visit !',
	['suppr_cloth'] = 'delete outfit - dressing-room',
	['supprimed_cloth'] = 'this outfit has been deleted of your dressing-room'
}
