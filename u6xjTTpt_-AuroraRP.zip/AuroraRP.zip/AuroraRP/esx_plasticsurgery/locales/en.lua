Locales['en'] = {
  ['valid_purchase'] = 'validate this purchase?',
  ['yes'] = 'yes',
  ['no'] = 'no',
  ['press_access'] = 'press ~INPUT_CONTEXT~ to access Plastic Surgery',
  ['not_enough_money'] = 'you do not have enough money',
  ['you_paid'] = 'you paid $%s',
  ['blip_plastic_surgery'] = 'Plastic Surgery',
}
