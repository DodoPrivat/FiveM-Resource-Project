Config                            = {}

Config.DrawDistance               = 100.0

Config.Marker                     = { type = 1, x = 1.5, y = 1.5, z = 1.0, r = 102, g = 0, b = 102, rotate = false }

Config.ReviveReward               = 3000  -- revive reward, set to 0 if you don't want it enabled
Config.AntiCombatLog              = true -- enable anti-combat logging?
Config.LoadIpl                    = true -- disable if you're using fivem-ipl or other IPL loaders

Config.Locale = 'en'

local second = 1000
local minute = 60 * second

Config.EarlyRespawnTimer          = 10 * minute  -- Time til respawn is available
Config.BleedoutTimer              = 10 * minute -- Time til the player bleeds out

Config.EnablePlayerManagement     = true
Config.EnableSocietyOwnedVehicles = true

Config.RemoveWeaponsAfterRPDeath  = true
Config.RemoveCashAfterRPDeath     = true
Config.RemoveItemsAfterRPDeath    = true

-- Let the player pay for respawning early, only if he can afford it.
Config.EarlyRespawnFine           = false
Config.EarlyRespawnFineAmount     = 2000

Config.RespawnPoint = { coords = vector3(364.43, -583.27, 42.28), heading = 167.32}

Config.CombatMedicClothes = {
	[0] = {
		male = {["tshirt_1"]=15,["tshirt_2"]=0,["torso_1"]=220,["torso_2"]=23,["decals_1"]=57,["decals_2"]=0,["arms"]=86,["pants_1"]=59,["pants_2"]=2,["shoes_1"]=24,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0},
		female = {["tshirt_1"]=6,["tshirt_2"]=0,["torso_1"]=230,["torso_2"]=22,["decals_1"]=66,["decals_2"]=0,["arms"]=109,["pants_1"]=61,["pants_2"]=2,["shoes_1"]=25,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0}
	},
	[1] = {
		male = {["tshirt_1"]=15,["tshirt_2"]=0,["torso_1"]=220,["torso_2"]=23,["decals_1"]=57,["decals_2"]=0,["arms"]=86,["pants_1"]=59,["pants_2"]=2,["shoes_1"]=24,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0},
		female = {["tshirt_1"]=6,["tshirt_2"]=0,["torso_1"]=230,["torso_2"]=22,["decals_1"]=66,["decals_2"]=0,["arms"]=109,["pants_1"]=61,["pants_2"]=2,["shoes_1"]=25,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0}
	},
	[2] = {
		male = {["tshirt_1"]=15,["tshirt_2"]=0,["torso_1"]=220,["torso_2"]=23,["decals_1"]=57,["decals_2"]=0,["arms"]=86,["pants_1"]=59,["pants_2"]=2,["shoes_1"]=24,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0},
		female = {["tshirt_1"]=6,["tshirt_2"]=0,["torso_1"]=230,["torso_2"]=22,["decals_1"]=66,["decals_2"]=0,["arms"]=109,["pants_1"]=61,["pants_2"]=2,["shoes_1"]=25,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0}
	},
	[3] = {
		male = {["tshirt_1"]=15,["tshirt_2"]=0,["torso_1"]=220,["torso_2"]=25,["decals_1"]=57,["decals_2"]=0,["arms"]=86,["pants_1"]=59,["pants_2"]=2,["shoes_1"]=24,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0},
		female = {["tshirt_1"]=6,["tshirt_2"]=0,["torso_1"]=230,["torso_2"]=25,["decals_1"]=66,["decals_2"]=0,["arms"]=109,["pants_1"]=61,["pants_2"]=2,["shoes_1"]=25,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0}
	},
	[4] = {
		male = {["tshirt_1"]=15,["tshirt_2"]=0,["torso_1"]=220,["torso_2"]=25,["decals_1"]=57,["decals_2"]=0,["arms"]=86,["pants_1"]=59,["pants_2"]=2,["shoes_1"]=24,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0},
		female = {["tshirt_1"]=6,["tshirt_2"]=0,["torso_1"]=230,["torso_2"]=25,["decals_1"]=66,["decals_2"]=0,["arms"]=109,["pants_1"]=61,["pants_2"]=2,["shoes_1"]=25,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0}
	},
	[5] = {
		male = {["tshirt_1"]=15,["tshirt_2"]=0,["torso_1"]=220,["torso_2"]=25,["decals_1"]=57,["decals_2"]=0,["arms"]=86,["pants_1"]=59,["pants_2"]=2,["shoes_1"]=24,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0},
		female = {["tshirt_1"]=6,["tshirt_2"]=0,["torso_1"]=230,["torso_2"]=25,["decals_1"]=66,["decals_2"]=0,["arms"]=109,["pants_1"]=61,["pants_2"]=2,["shoes_1"]=25,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0}
	},
	[6] = {
		male = {["tshirt_1"]=15,["tshirt_2"]=0,["torso_1"]=220,["torso_2"]=24,["decals_1"]=57,["decals_2"]=0,["arms"]=86,["pants_1"]=59,["pants_2"]=2,["shoes_1"]=24,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0},
		female = {["tshirt_1"]=6,["tshirt_2"]=0,["torso_1"]=230,["torso_2"]=24,["decals_1"]=66,["decals_2"]=0,["arms"]=109,["pants_1"]=61,["pants_2"]=2,["shoes_1"]=25,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0}
	},
	[7] = {
		male = {["tshirt_1"]=15,["tshirt_2"]=0,["torso_1"]=220,["torso_2"]=24,["decals_1"]=57,["decals_2"]=0,["arms"]=86,["pants_1"]=59,["pants_2"]=2,["shoes_1"]=24,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0},
		female = {["tshirt_1"]=6,["tshirt_2"]=0,["torso_1"]=230,["torso_2"]=24,["decals_1"]=66,["decals_2"]=0,["arms"]=109,["pants_1"]=61,["pants_2"]=2,["shoes_1"]=25,["shoes_2"]=0,["chain_1"]=0,["chain_2"]=0,["helmet_1"]=28,["helmet_2"]=0,["glasses_1"]=0,["glasses_2"]=0}
	}
}

Config.CombatWeapons = {
	[7] = {
		{ weapon = 'WEAPON_PISTOL', price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_FLAREGUN', price = 0 },
		{ weapon = 'WEAPON_BULLPUPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', price = 0 },
		{ weapon = 'WEAPON_COMBATPDW', price = 0 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 0 },
	},
	[6] = {
		{ weapon = 'WEAPON_PISTOL', price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_FLAREGUN', price = 0 },
		{ weapon = 'WEAPON_BULLPUPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', price = 0 },
		{ weapon = 'WEAPON_COMBATPDW', price = 0 },
		{ weapon = 'WEAPON_HEAVYSNIPER', price = 0 },
	},
	[5] = {
		{ weapon = 'WEAPON_PISTOL', price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_FLAREGUN', price = 0 },
		{ weapon = 'WEAPON_BULLPUPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', price = 0 },
		{ weapon = 'WEAPON_COMBATPDW', price = 0 },
	},
	[4] = {
		{ weapon = 'WEAPON_PISTOL', price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_FLAREGUN', price = 0 },
		{ weapon = 'WEAPON_BULLPUPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', price = 0 },
		{ weapon = 'WEAPON_COMBATPDW', price = 0 },
	},
	[3] = {
		{ weapon = 'WEAPON_PISTOL', price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_FLAREGUN', price = 0 },
		{ weapon = 'WEAPON_BULLPUPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', price = 0 },
		{ weapon = 'WEAPON_COMBATPDW', price = 0 },
	},
	[2] = {
		{ weapon = 'WEAPON_PISTOL', price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_FLAREGUN', price = 0 },
		{ weapon = 'WEAPON_BULLPUPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', price = 0 },
	},
	[1] = {
		{ weapon = 'WEAPON_PISTOL', price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_FLAREGUN', price = 0 },
		{ weapon = 'WEAPON_BULLPUPSHOTGUN', price = 0 },
	},
	[0] = {
		{ weapon = 'WEAPON_PISTOL', price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_FLAREGUN', price = 0 },
		{ weapon = 'WEAPON_BULLPUPSHOTGUN', price = 0 },
	},
}

Config.Hospitals = {

	PillBoxHospital = {

		Blip = {
			coords = vector3(296.98, -583.95, 70.5),
			sprite = 61,
			scale  = 1.2,
			color  = 2
		},

		AmbulanceActions = {
			vector3(302.23, -598.67, 42.28)
		},

		BossActions = {
			vector3(334.6, -593.68, 43.28)
		},

		Pharmacies = {
			vector3(310.83, -565.74, 42.28)
		},

		Vehicles = {
			{
				Spawner = vector3(291.61, -609.78, 43.37),
				InsideShop = vector3(321.37, -565.59, 90.61),
				Marker = { type = 36, x = 1.0, y = 1.0, z = 1.0, r = 100, g = 50, b = 200, a = 100, rotate = true },
				SpawnPoints = {
					{ coords = vector3(291.61, -609.78, 43.37), heading = 54.5, radius = 4.0 },
				}
			}
		},

		Helicopters = {
			{
				Spawner = vector3(351.79, -588.01, 74.16),
				InsideShop = vector3(351.79, -588.01, 74.16),
				Marker = { type = 34, x = 1.5, y = 1.5, z = 1.5, r = 100, g = 150, b = 150, a = 100, rotate = true },
				SpawnPoints = {
					{ coords = vector3(351.79, -588.01, 74.16), heading = 275.5, radius = 10.0 },
				}
			}
		},

		FastTravels = {
			{
				From = vector3(331.99, -595.61, 42.28),
				To = { coords = vector3(340.9, -584.79, 74.16), heading = 245.5 },
				Marker = { type = 1, x = 2.0, y = 2.0, z = 0.5, r = 102, g = 0, b = 102, rotate = false }
			},
			{
				From = vector3(338.26, -583.86, 74.16),
				To = { coords = vector3(328.78, -594.25, 42.28), heading = 70.91 },
				Marker = { type = 1, x = 2.0, y = 2.0, z = 0.5, r = 102, g = 0, b = 102, rotate = false }
			},

		},

		FastTravelsPrompt = {
			--[[{
				From = vector3(237.4, -1373.8, 26.0),
				To = { coords = vector3(251.9, -1363.3, 38.5), heading = 0.0 },
				Marker = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, rotate = false },
				Prompt = _U('fast_travel')
			},

			{
				From = vector3(256.5, -1357.7, 36.0),
				To = { coords = vector3(235.4, -1372.8, 26.3), heading = 0.0 },
				Marker = { type = 1, x = 1.5, y = 1.5, z = 0.5, r = 102, g = 0, b = 102, rotate = false },
				Prompt = _U('fast_travel')
			}]]--
		}

	}
}

Config.AuthorizedVehicles = {

	recruit = {
		{ model = 'ambulance', label = 'Ambulance Van', price = 1},
		{ model = 'dodgeEMS', label = 'Ambulance Dodge Charger', price = 1},
		{ model = 'ems_gs1200', label = 'Ambulance Motorcycle', price = 1}
	},
	
	ambulance = {
		{ model = 'ambulance', label = 'Ambulance Van', price = 1},
		{ model = 'dodgeEMS', label = 'Ambulance Dodge Charger', price = 1},
		{ model = 'ems_gs1200', label = 'Ambulance Motorcycle', price = 1}
	},
	
	trainer = {
		{ model = 'ambulance', label = 'Ambulance Van', price = 1},
		{ model = 'dodgeEMS', label = 'Ambulance Dodge Charger', price = 1},
		{ model = 'ems_gs1200', label = 'Ambulance Motorcycle', price = 1}
	},
	
	teamleader = {
		{ model = 'ambulance', label = 'Ambulance Van', price = 1},
		{ model = 'dodgeEMS', label = 'Ambulance Dodge Charger', price = 1},
		{ model = 'ems_gs1200', label = 'Ambulance Motorcycle', price = 1}
	},

	medicper = {
		{ model = 'ambulance', label = 'Ambulance Van', price = 1},
		{ model = 'dodgeEMS', label = 'Ambulance Dodge Charger', price = 1},
		{ model = 'ems_gs1200', label = 'Ambulance Motorcycle', price = 1}
	},
	
	doctor = {
		{ model = 'ambulance', label = 'Ambulance Van', price = 1},
		{ model = 'dodgeEMS', label = 'Ambulance Dodge Charger', price = 1},
		{ model = 'ems_gs1200', label = 'Ambulance Motorcycle', price = 1},
		{ model = 'wmfenyrcop', label = 'Aurora EMS Car', price = 1}
	},

	chief_doctor = {
		{ model = 'ambulance', label = 'Ambulance Van', price = 1},
		{ model = 'dodgeEMS', label = 'Ambulance Dodge Charger', price = 1},
		{ model = 'ems_gs1200', label = 'Ambulance Motorcycle', price = 1},
		{ model = 'wmfenyrcop', label = 'Aurora EMS Car', price = 1}
	},

	boss = {
		{ model = 'ambulance', label = 'Ambulance Van', price = 1},
		{ model = 'dodgeEMS', label = 'Ambulance Dodge Charger', price = 1},
		{ model = 'ems_gs1200', label = 'Ambulance Motorcycle', price = 1},
		{ model = 'wmfenyrcop', label = 'Aurora EMS Car', price = 1}
	}

}

Config.AuthorizedHelicopters = {

	recruit = {},
	
	ambulance = {},
	
	trainer = {
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 1 }
	},
	
	teamleader = {
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 1 }
	},
	
	medicper = {
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 1 }
	},

	doctor = {
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 1 }
	},

	chief_doctor = {
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 1 },
		{ model = 'seasparrow', label = 'Sea Sparrow', price = 1 }
	},

	boss = {
		{ model = 'buzzard2', label = 'Nagasaki Buzzard', price = 1 },
		{ model = 'seasparrow', label = 'Sea Sparrow', price = 1 }
	}

}
