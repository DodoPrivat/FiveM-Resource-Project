Config = {}

Config.StatusMax      = 1000000
Config.TickTime       = 5000
Config.UpdateInterval = 10000