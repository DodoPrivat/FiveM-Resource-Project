Config = {}
Config.Locale = 'en'

Config.ShouldWaitBetweenRobbing = true
Config.MinWaitSeconds = 60
Config.MaxWaitSeconds = 180 

Config.RobDistance = 3
Config.RobAnimationSeconds = 10

Config.MinMoney = 100
Config.MaxMoney = 500