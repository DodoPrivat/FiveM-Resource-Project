local theObjects = {
	--Object Name, X, Y, Z, isNetwork, thisScriptCheck, dynamic
	{obj = "prop_gas_pump_1c", x = -2224.34, y = 3254.08, z = 32.81, network = true, script = true, dyna = true},
	{obj = "prop_gas_pump_1c", x = -2225.98, y = 3250.83, z = 32.81, network = true, script = true, dyna = true},
	{obj = "prop_gas_pump_1c", x = -2228.12, y = 3247.38, z = 32.81, network = true, script = true, dyna = true},
	{obj = "prop_gas_pump_1c", x = -1067.68, y = 6987.72, z = 34.1, network = true, script = true, dyna = true},
	{obj = "prop_gas_pump_1c", x = -1073.59, y = 6987.72, z = 34.1, network = true, script = true, dyna = true},
	{obj = "prop_gas_pump_1c", x = -3293.92, y = 4828.38, z = 413.99, network = true, script = true, dyna = true},
}

Citizen.CreateThread(function()
	for x,i in ipairs(theObjects) do
	    local object = CreateObject(i['obj'], i['x'], i['y'], i['z'], i['network'], i['script'], i['dyna'])
	    PlaceObjectOnGroundProperly(object)
    end
end)