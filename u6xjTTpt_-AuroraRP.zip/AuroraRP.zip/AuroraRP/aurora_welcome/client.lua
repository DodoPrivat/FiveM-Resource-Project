local display = false
local displayed = false
local isContentReady = false
local freezePlayer = false

function ClearScreen()
    HideHudAndRadarThisFrame()
end

RegisterNetEvent('auroraloginnui:on')
AddEventHandler('auroraloginnui:on', function()
    isContentReady = true
end)

RegisterNetEvent('auroraloginnui:onUp')
AddEventHandler('auroraloginnui:onUp', function()
    freezePlayer = true
    while GetPlayerSwitchState() ~= 5 do
        Citizen.Wait(0)
        ClearScreen()
    end
    ShutdownLoadingScreen()
    
    ClearScreen()
    Citizen.Wait(0)
    DoScreenFadeOut(0)
    ShutdownLoadingScreenNui()
    ClearScreen()
    Citizen.Wait(0)
    ClearScreen()
    DoScreenFadeIn(500)
    while not IsScreenFadedIn() do
        Citizen.Wait(0)
        ClearScreen()
    end
    while not isContentReady do
        Citizen.Wait(0)
    end
    SendNUIMessage({
        type = "ui",
        display = true
    })
    displayed = true
    SetNuiFocus(true, true)
    while GetPlayerSwitchState() ~= 12 do
        Citizen.Wait(0)
        ClearScreen()
    end
    TriggerEvent('showInGameHud')
    DisplayRadar(true)
    DisplayHud(true)
    freezePlayer = false
    FreezeEntityPosition(PlayerPedId(), false)
    ClearDrawOrigin()
end)

RegisterNetEvent('auroraloginnui:unfreeze')
AddEventHandler('auroraloginnui:unfreeze', function()
    freezePlayer = false
end)

RegisterNetEvent('auroraloginnui:off')
AddEventHandler('auroraloginnui:off', function()
    SendNUIMessage({
        type = "ui",
        display = false
    })
    displayed = false
    SetNuiFocus(false, false)
    SwitchInPlayer(PlayerPedId())
end)

RegisterNetEvent('auroraloginnui:editGUI')
AddEventHandler('auroraloginnui:editGUI', function(theFormC, theFormEditC)
    print (theFormC)
    SendNUIMessage({
        type = "editforms",
        theForm = theFormC,
        theFormEdit = theFormEditC
    })
end)


RegisterNUICallback('play', function(data, cb)
    TriggerEvent("auroraloginnui:off")
    cb('ok')
end)


Citizen.CreateThread( function()
    TriggerEvent('hideInGameHud')
    DisplayRadar(false)
    DisplayHud(false)
    if not IsPlayerSwitchInProgress() then
        SwitchOutPlayer(PlayerPedId(), 0, 1)
    end
    ClearScreen()
    print("===========================================================")
    print("Welcome to AuroraRP Server")
    print("===========================================================")
	SetNuiFocus( false )
    SendNUIMessage({
        type = "editforms",
        theForm = "playerName",
        theFormEdit = GetPlayerName(PlayerId())
    })
    TriggerServerEvent('auroraloginnui:updateMe')
	while true do 
        if (freezePlayer == true) then 
            FreezeEntityPosition(PlayerPedId(), true)
        end
	    if ( displayed == true ) then
            local ped = GetPlayerPed( -1 )	

            DisableControlAction( 0, 1, true )
            DisableControlAction( 0, 2, true )
            DisableControlAction( 0, 24, true )
            DisablePlayerFiring( ped, true )
            DisableControlAction( 0, 142, true )
            DisableControlAction( 0, 106, true ) 
        end
        Citizen.Wait(0)
	end 
end )