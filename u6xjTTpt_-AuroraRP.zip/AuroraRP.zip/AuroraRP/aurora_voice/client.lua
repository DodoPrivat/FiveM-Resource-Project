ESX = nil
local Keys = {
	["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57,
	["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177,
	["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
	["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
	["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
	["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70,
	["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
	["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
	["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118
}
local currentVoice = 2
local currentRadio = 0
local clientAbleToUseRadio = false
local radioActive = false
local isPlayerStaff = false
local theProximity = {
	[1] = 3, -- Whisper
	[2] = 8, -- Normal 
	[3] = 15, -- Shout
	[4] = nil, -- Radio
	[5] = nil, -- Override
}

local theProxmities = {
	[1] = "Whisper",
	[2] = "Normal",
	[3] = "Shout",
	[4] = "Radio",
	[5] = "Staff Override Mode",
}

local playerVoice = {}
local theRadioVoice = {}
local theRadioAntiSpam = {}

function round(num, dec)
  local mult = 10^(dec or 0)
  return math.floor(num * mult + 0.5) / mult
end

RegisterNetEvent("aurora_voice:setPlayerStaff")
AddEventHandler("aurora_voice:setPlayerStaff", function(theData)
	isPlayerStaff = theData
end)

RegisterNetEvent("aurora_voice:setPlayerVoiceData")
AddEventHandler("aurora_voice:setPlayerVoiceData", function(theData)
	playerVoice = theData
end)

RegisterNetEvent("aurora_voice:setRadioVoiceData")
AddEventHandler("aurora_voice:setRadioVoiceData", function(theData)
	theRadioVoice = theData
end)

RegisterNetEvent("aurora_voice:setPlayerMute")
AddEventHandler("aurora_voice:setPlayerMute", function(id)
	MumbleSetVolumeOverride(GetPlayerFromServerId(id), 0.0)
end)

RegisterNetEvent("aurora_voice:setPlayerHear")
AddEventHandler("aurora_voice:setPlayerHear", function(id)
	MumbleSetVolumeOverride(GetPlayerFromServerId(id), 1.0)
end)

RegisterNetEvent("aurora_voice:onRadioDrop")
AddEventHandler("aurora_voice:onRadioDrop", function()
	if (currentRadio ~= 0) then 
		currentVoice = 2
		currentRadio = 0
	end
	clientAbleToUseRadio = false
end)

RegisterNetEvent("aurora_voice:ableToUseRadio")
AddEventHandler("aurora_voice:ableToUseRadio", function()
	clientAbleToUseRadio = true
end)

RegisterCommand("setradio", function(theSource, args, rawCommand)
	if (clientAbleToUseRadio) then 
		currentRadio = tonumber(args[1])
		TriggerServerEvent("aurora_voice:changeRadioFreq", currentRadio)
		exports['mythic_notify']:SendAlert('inform', "Frequency set to "..currentRadio..".")
		setVCStatus (false)
	else 
		exports['mythic_notify']:SendAlert('inform', "You don't have a radio in your inventory.")
	end 
end)

RegisterCommand("overridev", function(theSource, args, rawCommand)
	if (isPlayerStaff) then 
		local thePlayerID = GetPlayerFromServerId(tonumber(args[1]))
		local theVolume = tonumber(args[2])
		currentVoice = 5
		currentRadio = 0
		MumbleSetVolumeOverride(thePlayerID, theVolume)
		TriggerServerEvent("aurora_voice:changeProxvoice", currentVoice)
		exports['mythic_notify']:SendAlert('inform', "Override volume set to player id "..tonumber(args[1])..".")
		setVCStatus(false)
	end 
end)

RegisterCommand("hearmeoverridev", function(theSource, args, rawCommand)
	if (isPlayerStaff) then 
		local thePlayerID = tonumber(args[1])
		currentVoice = 5
		currentRadio = 0
		TriggerServerEvent("aurora_voice:changeProxvoice", currentVoice)
		TriggerServerEvent("aurora_voice:forceMeToHear", thePlayerID)
		exports['mythic_notify']:SendAlert('inform', "Player ID "..tonumber(args[1]).." can now hear you.")
		setVCStatus(false)
	end 
end)

Citizen.CreateThread(function()
	SetNuiFocus(false, false)
	TriggerServerEvent("aurora_voice:addUserToVC")
	TriggerServerEvent("aurora_voice:fetchPlayerVoiceList")
	for _, thePlayer in ipairs(GetActivePlayers()) do
		if ((NetworkIsPlayerActive(thePlayer)) and GetPlayerPed(thePlayer) ~= GetPlayerPed(-1)) then
			MumbleSetVolumeOverride(thePlayer, 0.0)
		end
	end
	while true do 
		for _, id in ipairs(GetActivePlayers()) do
			if ((NetworkIsPlayerActive(id)) and currentVoice ~=5) then
				local theCurrentStateVoice = playerVoice[GetPlayerServerId(id)]
				local theProximityStatus = theProximity[theCurrentStateVoice]
				if (theProximityStatus ~= nil and GetPlayerPed(id) ~= GetPlayerPed(-1) and (currentVoice ~= 5 or theCurrentStateVoice ~= 5)) then 
					local x1, y1, z1 = table.unpack(GetEntityCoords(GetPlayerPed(-1), true))
		            local x2, y2, z2 = table.unpack(GetEntityCoords(GetPlayerPed(id), true))
		            local distance = GetDistanceBetweenCoords(x1,  y1,  z1,  x2,  y2,  z2, true)
		            if (distance <= theProximityStatus) then 
		            	if (HasEntityClearLosToEntityInFront(GetPlayerPed(-1), GetPlayerPed(id))) then 
				            local number = distance/theProximityStatus
				            local theVolume = round(((1-number)/1), 2)
				            MumbleSetVolumeOverride(id, theVolume)
				        else
				        	if (distance <= theProximity[1]) then 
					        	local number = distance/theProximity[1]
					            local theVolume = round(((1-number)/1), 2)
					        	MumbleSetVolumeOverride(id, theVolume)
					        else
					        	MumbleSetVolumeOverride(id, 0.0)
					        end
				        end
			        else
			        	if (currentRadio ~= 0) then 
							if (theRadioVoice[GetPlayerServerId(id)] ~= nil and (theRadioVoice[GetPlayerServerId(id)] == currentRadio or GetPlayerPed(id) == GetPlayerPed(-1)) and theCurrentStateVoice == 4) then 
								if (theRadioAntiSpam[id] == nil and NetworkIsPlayerTalking(id)) then 
									theRadioAntiSpam[id] = true
									SendNUIMessage({command = "playSFX", theSFX = "assets/mic_click_on.mp3"})
									SendNUIMessage({command = "playStatic"})
								elseif (theRadioAntiSpam[id] == true and not NetworkIsPlayerTalking(id)) then 
									theRadioAntiSpam[id] = nil
									SendNUIMessage({command = "playSFX", theSFX = "assets/mic_click_off.mp3"})
									SendNUIMessage({command = "pauseStatic"})
								end
								if (GetPlayerPed(id) ~= GetPlayerPed(-1)) then 
									MumbleSetVolumeOverride(id, 1.0)
								end
							else
								if (GetPlayerPed(id) ~= GetPlayerPed(-1)) then 
									MumbleSetVolumeOverride(id, 0.0)
								end
							end
						else
							if (GetPlayerPed(id) ~= GetPlayerPed(-1)) then 
								MumbleSetVolumeOverride(id, 0.0)
							end
						end
			        end
			    else
			    	if (currentRadio ~= 0 and (currentVoice ~= 5 or theCurrentStateVoice ~= 5)) then 
						if (theRadioVoice[GetPlayerServerId(id)] ~= nil and (theRadioVoice[GetPlayerServerId(id)] == currentRadio or GetPlayerPed(id) == GetPlayerPed(-1)) and theCurrentStateVoice == 4) then 
							if (theRadioAntiSpam[id] == nil and NetworkIsPlayerTalking(id)) then 
								theRadioAntiSpam[id] = true
								SendNUIMessage({command = "playSFX", theSFX = "assets/mic_click_on.mp3"})
								SendNUIMessage({command = "playStatic"})
							elseif (theRadioAntiSpam[id] == true and not NetworkIsPlayerTalking(id)) then 
								theRadioAntiSpam[id] = nil
								SendNUIMessage({command = "playSFX", theSFX = "assets/mic_click_off.mp3"})
								SendNUIMessage({command = "pauseStatic"})
							end
							if (GetPlayerPed(id) ~= GetPlayerPed(-1)) then
								MumbleSetVolumeOverride(id, 1.0)
							end
						else
							if (GetPlayerPed(id) ~= GetPlayerPed(-1)) then 
								MumbleSetVolumeOverride(id, 0.0)
							end
						end
					else
						if (GetPlayerPed(id) ~= GetPlayerPed(-1) and (currentVoice ~= 5 or theCurrentStateVoice ~= 5)) then 
							MumbleSetVolumeOverride(id, 0.0)
						end
					end
			    end
			end
		end
		Citizen.Wait(100)
	end
end)

local networkTalkingSpam = false

function setVCStatus (isTalking)
	local theClass = "normal"
	if isTalking then 
		theClass = "talking"
	end 
	if (currentVoice == 0) then currentVoice = 1 end
	if (currentRadio == 0) then
		SendNUIMessage({command = "renameText", theID="voicechat", theText="<b class='"..theClass.."'>Voice Proximity: "..theProxmities[currentVoice].."</b>"})
	else 
		SendNUIMessage({command = "renameText", theID="voicechat", theText="<b class='"..theClass.."'>Voice Proximity: "..theProxmities[currentVoice].." | On Frequency: "..currentRadio..".00 Mhz</b>"})
	end
end

Citizen.CreateThread(function()
	while true do 
		Citizen.Wait(0)
		HideHudComponentThisFrame(4)
		HideHudComponentThisFrame(9)
		if NetworkIsPlayerTalking(PlayerId()) then
			if (networkTalkingSpam) then 
				networkTalkingSpam = false
				setVCStatus(true)
			end
		elseif not NetworkIsPlayerTalking(PlayerId()) then
			if (not networkTalkingSpam) then 
				networkTalkingSpam = true
				setVCStatus(false)
			end
		end
		if IsControlJustPressed(1, Keys['~']) then
			currentVoice = (currentVoice + 1) % 4
			if (currentVoice == 0) then currentVoice = 1 end
			TriggerServerEvent("aurora_voice:changeProxvoice", currentVoice)
			setVCStatus(false)
		end
		if IsControlJustPressed(1, Keys['H']) then
			if clientAbleToUseRadio and currentRadio ~= 0 then 
				local ped = PlayerPedId()
				if (DoesEntityExist(ped) and not IsEntityDead(ped)) then 
					RequestAnimDict("random@arrests")
					while (not HasAnimDictLoaded("random@arrests")) do 
						Citizen.Wait(1)
					end
					if IsEntityPlayingAnim(ped, "random@arrests", "generic_radio_chatter", 3) then
						ClearPedSecondaryTask(ped)
						currentVoice = 2
						TriggerServerEvent("aurora_voice:changeProxvoice", currentVoice)
					else
						TaskPlayAnim(ped, "random@arrests", "generic_radio_chatter", 2.0, 2.5, -1, 49, 0, 0, 0, 0 )
						local prop_name = prop_name
						local secondaryprop_name = secondaryprop_name
						DetachEntity(prop, 1, 1)
						DeleteObject(prop)
						DetachEntity(secondaryprop, 1, 1)
						DeleteObject(secondaryprop)
						currentVoice = 4
						TriggerServerEvent("aurora_voice:changeProxvoice", currentVoice)
					end
					setVCStatus (false)
				end
			else
				exports['mythic_notify']:SendAlert('inform', "You don't have any radio or your not connected to a certain frequency.")
			end
		end
	end
end)

local zones = { ['AIRP'] = "Los Santos International Airport", ['ALAMO'] = "Alamo Sea", ['ALTA'] = "Alta", ['ARMYB'] = "Fort Zancudo", ['BANHAMC'] = "Banham Canyon Dr", ['BANNING'] = "Banning", ['BEACH'] = "Vespucci Beach", ['BHAMCA'] = "Banham Canyon", ['BRADP'] = "Braddock Pass", ['BRADT'] = "Braddock Tunnel", ['BURTON'] = "Burton", ['CALAFB'] = "Calafia Bridge", ['CANNY'] = "Raton Canyon", ['CCREAK'] = "Cassidy Creek", ['CHAMH'] = "Chamberlain Hills", ['CHIL'] = "Vinewood Hills", ['CHU'] = "Chumash", ['CMSW'] = "Chiliad Mountain State Wilderness", ['CYPRE'] = "Cypress Flats", ['DAVIS'] = "Davis", ['DELBE'] = "Del Perro Beach", ['DELPE'] = "Del Perro", ['DELSOL'] = "La Puerta", ['DESRT'] = "Grand Senora Desert", ['DOWNT'] = "Downtown", ['DTVINE'] = "Downtown Vinewood", ['EAST_V'] = "East Vinewood", ['EBURO'] = "El Burro Heights", ['ELGORL'] = "El Gordo Lighthouse", ['ELYSIAN'] = "Elysian Island", ['GALFISH'] = "Galilee", ['GOLF'] = "GWC and Golfing Society", ['GRAPES'] = "Grapeseed", ['GREATC'] = "Great Chaparral", ['HARMO'] = "Harmony", ['HAWICK'] = "Hawick", ['HORS'] = "Vinewood Racetrack", ['HUMLAB'] = "Humane Labs and Research", ['JAIL'] = "Bolingbroke Penitentiary", ['KOREAT'] = "Little Seoul", ['LACT'] = "Land Act Reservoir", ['LAGO'] = "Lago Zancudo", ['LDAM'] = "Land Act Dam", ['LEGSQU'] = "Legion Square", ['LMESA'] = "La Mesa", ['LOSPUER'] = "La Puerta", ['MIRR'] = "Mirror Park", ['MORN'] = "Morningwood", ['MOVIE'] = "Richards Majestic", ['MTCHIL'] = "Mount Chiliad", ['MTGORDO'] = "Mount Gordo", ['MTJOSE'] = "Mount Josiah", ['MURRI'] = "Murrieta Heights", ['NCHU'] = "North Chumash", ['NOOSE'] = "N.O.O.S.E", ['OCEANA'] = "Pacific Ocean", ['PALCOV'] = "Paleto Cove", ['PALETO'] = "Paleto Bay", ['PALFOR'] = "Paleto Forest", ['PALHIGH'] = "Palomino Highlands", ['PALMPOW'] = "Palmer-Taylor Power Station", ['PBLUFF'] = "Pacific Bluffs", ['PBOX'] = "Pillbox Hill", ['PROCOB'] = "Procopio Beach", ['RANCHO'] = "Rancho", ['RGLEN'] = "Richman Glen", ['RICHM'] = "Richman", ['ROCKF'] = "Rockford Hills", ['RTRAK'] = "Redwood Lights Track", ['SANAND'] = "San Andreas", ['SANCHIA'] = "San Chianski Mountain Range", ['SANDY'] = "Sandy Shores", ['SKID'] = "Mission Row", ['SLAB'] = "Stab City", ['STAD'] = "Maze Bank Arena", ['STRAW'] = "Strawberry", ['TATAMO'] = "Tataviam Mountains", ['TERMINA'] = "Terminal", ['TEXTI'] = "Textile City", ['TONGVAH'] = "Tongva Hills", ['TONGVAV'] = "Tongva Valley", ['VCANA'] = "Vespucci Canals", ['VESP'] = "Vespucci", ['VINE'] = "Vinewood", ['WINDF'] = "Ron Alternates Wind Farm", ['WVINE'] = "West Vinewood", ['ZANCUDO'] = "Zancudo River", ['ZP_ORT'] = "Port of South Los Santos", ['ZQ_UAR'] = "Davis Quartz" }
Citizen.CreateThread(function()
	while true do
		local pos = GetEntityCoords(PlayerPedId())
		local streetName, crossing = GetStreetNameAtCoord(pos.x, pos.y, pos.z)
		streetName, crossing = GetStreetNameFromHashKey(streetName), GetStreetNameFromHashKey(crossing)
		local currentZone = zones[GetNameOfZone(pos.x, pos.y, pos.z)]
		SendNUIMessage({command = "renameText", theID="theID", theText="<b class='aurorax'>ID: "..GetPlayerServerId(PlayerId()).."</b>"})
		if (crossing == "") then 
			SendNUIMessage({command = "renameText", theID="theStreet2", theText="<b class='aurorax'>"..currentZone.."</b>"})
		else 
			SendNUIMessage({command = "renameText", theID="theStreet2", theText="<b class='aurorax'>"..crossing .. ", " .. currentZone.."</b>"})
		end 
		SendNUIMessage({command = "renameText", theID="theStreet1", theText="<b class='aurorax'>"..streetName.."</b>"})
		Citizen.Wait(5000)
	end
end)