tpTimeout = false
ESX = nil
local PlayerData                = {}
Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getShaurorarpacaredObjaurorarpacect', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
	
	while true do
		Wait(0)

		if IsControlJustReleased(1, 244) then
			PlayerData.job = ESX.GetPlayerData().job
			local elements = {
				{label = "Animations", value = "animations"},
				{label = "Open Invoices", value = "invoices"},
				{label = "Open ID Interaction", value = "idinteract"},
				{label = "Handcuffs", value = "handcuffs"},
				{label = "Rapid Transport", value = "rapid"},
				{label = "GTA Recording Options", value = "gtarec"},
			}

			if PlayerData.job ~= nil and PlayerData.job.name == 'ambulance' then
				table.insert(elements, {label = "EMS Tools", value = "ems"})
			end
			ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'auroramenu1', {
				title    = "Player Interaction",
				align    = 'top-right',
				elements = elements
			}, function(data, menu)
				if (data.current.value == "animations") then 
					TriggerEvent("aurora_animations:openEmotePanel")
					menu.close()
				elseif (data.current.value == "invoices") then 
					exports['esx_billing']:openBilling()
				elseif (data.current.value == "handcuffs") then 
					TriggerEvent('cuffs:OpenMenu')
				elseif (data.current.value == "ems") then 
					if PlayerData.job ~= nil and PlayerData.job.name == 'ambulance' then
						local elements = {
							{label = "Spawn Stretcher", value = "spawnstr"},
							{label = "Push Stretcher", value = "pushstr"},
							{label = "Put/take Stretcher Out of car", value = "puttakestretcher"},
							{label = "Open Ambulance Doors", value = "openbaydoors"},
							{label = "Get into Stretcher", value = "getintostr"},
							{label = "Delete Stretcher", value = "delstre"},
						}
						ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'auroramenu2', {
							title    = "EMS Stretcher",
							align    = 'top-right',
							elements = elements
						}, function(data, menu2)
							if (data.current.value == "pushstr") then 
								TriggerEvent("ARPF-EMS:pushstreacherss")
							elseif (data.current.value == "puttakestretcher") then 
								TriggerEvent("ARPF-EMS:togglestrincar")
							elseif (data.current.value == "spawnstr") then 
								TriggerEvent("ARPF-EMS:spawnstretcher")
							elseif (data.current.value == "openbaydoors") then 
								TriggerEvent("ARPF-EMS:opendoors")
							elseif (data.current.value == "getintostr") then 
								TriggerEvent("ARPF-EMS:getintostretcher")
							elseif (data.current.value == "delstre") then 
								TriggerEvent("ARPF-EMS:deletestretcher")
							end 
						end, function(data, menu)
							menu.close()
						end)
					end
				elseif (data.current.value == "rapid") then 
					ESX.TriggerServerCallback('aurora_interaction:checkDL3', function(response)
						if (response == true) then

							local rapidTPs = {
								{label = "LSPD", x = 414.01, y = -974.77, z = 29.44, h = 81.46},
								{label = "LS Hospital", x = 280.71, y = -586.63, z = 43.3, h = 67.79},
								{label = "Central Garage", x = 213.93, y = -809.19, z = 31.01, h = 350.2},
								{label = "Benny's Repair Shop", x = -207.27, y = -1298.3, z = 31.3, h = 173.01},
								{label = "Job Center", x = -552.6, y = -200.89, z = 38.26, h = 24.86},
								{label = "Car Dealer", x = -39.75, y = -1113.88, z = 26.44, h = 348.01},
								{label = "Impound Area", x = 404.13, y = -1628.3, z = 29.29, h = 306.75},
							}
							ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'rapidtransport', {
								title    = "Rapid Transport",
								align    = 'top-right',
								elements = rapidTPs
							}, function(datax, menu3)
								ESX.TriggerServerCallback('aurora_interaction:checkDL3', function(response)
									if (response == true) then
										if (tpTimeout == true) then
											TriggerEvent('chatMessage', "Interaction: ", {255, 0, 0}, "Feature in cooldown! Please wait 1 minute.")
											menu.close()
											menu3.close()
										else
											TriggerEvent('chatMessage', "Interaction: ", {255, 255, 255}, "Teleporting you.")
											tpTimeout = true
											SetTimeout(60000, function()
												tpTimeout = false
											end)
											menu.close()
											menu3.close()
											TriggerEvent('hideInGameHud')
										    DisplayRadar(false)
										    DisplayHud(false)
										    FreezeEntityPosition(PlayerPedId(), true)
										    SwitchOutPlayer(PlayerPedId(), 0, 1)
										    Wait(2500)
										    SetEntityCoords(PlayerPedId(), datax.current.x, datax.current.y, datax.current.z, datax.current.h)
										    Wait(500)
										    SwitchInPlayer(PlayerPedId())
										    Wait(3000)
										    TriggerEvent('showInGameHud')
										    DisplayRadar(true)
										    DisplayHud(true)
											FreezeEntityPosition(PlayerPedId(), false)
										end
									else
										TriggerEvent('chatMessage', "Interaction: ", {255, 0, 0}, "You do not have DL3 to do this. Buy DL3 at store.aurorav.net")
									end
								end)
							end, function(data, menu4)
								menu4.close()
							end)

						else
							TriggerEvent('chatMessage', "Interaction: ", {255, 0, 0}, "You do not have DL3 to do this. Buy DL3 at store.aurorav.net")
						end
					end)
				elseif (data.current.value == "idinteract") then 
					local elements = {
						{label = "Show ID", value = "showid"},
						{label = "Give ID to nearest player", value = "showidplayer"},
						{label = "Show Driver License", value = "showiddriving"},
						{label = "Give Driver License to nearest player", value = "showdrivingplayer"},
						{label = "Show Gun License", value = "showidweapon"},
						{label = "Give Gun License to nearest player", value = "showweaponplayer"},
					}
					ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'auroramenu2', {
						title    = "ID Interaction",
						align    = 'top-right',
						elements = elements
					}, function(data, menu)
						if (data.current.value == "showid") then 
							TriggerServerEvent('jsfour-idcard:open', GetPlayerServerId(PlayerId()), GetPlayerServerId(PlayerId()))
						elseif (data.current.value == "showiddriving") then 
							TriggerServerEvent('jsfour-idcard:open', GetPlayerServerId(PlayerId()), GetPlayerServerId(PlayerId()), 'driver')
						elseif (data.current.value == "showidweapon") then 
							TriggerServerEvent('jsfour-idcard:open', GetPlayerServerId(PlayerId()), GetPlayerServerId(PlayerId()), 'weapon')

						elseif (data.current.value == "showidplayer") then 
							local player, distance = ESX.Game.GetClosestPlayer()
							if distance ~= -1 and distance <= 3.0 then
							  TriggerServerEvent('jsfour-idcard:open', GetPlayerServerId(PlayerId()), GetPlayerServerId(player))
							else
							  ESX.ShowNotification('No players nearby')
							end
						elseif (data.current.value == "showdrivingplayer") then 
							local player, distance = ESX.Game.GetClosestPlayer()

							if distance ~= -1 and distance <= 3.0 then
							  TriggerServerEvent('jsfour-idcard:open', GetPlayerServerId(PlayerId()), GetPlayerServerId(player), 'driver')
							else
							  ESX.ShowNotification('No players nearby')
							end
						elseif (data.current.value == "showweaponplayer") then 
							local player, distance = ESX.Game.GetClosestPlayer()

							if distance ~= -1 and distance <= 3.0 then
							  TriggerServerEvent('jsfour-idcard:open', GetPlayerServerId(PlayerId()), GetPlayerServerId(player), 'weapon')
							else
							  ESX.ShowNotification('No players nearby')
							end
						end 
					end, function(data, menu)
						menu.close()
					end)
				elseif (data.current.value == "gtarec") then 
					local elements = {
						{label = "Start Recording", value = "rec"},
						{label = "Stop Recording", value = "stoprec"},
						{label = "Open Rockstar Editor", value = "rcsed"},
					}
					ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'auroramenu2', {
						title    = "ID Interaction",
						align    = 'top-right',
						elements = elements
					}, function(data, menu2)
						if (data.current.value == "rec") then 
							StartRecording(1)
						elseif (data.current.value == "stoprec") then 
							StopRecordingAndSaveClip()
						elseif (data.current.value == "rcsed") then 
							menu2.close()
							menu.close()
							NetworkSessionLeaveSinglePlayer()
							ActivateRockstarEditor()
						end 
					end, function(data, menu)
						menu.close()
					end)
				end 
			end, function(data, menu)
				menu.close()
			end)
		end
	end
end)

