Config                            = {}

Config.DrawDistance               = 50.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 0.5 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }

Config.Zones = {

	Cloakroom = {
		Pos     = {x = 484.1, y = -3050.94, z = 6.23},
		Size    = {x = 1.0, y = 1.0, z = 1.0},
		Color   = {r = 204, g = 204, b = 0},
		Type    = 21, Rotate = true
	},

	spawner1 = {
		Pos     = {x = 511.27, y = -3036.82, z = 6.14},
		Size    = {x = 1.0, y = 1.0, z = 1.0},
		Color   = {r = 204, g = 204, b = 0},
		Type    = 21, Rotate = true, heading = 0.0,
		theVehs	= {
			{ model = 'pounder2', label = 'Pounder 2 (0)', pointsRequired=0, startJob=true},
			{ model = 'packer', label = 'Packer (0)', pointsRequired=0, startJob=true}, 
			{ model = 'hauler', label = 'Hauler (1,200)', pointsRequired=1200, startJob=true}, 
			{ model = 'mule', label = 'Mule (2,300)', pointsRequired=2300, startJob=true}, 
			{ model = 'pounder', label = 'Pounder (3,400)', pointsRequired=3400, startJob=true}, 
			{ model = 'phantom', label = 'Phanton Truck (4,600)', pointsRequired=4600, startJob=true}, 
			{ model = 'phantom3', label = 'Phaton Truck 3 (7,600)', pointsRequired=7600, startJob=true}
		}
	},

	spawner2 = {
		Pos     = {x = 530.97, y = -3038.2, z = 6.07},
		Size    = {x = 1.0, y = 1.0, z = 1.0},
		Color   = {r = 204, g = 204, b = 0},
		Type    = 21, Rotate = true, heading = 55.66,
		theVehs	= {
			{ model = 'pounder2', label = 'Pounder 2 (0)', pointsRequired=0, startJob=true},
			{ model = 'packer', label = 'Packer (0)', pointsRequired=0, startJob=true}, 
			{ model = 'hauler', label = 'Hauler (1,200)', pointsRequired=1200, startJob=true}, 
			{ model = 'mule', label = 'Mule (2,300)', pointsRequired=2300, startJob=true}, 
			{ model = 'pounder', label = 'Pounder (3,400)', pointsRequired=3400, startJob=true}, 
			{ model = 'phantom', label = 'Phanton Truck (4,600)', pointsRequired=4600, startJob=true}, 
			{ model = 'phantom3', label = 'Phaton Truck 3 (7,600)', pointsRequired=7600, startJob=true}
		}
	}

	
}

Config.Trailers = {
	"trailerlogs",
	"trailerlarge",
	"tanker2",
	"tanker",
	"trailers",
	"trailers2",
	"trailers3",
	"trailers4",
	"tvtrailer",
	"tr4",
	"tr3"
}

Config.Trucker = {
	Blip = {
		Coords     = {x = 484.1, y = -3050.94, z = 6.23},
		Sprite  = 632,
		Display = 4,
		Scale   = 1.2,
		Colour  = 5
	},

	Cloakrooms = {
		vector3(-993.32, -2832.85, 13.94)
	},
}


Config.StartPointJobs = {
	vector3(486.72, -3153.86, 6.0),
	vector3(-172.75, -2390.98, 6.0),
	vector3(-235.16, -2560.41, 6.0),
	vector3(-410.26, -2789.92, 6.0),
	vector3(1004.64, -2511.07, 28.36),
	vector3(836.87, -1986.89, 29.36),
	vector3(836.87, -1986.89, 29.36),
	vector3(256.45, -1156.3, 29.31),
	vector3(2751.85, 1703.62, 24.75),
	vector3(3588.14, 3763.49, 30.01),
	vector3(1883.51, 5019.47, 49.33),
	vector3(1790.8, 4583.73, 37.27),
	vector3(1949.47, 4639.79, 40.67),
	vector3(1512.48, 3757.86, 34.08),
	vector3(919.39, 3660.6, 32.66),
	vector3(-567.26, 5351.55, 70.3),
	vector3(84.58, 6377.85, 31.3),
	vector3(-182.97, 6288.96, 31.56),
	vector3(-3048.06, 599.97, 7.47),
	vector3(-1332.89, -3319.78, 13.95),
}

Config.StopPointJobs = {
	vector3(486.72, -3153.86, 6.0),
	vector3(-172.75, -2390.98, 6.0),
	vector3(-235.16, -2560.41, 6.0),
	vector3(-410.26, -2789.92, 6.0),
	vector3(1004.64, -2511.07, 28.36),
	vector3(836.87, -1986.89, 29.36),
	vector3(256.45, -1156.3, 29.31),
	vector3(2751.85, 1703.62, 24.75),
	vector3(3588.14, 3763.49, 30.01),
	vector3(1883.51, 5019.47, 49.33),
	vector3(1790.8, 4583.73, 37.27),
	vector3(1949.47, 4639.79, 40.67),
	vector3(1512.48, 3757.86, 34.08),
	vector3(919.39, 3660.6, 32.66),
	vector3(-567.26, 5351.55, 70.3),
	vector3(84.58, 6377.85, 31.3),
	vector3(-182.97, 6288.96, 31.56),
	vector3(-3048.06, 599.97, 7.47),
	vector3(-1332.89, -3319.78, 13.95),
}