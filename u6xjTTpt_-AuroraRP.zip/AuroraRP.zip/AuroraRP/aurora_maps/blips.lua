local blips = {
    -- Example {title="", colour=, id=, x=, y=, z=},

     {title="Garden Wedding", colour=8, id=181, x = -1577.85, y = 89.96, z = 58.88},
     {title="City Hall", colour=46, id=475, x = -542.76, y = -208.34, z = 37.69},
	 --{title="City Hall", colour=46, id=475, x = 228.61, y = -892.35, z = 30.69},
	 {title="Aurora News", colour=1, id=135, x = -1081.66, y = -260.44, z = 37.81},
	 {title="Aurora Church", colour=37, id=183, x = -766.97, y = -23.21, z = 41.08},
	 --{title="Mafia", colour=76, id=78, x = 1349.07, y = -3333.73, z = 6.14},
	 --{title="38th Street Gang", colour=2, id=463, x = -565.906, y = 276.093, z = 100.176},
  }
      
Citizen.CreateThread(function()

    for _, info in pairs(blips) do
      info.blip = AddBlipForCoord(info.x, info.y, info.z)
      SetBlipSprite(info.blip, info.id)
      SetBlipDisplay(info.blip, 4)
      SetBlipScale(info.blip, 1.0)
      SetBlipColour(info.blip, info.colour)
      SetBlipAsShortRange(info.blip, true)
	  BeginTextCommandSetBlipName("STRING")
      AddTextComponentString(info.title)
      EndTextCommandSetBlipName(info.blip)
    end
end)

Citizen.CreateThread(function()
  AddTextEntryByHash(GetHashKey("demonhawk"), "Demon Hawk")
  AddTextEntryByHash(GetHashKey("lx570"), "Lexus LX570")
  AddTextEntryByHash(GetHashKey("subwrx"), "Subaru Impreza WRX STI 2004")
  AddTextEntryByHash(GetHashKey("urus"), "Lamborghini Urus")
  AddTextEntryByHash(GetHashKey("p1"), "McLaren P1 2014")
  AddTextEntryByHash(GetHashKey("veloster2"), "Tyrant's Velo")
  AddTextEntryByHash(GetHashKey("skyline"), "Tyrant's Godzilla")
  AddTextEntryByHash(GetHashKey("nmax155"), "Yamaha Nmax")
  AddTextEntryByHash(GetHashKey("10ram"), "2010 Dodge Ram 3500")
  AddTextEntryByHash(GetHashKey("agerars"), "Agera RS")
  AddTextEntryByHash(GetHashKey("avj"), "Lamborghini Aventador J Speedster 2012")
  AddTextEntryByHash(GetHashKey("bati2"), "Honda Sonic 125i")
  AddTextEntryByHash(GetHashKey("bison"), "Nissan Titan Warrior 2017")
  AddTextEntryByHash(GetHashKey("bmws"), "BMW S1000 RR 2014")
  AddTextEntryByHash(GetHashKey("brzbn"), "BN Sports BRZ GT86")
  AddTextEntryByHash(GetHashKey("bugatti"), "Bugatti Veyron")
  AddTextEntryByHash(GetHashKey("carbonrs"), "Yamaha Mio Sporty")
  AddTextEntryByHash(GetHashKey("chiron17"), "Bugatti Chiron 2017")
  AddTextEntryByHash(GetHashKey("civic"), "Civic SI")
  AddTextEntryByHash(GetHashKey("comet2"), "Porsche 911 RWB 1993")
  AddTextEntryByHash(GetHashKey("dominator"), "GTR Mustang")
  AddTextEntryByHash(GetHashKey("elegy2"), "Nissan GTR Nismo")
  AddTextEntryByHash(GetHashKey("everest"), "Ford Everest 2019")
  AddTextEntryByHash(GetHashKey("ferrari812"), "Ferrari 812")
  AddTextEntryByHash(GetHashKey("fusilade"), "Lamborghini Gallordo")
  AddTextEntryByHash(GetHashKey("fxxk"), "Ferrari Fxx-K")
  AddTextEntryByHash(GetHashKey("gtrc"), "Mercedes AMG GTR")
  AddTextEntryByHash(GetHashKey("hcbr17"), "2017 Honda CBR1000RR")
  AddTextEntryByHash(GetHashKey("hilux1"), "2016 Toyota Hilux")
  AddTextEntryByHash(GetHashKey("hondacivictr"), "Honda Civic Type R 2018")
  AddTextEntryByHash(GetHashKey("kuruma"), "Mitsubishi Lancer EVO X FQ-400")
  AddTextEntryByHash(GetHashKey("r25"), "2019 Yamaha R25/R3")
  AddTextEntryByHash(GetHashKey("r8prior"), "Audi R8 Prior")
  AddTextEntryByHash(GetHashKey("superduty"), "2008 Ford F350")
  AddTextEntryByHash(GetHashKey("supra2"), "Toyota Supra TRD")
  AddTextEntryByHash(GetHashKey("vxr"), "Land Cruiser")
end)