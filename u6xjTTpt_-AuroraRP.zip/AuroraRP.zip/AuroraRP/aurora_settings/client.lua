Citizen.InvokeNative(GetHashKey("ADD_TEXT_ENTRY"), "FE_THDR_GTAO", "Aurora Roleplay | aurorav.net")

ESX = nil
local theSettingTable = {
	['chat'] = 0
}

Citizen.CreateThread(function()
	TriggerEvent('esx:getShaurorarpacaredObjaurorarpacect', function(obj) 
		ESX = obj 
		ESX.TriggerServerCallback('aurora_settings:requestSetting', function(isSettingEnable)
			theSettingTable['chat'] = isSettingEnable
		end, "chat")
	end)
end)

RegisterNetEvent('aurora_settings:onChangeSetting')
AddEventHandler('aurora_settings:onChangeSetting', function(theSettingName, isSettingValue)
	print ("Got new setting from "..theSettingName.." set to "..isSettingValue)
    theSettingTable[theSettingName] = isSettingValue
end)
	
exports("getPlayerSetting", function (settingName)
  return theSettingTable[settingName]
end)