Config = {}

Config.nightclubs = {
	-- nightclubBahamas = {
		-- dancefloor = {
			-- Pos = {x = -1387.0628662109, y=  -618.31188964844, z = 30.81955909729},
			-- Marker = { w= 25.0, h= 1.0,r = 204, g = 204, b = 0},
			-- HelpPrompt = "Appuyer sur ~INPUT_PICKUP~ pour afficher le menu de danse",
		-- }, 
		-- djbooth = {
			-- Pos = {x = -1384.628662109, y=  -627.31188964844, z = 30.81955909729}, 
			-- Marker = { w= 1.0, h= 0.5,r = 204, g = 204, b = 0},
			-- HelpPrompt = "Appuyer sur ~INPUT_PICKUP~ pour prendre votre place de dj",
		-- },
	-- },	
	-- nightclubUnicorn = {
		-- dancefloor = {
			-- Pos = {x = 110.13, y=  -1288.70, z = 28.85},
			-- Marker = { w= 25.0, h= 1.0,r = 204, g = 204, b = 0},
			-- HelpPrompt = "Appuyer sur ~INPUT_PICKUP~ pour afficher le menu de danse",
		-- }, 
		-- djbooth = {
			-- Pos = {x = 118.6188, y=  -1288.85, z = 28.81955909729}, 
			-- Marker = { w= 1.0, h= 0.5,r = 204, g = 204, b = 0},
			-- HelpPrompt = "Appuyer sur ~INPUT_PICKUP~ pour prendre votre place de dj",
		-- },
	-- },	
	--[[nightclubunderground = {
		dancefloor = {
			Pos = {x = -1592.275, y=  -3012.131, z = -78.00},
			Marker = { w= 30.0, h= 1.0,r = 204, g = 204, b = 0},
			HelpPrompt = "Appuyer sur ~INPUT_PICKUP~ pour afficher le menu de danse",
		}, 
		djbooth = {
			Pos = {x = -1603.98, y=  -3012.802, z = -77.79}, 
			Marker = { w= 1.0, h= 0.5,r = 204, g = 204, b = 0},
			HelpPrompt = "Appuyer sur ~INPUT_PICKUP~ pour prendre votre place de dj",
		},
	},
	publicGarae = {
		dancefloor = {
			Pos = {x = 226.45, y= -783.22, z = 30.37},
			Marker = { w= 50.0, h= 1.0,r = 204, g = 204, b = 0},
			HelpPrompt = "Press ~INPUT_PICKUP~ to dance",
		}, 
		djbooth = {
			Pos = {x = 275.11, y=  -740.49, z = 39.02}, 
			Marker = { w= 1.0, h= 0.5,r = 204, g = 204, b = 0},
			HelpPrompt = "Press ~INPUT_PICKUP~ to dj",
		},
	},]]--
	publicStage = {
		dancefloor = {
			--Pos = {x = -1488.38, y= -1481.1, z = 5.1}, --Wedding Beach
			Pos = {x = 2850.41, y= -745.0, z = 9.5}, --X House 
			--Pos = {x = 1145.97, y= 3978.26, z = 59.04}, --Island
			--Pos = {x = -2234.62, y= -623.19, z = 15.62},
			--Pos = {x = -1578.94, y= 89.23, z = 59.0},
			--Pos = {x = 2853.61, y= -746.5, z = 9.48},
			--Pos = {x = 235.31, y= -760.39, z = 30.87},
			Marker = { w= 400.0, h= 30.0, r = 204, g = 204, b = 0},
			HelpPrompt = "Press ~INPUT_PICKUP~ to dance",
		}, 
		djbooth = {
			Pos = {x = 275.11, y=  -740.49, z = 39.02}, 
			Marker = { w= 1.0, h= 0.5,r = 204, g = 204, b = 0},
			HelpPrompt = "Press ~INPUT_PICKUP~ to dj",
		},
	},
}

Config.Songs = {
	{song = "https://o.curt.sg/file/curt-img/2019/08/imloney.mp3", label ="Lauv - i'm lonely (with Anne-Marie)"},
	{song = "https://o.curt.sg/file/curt-img/2019/08/beautifulpeople.mp3", label ="Ed Sheeran - Beautiful People"},
	{song = "http://www.181.fm/winamp.pls?station=181-party&file=181-party.pls", label ="Party 181 (Radio)"},
	{song = "http://www.181.fm/winamp.pls?station=181-powerexplicit&file=181-powerexplicit.pls", label ="Power 181 (Radio)"},
	{song = "http://fivem.curt.sg:8383/batangpasaway.mp3", label = "Batang Pasaway"}
}