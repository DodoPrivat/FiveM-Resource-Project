Config              = {}
Config.MarkerType   = -1 -- Marker visible or not. -1 = hiden  Set to 1 for a visible marker. To have a list of avaible marker go to https://docs.fivem.net/game-references/markers/
Config.DrawDistance = 100.0 --Distance where the marker be visible from
Config.ZoneSize     = {x = 2.0, y = 2.0, z = 3.0}
Config.MarkerColor  = {r = 0, g = 255, b = 0} --Color of the marker

Config.RequiredCopsCoke  = 0 --Ammount of cop that need to be online to be able to harvest/process/sell coke
Config.RequiredCopsMeth  = 0 --Ammount of cop that need to be online to be able to harvest/process/sell meth
Config.RequiredCopsWeed  = 0 --Ammount of cop that need to be online to be able to harvest/process/sell weed
Config.RequiredCopsOpium = 0 --Ammount of cop that need to be online to be able to harvest/process/sell opium

Config.TimeToFarmWeed     = 2  * 1000 -- Ammount of time to harvest weed
Config.TimeToProcessWeed  = 4  * 1000 -- Ammount of time to process weed
Config.TimeToSellWeed     = 1  * 1000 -- Ammount of time to sell weed

Config.TimeToFarmOpium    = 0.5  * 1000 -- Ammount of time to harvest coke
Config.TimeToProcessOpium = 1  * 1000 -- Ammount of time to process coke
Config.TimeToSellOpium    = 1  * 1000 -- Ammount of time to sell coke

Config.TimeToFarmCoke     = 6  * 1000 -- Ammount of time to harvest coke
Config.TimeToProcessCoke  = 8  * 1000 -- Ammount of time to process coke
Config.TimeToSellCoke     = 1  * 1000 -- Ammount of time to sell coke

Config.TimeToFarmMeth     = 0.5  * 1000 -- Ammount of time to harvest meth
Config.TimeToProcessMeth  = 1 * 1000 -- Ammount of time to process meth
Config.TimeToSellMeth     = 1  * 1000 -- Ammount of time to sell meth

Config.Locale = 'en'

Config.Zones = {
--	CokeField =			{x=1363.3,  y=-3316.49,  z=5.19},
--	CokeProcessing =	{x=1359.32,  y=-3316.12,  z=5.19},
--	CokeDealer =		{x=2744.28,   y=1487.22,   z=30.79},
	MethField =			{x=2368.42,  y=3055.72,  z=47.3},
	MethProcessing =	{x=3287.74,  y=5186.73,  z=18.42},
	MethDealer =		{x=-298.44,     y=2540.52,   z=73.61},
--	WeedField =			{x=1362.36,  y=-3322.15,  z=5.99},
--	WeedProcessing =	{x=1359.38,  y=-3322.44,  z=5.99},
--	WeedDealer =		{x=1538.81,   y=6321.92,  z=25.07},
	OpiumField =		{x=725.23,  y=4193.01,   z=40.71},
	OpiumProcessing =	{x=1391.84,   y=1147.4,   z=114.33},
	OpiumDealer =		{x=2338.12, y=2570.8,   z=47.72}
}

Config.DisableBlip = true -- Set to true to disable blips. False to enable them.
Config.Map = {

  {name="Coke Farm Entrance",    color=4, scale=0.8, id=501, x=47.842,     y=3701.961,   z=40.722},
  {name="Coke Farm",             color=4, scale=0.3, id=501, x=1363.3,  y=-3316.49,  z=4.19},
  {name="Coke Processing",       color=4, scale=0.3, id=501, x=1359.32,  y=-3316.12,  z=4.19},
  {name="Coke Sales",            color=3, scale=0.3, id=501, x=2744.28,   y=1487.22,   z=30.79},
  {name="Meth Farm Entrance",    color=6, scale=0.8, id=499, x=1386.659,   y=3622.805,   z=35.012},
  {name="Meth Farm",             color=6, scale=0.8, id=499, x=2368.42,  y=3055.72,  z=47.3},
  {name="Meth Processing",       color=6, scale=0.3, id=499, x=3287.74,  y=5186.73,  z=18.42},
  {name="Meth Sales",            color=3, scale=0.3, id=499, x=-298.44,     y=2540.52,   z=73.61},
  {name="Opium Farm Entrance",   color=6, scale=0.8, id=403, x=1538.64,     y=6321.92,   z=190.33},
  {name="Opium Farm",            color=6, scale=0.3, id=403, x=1362.38,  y=-3319.46,   z=5.19},
  {name="Opium Processing",      color=6, scale=0.3, id=403, x=1359.58,   y=-3319.54,   z=5.19},
  {name="Opium Sales",           color=3, scale=0.3, id=403, x=-1909.43, y=2082.72,   z=140.38},
  {name="Weed Farm Entrance",    color=2, scale=0.8, id=140, x=2221.858,   y=5614.81,    z=54.902},
  {name="Weed Farm",             color=2, scale=0.3, id=140, x=1362.36,  y=-3322.15,  z=4.99},
  {name="Weed Processing",       color=2, scale=0.3, id=140, x=1359.38,  y=-3322.44,  z=4.99},
  {name="Weed Sales",            color=3, scale=0.3, id=140, x=85.58,      y=-1959.34,   z=20.13}

}
