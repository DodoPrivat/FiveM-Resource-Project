-- DFWM 6.0 config

--Readme , if you ask support about that you will get banned...
--Rememeber to configure your config.lua, if it give errors , lags or problems is your fault!!
--The default options are giving you great protection without performance issues

Config = {}
Config.Version=6 -- DO NOT TOUCH!

--LOGS--
Config.ConsoleLogger = true -- LOG on CONSOLE when someone get detected / kicked / banned (recommended)
Config.DiscordLogger = true -- LOG on DISCORD when someone get detected / kicked / banned (recommended)
Config.ChatLogger = true -- LOG on INGAME CHAT when someone get detected / kicked / banned (optional)

Config.ViolationDetectedMSG = "You have been kicked due to unusual action. This action has been logged and sent to our staff. If you believe that this is an error, please contact a staff.\nMore info: discord.aurorav.net."
Config.BanOnKick = false -- AUTOMATICALLY BAN A DETECTED USER (optional, for lazy people) #can be unstable
-------

Config.AntiCheat = true -- General shit, "AntiInvincible, AntiInfiniteAmmo, etc."
Config.AntiGodmode = false -- DISABLE THIS ON VRP!! #can be unstable
Config.AntiSpectate = true -- HIGHLY RECOMMENDED
Config.AntiBlips = false  -- HIGHLY RECOMMENDED
Config.PlayerProtection = false -- FIRE AND EXPLOSIONS (this only protect your players from being damaged by explosions or fire)

Config.AntiSpeedHack = true -- On foot (not falling) anti speed hack (optional)
Config.SpeedHackValue = 10.0 -- MAX SPEED ALLOWED FOR WALKING/RUNNING/SWIMMING from 0.0 to 99.0

Config.TriggerKick = true -- Use this only if you windows.bat/replace.py your files, HIGHLY RECOMMENDED
Config.ChatKick = true -- Kick a player if says something blacklisted (cheat stuff,links,etc.) HIGHLY RECOMMENDED

Config.AntiNuke = true -- ONESYNC ONLY!! HIGHLY RECOMMENDED (WORKS WITH BLACKLISTED ENTITIES BELOW! REMEMBER TO CONFIGURE THEM BEFORE SWITCHING THIS TO TRUE) (Detects nukes and kick/ban the user that tried to nuke your server)
Config.BlockExplosions = false -- ONESYNC ONLY!! (PROBABLY FIXED! TEST IT!)
Config.KickOnExplosion = false -- not recommended
---------------AntiKeys-------- not recommended------------ 

Config.AntiKey = false -- MASTERSWITCH FOR ANTIKEYS
Config.AntiKeyInsert = false -- INSERT KEY KICK
Config.AntiKeyTabQ = false -- TAB + Q KEY KICK
Config.AntiKeyShiftG = false -- SHIFT + G KEY KICK

---------------Blacklisted Commands------------------------

Config.AntiBlacklistedCmds = false -- Detects less cheats but works on all servers
Config.AntiBlacklistedCmdsBETA = true -- Detects more cheats but not working on all servers

---------------Blacklisted Weapons-----------------

Config.AntiBlacklistedWeapons = true -- Detect and log if someone is holding a blacklisted weapon
Config.AntiBlacklistedWeaponsKick = false -- if the player get detected, kick him (NOT RECOMMENDED)
Config.BlacklistedWeapons = {
	"WEAPON_HOMINGLAUNCHER",
	"WEAPON_COMPACTLAUNCHER",
	"WEAPON_RAYCARBINE",
	"WEAPON_COMPACTRIFLE",
	"WEAPON_MG",
	"WEAPON_PROXMINE",
	"WEAPON_MARKSMANRIFLE",
	"WEAPON_MARKSMANRIFLE_MK2",
	"WEAPON_MARKSMANPISTOL",
	"WEAPON_SAWNOFFSHOTGUN",
	"WEAPON_MUSKET",
	"WEAPON_MINIGUN",
	"WEAPON_RAYPISTOL",
	"WEAPON_RAILGUN",
	"WEAPON_HEAVYSNIPER_MK2"
}
---------------Permissions-------------------------

Config.Bypass = {"dfwmadmin","dfwmmod"} --GODMODE,BLIPS,BLACKLISTEDCMDS,SPEEDHACK

Config.OpenMenuAllowed = {"dfwmadmin"}
Config.SpectateAllowed = {"dfwmadmin","dfwmmod"}
Config.ClearAreaAllowed = {"dfwmadmin"}
Config.BlipsAllowed = {"dfwmadmin","dfwmmod","dfwmpolice"} -- ADDED DFWM POLICE BYPASS

---------------Blacklisted Models-------------------------


Config.AutomaticVehDelete = false -- This bool deletes automatically blacklisted vehicles (may cause lag!! use as your risk)
Config.AutomaticEntDelete = true -- This bool deletes automatically blacklisted entities (may cause lag!! use as your risk)
Config.AutomaticPedsDelete = true -- This bool deletes automatically blacklisted peds (may cause lag!! use as your risk)
Config.AutomaticDeleteTimeout = 3500 -- This timeout is how often the server checks for blacklisted stuff! (1000 = 1s) (Lower = lag)

-- README , IF YOU ASK SUPPORT ABOUT THAT , I PROMISE, I BAN YOU <3
-- For string models use "" example : "cargoplane","adder","lol"
-- For Hash models DON'T USE "" example : -12345,-98712,13371337
-- DONT FORGET TO PUT , if you add more models!! USE YOUR BRAIN!

Config.BlacklistedModels = {
}

Config.BlacklistedEntities = {
	"prop_fnclink_05crnr1",
	"xs_prop_hamburgher_wl",
	"xs_prop_plastic_bottle_wl",
	"prop_windmill_01",
	"p_spinning_anus_s",
	"stt_prop_ramp_adj_flip_m",
	"stt_prop_ramp_adj_flip_mb",
	"stt_prop_ramp_adj_flip_s",
	"stt_prop_ramp_adj_flip_sb",
	"stt_prop_ramp_adj_hloop",
	"stt_prop_ramp_adj_loop",
	"stt_prop_ramp_jump_l",
	"stt_prop_ramp_jump_m",
	"stt_prop_ramp_jump_s",
	"stt_prop_ramp_jump_xl",
	"stt_prop_ramp_jump_xs",
	"stt_prop_ramp_jump_xxl",
	"stt_prop_ramp_multi_loop_rb",
	"stt_prop_ramp_spiral_l",
	"stt_prop_ramp_spiral_l_l",
	"stt_prop_ramp_spiral_l_m",
	"stt_prop_ramp_spiral_l_s",
	"stt_prop_ramp_spiral_l_xxl",
	"stt_prop_ramp_spiral_m",
	"stt_prop_ramp_spiral_s",
	"stt_prop_ramp_spiral_xxl",
	-145066854
}
	
	
Config.BlacklistedPeds = {
	"s_m_y_swat_01",
	"a_m_y_mexthug_01",
	"a_c_husky", 
	"a_c_cat_01", 
	"a_c_boar", 
	"a_c_sharkhammer", 
	"a_c_coyote", 
	"a_c_chimp", 
	"a_c_chop", 
	"a_c_cow", 
	"a_c_deer", 
	"a_c_dolphin", 
	"a_c_fish", 
	"a_c_hen", 
	"a_c_humpback", 
	"a_c_killerwhale", 
	"a_c_mtlion", 
	"a_c_pig", 
	"a_c_pug", 
	"a_c_rabbit_01", 
	"a_c_retriever", 
	"a_c_rhesus", 
	"a_c_rottweiler", 
	"a_c_sharktiger", 
	"a_c_shepherd", 
	"a_c_westy",
	"u_m_y_zombie_01"
}

