Config                            = {}

Config.DrawDistance               = 50.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 0.5 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }

Config.Zones = {

	Cloakroom = {
		Pos     = {x = 678.1, y = -912.98, z = 23.46},
		Size    = {x = 1.0, y = 1.0, z = 1.0},
		Color   = {r = 204, g = 204, b = 0},
		Type    = 607, Rotate = true
	},

	spawner1 = {
		Pos     = {x = 672.91, y = -904.12, z = 22.24},
		Size    = {x = 1.0, y = 1.0, z = 1.0},
		Color   = {r = 204, g = 204, b = 0},
		Type    = 21, Rotate = true, heading = 177.81,
		theVehs	= {
			{ model = 'train', label = 'Train (0)', pointsRequired=0, startJob=true},
		}
	}

	
}


Config.Train = {
	Blip = {
		Coords     = {x = 678.1, y = -912.98, z = 23.46},
		Sprite  = 607,
		Display = 4,
		Scale   = 1.2,
		Colour  = 5
	},

	Cloakrooms = {
		vector3(-993.32, -2832.85, 13.94)
	},
}


Config.StartPointJobs = {
	vector3(664.62, -954.23, 22.56),
	vector3(239.66, -2596.97, 6.68),
	vector3(680.66, -1263.01, 25.02),
	vector3(669.27, -872.28, 23.33),
	vector3(2611.04, 1698.72, 27.44),
	vector3(2623.73, 2946.43, 40.74),
	vector3(371.67, 6431.71, 32.11),
	vector3(-141.94, 6140.35, 32.22),
	vector3(2570.63, 2882.97, 40.01),
}

Config.StopPointJobs = {
	vector3(664.62, -1086.14, 23.73),
	vector3(239.66, -2596.97, 6.68),
	vector3(680.66, -1263.01, 25.02),
	vector3(669.27, -872.28, 23.33),
	vector3(2611.04, 1698.72, 27.44),
	vector3(2623.73, 2946.43, 40.74),
	vector3(371.67, 6431.71, 32.11),
	vector3(-141.94, 6140.35, 32.22),
	vector3(2570.63, 2882.97, 40.01),
}