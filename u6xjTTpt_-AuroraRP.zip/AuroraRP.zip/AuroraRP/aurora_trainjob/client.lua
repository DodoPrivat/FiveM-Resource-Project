local HasAlreadyEnteredMarker, OnJob, IsNearCustomer, CustomerIsEnteringVehicle, CustomerEnteredVehicle, IsDead, CurrentActionData, CurrentRotation, startJob = false, false, false, false, false, false, {}, 0, false
local CurrentCustomer, CurrentCustomerBlip, DestinationBlip, targetCoords, LastZone, CurrentAction, CurrentActionMsg
local theJobVehicles = {}
local theJobTrailer, theJobVehicle
ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getShaurorarpacaredObjaurorarpacect', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)


Citizen.CreateThread(function()
	local blip = AddBlipForCoord(Config.Train.Blip.Coords.x, Config.Train.Blip.Coords.y, Config.Train.Blip.Coords.z)

	SetBlipSprite (blip, Config.Train.Blip.Sprite)
	SetBlipDisplay(blip, 4)
	SetBlipScale  (blip, 1.0)
	SetBlipColour (blip, 5)
	SetBlipAsShortRange(blip, true)

	BeginTextCommandSetBlipName('STRING')
	AddTextComponentSubstringPlayerName("Train Driver")
	EndTextCommandSetBlipName(blip)
end)

function hasEnteredMarker (zone)
	if zone == 'Cloakroom' then
		CurrentAction     = 'cloakroom'
		CurrentActionMsg  = "Open Cloakroom"
		CurrentActionData = {}
	elseif zone == 'spawner1' then
		if (OnJob == true) then 
			CurrentAction     = 'vehicle'
			CurrentActionMsg  = "Open Vehicle Spawner"
			CurrentActionData = Config.Zones.spawner1.theVehs
			CurrentRotation = Config.Zones.spawner1.heading
		else
			ESX.ShowHelpNotification("Your not in duty!")
		end
	end
end

--Train API utils
function getVehicleInDirection(coordFrom, coordTo)
	local rayHandle = CastRayPointToPoint(coordFrom.x, coordFrom.y, coordFrom.z, coordTo.x, coordTo.y, coordTo.z, 10, GetPlayerPed(-1), 0)
	local a, b, c, d, vehicle = GetRaycastResult(rayHandle)
	return vehicle
end

function findNearestTrain()
	local localPedPos = GetEntityCoords(GetPlayerPed(-1))
	local entityWorld = GetOffsetFromEntityInWorldCoords(GetPlayerPed(-1), 0.0, 120.0, 0.0)
	local veh = getVehicleInDirection(localPedPos, entityWorld)
	
	if veh > 0 and IsEntityAVehicle(veh) and IsThisModelATrain(GetEntityModel(veh)) then
		return veh
	else
		return 0
	end
end
--End of train API utils

function hasExitedMarker (zone)
	ESX.UI.Menu.CloseAll()
	CurrentAction = nil
end

function OpenCloakroom()
	ESX.UI.Menu.CloseAll()

	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'train_cloakroom',
	{
		title    = "Cloakroom",
		align    = 'top-left',
		elements = {
			{ label = "Wear Citizen", value = 'wear_citizen' },
			{ label = "Wear Work Clothes",    value = 'wear_work'}
		}
	}, function(data, menu)
		if data.current.value == 'wear_citizen' then
			OnJob = false
			ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin)
				TriggerEvent('skinchanger:loadSkin', skin)
			end)
		elseif data.current.value == 'wear_work' then
			ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
				if skin.sex == 0 then
					TriggerEvent('skinchanger:loadClothes', skin, {
	                    ['tshirt_1'] = 35,  ['tshirt_2'] = 0,
	                    ['torso_1'] = 112,   ['torso_2'] = 0,
	                    ['decals_1'] = 0,   ['decals_2'] = 0,
	                    ['arms'] = 14,
	                    ['pants_1'] = 22,   ['pants_2'] = 5,
	                    ['shoes_1'] = 20,   ['shoes_2'] = 0,
	                    ['helmet_1'] = 113,  ['helmet_2'] = 5,
	                    ['chain_1'] = 26,    ['chain_2'] = 2
	                })
	            else
	            	TriggerEvent('skinchanger:loadClothes', skin, {
	                    ['tshirt_1'] = 41,  ['tshirt_2'] = 2,
	                    ['torso_1'] = 104,   ['torso_2'] = 0,
	                    ['decals_1'] = 0,   ['decals_2'] = 0,
	                    ['arms'] = 0,
	                    ['pants_1'] = 50,   ['pants_2'] = 0,
	                    ['shoes_1'] = 42,   ['shoes_2'] = 2,
	                    ['helmet_1'] = 112,  ['helmet_2'] = 5,
	                    ['chain_1'] = 28,    ['chain_2'] = 0
	                })
	            end 
			end)
			OnJob = true
			ESX.ShowHelpNotification("Your now able to work as a Train Driver!")
			ESX.ShowAdvancedNotification("Aurora Train Driver", "Welcome to the team", "To get started, please head to the train vehicle marker!", "CHAR_DAVE", 1)
		end
	end, function(data, menu)
		menu.close()

		CurrentAction     = 'cloakroom'
		CurrentActionMsg  = "Open Cloakroom"
		CurrentActionData = {}
	end)
end

function OpenVehicleSpawnerMenu(theVehicles)
	local coords = GetEntityCoords(PlayerPedId())
	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'vehicle_spawner',
	{
		title		= "Vehicles",
		align		= 'top-left',
		elements	= theVehicles
	}, function(data, menu)
		if not ESX.Game.IsSpawnPointClear(coords, 5.0) then
			ESX.ShowNotification("Cannot spawn due to spawn point is blocked!")
			return
		end

		ESX.TriggerServerCallback('aurora_jobranks:getPlayerPointsFromJob', function(thePlayerPoint)
			if (thePlayerPoint >= data.current.pointsRequired) then
				if (theJobVehicle ~= nil) then 
					print("Trying to delete train.")
					exports.aurora_trainsapi:deleteTrain(theJobVehicle)
				end
				theJobVehicle = exports.aurora_trainsapi:createTrain(23, 664.6, -903.27, 22.16)
				if (GetPedInVehicleSeat(theJobVehicle, 1) == 0) then
					SetPedIntoVehicle(GetPlayerPed(-1), theJobVehicle, -1)
					Citizen.CreateThread(function()
						local threadID = GetIdOfThisThread()
						local countdown = 5
						local ped = GetPlayerPed(-1)
						while true do
							local vehicle = GetVehiclePedIsIn(ped, false)
							if (not IsPedSittingInAnyVehicle(ped)) then 
								if (GetPedInVehicleSeat(vehicle, -1) ~= ped) then 
									if (vehicle ~= theJobVehicle) then 
										if (countdown <= 0) then 
											exports.aurora_trainsapi:deleteTrain(theJobVehicle)
											theJobVehicle = nil
											ESX.ShowAdvancedNotification("Aurora Train Driver", "Get back to your train", "Your train despawned.", "CHAR_DAVE", 1)
											TerminateThread(threadID)
											break
										else
											countdown = countdown - 1
											ESX.ShowAdvancedNotification("Aurora Train Driver", "Get back to your train", "Your train will despawn in "..countdown..".", "CHAR_DAVE", 1)
										end
									end
								end
							else
								countdown = 5
							end
							Citizen.Wait(1000)
						end
					end)

					if data.current.startJob and startJob == false then
						makeClientStartJob()
					else
						startJob = false
					end
				end
				menu.close()
			else
				ESX.ShowAdvancedNotification("Aurora Train Driver", "Miles Required", "You only have "..thePlayerPoint.." miles travelled! You need to earn more miles.", "CHAR_DAVE", 1)
			end
		end, "TrainDriver")
		
	end, function(data, menu)
		CurrentAction     = 'vehicle_spawner'
		CurrentActionMsg  = "Open Vehicle Spawner"
		CurrentActionData = {}

		menu.close()
	end)
end

function makeClientStartJob ()
	local theEndCoords, targetCoords
	while true do 
		local coords = GetEntityCoords(PlayerPedId())
		ESX.ShowAdvancedNotification("Aurora Train Driver", "Finding", "Finding the best route for your mission.", "CHAR_DAVE", 1)
		theEndCoords = Config.StopPointJobs[GetRandomIntInRange(1, #Config.StartPointJobs)]
		targetCoords = Config.StopPointJobs[GetRandomIntInRange(1, #Config.StopPointJobs)]
		local theFinalDistance = GetDistanceBetweenCoords(targetCoords.x, targetCoords.y, targetCoords.z, theEndCoords.x, theEndCoords.y, theEndCoords.z, true)
		local theFinalDistanceUser = GetDistanceBetweenCoords(targetCoords.x, targetCoords.y, targetCoords.z, coords, true)
		break
		if (theFinalDistance >= 500) then 
			if (theFinalDistanceUser <= 500) then 
				break
			end
		end
		Citizen.Wait(200)
	end
	startJob = true
	ESX.ShowAdvancedNotification("Aurora Train Driver", "Ready for cargo load", "Please proceed to the marked area for loading the cargo.", "CHAR_DAVE", 1)
	SetNewWaypoint(targetCoords.x, targetCoords.y)
	local ped = GetPlayerPed(-1)
	while true do 
		if startJob then
			if ESX.PlayerData.job.name ~= 'train' then
				break
			end
			local coords = GetEntityCoords(PlayerPedId())
			local distance = GetDistanceBetweenCoords(coords, targetCoords.x, targetCoords.y, targetCoords.z, true)
			if distance < 100 then
				DrawMarker(22, targetCoords.x, targetCoords.y, targetCoords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 5.0, 5.0, 5.5, 204, 204, 0, 100, false, false, 2, true, nil, nil, false)
			end
			if distance < 15.0 then
				if (GetEntitySpeed(theJobVehicle) == 0) then 
					if (IsPedSittingInAnyVehicle(ped)) then 
						if (DoesEntityExist(ped) and not IsEntityDead(ped)) then 
							local vehicle = GetVehiclePedIsIn(ped, false)
							if (IsPedSittingInAnyVehicle(ped)) then 
								if (GetPedInVehicleSeat(vehicle, -1) == ped) then 
									if (vehicle == theJobVehicle) then 
										break
									else
										ESX.ShowAdvancedNotification("Aurora Train Driver", "Error", "Hmm, the vehicle doesn't belong to us.", "CHAR_DAVE", 1)
									end
						        else 
						            ESX.ShowAdvancedNotification("Aurora Train Driver", "Error", "Your not the driver!", "CHAR_DAVE", 1)
						        end 
							else 
								ESX.ShowAdvancedNotification("Aurora Train Driver", "Error", "Your not in the train!", "CHAR_DAVE", 1)
							end
						end
					end
				else 
					ESX.ShowAdvancedNotification("Aurora Train Driver", "Error", "Your train must be in a full STOP.", "CHAR_DAVE", 1)
				end
			end
		end
		Citizen.Wait(0)
	end
	if ESX.PlayerData.job.name == 'train' then
		exports['mythic_progbar']:Progress({
            name = "aurora_train_action",
            duration = 10500,
            label = "Loading Cargo",
            useWhileDead = true,
            canCancel = false,
            controlDisables = {
                disableMovement = true,
                disableCarMovement = true,
                disableMouse = false,
                disableCombat = true,
            }
        }, function(status)
            if not status then
                while true do 
					if startJob then
						local coords = GetEntityCoords(PlayerPedId())
						local distance = GetDistanceBetweenCoords(coords, theEndCoords.x, theEndCoords.y, theEndCoords.z, true)
						ESX.ShowAdvancedNotification("Aurora Train Driver", "Mission Started", "Please proceed to the marked area to delivery the goods.", "CHAR_DAVE", 1)
						SetNewWaypoint(theEndCoords.x, theEndCoords.y)
						if distance < 100 then
							DrawMarker(22, theEndCoords.x, theEndCoords.y, theEndCoords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 5.0, 5.0, 5.5, 204, 204, 0, 100, false, false, 2, true, nil, nil, false)
						end
						if distance < 15.0 then
							if (GetEntitySpeed(theJobVehicle) == 0) then 
								if (IsPedSittingInAnyVehicle(ped)) then 
									if (DoesEntityExist(ped) and not IsEntityDead(ped)) then 
										local vehicle = GetVehiclePedIsIn(ped, false)
										if (IsPedSittingInAnyVehicle(ped)) then 
											if (GetPedInVehicleSeat(vehicle, -1) == ped) then 
												if (vehicle == theJobVehicle) then 
													break
												else
													ESX.ShowAdvancedNotification("Aurora Train Driver", "Error", "Hmm, the vehicle doesn't belong to us.", "CHAR_DAVE", 1)
												end
									        else 
									            ESX.ShowAdvancedNotification("Aurora Train Driver", "Error", "Your not the driver!", "CHAR_DAVE", 1)
									        end 
										else 
											ESX.ShowAdvancedNotification("Aurora Train Driver", "Error", "Your not in the train!", "CHAR_DAVE", 1)
										end
									end
								end
							else 
								ESX.ShowAdvancedNotification("Aurora Train Driver", "Error", "Your train must be in a full STOP.", "CHAR_DAVE", 1)
							end
						end
					end
					Citizen.Wait(0)
				end

				local theFinalDistance = GetDistanceBetweenCoords(targetCoords.x, targetCoords.y, targetCoords.z, theEndCoords.x, theEndCoords.y, theEndCoords.z, true)
				startJob = false
				exports['mythic_progbar']:Progress({
		            name = "aurora_train_action",
		            duration = 10500,
		            label = "Unloading Cargo",
		            useWhileDead = true,
		            canCancel = false,
		            controlDisables = {
		                disableMovement = true,
		                disableCarMovement = true,
		                disableMouse = false,
		                disableCombat = true,
		            }
		        }, function(status)
		        	if not status then
		        		local thePlayerBaseSalary = math.floor(theFinalDistance*20)
		        		local thePlayerDistance = math.floor(theFinalDistance/1200)
		        		ESX.TriggerServerCallback('aurora_jobranks:addPlayerPointsToJob', function(theReturn)
		        			ESX.TriggerServerCallback('aurora_jobranks:payPlayerSalary', function(theReturn)
		        				ESX.ShowAdvancedNotification("Aurora Train Driver", "Mission Ended", "You have arrived at your destination! You earned P"..thePlayerBaseSalary.." and "..thePlayerDistance.." miles point.", "CHAR_DAVE", 1)
		        				ESX.ShowAdvancedNotification("Aurora Train Driver", "Mission Ended", "For another job press F6 then start job!", "CHAR_DAVE", 1)
		        			end, "TrainDriver", thePlayerBaseSalary)
		        		end, "TrainDriver", thePlayerDistance)
		        	end
		       	end)
            end
        end)
	else
		startJob = false
		OnJob = false
		ESX.ShowAdvancedNotification("Aurora Train Driver", "Failed to load cargo", "Opps! You failed to load the cargo.", "CHAR_DAVE", 1)
	end
end

function OpenMobileActionsMenu()
	ESX.TriggerServerCallback('aurora_jobranks:getPlayerPointsFromJob', function(thePlayerPoint)
		ESX.TriggerServerCallback('aurora_jobranks:getPlayerRankFromJob', function(thePlayerRank)
			ESX.UI.Menu.CloseAll()
			ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'mobile_train_actions', {
				title    = 'Aurora Train Driver',
				align    = 'top-left',
				elements = {
					{label = "Rank: "..thePlayerRank,   value = 'none'},
					{label = "Job Points: "..thePlayerPoint,   value = 'none'},
					{label = "Start Job", value = 'start_job'}
			}}, function(data, menu)
				if data.current.value == 'start_job' then
					if startJob == false then 
						makeClientStartJob()
					else
						ESX.ShowNotification("You cannot start a job while your job is in progress.")
					end
				end
			end, function(data, menu)
				menu.close()
			end)
		end, "TrainDriver")
	end, "TrainDriver")
end

local theBlipCreated = false
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)

		if ESX.PlayerData.job and ESX.PlayerData.job.name == 'train' then
			if (not theBlipCreated) then 
				for k,v in pairs(Config.Zones) do
					if (k == "spawner1") then 
						local blip = AddBlipForCoord(v.Pos.x, v.Pos.y, v.Pos.z)
						SetBlipSprite (blip, 607)
						SetBlipDisplay(blip, 4)
						SetBlipScale  (blip, 0.5)
						SetBlipColour (blip, 5)
						SetBlipAsShortRange(blip, true)
						BeginTextCommandSetBlipName('STRING')
						AddTextComponentSubstringPlayerName("Train Spawner")
						EndTextCommandSetBlipName(blip)
					end
				end
				theBlipCreated = true
			end

			local coords = GetEntityCoords(PlayerPedId())
			local isInMarker, letSleep, currentZone = false, true

			for k,v in pairs(Config.Zones) do
				local distance = GetDistanceBetweenCoords(coords, v.Pos.x, v.Pos.y, v.Pos.z, true)

				if v.Type ~= -1 and distance < Config.DrawDistance then
					letSleep = false
					DrawMarker(v.Type, v.Pos.x, v.Pos.y, v.Pos.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, v.Size.x, v.Size.y, v.Size.z, v.Color.r, v.Color.g, v.Color.b, 100, false, false, 2, v.Rotate, nil, nil, false)
				end

				if distance < v.Size.x then
					isInMarker, currentZone = true, k
				end
			end

			if (isInMarker and not HasAlreadyEnteredMarker) or (isInMarker and LastZone ~= currentZone) then
				HasAlreadyEnteredMarker, LastZone = true, currentZone
				hasEnteredMarker(currentZone)
			end

			if not isInMarker and HasAlreadyEnteredMarker then
				HasAlreadyEnteredMarker = false
				hasExitedMarker(currentZone)
			end

			if letSleep then
				Citizen.Wait(500)
			end
		else
			Citizen.Wait(1000)
		end
	end
end)



Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)

		if CurrentAction and not IsDead then
			ESX.ShowHelpNotification(CurrentActionMsg)

			if IsControlJustReleased(0, 38) and ESX.PlayerData.job and ESX.PlayerData.job.name == 'train' then
				if CurrentAction == 'cloakroom' then
					OpenCloakroom()
				elseif CurrentAction == 'vehicle' then
					OpenVehicleSpawnerMenu(CurrentActionData)
				elseif CurrentAction == 'delete_vehicle' then
					DeleteJobVehicle()
				end

				CurrentAction = nil
			end
		end

		if IsControlJustReleased(0, 167) and IsInputDisabled(0) and not IsDead and ESX.PlayerData.job and ESX.PlayerData.job.name == 'train' then
			OpenMobileActionsMenu()
		end
	end
end)

AddEventHandler('esx:onPlayerDeath', function()
	IsDead = true
end)

AddEventHandler('playerSpawned', function(spawn)
	IsDead = false
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)