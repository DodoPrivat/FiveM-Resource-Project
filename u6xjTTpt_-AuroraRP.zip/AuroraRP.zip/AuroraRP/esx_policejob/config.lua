Config                            = {}

Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 0.5 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }

Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- enable if you're using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableLicenses             = true -- enable if you're using esx_license

Config.EnableHandcuffTimer        = true -- enable handcuff timer? will unrestrain player after the time ends
Config.HandcuffTimer              = 10 * 60000 -- 10 mins

Config.EnableJobBlip              = true -- enable blips for colleagues, requires esx_society

Config.MaxInService               = -1
Config.Locale = 'en'

Config.PoliceStations = {

	LSPD = {

		Blip = {
			Coords  = vector3(425.1, -979.5, 30.7),
			Sprite  = 60,
			Display = 4,
			Scale   = 1.2,
			Colour  = 29
		},

		Cloakrooms = {
			vector3(452.6, -992.8, 30.6)
		},

		Armories = {
			vector3(451.7, -980.1, 30.6)
		},

		Vehicles = {
			{
				Spawner = vector3(454.6, -1017.4, 28.4),
				InsideShop = vector3(228.5, -993.5, -99.5),
				SpawnPoints = {
					{ coords = vector3(438.4, -1018.3, 27.7), heading = 90.0, radius = 6.0 },
					{ coords = vector3(441.0, -1024.2, 28.3), heading = 90.0, radius = 6.0 },
					{ coords = vector3(453.5, -1022.2, 28.0), heading = 90.0, radius = 6.0 },
					{ coords = vector3(450.9, -1016.5, 28.1), heading = 90.0, radius = 6.0 }
				}
			},

			{
				Spawner = vector3(473.3, -1018.8, 28.0),
				InsideShop = vector3(228.5, -993.5, -99.0),
				SpawnPoints = {
					{ coords = vector3(475.9, -1021.6, 28.0), heading = 276.1, radius = 6.0 },
					{ coords = vector3(484.1, -1023.1, 27.5), heading = 302.5, radius = 6.0 }
				}
			}
		},

		Helicopters = {
			{
				Spawner = vector3(461.1, -981.5, 43.6),
				InsideShop = vector3(477.0, -1106.4, 43.0),
				SpawnPoints = {
					{ coords = vector3(449.5, -981.2, 43.6), heading = 92.6, radius = 10.0 }
				}
			}
		},

		BossActions = {
			vector3(448.4, -973.2, 30.6)
		}

	}

}

Config.AuthorizedWeapons = {
	recruit = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
	},

	patrol = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', price = 0 },
	},

	corporal = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', price = 0 },
	},

	sergeant = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_MINISMG', price = 0 },
	},

	mastergergeant = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_MINISMG', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 3000, 1000, 4000, 5000, nil }, price = 0 },
		
	},

	srmasterseargent = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_MINISMG', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 3000, 1000, 4000, 5000, nil }, price = 0 },
	},

	pems = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
		{ weapon = 'WEAPON_MINISMG', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 3000, 1000, 4000, 5000, nil }, price = 0 },
	},

	plt = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_MINISMG', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 3000, 1000, 4000, 5000, nil }, price = 0 },
	},

	pcpt = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_MINISMG', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 3000, 1000, 4000, 5000, nil }, price = 0 },
		{ weapon = 'WEAPON_BZGAS', price = 0 },
	},

	pmaj = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_MINISMG', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 3000, 1000, 4000, 5000, nil }, price = 0 },
		{ weapon = 'WEAPON_BZGAS', price = 0 },
	},

	plc = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_MINISMG', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 3000, 1000, 4000, 5000, nil }, price = 0 },
		{ weapon = 'WEAPON_BZGAS', price = 0 },
	},

	pol = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
		{ weapon = 'WEAPON_MINISMG', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 3000, 1000, 4000, 5000, nil }, price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_BZGAS', price = 0 },
		{ weapon = 'WEAPON_SNIPERRIFLE', price = 0 },
		{ weapon = 'WEAPON_GRENADE', price = 0 },
		
	},

	pbgen = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_MINISMG', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 3000, 1000, 4000, 5000, nil }, price = 0 },
		{ weapon = 'WEAPON_BZGAS', price = 0 },
		{ weapon = 'WEAPON_SNIPERRIFLE', price = 0 },
		{ weapon = 'WEAPON_GRENADE', price = 0 },
		{ weapon = 'GADGET_PARACHUTE', price = 0 },
		{ weapon = 'WEAPON_RPG', price = 0 },
	},

	pmgen = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
		{ weapon = 'WEAPON_MINISMG', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 3000, 1000, 4000, 5000, nil }, price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_BZGAS', price = 0 },
		{ weapon = 'WEAPON_SNIPERRIFLE', price = 0 },
		{ weapon = 'WEAPON_GRENADE', price = 0 },
		{ weapon = 'GADGET_PARACHUTE', price = 0 },
		{ weapon = 'WEAPON_RPG', price = 0 },
	},

	pltgen = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
		{ weapon = 'WEAPON_MINISMG', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 3000, 1000, 4000, 5000, nil }, price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_BZGAS', price = 0 },
		{ weapon = 'WEAPON_SNIPERRIFLE', price = 0 },
		{ weapon = 'WEAPON_GRENADE', price = 0 },
		{ weapon = 'GADGET_PARACHUTE', price = 0 },
		{ weapon = 'WEAPON_RPG', price = 0 },
	},

	chief = {
		{ weapon = 'WEAPON_APPISTOL', components = { 0, 0, 1000, 4000, nil }, price = 0 },
		{ weapon = 'WEAPON_STUNGUN', price = 0 },
		{ weapon = 'WEAPON_NIGHTSTICK', price = 0 },
		{ weapon = 'WEAPON_FLASHLIGHT', price = 0 },
		{ weapon = 'WEAPON_MINISMG', price = 0 },
		{ weapon = 'WEAPON_ADVANCEDRIFLE', components = { 0, 3000, 1000, 4000, 5000, nil }, price = 0 },
		{ weapon = 'WEAPON_PUMPSHOTGUN', price = 0 },
		{ weapon = 'WEAPON_BZGAS', price = 0 },
		{ weapon = 'WEAPON_SNIPERRIFLE', price = 0 },
		{ weapon = 'WEAPON_GRENADE', price = 0 },
		{ weapon = 'GADGET_PARACHUTE', price = 0 },
		{ weapon = 'WEAPON_RPG', price = 0 },
	},
}

Config.AuthorizedVehicles = {
	Shared = {
	},

	recruit = {
		{ model = 'police3', label = 'Police Interceptor', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
		
	},

	patrol = {
		{ model = 'police3', label = 'Police Interceptor', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
		
	},

	corporal = {
		{ model = 'police3', label = 'Police Interceptor', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
		
	},

	sergeant = {
		{ model = 'police3', label = 'Police Interceptor', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
		
	},

	mastergergeant = {
		{ model = 'police3', label = 'Police Interceptor', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = 'suburban2008', label = 'Unmarked Suburban', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
		
	},

	srmasterseargent = {
		{ model = 'police3', label = 'Police Interceptor', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = 'suburban2008', label = 'Unmarked Suburban', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
		
	},

	pems = {
		{ model = 'police3', label = 'Police Interceptor', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = 'policet', label = 'Police Transporter', price = 1 },
		{ model = 'suburban2008', label = 'Unmarked Suburban', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
		
	},

	plt = {
		{ model = 'police3', label = 'Police Interceptor', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = 'policet', label = 'Police Transporter', price = 1 },
		{ model = 'suburban2008', label = 'Unmarked Suburban', price = 1 },
		{ model = 'escade', label = 'Unmarked Escalade', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
		
	},

	pcpt = {
		{ model = 'police3', label = 'Police Interceptor', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = 'policet', label = 'Police Transporter', price = 1 },
		{ model = 'suburban2008', label = 'Unmarked Suburban', price = 1 },
		{ model = 'escade', label = 'Unmarked Escalade', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
		
	},

	pmaj = {
		{ model = 'police3', label = 'Police Interceptor', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = 'policet', label = 'Police Transporter', price = 1 },
		{ model = 'suburban2008', label = 'Unmarked Suburban', price = 1 },
		{ model = 'escade', label = 'Unmarked Escalade', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
		
	},

	plc = {
		{ model = 'police3', label = 'Police Interceptor', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = 'policet', label = 'Police Transporter', price = 1 },
		{ model = 'suburban2008', label = 'Unmarked Suburban', price = 1 },
		{ model = 'escade', label = 'Unmarked Escalade', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
		
	},

	pol = {
		{ model = 'policet', label = 'Police Transporter', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = 'pol718', label = 'Police Porsche', price = 1 },
		{ model = 'fbi2', label = 'FIB SUV 2', price = 1 },
		{ model = 'pbus', label = 'Police Prison Bus', price = 1 },
		{ model = 'suburban2008', label = 'Unmarked Suburban', price = 1 },
		{ model = 'escade', label = 'Unmarked Escalade', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
		
	},

	pbgen = {
		{ model = 'policet', label = 'Police Transporter', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = 'pol718', label = 'Police Porsche', price = 1 },
		{ model = 'fbi2', label = 'FIB SUV 2', price = 1 },
		{ model = 'pbus', label = 'Police Prison Bus', price = 1 },
		{ model = 'suburban2008', label = 'Unmarked Suburban', price = 1 },
		{ model = 'escade', label = 'Unmarked Escalade', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
		
	},

	pmgen = {
		{ model = 'policet', label = 'Police Transporter', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = 'pol718', label = 'Police Porsche', price = 1 },
		{ model = 'fbi2', label = 'FIB SUV 2', price = 1 },
		{ model = 'pbus', label = 'Police Prison Bus', price = 1 },
		{ model = 'suburban2008', label = 'Unmarked Suburban', price = 1 },
		{ model = 'escade', label = 'Unmarked Escalade', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
		
	},

	pltgen = {
		{ model = 'fbi', label = 'FBI SUV', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = 'policet', label = 'Police Transporter', price = 1 },
		{ model = 'fbi2', label = 'FIB SUV 2', price = 1 },
		{ model = 'pol718', label = 'Police Porsche', price = 1 },
		{ model = 'riot', label = 'Police Riot', price = 1 },
		{ model = 'pbus', label = 'Police Prison Bus', price = 1 },
		{ model = 'polchiron', label = 'Police Chiron', price = 1 },
		{ model = 'suburban2008', label = 'Unmarked Suburban', price = 1 },
		{ model = 'escade', label = 'Unmarked Escalade', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },
		
	},

	chief = {
		{ model = 'fbi', label = 'FBI SUV', price = 1 },
		{ model = 'policet', label = 'Police Transporter', price = 1 },
		{ model = 'police2', label = 'Police Dodge Charger', price = 1 },
		{ model = 'pol718', label = 'Police Porsche', price = 1 },
		{ model = 'fbi2', label = 'FIB SUV 2', price = 1 },
		{ model = 'riot', label = 'Police Riot', price = 1 },
		{ model = 'pbus', label = 'Police Prison Bus', price = 1 },
		{ model = 'polchiron', label = 'Police Chiron', price = 1 },
		{ model = 'suburban2008', label = 'Unmarked Suburban', price = 1 },
		{ model = 'escade', label = 'Unmarked Escalade', price = 1 },
		{ model = '50thpolstang', label = 'Unmarked Mustang', price = 3000000 },

		
	},
}

Config.AuthorizedHelicopters = {

	Shared = {
	},

	recruit = {
	
	},

	patrol = {

	},

	corporal = {

	},

	sergeant = {

	},

	mastergergeant = {

	},

	srmasterseargent = {

	},

	pems = {

	},

	plt = {

	},

	pcpt = {

	},

	pmaj = {

	},

	plc = {

	},

	pol = {
		{ model = 'polmav', label = 'Police Chopper', price = 1000 },
	},

	pbgen = {
		{ model = 'polmav', label = 'Police Chopper', price = 1000 },
	},

	pmgen = {
		{ model = 'polmav', label = 'Police Chopper', price = 1000 },
	},

	pltgen = {
		{ model = 'polmav', label = 'Police Chopper', price = 1000 },
	},

	chief = {
		{ model = 'polmav', label = 'Police Chopper', price = 1000 },
	},
}

-- CHECK SKINCHANGER CLIENT MAIN.LUA for matching elements

Config.Uniforms = {
	recruit_wear = {
		male = {
			['tshirt_1'] = 59,  ['tshirt_2'] = 1,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 41,
			['pants_1'] = 25,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = 46,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 36,  ['tshirt_2'] = 1,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = 45,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	officer_wear = {
		male = {
			['tshirt_1'] = 58,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 41,
			['pants_1'] = 25,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	sergeant_wear = {
		male = {
			['tshirt_1'] = 58,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 8,   ['decals_2'] = 1,
			['arms'] = 41,
			['pants_1'] = 25,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 1,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	intendent_wear = {
		male = {
			['tshirt_1'] = 58,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 8,   ['decals_2'] = 2,
			['arms'] = 41,
			['pants_1'] = 25,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	lieutenant_wear = { -- currently the same as intendent_wear
		male = {
			['tshirt_1'] = 58,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 8,   ['decals_2'] = 2,
			['arms'] = 41,
			['pants_1'] = 25,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	chef_wear = {
		male = {
			['tshirt_1'] = 58,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 8,   ['decals_2'] = 3,
			['arms'] = 41,
			['pants_1'] = 25,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	boss_wear = { -- currently the same as chef_wear
		male = {
			['tshirt_1'] = 58,  ['tshirt_2'] = 0,
			['torso_1'] = 55,   ['torso_2'] = 0,
			['decals_1'] = 8,   ['decals_2'] = 3,
			['arms'] = 41,
			['pants_1'] = 25,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	bullet_wear = {
		male = {
			['bproof_1'] = 11,  ['bproof_2'] = 1
		},
		female = {
			['bproof_1'] = 13,  ['bproof_2'] = 1
		}
	},
	gilet_wear = {
		male = {
			['tshirt_1'] = 59,  ['tshirt_2'] = 1
		},
		female = {
			['tshirt_1'] = 36,  ['tshirt_2'] = 1
		}
	}

}