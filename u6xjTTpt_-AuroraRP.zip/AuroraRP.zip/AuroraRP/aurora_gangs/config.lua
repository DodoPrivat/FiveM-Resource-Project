Config              = {
	Locale = "en"
}

Config.DrawDistance = 50.0
Config.MarkerType = 25
Config.MarkerSize = { x = 1.5, y = 1.5, z = 0.5 }
Config.MarkerColor = { r = 113, g = 204, b = 81 }
Config.ClubBlipPre = "Group Base: " --Prefix to Blip Name on map
Config.PayInterval = 30 * 60000 -- Adjust '28' to set payout time in minutes
Config.EnableClubBankPay = true -- Enables Pay to come out of club's bank instead of thin air
Config.EnableESXIdentity = true -- Shows characer first/lastname instead of Steam name in member menu

Config.ClubBlips = { -- Only shown to club members
	mafia = { -- Must match Database name
		BlipSprite = 226,
		BlipPos = {x= 3343.91, y= 5221.44, z= 13.29},
		BlipColor = 5,
	},
	gaijin = { -- Must match Database name
		BlipSprite = 541,
		BlipPos = {x= -2590.65, y= 1893.55, z= 162.43},
		BlipColor = 1,
	},
	lafuentablanca = { -- Must match Database name
		BlipSprite = 630,
		BlipPos = {x= 1430.2, y= 1118.66, z= 114.64},
		BlipColor = 2,
	},
}

Config.Clubs = {
	mafia = { -- Must match Database name
		Garage = { -- Vehicle Garage
			x = 3332.68, y = 5159.42, z = 18.31, h = 241.45
		},

		Helipad = {
			x = 3331.18, y = 5211.54, z = 26.24, h = 328.72
		},

		Perms = {
			StorageRankMin = 1,
			StorageRankMinPriv = 3
		},

		Vehicles = {
			{ model = 'lp670', label = 'Lamborghini Murciélago', price = 1 },
			{ model = 'laferrari17', label = 'laferrari17', price = 1 },			
		},

		Aircraft = {
			{ model = 'maverick', label = 'Maverick', price = 1},
		},

		Zones = {

			ChangingRoom = {
				Pos   = {x =  -2674.19, y = 1304.89, z = 152.01},
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 20, g = 250, b = 20},
				Marker= 25,
				Blip  = false,
				Name  = _U('lockertitle'),
				Type  = "changingroom",
				Hint  = _U('changing_room'),
			},

			Storage1 = {
				Pos   = {x = -1679.69, y = 1336.26, z = 144.26},
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 150, g = 5, b = 5},
				Marker= 25,
				Blip  = false,
				Name  = _U('storage'),
				Type  = "storagepub", -- Public storage, available to all members
				Hint  = _U('storage_info'),
			},

			Storage2 = {
				Pos   = {x = -2679.37, y = 1336.38, z = 140.88},
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 150, g = 5, b = 5},
				Marker= 25,
				Blip  = false,
				Name  = _U('storage'),
				Type  = "storagepriv", -- Private Storage, requires StorageRankMin
				Hint  = _U('storage_info'),
			},

			--[[
			Teleporter1 = { -- If using an IPL as clubhouse
				Pos   = {x = 1930.01, y = 4635.41, z = 39.47},
				PosDest   = {x = 1120.96, y = -3152.21, z = -38.05},
				PosDestH   = 1.02,
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 0, g = 100, b = 255},
				Marker= 25,
				Blip  = false,
				Name  = _U('lmcteleporter1'),
				Type  = "teleport",
				Hint  = _U('lmcteleporter1_info'),
			},

			Teleporter2 = { -- If using an IPL as clubhouse
				Pos   = {x = 1120.96, y = -3152.21, z = -38.05},
				PosDest   = {x = 1930.01, y = 4635.41, z = 39.47},
				PosDestH   = 357.25,
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 0, g = 100, b = 255},
				Marker= 25,
				Blip  = false,
				Name  = _U('lmcteleporter2'),
				Type  = "teleport",
				Hint  = _U('lmcteleporter2_info'),
			},

			GarageTeleporter1 = { -- If using an IPL as clubhouse
				Pos   = {x = 1927.92, y = 4603.3, z = 38.16},
				PosDest   = {x = 1109.06, y = -3162.71, z = -38.53},
				PosDestH   = 0.3,
				Size  = {x = 1.5, y = 1.5, z = 0.5},
				Color = {r = 0, g = 200, b = 5},
				Marker= 1,
				Blip  = false,
				Name  = _U('lmcgteleporter1'),
				Type  = "gteleport",
				Hint  = _U('lmcgteleporter1_info'),
			},

			GarageTeleporter2 = { -- If using an IPL as clubhouse
				Pos   = {x = 1109.06, y = -3162.71, z = -38.53},
				PosDest   = {x = 1927.92, y = 4603.3, z = 38.16},
				PosDestH   = 199.53,
				Size  = {x = 1.5, y = 1.5, z = 0.5},
				Color = {r = 0, g = 200, b = 5},
				Marker= 1,
				Blip  = false,
				Name  = _U('lmcgteleporter2'),
				Type  = "gteleport",
				Hint  = _U('lmcgteleporter2_info'),
			},
			]]--

			Owner = { -- Owner menu location
				Pos   = {x = 3345.21, y = 5233.5, z = 20.33},
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 113, g = 204, b = 81},
				Marker= 25,
				Blip  = false,
				Name  = _U('lmcmenu'),
				Type  = "owner",
				Hint  = _U('lmcmenu_info'),
			},
		},
	},
	gaijin = { -- Must match Database name
		Garage = { -- Vehicle Garage
			x = -2584.46, y = 1931.0, z = 166.31, h = 255.14
		},

		Perms = {
			StorageRankMin = 1,
			StorageRankMinPriv = 3
		},

		Vehicles = {
			{ model = 'bmci', label = '2018 BMW M5 F90', price = 1 },
			{ model = 'fxxk', label = 'Ferrari FXX K', price = 1 },
			--{model='f824slw', label='BMW Gaijin', price=1}
		},

		Zones = {

			ChangingRoom = {
				Pos   = {x =  -2592.21, y = 1904.87, z = 166.56},
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 20, g = 250, b = 20},
				Marker= 25,
				Blip  = true,
				Name  = _U('lockertitle'),
				Type  = "changingroom",
				Hint  = _U('changing_room'),
			},

			Storage1 = {
				Pos   = {x = -2595.46, y = 1905.83, z = 162.74},
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 150, g = 5, b = 5},
				Marker= 25,
				Blip  = true,
				Name  = _U('storage'),
				Type  = "storagepub", -- Public storage, available to all members
				Hint  = _U('storage_info'),
			},

			Storage2 = {
				Pos   = {x = -2596.79, y = 1913.11, z = 162.74},
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 150, g = 5, b = 5},
				Marker= 25,
				Blip  = true,
				Name  = _U('storage'),
				Type  = "storagepriv", -- Private Storage, requires StorageRankMin
				Hint  = _U('storage_info'),
			},

			
			Teleporter1 = {
				Pos   = {x = -2588.12, y = 1911.41, z = 166.5},
				PosDest   = {x = -2587.59, y = 1909.23, z = 166.52},
				PosDestH   = 170.68,
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 0, g = 100, b = 255},
				Marker= 25,
				Blip  = false,
				Name  = _U('lmcteleporter1'),
				Type  = "teleport",
				Hint  = _U('lmcteleporter1_info'),
			},

			Teleporter2 = { -- If using an IPL as clubhouse
				Pos   = {x = -2587.59, y = 1909.23, z = 166.52},
				PosDest   = {x = -2588.12, y = 1911.41, z = 166.5},
				PosDestH   = 3.96,
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 0, g = 100, b = 255},
				Marker= 25,
				Blip  = false,
				Name  = _U('lmcteleporter2'),
				Type  = "teleport",
				Hint  = _U('lmcteleporter2_info'),
			},

			Teleporter3 = { -- If using an IPL as clubhouse
				Pos   = {x = -2599.77, y = 1907.3, z = 166.54},
				PosDest   = {x = -2601.13, y = 1907.17, z = 166.54},
				PosDestH   = 98.63,
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 0, g = 100, b = 255},
				Marker= 25,
				Blip  = false,
				Name  = _U('lmcteleporter2'),
				Type  = "teleport",
				Hint  = _U('lmcteleporter2_info'),
			},

			Teleporter4 = { -- If using an IPL as clubhouse
				Pos   = {x = -2601.13, y = 1907.17, z = 166.54},
				PosDest   = {x = -2599.77, y = 1907.3, z = 166.54},
				PosDestH   = 282.97,
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 0, g = 100, b = 255},
				Marker= 25,
				Blip  = false,
				Name  = _U('lmcteleporter1'),
				Type  = "teleport",
				Hint  = _U('lmcteleporter1_info'),
			},

			Teleporter5 = { -- If using an IPL as clubhouse
				Pos   = {x = -2599.11, y = 1900.8, z = 162.77},
				PosDest   = {x = -2600.25, y = 1900.51, z = 162.75},
				PosDestH   = 98.63,
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 0, g = 100, b = 255},
				Marker= 25,
				Blip  = false,
				Name  = _U('lmcteleporter2'),
				Type  = "teleport",
				Hint  = _U('lmcteleporter2_info'),
			},

			Teleporter6 = { -- If using an IPL as clubhouse
				Pos   = {x = -2600.25, y = 1900.51, z = 162.75},
				PosDest   = {x = -2599.11, y = 1900.8, z = 162.77},
				PosDestH   = 282.97,
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 0, g = 100, b = 255},
				Marker= 25,
				Blip  = false,
				Name  = _U('lmcteleporter1'),
				Type  = "teleport",
				Hint  = _U('lmcteleporter1_info'),
			},

			Owner = { -- Owner menu location
				Pos   = {x = -2595.03, y = 1881.42, z = 166.52},
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 113, g = 204, b = 81},
				Marker= 25,
				Blip  = true,
				Name  = _U('lmcmenu'),
				Type  = "owner",
				Hint  = _U('lmcmenu_info'),
			},
		},
	},
	lafuentablanca = { -- Must match Database name
		Garage = { -- Vehicle Garage
			x = 1407.16, y = 1117.69, z = 113.84, h = 87.49
		},

		Perms = {
			StorageRankMin = 1,
			StorageRankMinPriv = 3
		},

		Vehicles = {
			{ model = 'dzsb', label = 'Chevrolet Captiva 2013', price = 1 },
			{ model = 'h6', label = 'Hummer H6', price = 1 },
		},

		Zones = {

			ChangingRoom = {
				Pos   = {x =  1399.04, y = 1165.11, z = 113.33},
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 20, g = 250, b = 20},
				Marker= 25,
				Blip  = true,
				Name  = _U('lockertitle'),
				Type  = "changingroom",
				Hint  = _U('changing_room'),
			},

			Storage1 = {
				Pos   = {x = 1391.99, y = 1149.89, z = 113.33},
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 150, g = 5, b = 5},
				Marker= 25,
				Blip  = true,
				Name  = _U('storage'),
				Type  = "storagepub", -- Public storage, available to all members
				Hint  = _U('storage_info'),
			},

			Storage2 = {
				Pos   = {x = 1392.48, y = 1145.25, z = 113.33},
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 150, g = 5, b = 5},
				Marker= 25,
				Blip  = true,
				Name  = _U('storage'),
				Type  = "storagepriv", -- Private Storage, requires StorageRankMin
				Hint  = _U('storage_info'),
			},

			Owner = { -- Owner menu location
				Pos   = {x = 1401.63, y = 1132.37, z = 113.33},
				Size  = {x = 0.7, y = 0.7, z = 0.5},
				Color = {r = 113, g = 204, b = 81},
				Marker= 25,
				Blip  = true,
				Name  = _U('lmcmenu'),
				Type  = "owner",
				Hint  = _U('lmcmenu_info'),
			},
		},
	},
}