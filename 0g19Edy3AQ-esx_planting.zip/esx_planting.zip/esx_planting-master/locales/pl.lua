Locales["pl"] = {
  ["cancel"] = "Anulowano operację.",
  ["vehicle_deny"] = "Niestety, nie możesz znajdować się w pojeździe.",
  ["wait_end"] = "Niestety, musisz poczekać, aż zakończysz poprzednią akcję.",
  ["wrong_place"] = "Niestety, nie możesz wykonać tego w tym miejscu.",
  ["doing_action"] = "Wykonujesz operację. Potrwa ona około 40 sekund.",
  ["how_cancel"] = "Aby anulować operację kliknij <button type='button'>X</button>",
  ["wait_ten_sec"] = 'Poczekaj przynamniej 10 sekund przed ponownym rozpoczęciem tej operacji.',
}
